#ifndef CPPTL_ZEROIZER_H_INCLUDED
# define CPPTL_ZEROIZER_H_INCLUDED

namespace Json {

class Value;	
void zeroValue(Value& value, bool recursive = true);

}; // name space


#endif // include
