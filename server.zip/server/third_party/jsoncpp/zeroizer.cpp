#include "zeroizer.h"
#include "value.h"

namespace Json {

void zeroValue(Value& value, bool recursive)
{
    (void)recursive;
    if(value.isNull()) return;
    else if(value.isBool())
    {
        value = Value(false);
        return;
    }
    else if(value.isInt() || value.isUInt())
    {
        value = Value(0);
        return;
    }
}

}; // name space

