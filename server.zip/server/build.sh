#! /bin/bash
#git pull
#if [ $? -ne 0 ]; then 
#    echo "Git pull ERROR!!!"
#    exit 1
#fi
cd xhs/
./svn_version.sh
cd ..
make clean
make
if [ $? -ne 0 ]; then 
    echo "Build Failed!!!"
    exit 1
fi

echo "Build Successful, and copy all to build_bin/"

#rm -rf build_bin
#mkdir -p build_bin/services/{admin,bin,plugins,etc,idls}
#cp xhs/etc/* build_bin/services/etc/ -vf
#cp xhs/admin/* build_bin/services/admin/ -vf
#cp xhs/xsd/xsd build_bin/services/bin/ -vf
#cp xhs/proxy/proxy build_bin/services/bin/ -vf
#cp xhs/s++/s++ build_bin/services/bin/ -vf
#cp xhs/taskmanager/taskmanager build_bin/services/bin/ -vf
#cp xhs/proxy_statistics/proxy_statistics build_bin/services/bin/ -vf


