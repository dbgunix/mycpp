// ossl_io.h
// vi:set ts=4 sw=4 nowrap:

#ifndef OSSL_IO_H_ALREADY_INCLUDED
#define OSSL_IO_H_ALREADY_INCLUDED

#include <utils/string.h>
#include <utils/xdr.h>

#include <openssl/bio.h>

namespace colib
{

	BIO*	CreateAppendOnlyStringBIO(string *pstr);
	BIO*	CreateWriteOnlyStringBIO(string *pstr);
	BIO*	CreateWriteOnlyXDRBIO(CXDR*);
	BIO*	CreateReadOnlyXDRBIO(CXDR*);

	BIO*	CreateAppendOnlyStringBIO(string& io, string& err);
	BIO*	CreateWriteOnlyStringBIO(string& io, string& err);
	BIO*	CreateWriteOnlyXDRBIO(CXDR* xdr, string& err);
	BIO*	CreateReadOnlyXDRBIO(CXDR* xdr, string& err);

}//end namespace colib


#endif

