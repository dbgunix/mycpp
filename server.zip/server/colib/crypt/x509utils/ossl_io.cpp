// ossl_io.cpp
// vi:set ts=4 sw=4 nowrap:

#include <crypt/x509utils/ossl_io.h>

#include <string.h>

namespace colib
{
	//
	// XDR IO
	//
	static int	XDRBIO_write(BIO* b, const char* buf, int size)
	{
		CXDR* pxdr = reinterpret_cast<CXDR*>(b->ptr);
		if ( !pxdr->XdrBytes((char*)buf, size) )
		{
			return -1;
		}
		return size;
	}
	
	static int	XDRBIO_puts(BIO* b, const char* buf)
	{
		return XDRBIO_write(b, buf, strlen(buf));
	}
	
	static int	XDRBIO_read(BIO* b, char* buf, int size)
	{
		CXDR* pxdr = reinterpret_cast<CXDR*>(b->ptr);
		if ( !pxdr->XdrBytes(buf,size) )
		{
			return -1;
		}
		return size;
	}
	
	long	XDRBIO_ctrl(BIO*, int, long, void*)
	{
		return 1;
	}
	
	int		XDRBIO_new(BIO* b)
	{
		b->init = 1;
		b->num = 0;
		b->ptr = 0;
		return 1;
	}

	int		XDRBIO_free(BIO*)
	{
		return 1;
	}

	BIO_METHOD XDRBIOMethod =
	{
		BIO_TYPE_MEM,
		"iDirectXDRBIO",
		XDRBIO_write,
		XDRBIO_read,
		XDRBIO_puts,
		0,//XDRBIO_gets,
		XDRBIO_ctrl,
		XDRBIO_new,
		XDRBIO_free,
		NULL,
	};

	BIO*	CreateWriteOnlyXDRBIO(CXDR* pxdr)
	{
		if ( pxdr->GetOp() != CXDR::XDR_ENCODE )
			return 0;
		BIO* ret = BIO_new(&XDRBIOMethod);
		if ( ret ) ret->ptr = pxdr;
		return ret;
	}

	BIO*	CreateReadOnlyXDRBIO(CXDR* pxdr)
	{
		if ( pxdr->GetOp() != CXDR::XDR_DECODE )
			return 0;
		BIO* ret = BIO_new(&XDRBIOMethod);
		if ( ret ) ret->ptr = pxdr;
		return ret;
	}

	//
	// String IO
	//
	static int	StringBIO_write(BIO* b, const char* buf, int size)
	{
		string* pstr = reinterpret_cast<string*>(b->ptr);
		*pstr += string(buf, (unsigned int)size);
		return size;
	}
	
	static int	StringBIO_puts(BIO* b, const char* buf)
	{
		string* pstr = reinterpret_cast<string*>(b->ptr);
		*pstr += buf;
		return strlen(buf);
	}

	long	StringBIO_ctrl(BIO*, int, long, void*)
	{
		return 1;
	}
	
	int		StringBIO_new(BIO* b)
	{
		b->init = 1;
		b->num = 0;
		b->ptr = 0;
		return 1;
	}

	int		StringBIO_free(BIO*)
	{
		return 1;
	}

	BIO_METHOD StringBIOMethod =
	{
		BIO_TYPE_MEM,
		"iDirectStringBIO",
		StringBIO_write,
		0,//StringBIO_read,
		StringBIO_puts,
		0,//StringBIO_gets,
		StringBIO_ctrl,
		StringBIO_new,
		StringBIO_free,
		NULL,
	};

	BIO*	CreateWriteOnlyStringBIO(string *pstr)
	{
		pstr->empty();
		BIO* ret = BIO_new(&StringBIOMethod);
		if ( ret ) ret->ptr = pstr;
		return ret;
	}
	
	BIO*	CreateAppendOnlyStringBIO(string *pstr)
	{
		BIO* ret = BIO_new(&StringBIOMethod);
		if ( ret ) ret->ptr = pstr;
		return ret;
	}
	
	BIO*	CreateAppendOnlyStringBIO(string& io, string& err)
	{	
		BIO* bio = CreateAppendOnlyStringBIO(&io);
		if ( !bio ) err = "Failed to create AppendOnly string BIO";
		return bio;	
	}

	BIO*	CreateWriteOnlyStringBIO(string& io, string& err)
	{
		BIO* bio = CreateWriteOnlyStringBIO(&io);
		if ( !bio ) err = "Failed to create WriteOnly string BIO";
		return bio;
	}

	BIO*	CreateWriteOnlyXDRBIO(CXDR* xdr, string& err)
	{	
		BIO* bio = CreateWriteOnlyXDRBIO(xdr);
		if ( !bio ) err = "Failed to create WriteOnly XDR BIO";
		return bio;
	}

	BIO*	CreateReadOnlyXDRBIO(CXDR* xdr, string& err)
	{	
		BIO* bio = CreateReadOnlyXDRBIO(xdr);
		if ( !bio ) err = "Failed to create ReadOnly XDR BIO";
		return bio;	
	}

}//end namespace colib

