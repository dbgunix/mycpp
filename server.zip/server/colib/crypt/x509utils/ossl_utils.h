// ossl_utils.h
// vi:set ts=4 sw=4 nowrap:

#ifndef OSSL_UTILS_H_ALREADY_INCLUDED
#define OSSL_UTILS_H_ALREADY_INCLUDED

#include <crypt/key/key.h>

#include <openssl/bn.h>
#include <openssl/err.h>
#include <openssl/rsa.h>
#include <openssl/x509.h>

namespace colib
{

	bool	apply_publickey_to(RSA* from, EncryptionKey* to);
	bool	apply_privatekey_to(RSA* from, EncryptionKey* to);
	bool	apply_publickey_to(EncryptionKey* from, RSA* to);
	bool	apply_privatekey_to(EncryptionKey* from, RSA* to);

	void	zeroize_rsa_key(RSA* x);
	void	zeroize_x509(X509* x);
	void	zeroize_x509_crl(X509_CRL* x);
	void	zeroize_x509_store(X509_STORE* x);
	void	zeroize_sk_of_x509(STACK_OF(X509)* x);

	void	SET_ERROR_HARVEST(string& str, const char* desc, X509_STORE_CTX *ctx = NULL);

}//end namespace colib
	
#endif

