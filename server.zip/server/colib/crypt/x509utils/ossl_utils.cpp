// ossl_utils.cpp
// vi:set ts=4 sw=4 nowrap:

#include <crypt/x509utils/ossl_utils.h>
#include <utils/system/macros.h>

namespace colib
{
	static int	tabulate_mpi_memreqs(unsigned int count, BIGNUM* bn[])
	{
		int total = 0;
	
		for ( unsigned int at = 0; at < count; ++at )
		{
			if ( !bn[at] ) return -1;
			total += BN_bn2mpi(bn[at], 0);
		}
		return total;
	}
	
	static void	serialize_mpis(unsigned int count, BIGNUM* bn[], unsigned char* dest)
	{
		for ( unsigned int at = 0; at < count; ++at )
		{
			dest += BN_bn2mpi(bn[at], dest);
		}
	}
	
	static bool	probe_mpis(
							unsigned int count, 
							unsigned char* data, 
							unsigned int datalength,
							unsigned char** bndata, 
							unsigned int* bnlen
							)
	{
		if ( !data || datalength < (count*sizeof(unsigned int)) )
			return false;

		for ( unsigned int at = 0; at < count; ++at )
		{
			bnlen[at] = NET_GET32(data) + sizeof(unsigned int);
			bndata[at] = data;
			//
			// Make sure the length is possible
			// 
			if ( bnlen[at] > datalength - ((count-1-at)*sizeof(unsigned int)) )
				return false;
			data += bnlen[at];
			datalength -= bnlen[at];
		}

		return true;
	}

	static bool	apply_mpis(unsigned int count, unsigned char** bndata, unsigned int* bnlen, BIGNUM** bn[])
	{
		for ( unsigned int at = 0; at < count; ++at )
		{
			*bn[at] = BN_mpi2bn(bndata[at], bnlen[at], *bn[at]);
			if ( !*bn[at] ) return false;
		}
		return true;
	}

	bool	apply_publickey_to(RSA* from, EncryptionKey* to)
	{
		BIGNUM* pbn[] = {from->n, from->e};

		int memreq = tabulate_mpi_memreqs(2, pbn);

		if ( !to->Reallocate(memreq) ) return false;
	
		serialize_mpis(2, pbn, to->GetData());

		return true;
	}
		
	bool	apply_publickey_to(EncryptionKey* from, RSA* to)
	{
		unsigned char* data = from->GetData();
		unsigned int length = from->GetLength();
		//
		// extract 2 bignums
		//
		unsigned int bnlen[2];
		unsigned char *bndata[2];

		if ( !probe_mpis(2, data, length, bndata, bnlen) )
		{
			return false;
		}

		BIGNUM** pbn[] = {
						&to->n,
						&to->e 
						};

		return apply_mpis(2, bndata, bnlen, pbn);
	}

	bool	apply_privatekey_to(RSA* from, EncryptionKey* to)
	{
		BIGNUM* pbn[] = {
						from->n,
						from->e,
						from->d,
						from->p,
						from->q,
						from->dmp1,
						from->dmq1,
						from->iqmp 
						};

		int memreq = tabulate_mpi_memreqs(8, pbn);

		if ( !to->Reallocate(memreq) ) return false;
	
		serialize_mpis(8, pbn, to->GetData());

		return true;
	}

	bool	apply_privatekey_to(EncryptionKey* from, RSA* to)
	{
		unsigned char* data = from->GetData();
		unsigned int length = from->GetLength();

		//extract 8 bignums
		unsigned int bnlen[8];
		unsigned char *bndata[8];

		if ( !probe_mpis(8, data, length, bndata, bnlen) )
		{
			return false;
		}

		BIGNUM** pbn[] = {
						&to->n,
						&to->e,
						&to->d,
						&to->p,
						&to->q,
						&to->dmp1,
						&to->dmq1,
						&to->iqmp 
						};

		return apply_mpis(8, bndata, bnlen, pbn);
	}

	//
	// Zeroize
	//
	void		zeroize_asn1_string(ASN1_STRING *x)
	{
		//ASN1_STRING defined in openssl/ans1.h
		if ( x && x->data )
		{
			for ( int i = 0; i < x->length; ++i)
			{
				x->data[i] = 0;
			}
		}
	}

	void		zeroize_x509_name(X509_NAME *x)
	{
		if ( x && X509_NAME_entry_count(x) > 0 )
		{
			X509_NAME_ENTRY* name_entry = X509_NAME_get_entry(x, 0);
			if ( name_entry )
			{
				ASN1_STRING *entry_data = X509_NAME_ENTRY_get_data(name_entry);
			   	zeroize_asn1_string(entry_data);
			}
			x->modified = 1;
		}
	}

	void		zeroize_asn1_time(ASN1_TIME *x)
	{
		if ( x )
		{
			ASN1_TIME_set(x, 0);
		}
	}

	void		BN_set_random(BIGNUM *x)
	{
		if ( x && x->d )
		{
	   		memset(x->d, 0xFF, x->dmax * sizeof(x->d[0]));
		}
	}

	void zeroize_rsa_key(RSA *x)
	{
		if ( x )
		{
			BN_set_random(x->n);
			BN_set_random(x->d);
			BN_set_random(x->e);
			BN_set_random(x->p);
			BN_set_random(x->q);
			BN_set_random(x->dmp1);
			BN_set_random(x->dmq1);
			BN_set_random(x->iqmp);
		}
	}

	void		zeroize_evp_pkey(EVP_PKEY *x)
	{
		if ( x )
		{
			//
			// get RSA key from EVP_PKEY
			//
			RSA* rsa_key = EVP_PKEY_get1_RSA(x);
			if ( rsa_key )
			{
				zeroize_rsa_key(rsa_key);
			}
		}
	}

	void 		zeroize_x509_revoked_stack(STACK_OF(X509_REVOKED) *x)
	{
		if ( x )
		{
			for ( int i = 0; i < sk_X509_REVOKED_num(x); ++i )
			{
				X509_REVOKED* r = sk_X509_REVOKED_value(x, i);
				zeroize_asn1_string(r->serialNumber);
				zeroize_asn1_time(r->revocationDate);
			}
		}
	}

	void		zeroize_x509(X509 *x)
	{
		if ( x )
		{
			// cert info
			if ( x->cert_info )
			{
				zeroize_asn1_string(x->cert_info->version);
				zeroize_asn1_string(x->cert_info->serialNumber);
				zeroize_x509_name(X509_get_issuer_name(x));
				zeroize_x509_name(X509_get_subject_name(x));
				if ( x->cert_info->validity )
				{
					zeroize_asn1_time(x->cert_info->validity->notBefore);
					zeroize_asn1_time(x->cert_info->validity->notAfter);
				}
				EVP_PKEY *pkey = X509_get_pubkey(x);
				zeroize_evp_pkey(pkey);
				X509_set_pubkey(x, pkey);
			}
			zeroize_asn1_string(x->signature);
		}
	}

	void		zeroize_x509_crl(X509_CRL* x)
	{
		if ( x )
		{
			if ( x->crl )
			{
				zeroize_x509_name(x->crl->issuer);
				zeroize_asn1_time(x->crl->lastUpdate);
				zeroize_asn1_time(x->crl->nextUpdate);
				zeroize_x509_revoked_stack(X509_CRL_get_REVOKED(x));
			}
			zeroize_asn1_string(x->signature);
		}
	}
	
	void		zeroize_x509_store(X509_STORE *x)
	{
		if ( x && x->objs )
		{
			STACK_OF(X509_OBJECT) *objs = x->objs;
			for ( int i = 0; i < sk_X509_OBJECT_num(objs); ++i )
			{
				X509_OBJECT* obj = sk_X509_OBJECT_value(objs, i);
				if ( obj->type == X509_LU_X509 )
				{
					zeroize_x509(obj->data.x509);
				}
				else if ( obj->type == X509_LU_CRL )
				{
					zeroize_x509_crl(obj->data.crl);
				}
			}
		}
	}

	void		zeroize_sk_of_x509(STACK_OF(X509) *x)
	{
		if ( x )
		{
			for ( int i = 0; i < sk_X509_num(x); ++i )
			{
				zeroize_x509(sk_X509_value(x, i));
			}
		}
	}

	void		SET_ERROR_HARVEST(string& str, const char* desc, X509_STORE_CTX* ctx)
	{
		str = desc;

		char buf[200];
		unsigned long err;

		while ( 0 != (err = ERR_get_error()) )
		{
			buf[0]='\0';
			ERR_error_string_n(err, buf, sizeof(buf));
			str.AppendFmt(": %s", buf);
		}

		if ( ctx ) 
		{
   			char buf[256];
			X509* err_cert;
	    	int err, depth;
	    	err_cert = X509_STORE_CTX_get_current_cert(ctx);
	    	err = X509_STORE_CTX_get_error(ctx);
			depth = X509_STORE_CTX_get_error_depth(ctx);
			buf[0] = 0;
    		X509_NAME_oneline(X509_get_subject_name(err_cert), buf, sizeof(buf)-1);
	    	str.AppendFmt("\nsubject name: [%s], depth = %d\n", buf, depth);
			if ( X509_verify_cert_error_string(err) ) 
			{
				str.AppendFmt("verify_cert_error: %s\n", X509_verify_cert_error_string(err));		
			}
		}	
	}


}//end namespace colib

