/* -*- tab-width:4; c-basic-offset: 4 -*- */
// packet_classifier.cpp
// // vi:set ts=4 sw=4 nowrap:
// //

#include <utils/system/machine.h>
#include <crypt/sha/sha.h>
#include <crypt/key/pbkdf2.h>
#include <utils/dump_hex.h>
#include <utils/base_encoder.h>
#include <crypt/key/aes_key.h>
#include <crypt/key/passwd_to_aes_key.h>

namespace colib
{
	void Sha512Checksum(const unsigned char* pData, int dataLen,
						unsigned char*  checkSum, int chksumLen)
	{
    	unsigned char tmp_buffer[SHA512_DIGEST_LENGTH] = {0};
    	iDirect_sha512(pData, dataLen, tmp_buffer);
    	memcpy(checkSum, tmp_buffer, (chksumLen < (int)sizeof(tmp_buffer)) ? chksumLen: sizeof(tmp_buffer));
	}

	bool VerifyCheckSum(const unsigned char* pBinaryData, int dataLen, int chkSumLen)
	{
		if (dataLen < chkSumLen || chkSumLen > SHA512_DIGEST_LENGTH) return false;

		unsigned char chkSum[SHA512_DIGEST_LENGTH];
		Sha512Checksum(pBinaryData, dataLen - chkSumLen, chkSum, chkSumLen);
		return (memcmp(chkSum, pBinaryData + dataLen - chkSumLen, chkSumLen) == 0);
	}

	Passwd2AESKey::SegmentedKeyBuf::SegmentedKeyBuf()
		: m_key_buf_seg()
		, m_key_buf_seg_len()
		, m_passphrase()
		, m_salt()
		, m_salt_len(0)
		, m_key_dump_format(KEY_DUMP_BASE_64)
		, m_key_index(0xFF)
		, m_key_buf()
		, m_key_len(0)
		, m_id(0)
		, m_next_idx(0)
		, m_state(INIT)
	{
		for(unsigned int idx = 0; idx < NUM_SEGMENTS; ++ idx) {
			m_key_buf_seg_len[idx] = 0;
		}
	}

	void Passwd2AESKey::SegmentedKeyBuf::Reset()
	{
		for(unsigned int idx = 0; idx < NUM_SEGMENTS; ++ idx) {
			m_key_buf_seg_len[idx] = 0;
		}
		m_salt_len = 0;
		m_next_idx = 0;
		m_key_len = 0;
		m_key_index = 0xFF;
		m_id = 0;
		m_passphrase.empty();

		ResetState();
	}

	bool Passwd2AESKey::SegmentedKeyBuf::RetrieveKeyDumpFormat(const unsigned char* seg,
															   KeyDumpFormat& dumpFmt,
															   unsigned char& flags3bits)
	{

		if (seg) {
			return DecodeByte(dumpFmt, flags3bits, seg[0]);
		}
		return false;
	}

	bool Passwd2AESKey::SegmentedKeyBuf::SetKeySegment(int idx,
												   const unsigned char* seg,
												   colib::string& errStr)
	{
		if (idx < 0 || idx > static_cast<int>(NUM_SEGMENTS)) {
			errStr = "invalid segment id";
			return false;
		}
		if (!seg) {
			errStr = "empty segment";
			return false;
		}
		int seglen = strlen((const char*)seg);

		if (seglen > (int)MAX_SEGMENT_SIZE || seglen < 1) {
			errStr = string::Format("segment %d is too large or too short (len = %d)",
						idx + 1, seglen);
			return false;
		}

		const unsigned char* pos = seg;
		if (idx == 0) {
			if (!RetrieveKeyDumpFormat(seg, m_key_dump_format, m_key_index)) {
				errStr = string::Format("Segment %d: Invalid encoding format", idx + 1);
				return false;
			}
			pos ++; // skip the format byte
			seglen --;
		}

		int len = ToBinary(pos, seglen, m_key_buf_seg[idx], SAESeKey::AES_KEY_BYTES,
						   m_key_dump_format, errStr);
		if (len <= 2) {
			return false;
		}

		if (idx == 0) {
			unsigned char tmp[sizeof(m_key_buf_seg[idx]) + 1];
			tmp[0] = seg[0];
			memcpy(tmp + 1, m_key_buf_seg[idx], len);
			if (!VerifyCheckSum(tmp, len + 1, 2)) {
				errStr = colib::string::Format("Failed to verify checksum for segment %d\n", idx + 1);
				return false;
			}
		} else {
			if (!VerifyCheckSum(m_key_buf_seg[idx], len, 2)) {
				errStr = colib::string::Format("Failed to verify checksum for segment %d\n", idx + 1);
				return false;
			}
		}

		m_key_buf_seg_len[idx] = len - 2; // remove the trailing checksum

		return true;
	}

	Passwd2AESKey::SegmentedKeyBuf::ErrorCode
	Passwd2AESKey::SegmentedKeyBuf::ProcessLastSegment(colib::string& errStr)
	{
		if (!RecvdAllData()) {
			errStr = "have not got all the segments or passphrase yet";
			return ERROR_INCOMPLETE;
		}
		// verify checksum for "ACC key|| salt"
		unsigned char* pos = m_key_buf;

		memcpy(pos, m_key_buf_seg[0], m_key_buf_seg_len[0]);
		pos += m_key_buf_seg_len[0];

		memcpy(pos, m_key_buf_seg[1], m_key_buf_seg_len[1]);
		pos += m_key_buf_seg_len[1];

		memcpy(pos, m_key_buf_seg[2], m_key_buf_seg_len[2]);
		pos += (SALT_LEN_BYTES + SALT_OFFSET_IN_LAST_SEGMENT);

		if (!VerifyCheckSum(m_key_buf, SAESeKey::AES_KEY_BYTES + SALT_LEN_BYTES + 2, 2)) {
			errStr = "Failed to verify checksum for the third segment(encrypted key and salt)";
			return ERROR_CHECKSUM;
		}

		// get salt
		if (!RetrieveSalt()) {
			errStr = "Failed to retrieve salt";
			return ERROR_SALT;
		}

		if (m_passphrase.is_empty()) {
			errStr = "have not got the passphrase yet";
			return ERROR_PASSPHRASE;
		}

		// verify the checksum of ACC Key || Salt || passphrase || id
		unsigned char secondShecksum[2];
		memcpy(secondShecksum, pos + 2, 2);
		memcpy(pos, m_passphrase.c_str(), m_passphrase.get_length());
		pos += m_passphrase.get_length();
		unsigned int flipId = FLIP(m_id);
		memcpy(pos, &flipId, sizeof(unsigned int));
		pos += sizeof(unsigned int);
		memcpy(pos, secondShecksum, sizeof(secondShecksum));

		if (!VerifyCheckSum(m_key_buf,
					SAESeKey::AES_KEY_BYTES + SALT_LEN_BYTES + m_passphrase.get_length() + sizeof(unsigned int) + 2, 2)) {
			 errStr = "invalid passphrase or remote DID";
			 return ERROR_PASSPHRASE;
		}
		m_key_buf_seg_len[2] = SALT_OFFSET_IN_LAST_SEGMENT;
		m_key_len = SAESeKey::AES_KEY_BYTES;
		return NO_ERROR;
	}

	bool Passwd2AESKey::SegmentedKeyBuf::RetrieveSalt()
	{
		if (m_key_buf_seg_len[2] < (int)(SALT_OFFSET_IN_LAST_SEGMENT + SALT_LEN_BYTES)) {
			return false;
		}
		memcpy(m_salt, m_key_buf_seg[2] + SALT_OFFSET_IN_LAST_SEGMENT, SALT_LEN_BYTES);
		m_salt_len = SALT_LEN_BYTES;
		return true;
	}

	bool Passwd2AESKey::SegmentedKeyBuf::RetrieveKey(unsigned char* buf, int len,
							unsigned int DID, colib::string& errStr)
	{
		if (!IsComplete()) {
			errStr = "Haven't got all the data";
			return false;
		}

		memcpy(buf, m_key_buf, len);

		return (RetrieveAesKey(buf, len, DID,
						  m_salt, m_salt_len,
                          m_passphrase, errStr)
						== SAESeKey::AES_KEY_BYTES);
	}

	bool Passwd2AESKey::SegmentedKeyBuf::RecvdAllData() const
	{
		for (int idx = 0; idx < (int)NUM_SEGMENTS; ++ idx) {
			if (!m_key_buf_seg_len[idx]) {
				return false;
			}
		}
		return !m_passphrase.is_empty();
	}

	bool Passwd2AESKey::SegmentedKeyBuf::IsComplete() const
	{
		return RecvdAllData()
				&& (m_salt_len == (int)SALT_LEN_BYTES)
				&& IsKeyIndexValid();
	}

	Passwd2AESKey::SegmentedKeyBuf::SegmentedKeyBufState
				Passwd2AESKey::SegmentedKeyBuf::ToNextState()
	{
		m_state = (SegmentedKeyBufState) ((m_state + 1) % NUM_STATE);

		return m_state;
	}

	colib::string Passwd2AESKey::SegmentedKeyBuf::GetPrompt() const
	{
		switch(GetState())
		{
			case INIT:
				return "";
			case WAIT_PASSPHRASE:
				return "Please type passphrase:";
			case WAIT_SEGMENT_1:
				return "Please type the first segment:";
			case WAIT_SEGMENT_2:
				return "Please type the second segment:";
			case WAIT_SEGMENT_3:
				return "Please type the third segment:";
			case WAIT_CONFIRM:
				return "Network Acquisition Key will be overwritten \n"
					   "and the remote may not be able to acquired \n"
					   "into network if this key is not valid. Continue ? [Yes/No]:";
			case COMPLETE:
				return "Network Acquisition Key has been updated";
			case NUM_STATE:
				return "Invalid State";
		}
		return "should not reach here";
	}

	Passwd2AESKey::SegmentedKeyBuf::SegmentedKeyBufState
		Passwd2AESKey::SegmentedKeyBuf::ProcessSetKeyCommand(unsigned int devID,
							const char *argv, colib::string& retStr)
	{
		if ((argv && argv[0]) || GetState() == COMPLETE || GetState() == INIT)
		{
			if (!strcmp(argv, "Q")) {
        		Reset();
				return GetState();
			} else if (!strcmp(argv, "reset")) {
				Reset();
				retStr = "start over!";
				SetState(WAIT_SEGMENT_1);
			} else {
				SetId(devID);
				ErrorCode ret_err = NO_ERROR;
				switch(GetState())
				{
					case INIT:
						ToNextState();
						break;
		  			case WAIT_SEGMENT_1:
					case WAIT_SEGMENT_2:
					case WAIT_SEGMENT_3:
						if (SetKeySegment((const unsigned char*)argv, retStr)) {
            				ToNextState();
						}
						break;
					case WAIT_PASSPHRASE:
						SetPassphrase(argv);
						ret_err = ProcessLastSegment(retStr);
						if (ret_err == NO_ERROR) {
							ToNextState();
						}
						break;
					case WAIT_CONFIRM:
						if (!strcmp(argv, "Yes")) {
							ToNextState();
						} else if (!strcmp(argv, "No")) {
							Reset();
						}
						break;
					case COMPLETE:
					case NUM_STATE:
						Reset();
						break;
				}
			}
		}
		if (retStr.is_empty()){
			retStr = GetPrompt();
		} else {
			retStr = string::Format("%s\n%s", retStr.c_str(), GetPrompt().c_str());
		}
		return GetState();
	}

	bool Passwd2AESKey::GenerateAesKey(unsigned int DID, const colib::string passphrase,
						SAESeKey& aes_key, const unsigned char* salt, unsigned int saltLen,
                    	colib::string& errorStr, unsigned int iter)
	{
		if (passphrase.get_length() >= MAX_PASSWORD_LEN)
		{
			// should never happen but good to double check
			errorStr = "passphrase is too long \n";
			return false;
		}
    	unsigned char passBytes[MAX_PASSWORD_LEN + sizeof(DID) + 2];

    	memset(passBytes, 0, sizeof(passBytes));

    	unsigned char *pos = passBytes;
		unsigned int flipDID = FLIP(DID);
    	memcpy(pos, (void*)&flipDID, sizeof(flipDID));
    	pos += sizeof(flipDID);

    	int passLen = passphrase.get_length() + sizeof(flipDID);
    	if (passLen >= (int)sizeof(passBytes)) {
			errorStr = "passphrase is too long";
        	return false;
    	}

    	memcpy(pos, passphrase.c_str(), passphrase.get_length());

    	unsigned char dKey[SAESeKey::AES_KEY_BYTES];


    	iDirect_PKCS5_PBKDF2_HMAC_SHA512((const char*)passBytes, passLen, salt, saltLen, iter,
                               		SAESeKey::AES_KEY_BYTES, dKey);

    	if  (!aes_key.Reallocate(SAESeKey::AES_KEY_BYTES)
            	|| !aes_key.SetData(SAESeKey::AES_KEY_BYTES, dKey)) {
			errorStr = "cannot generate AES key from passphrase";
        	return false;
    	}
    	return true;
	}

	colib::string Passwd2AESKey::FormatDumpStr(const unsigned char* pData, int dataLen,
								  colib::string& errorStr, KeyDumpFormat dumpFmt)
	{
		bool padding = false;
		char output[MAX_ENCODE_LEN + 8];
		memset(output, 0, sizeof(output));

		switch (dumpFmt) {
			case KEY_DUMP_BASE_64:
			{
				int len64 = BaseEncoder::GetBase64Len(dataLen, padding); //no padding '='

				if (len64 >= (int)sizeof(output)) {
					errorStr = "too large string";
					return "";
				}
				if((len64 = BaseEncoder::Encode64(output, sizeof(output), pData, dataLen, padding)) > 0) {
					return colib::string(output, (unsigned)len64);
				} else {
					errorStr = "failed to encode to base 64";
					return colib::string("");
				}
				break;
			}
			case KEY_DUMP_BASE_32:
			{
				int len32 = BaseEncoder::GetBase32Len(dataLen, padding); //no padding '='
				if (len32 >= (int)sizeof(output)) {
					errorStr = "too large string";
					return "";
				}
				if((len32 = BaseEncoder::Encode32(output, sizeof(output), pData, dataLen, padding) > 0)) {
					return colib::string(output, (unsigned)len32);
				} else {
					errorStr = "failed to encode to base 32";
					return colib::string("");
				}
				break;
			}
			case KEY_DUMP_BASE_16:
			{
				int len16 = BaseEncoder::GetBase16Len(dataLen);

				if (len16 >= (int)sizeof(output)) {
					errorStr = "too large string";
					return "";
				}
				if ((len16 = BaseEncoder::Encode16(output, sizeof(output), pData, dataLen) > 0)) {
					return colib::string(output, (unsigned)len16);
				} else {
					errorStr = "failed to encode to base 16";
					return colib::string("");
				}
			}
			default:
				errorStr = "unrecognized format";
				return colib::string("");
		}
	}

	bool Passwd2AESKey::EncodeByte(KeyDumpFormat dumpFmt,
								 unsigned char flags3bits,
								 char& byte)
	{
		// 5 bits are used as header: 0-2 for key index (only 2 bits are currently used)
		// and 3-4 for encoding format (only support  3 format, base64, base32, hex)
		if (dumpFmt > 0x3 || flags3bits > 0x7) {
			return false;
		}
		// pading will be appended to the right side. So we need to shift 5 bits to the
		// leftmost
		unsigned char tmpBin = (((dumpFmt << 3) | flags3bits) << 3);
		char tmpB32[8];
		if (BaseEncoder::Encode32(tmpB32, sizeof(tmpB32),&tmpBin, 1, false) <= 0) {
			return false;
		}
		// byte tmpB32[1] is padding
		byte = (unsigned char)tmpB32[0];
		return  true;
	}

	bool Passwd2AESKey::DecodeByte(KeyDumpFormat& dumpFmt,
								   unsigned char& flags3bits,
								   char byte)
	{
		unsigned char tmpBin = 0;

		char tmpB32[3] = {0, 0, 0};

		// Because the padding was not included in the received string,
		// we need to add it back before decoding
		BaseEncoder::Encode32(tmpB32, sizeof(tmpB32), &tmpBin, 1); // get the 0 padding character
		tmpB32[0] = byte;

		// tmpB32[1] is the base encode for 0
		if (!BaseEncoder::Decode32(&tmpBin, 1, tmpB32, 2)) {
			return false;
		}

		// shift the 5 information bits to the right to revert
		// the left shift when encode the byte
		tmpBin = (tmpBin >> 3);

		if ((tmpBin >> 3) < KEY_DUMP_FMT_COUNT) {
			dumpFmt = (KeyDumpFormat) (tmpBin >> 3);
		} else {
			return false;
		}
		flags3bits = (tmpBin & 0x7);
		return true;
	}

	int Passwd2AESKey::ToBinary(const unsigned char* hdata, int len,
								unsigned char* pBinBuf, int binBufSize,
								KeyDumpFormat dumpFmt, colib::string& errorStr)
	{
		switch(dumpFmt) {
			case KEY_DUMP_BASE_64:
			{
				int dlen = BaseEncoder::Decode64(pBinBuf, binBufSize, (const char*)hdata, len);
				if (dlen > 0) {
					return dlen;
				} else {
					errorStr = "failed to convert base64 to binary";
					return 0;
				}
			}
			case KEY_DUMP_BASE_32:
			{
				int dlen = BaseEncoder::Decode32(pBinBuf, binBufSize, (const char*)hdata, len);
				if (dlen > 0) {
					return dlen;
				} else {
					errorStr = "failed to convert base32 to binary";
					return 0;
				}
			}
			case KEY_DUMP_BASE_16:
			{
				int dlen = BaseEncoder::Decode16(pBinBuf, binBufSize, (const char*)hdata, len);
				if (dlen > 0) {
					return dlen;
				} else {
					errorStr = "failed to convert base16 to binary";
					return 0;
				}
			}
			default:
				return 0;
		}

	}

	bool Passwd2AESKey::DumpToString(const unsigned char* aes_key, unsigned char flags3bits,
						  			 unsigned int id, const unsigned char* salt, int saltLen,
									 const colib::string& passwd,
                          			 colib::string& out1,
                          			 colib::string& out2,
                          			 colib::string& out3,
									 colib::string& errorStr,
                          			 KeyDumpFormat dumpFmt) {

		if (saltLen > (int)SALT_LEN_BYTES) {
			return false;
		}
		unsigned char tmpBuf[SAESeKey::AES_KEY_BYTES + MAX_PASSWORD_LEN + SALT_LEN_BYTES + sizeof(unsigned int) + 2];

		// Step 1: compute the sha512 checksum for first 14 bytes of encrypted ACC key

		// append the header
		char header;
		if (!EncodeByte(dumpFmt, flags3bits, header)) {
			return  false;
		}
		tmpBuf[0] = header;

        const unsigned char* pos = aes_key;
        memcpy(tmpBuf + 1, pos, 14);
        Sha512Checksum(tmpBuf, 15, tmpBuf + 15, 2);
        pos += 14;
		out1 = FormatDumpStr(tmpBuf + 1, 14 + 2, errorStr, dumpFmt);

		out1 = string::Format("%c%s", (char)header, out1.c_str());

		// Step 2: compute the sha512 checksum for the second 14 bytes of encrypted ACC key
        memcpy(tmpBuf, pos, 15);
        pos += 15;
        Sha512Checksum(tmpBuf, 15, tmpBuf + 15, 2);

        out2 = FormatDumpStr(tmpBuf, 15 + 2, errorStr, dumpFmt);

		// Step 3: last piece
		unsigned char chkSum1[2], chkSum2[2];

		// checksum for encrypted ACC key || salt
        pos = aes_key;
        memcpy(tmpBuf, aes_key, SAESeKey::AES_KEY_BYTES);
        pos += SAESeKey::AES_KEY_BYTES;
        memcpy(tmpBuf + SAESeKey::AES_KEY_BYTES, (const void*)salt, saltLen);

		Sha512Checksum(tmpBuf, SAESeKey::AES_KEY_BYTES + saltLen, chkSum1, sizeof(chkSum1));

		// checksum for encrypted ACC key || salt || passphrase || DID
        memcpy(tmpBuf + SAESeKey::AES_KEY_BYTES + saltLen, passwd.c_str(), passwd.get_length());

		unsigned int flipID = FLIP(id);
		memcpy(tmpBuf + SAESeKey::AES_KEY_BYTES + saltLen + passwd.get_length(), &flipID, sizeof(unsigned int));

        Sha512Checksum(tmpBuf,
					   SAESeKey::AES_KEY_BYTES + saltLen + passwd.get_length() + sizeof(unsigned int),
					   chkSum2, sizeof(chkSum2));

		unsigned char last[SAESeKey::AES_KEY_BYTES + MAX_PASSWORD_LEN + SALT_LEN_BYTES + 1];
		unsigned char* lastPos = last;
		memcpy(lastPos, aes_key + 14 + 15, 3); // last 3 byte acc key
		lastPos += 3;

        memcpy(lastPos, (const void*)salt, saltLen);
        lastPos += saltLen;

		memcpy(lastPos, chkSum1, sizeof(chkSum1));
		lastPos += sizeof(chkSum1);

		memcpy(lastPos, chkSum2, sizeof(chkSum2));
		lastPos += sizeof(chkSum2);

		Sha512Checksum(last, 3 + saltLen + sizeof(chkSum1) + sizeof(chkSum2), lastPos, 2);

		int lastLen = 3 + saltLen + sizeof(chkSum1) + sizeof(chkSum2) + 2;

		out3 = FormatDumpStr(last, lastLen, errorStr, dumpFmt);

		return true;
	}

	bool Passwd2AESKey::VerifySegment(const char* segment,
					   				 KeyDumpFormat dumpFmt, colib::string errorStr)
	{
		if (!segment) return false;

		unsigned char tmpBuf[SAESeKey::AES_KEY_BYTES + 2];

		int binLen = ToBinary(segment, strlen(segment),
							  tmpBuf, sizeof(tmpBuf), dumpFmt, errorStr);

		if (binLen < 2) return false;

		if (VerifyCheckSum(tmpBuf, binLen, 2)) {
			return true;
		} else {
			errorStr = "checksum failed for the segment";
			return false;
		}
	}

	int Passwd2AESKey::RetrieveAesKey(unsigned char* aeskeyBuf, int keyBufSize,
									  unsigned int DID, unsigned char* salt, int saltLen,
									  const colib::string& passphrase,
									  colib::string& errorStr)
	{
		if (keyBufSize != SAESeKey::AES_KEY_BYTES) {
			return 0;
		}

		SAESeKey aes_key;
		if (!Passwd2AESKey::GenerateAesKey(DID, passphrase, aes_key,
										   salt, saltLen, errorStr)) {
			return 0;
		}

		for( int i = 0; i < SAESeKey::AES_KEY_BYTES; i += 16 )
		{
			AES_ecb_encrypt(
					(const unsigned char*)aeskeyBuf + i, //input buffer
					(unsigned char*)aeskeyBuf + i, //output buffer
					&aes_key.m_dec_ctx, //key
					0 //decrypt
					);
		}

		return SAESeKey::AES_KEY_BYTES;
	}

}; // end of name space

