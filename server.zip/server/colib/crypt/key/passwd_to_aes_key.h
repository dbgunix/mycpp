//passwd_to_aes_key.h

#ifndef passwd_to_aes_key_h_already_included
#define passwd_to_aes_key_h_already_included

#include <utils/string.h>
#include <crypt/key/aes_key.h>

namespace colib {

	class Passwd2AESKey {
	public:

		static const int DEFAULT_ITERATION_COUNT = 1000;
		static const unsigned int MAX_PASSWORD_LEN = 128;
		static const unsigned int SALT_LEN_BYTES = 8; //
		static const unsigned int MAX_ENCODE_LEN = 256; //
		static const unsigned int NUM_SEGMENTS = 3; //
		static const unsigned int MAX_ENCODE_SEGMENT_LEN = (MAX_ENCODE_LEN / NUM_SEGMENTS); //
		static const unsigned int NUM_CHECKSUM_BYTES = (1 + 1 + 3) * 2;
		static const unsigned int MAX_SEGMENT_SIZE = (SALT_LEN_BYTES + NUM_CHECKSUM_BYTES
                                                            + 1 + SAESeKey::AES_KEY_BYTES);

		static const int SALT_OFFSET_IN_LAST_SEGMENT = 3;

		enum KeyDumpFormat {
			KEY_DUMP_BASE_64 = 0,
			KEY_DUMP_BASE_32 = 1,
			KEY_DUMP_BASE_16 = 2,
			KEY_DUMP_BASE_10 = 3, // not supported
			KEY_DUMP_FMT_COUNT
		};

		class SegmentedKeyBuf {
		public:

			enum SegmentedKeyBufState {
				INIT = 0,
				WAIT_SEGMENT_1,
				WAIT_SEGMENT_2,
				WAIT_SEGMENT_3,
				WAIT_PASSPHRASE,
				WAIT_CONFIRM,
				COMPLETE,
				NUM_STATE
			};

			enum ErrorCode {
				NO_ERROR = 0,
				ERROR_INCOMPLETE,
				ERROR_CHECKSUM,
				ERROR_SALT,
				ERROR_PASSPHRASE,
				ERROR_COUNT
			};

			void ResetState() { m_state = INIT; }
			bool IsInInitState() const { return (m_state == INIT); }
			void SetState(SegmentedKeyBufState toState) { m_state = toState; }
			SegmentedKeyBufState GetState() const { return m_state; };
			SegmentedKeyBufState ToNextState();
			SegmentedKeyBufState ProcessSetKeyCommand(unsigned int devID, const char *argv,
                                      colib::string& retStr);

			colib::string GetPrompt() const;

			void Reset();
			SegmentedKeyBuf();
			bool SetKeySegment(int idx, const unsigned char* seg, colib::string& errStr);
			bool SetKeySegment(const unsigned char* seg, colib::string& errStr) {
				if (SetKeySegment(m_next_idx, seg, errStr)) {
					m_next_idx ++;
					return true;
				}
				return false;
			}

			int GetNextEmptySegmentIdx() const { return m_next_idx; }

			bool RetrieveKey(unsigned char* buf, int len, unsigned int DID, colib::string& errStr);

			bool IsComplete() const;
			bool RecvdAllData() const;

			const unsigned char*  GetKeyBuf(int& len) const { len = m_key_len; return m_key_buf;}

			int GetKeyIndex() const { return m_key_index; }

			bool IsKeyIndexValid() const { return m_key_index != 0xFF; }
			static bool RetrieveKeyDumpFormat(const unsigned char* seg,
											  KeyDumpFormat& dumpFmt,
											  unsigned char& flags3bits);

			void SetPassphrase(colib::string pass) { m_passphrase = pass; }

			void SetId(unsigned int id) { m_id = id; }
			unsigned int GetId() const { return m_id; }
			bool IsIdValid() const { return m_id != 0; }
		private:

			ErrorCode ProcessLastSegment(colib::string& errStr);
			bool RetrieveSalt();

		private:

			unsigned char   m_key_buf_seg[NUM_SEGMENTS][SAESeKey::AES_KEY_BYTES];
			int             m_key_buf_seg_len[NUM_SEGMENTS];

			colib::string m_passphrase;
			unsigned char   m_salt[SALT_LEN_BYTES];
			int             m_salt_len;
			KeyDumpFormat   m_key_dump_format;
			unsigned char   m_key_index;
			unsigned char   m_key_buf[MAX_ENCODE_LEN];
			int             m_key_len;
			unsigned int    m_id;
			int             m_next_idx;

			SegmentedKeyBufState m_state;
		};

		static bool GenerateAesKey(unsigned int DID, const colib::string passphrase,
						    SAESeKey& aes_key, const unsigned char* salt, unsigned int saltLen,
							colib::string& errorStr,
                            unsigned int iter = DEFAULT_ITERATION_COUNT);

		static bool DumpToString(const unsigned char* aes_key, unsigned char flags3bits,
							unsigned int id, const unsigned char* salt, int saltlen,
							const colib::string& passwd,
							colib::string& out1,
							colib::string& out2,
							colib::string& out3,
							colib::string& errorStr,
							KeyDumpFormat dumpFmt = KEY_DUMP_BASE_64);

		bool VerifySegment(const char* segment,
						   KeyDumpFormat dumpFmt, colib::string errorStr);


		static int RetrieveAesKey(unsigned char* aeskeyBuf, int keyBufSize,
							     unsigned int DID, unsigned char* salt, int saltLen,
								 const colib::string& passphase,
								 colib::string& errorStr);

		private:

		static colib::string FormatDumpStr(const unsigned char* pData, int dataLen,
										colib::string& errorStr,
										KeyDumpFormat dumpFmt);


		static int ToBinary(const unsigned char* hdata, int len,
					 unsigned char* pBinBuf, int binBufSize,
					 KeyDumpFormat dumpFmt,
					 colib::string& errorStr);

		static int ToBinary( const char* hdata, int len,
					 unsigned char* pBinBuf, int binBufSize,
					 KeyDumpFormat dumpFmt,
					 colib::string& errorStr) {

			return ToBinary((const unsigned char*) hdata, len, pBinBuf, binBufSize, dumpFmt, errorStr);
		}

		static bool EncodeByte(KeyDumpFormat dumpFmt, unsigned char flags3bits, char& byte);
		static bool DecodeByte(KeyDumpFormat& dumpFmt, unsigned char& flags3bits, char byte);
	};

} // end of namespace


#endif
