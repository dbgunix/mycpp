//key.h
// vi:set ts=4 sw=4 nowrap:
//

#ifndef key_h_already_included
#define key_h_already_included

#include <string.h>


#include <utils/data_struct/dlist.h>
#include <utils/string.h>
#include <utils/xdr.h>
#include <utils/trace/writable.h>

namespace colib {


class EncryptionKey
{
public:

	const static uint32_t KEY_TYPE_BASE		= 0;
	const static uint32_t KEY_TYPE_OSSL_AES	= 8; //SAESeKey

	EncryptionKey();
	EncryptionKey(const EncryptionKey& from);
	EncryptionKey(uint8_t* data, uint32_t len);

	virtual ~EncryptionKey();

	virtual uint32_t GetType() const {return KEY_TYPE_BASE;}

	virtual bool Reallocate( uint32_t key_sz );
	virtual bool XdrProc(CXDR*);

	virtual bool operator==(const EncryptionKey &other);

	virtual bool Copy ( const EncryptionKey &from );
	virtual bool Zeroize();

	bool Split( uint32_t length, Dlist<EncryptionKey> &into ) const;
	bool Join( uint32_t length, Dlist<EncryptionKey> &from );

	void Dump( Writable *to ) const;

	uint32_t GetLength() const {return m_length;}
	virtual bool SetData(uint32_t length, const uint8_t* data);
	virtual uint8_t* GetData() const {return m_data;}

	virtual bool GenerateRandomKey();

protected:
	uint32_t m_length; //length in bytes
	uint8_t* m_data;

private:
	void operator=(const EncryptionKey &to);
};


} // end of namespace

#endif

