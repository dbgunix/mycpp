//aes_key.h

#ifndef AES_KEY_H
#define AES_KEY_H

#include <openssl/aes.h>
#include <utils/xdr.h>
#include <crypt/key/key.h>

namespace colib {

class SAESeKey : public EncryptionKey
{
public:

	virtual ~SAESeKey();

	static const int AES_KEY_BITS = 256;
	static const int AES_KEY_BYTES = 32;

	uint32_t GetType() const {return KEY_TYPE_OSSL_AES;}

	//virtual bool reset( unsigned int key_sz );
	bool SetData(uint32_t length, const uint8_t *data );
	bool XdrProc(CXDR*);
	bool Copy(const EncryptionKey &to );
	bool Zeroize();

	bool GenerateRandomKey();

	AES_KEY m_enc_ctx;
	AES_KEY m_dec_ctx;

private:

	bool gen_sched();
	
};

} // end of namespace
#endif

