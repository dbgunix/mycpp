//pbkdf2.h
// vi:set ts=4 sw=4 nowrap:

#ifndef PBKDF_H_ALREADY_INCLUDED
#define PBKDF_H_ALREADY_INCLUDED

namespace colib {

void iDirect_PKCS5_PBKDF2_HMAC_SHA512(const char *pass, int passLen,
               				   const unsigned char *salt, int saltLen,
							   int iter,
               				   int dkLen, unsigned char* dKey);

} // end of namespace
#endif
