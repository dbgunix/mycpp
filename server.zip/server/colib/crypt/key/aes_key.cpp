//aes_key.cpp

#include <crypt/key/aes_key.h>

namespace colib {

SAESeKey::~SAESeKey()
{
	memset(&m_enc_ctx,0,sizeof(m_enc_ctx));
	memset(&m_dec_ctx,0,sizeof(m_dec_ctx));
}


bool SAESeKey::gen_sched()
{
	AES_set_encrypt_key(m_data,AES_KEY_BITS,&m_enc_ctx);
	AES_set_decrypt_key(m_data,AES_KEY_BITS,&m_dec_ctx);
	return true;
}

bool SAESeKey::SetData(uint32_t length, const uint8_t *data )
{
	if( !EncryptionKey::SetData(length,data) )
		return false;
	return gen_sched();
}

bool SAESeKey::Copy(const EncryptionKey &from )
{
	uint32_t len = from.GetLength();
	if( !Reallocate(len) )
		return false;

	memcpy(m_data, from.GetData(),len);

	return gen_sched();
}

bool SAESeKey::XdrProc( CXDR *xdr )
{
	if( !EncryptionKey::XdrProc(xdr) )
	   return false;

	if(	xdr->GetOp() == CXDR::XDR_DECODE )
	{
		return gen_sched();
	}
	return true;
}

bool SAESeKey::Zeroize()
{
	if(!m_data)
	{
		return false;
	}
	memset(m_data,0,m_length);
	memset(&m_enc_ctx,0,sizeof(AES_KEY));
	memset(&m_dec_ctx,0,sizeof(AES_KEY));
	return true;
}

bool SAESeKey::GenerateRandomKey()
{
	if(!EncryptionKey::GenerateRandomKey())
		return false;
	return gen_sched();

}

} // end of namespace

