#include "crypt/key/key.h"
#include "crypt/key/aes_key.h"
#include <iostream>
#include <gtest/gtest.h>
#include <stdio.h>
#include "utils/dump_hex.h"
#include "utils/trace/stdio_writable.h"

using namespace colib;

TEST(Keys, Basic)
{
   	int key_len = 32;
	uint8_t aeskey_data[key_len];
	memset(aeskey_data, '\xFF', key_len);

	EncryptionKey* key1 = new EncryptionKey();
	key1->Reallocate(key_len);
	key1->SetData(key_len, aeskey_data);

	EncryptionKey* key2 = new EncryptionKey(*key1);
	SAESeKey key3;
	key3.Copy(*key2);

	colib::StdioWritable output(stdout);

	output.Print("EncryptionKey 1: length %u data:\n", key_len);
	colib::DumpHex(&output, key1->GetData(), key_len);
	output.PrintString("\n");

	output.Print("EncryptionKey 2: length %u data:\n", key_len);
	colib::DumpHex(&output, key2->GetData(), key_len);
	output.PrintString("\n");

//	ASSERT_TRUE(key1->GenerateRandomKey());
	ASSERT_TRUE(key2->GenerateRandomKey());

	output.Print("EncryptionKey 1: length %u data:\n", key_len);
	colib::DumpHex(&output, key1->GetData(), key_len);
	output.PrintString("\n");

	output.Print("EncryptionKey 2: length %u data:\n", key_len);
	colib::DumpHex(&output, key2->GetData(), key_len);
	output.PrintString("\n");

	output.Print("EncryptionKey 2 expanded enc context: length %u data:\n", 4*(AES_MAXNR+1));
	colib::DumpHex(&output, key3.m_enc_ctx.rd_key, 4*(AES_MAXNR+1));
	output.PrintString("\n");

	output.Print("EncryptionKey 2 expanded dec context: length %u data:\n", 4*(AES_MAXNR+1));
	colib::DumpHex(&output, key3.m_dec_ctx.rd_key, 4*(AES_MAXNR+1));
	output.PrintString("\n");

}



