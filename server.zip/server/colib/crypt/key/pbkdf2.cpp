//pbkdf2.cpp
// vi:set ts=4 sw=4 nowrap:


#include <openssl/ssl.h>

namespace colib
{

int iDirect_PKCS5_PBKDF2_HMAC_SHA512(const char *pass, int passlen,
				const unsigned char *salt, int saltlen, int iter,
				int keylen, unsigned char *out)
{
	return PKCS5_PBKDF2_HMAC(pass, passlen, salt, saltlen, iter, EVP_sha512(), keylen, out);
}

} // end of namespace
