//keyroll.cpp
// vi:set ts=4 sw=4 nowrap:


#include <crypt/key/key.h>
#include <crypt/rng/global_rng.h>
#include <utils/dump_hex.h>
#include <utils/trace/trace.h>

#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <time.h>

namespace colib {

EncryptionKey::EncryptionKey()
{
	m_length = 0;
	m_data = NULL;
}

EncryptionKey::EncryptionKey(const EncryptionKey& from) {
	m_length = 0;
	m_data = NULL;
	uint32_t len = from.GetLength();
	if (Reallocate(len)) {
		memcpy(m_data, from.GetData(), len);
	}
}
EncryptionKey::EncryptionKey(uint8_t* data, uint32_t len)
{
	m_length = 0;
	m_data = NULL;
	if (Reallocate(len)) {
		memcpy(m_data, data,  len);
	}
}

EncryptionKey::~EncryptionKey()
{
	if(m_data)
	{
		memset(m_data, 0, m_length);
		delete[] m_data;
		m_data = NULL;
	}
	m_length = 0;
}


bool EncryptionKey::Zeroize()
{
	if(m_data)
	{
		memset(m_data, 0, m_length);
		return true;
	}
	return false;
}

void EncryptionKey::Dump( Writable *to ) const
{
	to->Print("EncryptionKey: length %u data:\n", m_length );
	colib::DumpHex(to,m_data,m_length);
	to->PrintString("\n");
}

bool EncryptionKey::Reallocate(uint32_t key_sz )
{
	if(key_sz != m_length)
	{
		if(m_data)
		{
			delete[] m_data;
		}
		m_length=0;

		m_data = new uint8_t [key_sz];

		if(!m_data)
			return false;

		m_length = key_sz;
	}
	return true;
}
bool EncryptionKey::SetData(uint32_t len, const uint8_t* data)
{
	if( !m_data || len != m_length )
		return false;

	memcpy(m_data, data, len);

	return true;
}

bool EncryptionKey::XdrProc(CXDR *xdr)
{
	uint32_t length;

	if( xdr->GetOp() == CXDR::XDR_ENCODE )
	{
		length = m_length;
	}

	if( !xdr->XdrUint(&length) )
		return false;

	if(length)
	{
		if( xdr->GetOp() == CXDR::XDR_DECODE && !Reallocate(length) )
		{
			return false;
		}

		if( !xdr->XdrBytes((char*)m_data, m_length) )
			return false;
	}
	return true;
}

bool EncryptionKey::Split( uint32_t chunk_length, Dlist<EncryptionKey> &into ) const
{
	//empty out dest list
	into.Clear();

	uint32_t rem_len = m_length;
	uint8_t *pdata = m_data;

	while(rem_len > 0)
	{
		//add a new key to list
		Dlist<EncryptionKey>::Node *iter = into.Append();
		if( !iter )
			return false;
		EncryptionKey &newkey = iter->m_data;

		if( !iter->m_data.Reallocate(chunk_length) )
			return false;

		//copy the data into place
		if( rem_len < chunk_length )
		{
			memcpy( newkey.GetData(), pdata, rem_len );
			memset( newkey.GetData()+rem_len, 0, chunk_length - rem_len);
			break;
		}
		else
		{
			memcpy( newkey.GetData(), pdata, chunk_length );
		}
		rem_len -= chunk_length;
		pdata += chunk_length;
	}

	return true;
}

bool EncryptionKey::Join( uint32_t total_length, Dlist<EncryptionKey> &from )
{
	//reset this key
	if(!Reallocate(total_length))
		return false;
	uint32_t rem = m_length;
	uint8_t *dest = GetData();

	Dlist<EncryptionKey>::Node *iter;

	for( iter=from.GetHead(); iter; iter=from.GetNext(iter) )
	{
		EncryptionKey &atkey = iter->m_data;
		uint32_t getlen = atkey.m_length;

		if(getlen >rem)
		{
			getlen = rem;
		}
		memcpy(dest,atkey.GetData(),getlen);
		dest+=getlen;
		rem -= getlen;
	}
	return rem==0;
}

bool EncryptionKey::Copy( const EncryptionKey &from )
{
	uint32_t len = from.GetLength();
	if( !Reallocate(len) )
		return false;

	memcpy(m_data, from.GetData(), len);

	return true;
}

bool EncryptionKey::operator==(const EncryptionKey &other)
{
	if (m_length != other.GetLength())
	{
		return false;
	}
	return memcmp(m_data, other.GetData(), m_length) == 0;
}

bool EncryptionKey::GenerateRandomKey()
{
	if(!m_data || !m_length)
		return false;
	return iDirect_RAND(m_data, m_length);
}


} // end of namespcae
