#include <idirect/crypt/hmac/hmac.h>
#include <idirect/crypt/sha/hash_consts.h>
#include <idirect/utils/string.h>
#include <idirect/utils/dump_hex.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

/*
	//md must point at a buffer 32 bytes long.
	bool iDirect_hmac_sha256(const void *key, int key_len,
							 const unsigned char *data, int byte_len,
							 unsigned char *md, unsigned int *md_len);

	//md must point at a buffer 64 bytes long.
	bool iDirect_hmac_sha512(const void *key, int key_len,
							 const unsigned char *data, int byte_len,
							 unsigned char *md, unsigned int *md_len);

*/

int main(int argc, char* argv[])
{
	(void) argc;
	(void) argv;

	const char* ipPseuHeader = "This is IP pseudo header";
	const char* tcpHeader = "This is TCP header";
	const char* tcpPayload = "This is TCP payload";

	const char* passwd = "This is P@55w0rd!";

	colib::string combined;

	combined.AppendFmt("%s%s%s", ipPseuHeader, tcpHeader, tcpPayload);

	unsigned char Sha256[colib::SHA256_HASH_LEN_IN_BYTES];
	unsigned int sha256_len = 0;//sizeof(Sha256);

	unsigned char Sha512[colib::SHA512_HASH_LEN_IN_BYTES];
	unsigned int sha512_len = 0;//sizeof(Sha512);

	bool ret = false;

	ret = colib::iDirect_hmac_sha256((const void*)passwd, strlen(passwd),
					(const unsigned char *) combined.c_str(), combined.get_length(),
					Sha256, &sha256_len);

	if (!ret) {
		printf("iDirect_hmac_sha256 failed\n");
		exit(1);
	} else {
		printf("iDirect_hmac_sha256 output %u bytes \n", sha256_len);
	}
	ret = colib::iDirect_hmac_sha512((const void*)passwd, strlen(passwd),
					(const unsigned char *) combined.c_str(), combined.get_length(),
					Sha512, &sha512_len);

	if (!ret) {
		printf("iDirect_hmac_sha512 failed\n");
		exit(1);
	} else {
		printf("iDirect_hmac_sha512 output %u bytes \n", sha512_len);
	}

	printf("=====================HMAC SHA 256========================\n\n\n");
	colib::DumpHex(Sha256, sha256_len);

	printf("\n\n\n=====================HMAC SHA 512=========================\n\n\n");
	colib::DumpHex(Sha512, sha512_len);

	exit(0);
}

