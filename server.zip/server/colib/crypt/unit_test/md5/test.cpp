#include <idirect/crypt/sha/md5.h>
#include <idirect/crypt/sha/hash_consts.h>
#include <idirect/utils/string.h>
#include <idirect/utils/dump_hex.h>

#include <string.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[])
{
	(void) argc;
	(void) argv;

	const char* ipPseuHeader = "This is IP pseudo header";
	const char* tcpHeader = "This is TCP header";
	const char* tcpPayload = "This is TCP payload";

	const char* passwd = "This is P@55w0rd!";

	colib::CMD5 cmd;
	unsigned char Md5Hash[colib::MD5_HASH_LEN_IN_BYTES];

	bool ret = false;

	if (cmd.Init()) {
		ret = cmd.Update((const unsigned char*)ipPseuHeader, strlen(ipPseuHeader))
			 && cmd.Update((const unsigned char*)tcpHeader, strlen(tcpHeader))
			 && cmd.Update((const unsigned char*)tcpPayload, strlen(tcpPayload))
			 && cmd.Update((const unsigned char*)passwd, strlen(passwd));

		if (ret) {
			ret = cmd.Final(Md5Hash);
		}
	}

	if (!ret) {
		printf("failed to compute MD5 hash by CMD5\n");
		exit(1);
	}
	colib::string combined;

	combined.AppendFmt("%s%s%s%s", ipPseuHeader, tcpHeader, tcpPayload, passwd);

	unsigned char Md5Hash2[colib::MD5_HASH_LEN_IN_BYTES];

	ret = colib::iDirect_MD5((const unsigned char*)combined.c_str(), combined.get_length(), Md5Hash2);

	if (!ret) {
		printf("failed to compute MD5 hash by iDirect_MD5\n");
		exit(2);
	}

	if (memcmp(Md5Hash2, Md5Hash, colib::MD5_HASH_LEN_IN_BYTES)) {
		printf("MD5 hash by iDirect_MD5 != CMD5\n");
		exit(3);
	}

	colib::DumpHex(Md5Hash2, sizeof(Md5Hash2));

	colib::DumpHex(Md5Hash, sizeof(Md5Hash));

	exit(0);
}

