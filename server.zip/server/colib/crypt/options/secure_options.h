//secure_options.h
// vi:set ts=4 sw=4 nowrap:

#ifndef SECURE_OPTIONS_H_ALREADY_INCLUDED
#define SECURE_OPTIONS_H_ALREADY_INCLUDED

#include <message/message.h>
#include <utils/string.h>
#include <crypt/asymif/asymif.h>
#include <crypt/pki/format/x509_cert.h>
#include <crypt/pki/format/idirect_krec.h>
#include <crypt/pki/format/idirect_sig.h>
#include <utils/data_struct/rangeset.h>
#include <options/options.h>
#include <crypt/sha/sha512.h>

#include <vector>

namespace colib
{

class SecureOptions : public Message
{
public:

	SecureOptions();
	~SecureOptions();

	void SetModemID(uint32_t modem_id){m_modem_id = modem_id;};
	uint32_t GetModemID(void){return m_modem_id;};

	void SetOptions(const Options &options){m_options = options;};
	Options& GetOptions(void){return m_options;};

	colib::string GetSignatureSubject(void){return m_signing_key_subject;};

	void SetAdminPassword(colib::string pass);

	colib::string GetLastError() {return m_error;};

	bool XdrProc( CXDR *xdr );

	bool Encrypt( AsymIf *asym, x509_Certificate *encrypt_to,
		KeyRecord *signing_private_key, colib::string signing_key_subject);

	bool Decrypt(  AsymIf *asym, x509_Certificate *sig_verifier,
		KeyRecord *decrypting_private_key);
	
	colib::string GetAdminPasswdFromGParam();
	
private:
	colib::string m_error;

	Options m_options;

	//the modem identifier
	uint32_t m_modem_id;
	//the subject of the key used to sign
	colib::string m_signing_key_subject;
	//iv used in the AES encryption of the options file
	std::vector<uint8_t> m_iv;
	//RSA encrypted session key
	std::vector<uint8_t> m_session_key; 
	//contains the modems open password
	std::vector<uint8_t> m_admin_password;
	//AES encrypted using the generated session key in m_session_key
	std::vector<uint8_t> m_options_file; 
	//signature of all the fields
	Signature<SHA512> m_sig;
};

} //end namespace colib
#endif

