//asymlink.cpp
// vi:set ts=4 sw=4 nowrap:

#include <crypt/options/secure_options.h>
#include <utils/data_struct/dlist_xdr.h>
#include <utils/data_struct/vector_xdr.h>
#include <utils/data_struct/rangeset_parser.h>
#include <utils/data_struct/rangeset_xdr.h>
#include <utils/trace/trace.h>
#include <crypt/rng/global_rng.h>
#include <compress/compressed_string.h>
#include <utils/system/memory.h>
#include <config/global_params.h>
#include <crypt/passwd/token.h>
#include <utils/dump_hex.h>

#include <openssl/aes.h>

namespace colib
{


SecureOptions::SecureOptions()
{
}

SecureOptions::~SecureOptions()
{
	memset(m_admin_password.data(), 0, m_admin_password.size());	
}

bool SecureOptions::Encrypt( AsymIf *asym, x509_Certificate *encrypt_to,
			KeyRecord *signing_private_key, colib::string signing_key_subject)
{
	colib::string err;
	m_signing_key_subject = signing_key_subject;
	//check arguments
	if(!asym || !encrypt_to || !signing_private_key )
	{
		m_error = "invalid arguments";
		return false;
	}
	// setup asym from cert
	err = "";
	if( !ApplyX509CertificatetoAsymIf(asym,encrypt_to,err) )
	{
		m_error = "Failed to apply certificate public key to asymif" + err;
		return false;
	}

	m_iv.resize(AES_BLOCK_SIZE); 

	//generate the 128 bit random iv
	if(!iDirect_RAND(m_iv.data(), AES_BLOCK_SIZE))
	{
		m_error=colib::string::Format("Failed to generate iv");
		return false;
	}
	//generate the 256 bit random session key
	unsigned int rsa_sz = asym->GetRequiredSpace();
	m_session_key.resize(rsa_sz);
	//get 256 bit random session key
	unsigned char *bufptr = m_session_key.data();
	if(! iDirect_RAND(bufptr, 32))
	{
		m_error=colib::string::Format("Failed to generate session key");
		return false;
	}
	//set aes encryption key used to encrypt compressed options file
	AES_KEY aes_enc_key;
	AES_set_encrypt_key(bufptr, 256, &aes_enc_key);
	// rsa encypt session key array
	if( -1 == asym->public_encrypt(32, bufptr, bufptr) )
	{
		m_error=colib::string::Format("Failed to rsa encrypt session key: %s", asym->GetLastError() );
		memset((void*)&aes_enc_key, 0, sizeof(AES_KEY));
		return false;
	}
	//compress the option string
	CompressedString cmpr;
	colib::string opt_str = m_options.DumpToStr();

	if( !cmpr.Compress(opt_str) )
	{
		m_error=colib::string::Format("Failed to compress options: %s", cmpr.GetLastError().c_str());
		memset((void*)&aes_enc_key, 0, sizeof(AES_KEY));
		return false;
	}
	m_options_file.resize(opt_str.get_length() + 20);
	{
		// dray 06/15 - max length is output buffer's length
		XdrEncode xdr((char*)m_options_file.data(),  m_options_file.size());
// 		CXDR xdr( CXDR::XDR_ENCODE, (char*)m_options_file.data(),  opt_str.get_length());
		if( !cmpr.XdrProc(&xdr) )
		{
			m_error=colib::string::Format("Failed to XDR encode compressed options: %s", cmpr.GetLastError().c_str());
			memset((void*)&aes_enc_key, 0, sizeof(AES_KEY));
			return false;
		}
		m_options_file.resize(xdr.GetLength());
	}
	//encrypt compressed options file using session key
	unsigned char temp_iv[AES_BLOCK_SIZE];
	memcpy(temp_iv, m_iv.data(), AES_BLOCK_SIZE);

	bufptr = m_options_file.data();
	int num = 0;
	AES_cfb128_encrypt(
					(const unsigned char*)bufptr, //input
					(unsigned char*)bufptr, //output
					m_options_file.size(), //length
					&aes_enc_key, //key
					temp_iv,
					&num,
					1 //enc
					);

	bufptr = m_admin_password.data();
	AES_cfb128_encrypt(
					(const unsigned char*)bufptr, //input
					(unsigned char*)bufptr, //output
					m_admin_password.size(), //length
					&aes_enc_key, //key
					temp_iv,
					&num,
					1 //enc
					);
	
	memset((void*)&aes_enc_key, 0, sizeof(AES_KEY));
	// we sign this with the provided rsa private key
	// setup asym 
	err = "";
	if( !signing_private_key->ApplyKeytoAsym(asym,err) )
	{
		m_error=colib::string::Format("Failed to apply private key to asym: %s",
				err.c_str() );
		return false;
	}
	if( asym->GetStatus() != AsymIf::STATUS_KEYPAIR )
	{
		m_error=colib::string::Format("Private key required for signing, asymif status: %d",
				 asym->GetStatus());
		return false;
	}
	// sign payload
	m_modem_id = FLIP(m_modem_id);
	err = "";
	if(!m_sig.SignObjects(err, asym, 6
							 , &m_modem_id, sizeof(uint32_t)
							, m_signing_key_subject.get_buffer(), m_signing_key_subject.get_length()
							, m_iv.data(), AES_BLOCK_SIZE
							, m_session_key.data(), m_session_key.size()
							, m_options_file.data(), m_options_file.size()
							, m_admin_password.data(), m_admin_password.size()))
	{
		m_error=colib::string::Format("Failed to sign: %s",
				err.c_str() );
		m_modem_id = FLIP(m_modem_id);
		return false;
	}
	m_modem_id = FLIP(m_modem_id);

	return true;
}

colib::string SecureOptions::GetAdminPasswdFromGParam() 
{
	return GLOBALSTRPARAM(SECURITY, admin_password);
}

bool SecureOptions::Decrypt( AsymIf *asym, x509_Certificate *sig_verifier,
			KeyRecord *decrypting_private_key)
{
	colib::string err;

	//check arguments
	if(!asym || !decrypting_private_key )
	{
		m_error = "invalid arguments";
		return false;
	}
	if(sig_verifier != NULL)
	{
		// setup asym from cert
		err = "";
		if( !ApplyX509CertificatetoAsymIf(asym,sig_verifier,err) )
		{
			m_error = "Failed to apply certificate public key to asymif: " + err;
			return false;
		}
		//check signature:
		m_modem_id = FLIP(m_modem_id);
		err = "";
		if(!m_sig.VerifyObjects(err, asym, 6
							 , &m_modem_id, sizeof(uint32_t)
							, m_signing_key_subject.get_buffer(), m_signing_key_subject.get_length()
							,m_iv.data(), AES_BLOCK_SIZE
							, m_session_key.data(), m_session_key.size()
							, m_options_file.data(), m_options_file.size()
							, m_admin_password.data(), m_admin_password.size()))
		{
			m_error=colib::string::Format("Failed to verify signature: %s",
					err.c_str() );
			m_modem_id = FLIP(m_modem_id);
			return false;
		}
		m_modem_id = FLIP(m_modem_id);
	}
	// setup asym from decrypting key
	err = "";
	if( !decrypting_private_key->ApplyKeytoAsym(asym,err) )
	{
		m_error=colib::string::Format("Failed to apply private key to asym: %s",
				err.c_str() );
		return false;
	}
	unsigned int rsa_sz = asym->GetRequiredSpace();
	if( m_session_key.size() != rsa_sz )
	{
		m_error=colib::string::Format("Failed to verify signature: expected length %u obj, not %zu",
				rsa_sz, m_session_key.size() );
		return false;
	}
	if( asym->GetStatus() != AsymIf::STATUS_KEYPAIR )
	{
		m_error=colib::string::Format("Private key required for decryption, asymif status: %d",
				 asym->GetStatus());
		return false;
	}
	unsigned char *bufptr = m_session_key.data();
	//rsa decrypt payload:
	if( -1 == asym->private_decrypt( rsa_sz, bufptr, bufptr))
	{
		m_error=colib::string::Format("Failed to rsa decrypt payload: %s", asym->GetLastError() );
		return false;
	}
	//set aes encryption key used to decrypt compressed options file
	AES_KEY aes_dec_key;
	AES_set_encrypt_key(bufptr, 256, &aes_dec_key);
	//decrypt compressed options file using session key
	unsigned char temp_iv[AES_BLOCK_SIZE];
	memcpy(temp_iv, m_iv.data(), AES_BLOCK_SIZE);

	bufptr = m_options_file.data();
	int num = 0;
	AES_cfb128_encrypt(
					(const unsigned char*)bufptr, //input
					(unsigned char*)bufptr, //output
					m_options_file.size(), //length
					&aes_dec_key, //key
					temp_iv, //ivec
					&num,
					0 //decrypt
					);

	bufptr = m_admin_password.data();
	AES_cfb128_encrypt(
					(const unsigned char*)bufptr, //input
					(unsigned char*)bufptr, //output
					m_admin_password.size(), //length
					&aes_dec_key, //key
					temp_iv, //ivec
					&num,
					0 //decrypt
					);

	memset((void*)&aes_dec_key, 0, sizeof(AES_KEY));
	//decompress the options and password
	{
		CompressedString cmpr;
		XdrDecode xdr((char*)m_options_file.data(), m_options_file.size() );
		if( !cmpr.XdrProc(&xdr) )
		{
			m_error=colib::string::Format("Failed to XDR decode options: %s", cmpr.GetLastError().c_str());
			return false;
		}
		colib::string opt_str;
		if( !cmpr.Decompress(opt_str) )
		{
			m_error=colib::string::Format("Failed to decompress options: %s", cmpr.GetLastError().c_str());
			return false;
		}
		if(!m_options.Load(opt_str))
		{
			m_error=colib::string::Format("Failed to parse options string");
			return false;
		}
		const char *hash = GLOBALSTRPARAM(SECURITY, admin_password);
		if(!hash)
		{
			m_error=colib::string::Format("admin password not set in global params");
			return false;
		}
		if(!idirect_token_verify((const char *)m_admin_password.data(), hash))
		{
			m_error=colib::string::Format("admin password check failed");
			return false;
		}
	}

	return true;
}

bool SecureOptions::XdrProc( CXDR *xdr )
{
	if(!xdr->XdrUint(&m_modem_id))
	{
		TRACE("Failed xdr: modem id\n");
		return false;
	}
	if(!xdr->XdrStringPacked(m_signing_key_subject))
	{
		TRACE("Failed xdr: subject\n");
		return false;
	}
	if(!XdrVectorBlock<uint8_t>(xdr,m_iv))
	{
		TRACE("Failed xdr: iv\n");
		return false;
	}
	if(!XdrVectorBlock<uint8_t>(xdr,m_session_key))
	{
		TRACE("Failed xdr: session key\n");
		return false;
	}
	if(!XdrVectorBlock<uint8_t>(xdr,m_options_file))
	{
		TRACE("Failed xdr: option file\n");
		return false;
	}
	if(!XdrVectorBlock<uint8_t>(xdr,m_admin_password))
	{
		TRACE("Failed xdr: password \n");
		return false;
	}
	if(!m_sig.MinimalXdrProc(xdr))
	{
		TRACE("Failed xdr: sig\n");
		return false;
	}

	return true;
}

void SecureOptions::SetAdminPassword(colib::string pass)
{
	m_admin_password.resize(pass.get_length() + 1);

	memcpy(m_admin_password.data(), pass.get_buffer(), pass.get_length() + 1);
}

} //end namespace colib
