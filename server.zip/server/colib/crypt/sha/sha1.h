#ifndef SHA1_H_
#define SHA1_H_

#include <stdarg.h>
#include <openssl/sha.h>
#include <crypt/sha/sha.h>
#include <string.h>
#include <crypt/pki/format/const.h>

namespace colib {

class SHA1 {
public:

	static const int DIGEST_LENGTH = SHA_DIGEST_LENGTH;
	const char* const IDIRECT_SIG_NAME;

	SHA1(): IDIRECT_SIG_NAME(IDIRECT_SIG_RSA_SHA1){
		memset(m_shabuf, 0, DIGEST_LENGTH);
	}

	void CalculateHash(unsigned int num, va_list args){
		iDirect_sha1(m_shabuf, num, args);
	}
	const unsigned char* GetHashData(){
		return m_shabuf;
	}
	void Zeroize(){
		memset(m_shabuf, 0, DIGEST_LENGTH);
	}
private:
	unsigned char m_shabuf[DIGEST_LENGTH];
};

}
#endif /* SHA1_H_ */
