//sha1.h
// vi:set ts=4 sw=4 nowrap:

#ifndef SHA_H_ALREADY_INCLUDED
#define SHA_H_ALREADY_INCLUDED

#include <openssl/sha.h>
#include <stdarg.h>

namespace colib {

//output must point at a buffer 20 bytes long.
void iDirect_sha1(const unsigned char *data, unsigned long byte_len, unsigned char *output);

// num is the number of "data" and "length" pairs that are passed
// example: iDirect_sha1(num, data1, len1, data2, len2)
void iDirect_sha1(unsigned char *output, unsigned int num, ...);
void iDirect_sha1(unsigned char *output, unsigned int num, va_list args);
bool iDirect_sha1_KAT(void);


//output must point at a buffer 32 bytes long.
void iDirect_sha256(const unsigned char *data, unsigned long byte_len, unsigned char *output);
void iDirect_sha256(unsigned char *output, unsigned int num, ...);
void iDirect_sha256(unsigned char *output, unsigned int num, va_list args);
bool iDirect_sha256_KAT(void);


//output must point at a buffer 64 bytes long.
void iDirect_sha512(const unsigned char *data, unsigned long byte_len, unsigned char *output);
void iDirect_sha512(unsigned char *output, unsigned int num, ...);
void iDirect_sha512(unsigned char *output, unsigned int num, va_list arg);
bool iDirect_sha512_KAT(void);



}

#endif

