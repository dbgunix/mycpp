//vi:set ts=4 sw=4 nowrap:

#include <crypt/sha/md5.h>
#include <openssl/md5.h>

namespace colib {

bool iDirect_MD5(const unsigned char *data, unsigned long byte_len,
				 unsigned char *output)
{
	return (NULL != MD5(data, byte_len, output));
}

bool CMD5::Init() 
{
	return MD5_Init(&m_md5_ctx) == 1;	
}

bool CMD5::Update(const unsigned char *data, unsigned long byte_len)
{
	return MD5_Update(&m_md5_ctx, data, byte_len) == 1;
}

bool CMD5::Final(unsigned char *output)
{
	return MD5_Final(output, &m_md5_ctx) == 1;
}

} // end of namespace
