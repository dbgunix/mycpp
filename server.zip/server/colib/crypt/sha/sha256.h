#ifndef SHA256_H_
#define SHA256_H_

#include <stdarg.h>
#include <openssl/sha.h>
#include <string.h>
#include <crypt/sha/sha.h>
#include <crypt/pki/format/const.h>

namespace colib {

class SHA256 {
public:

	static const int DIGEST_LENGTH = SHA256_DIGEST_LENGTH;
	const char* const IDIRECT_SIG_NAME;

	SHA256(): IDIRECT_SIG_NAME(IDIRECT_SIG_RSA_SHA256){
		memset(m_shabuf, 0, DIGEST_LENGTH);
	}

	void CalculateHash(unsigned int num, va_list args){
		iDirect_sha256( m_shabuf, num, args);
	}
	const unsigned char* GetHashData() const{
		return m_shabuf;
	}
	void Zeroize(){
		memset(m_shabuf, 0, DIGEST_LENGTH);
	}
private:
	unsigned char m_shabuf[DIGEST_LENGTH];
};

}

#endif /* SHA256_H_ */
