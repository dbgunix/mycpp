//sha1.cpp
// vi:set ts=4 sw=4 nowrap:

#include <openssl/sha.h>
#include <crypt/sha/sha.h>

namespace colib {


void iDirect_sha1(unsigned char *output, unsigned int num,  ...)
{
	va_list args;
	va_start(args, num);
	iDirect_sha1(output, num, args);
	va_end(args);
}

void iDirect_sha1(unsigned char *output, unsigned int num, va_list args)
{
	unsigned char* data;
	unsigned int length;

	SHA_CTX ctx;
	SHA1_Init(&ctx);
	while ( num-- )
	{
		data = va_arg(args, unsigned char*);
		length = va_arg(args, unsigned int);
		SHA1_Update(&ctx, data, length);
	}
	SHA1_Final(output, &ctx);
}

void iDirect_sha1(const unsigned char *data, unsigned long byte_len, unsigned char *output)
{
	iDirect_sha1(output, 1, data, byte_len);
}

void iDirect_sha256(unsigned char *output, unsigned int num, ...)
{
	va_list args;
	va_start(args, num);
	iDirect_sha256(output, num, args);
	va_end(args);
}

void iDirect_sha256(unsigned char *output, unsigned int num, va_list args)
{
	unsigned char* data;
	unsigned int length;

	SHA256_CTX ctx;
	SHA256_Init(&ctx);
	while ( num-- )
	{
		data = va_arg(args, unsigned char*);
		length = va_arg(args, unsigned int);
		SHA256_Update(&ctx, data, length);
	}
	SHA256_Final(output, &ctx);
}

void iDirect_sha256(const unsigned char *data, unsigned long byte_len, unsigned char *output)
{
	iDirect_sha256(output, 1, data, byte_len);
}

void iDirect_sha512(unsigned char *output, unsigned int num,  ...)
{
	va_list args;
	va_start(args, num);
	iDirect_sha512(output, num, args);
	va_end(args);
}

void iDirect_sha512(unsigned char *output, unsigned int num, va_list args)
{
	unsigned char* data;
	unsigned int length;

	SHA512_CTX ctx;
	SHA512_Init(&ctx);
	while ( num-- )
	{
		data = va_arg(args, unsigned char*);
		length = va_arg(args, unsigned int);
		SHA512_Update(&ctx, data, length);
	}
	SHA512_Final(output, &ctx);
}

void iDirect_sha512(const unsigned char *data, unsigned long byte_len, unsigned char *output)
{
	iDirect_sha512(output, 1, data, byte_len);
}

} // end of namespace
