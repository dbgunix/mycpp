//vi:set ts=4 sw=4 nowrap:

#ifndef HASH_CONSTS_H_ALREADY_INCLUDED
#define HASH_CONSTS_H_ALREADY_INCLUDED

#include <openssl/md5.h>
#include <openssl/sha.h>

namespace colib {

static const int MD5_HASH_LEN_IN_BYTES = MD5_DIGEST_LENGTH;
static const int SHA1_HASH_LEN_IN_BYTES = SHA_DIGEST_LENGTH;
static const int SHA256_HASH_LEN_IN_BYTES = SHA256_DIGEST_LENGTH;
static const int SHA512_HASH_LEN_IN_BYTES = SHA512_DIGEST_LENGTH;
 
} // namespace

#endif

