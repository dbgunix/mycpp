//vi:set ts=4 sw=4 nowrap:

#ifndef MD5_H_ALREADY_INCLUDED
#define MD5_H_ALREADY_INCLUDED

#include <openssl/md5.h>

namespace colib {

//output must point at a buffer 16 bytes long.
bool iDirect_MD5(const unsigned char *data, unsigned long byte_len, unsigned char *output);

class CMD5 {
public:
	CMD5() {}
	~CMD5() {}
	bool Init();
	bool Update(const unsigned char *data, unsigned long len);
	bool Final(unsigned char *md);

private:

	MD5_CTX m_md5_ctx;	
};


} // namespace

#endif

