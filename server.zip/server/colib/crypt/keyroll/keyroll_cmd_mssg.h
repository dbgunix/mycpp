#ifndef KEYROLL_CMD_MSSG_H_
#define KEYROLL_CMD_MSSG_H_

#include <crypt/keyroll/keyroll_cmd.h>
#include <time.h>


namespace colib{

class KeyRollCmdMssg{

public:

	time_t m_last_roll_time;
	time_t m_cur_key_active_time;
	KeyRollCmd m_keyroll_cmd;
	string m_key_name;

	KeyRollCmdMssg();
	bool XdrProc(CXDR* xdr);

};


}

#endif /* KEYROLL_CMD_MSSG_H_ */
