//keyroll.h
// vi:set ts=4 sw=4 nowrap:
//

#ifndef keyroll_h_already_included
#define keyroll_h_already_included

#include <utils/string.h>
#include <utils/trace/writable.h>
#include <crypt/key/key.h>
#include <crypt/keyroll/keyroll_cmd.h>

namespace colib {

class KeyRoll
{
public:

	static const int MAX_KEY_INDEX = 3;
	static const int MAX_KEY_ROLL_XDR_LEN = 4 * 128; //TODO: check what size is needed

/**
 * Initializes data members. Does not allocate memory
 */
	KeyRoll();
	~KeyRoll();

/**
 * Allocate memory and invalidate keys
 * @param key_sz[in] key size
 * @param key_type[in] key type
 * @return true - if succeeded; false - if failed
 */
	bool Init(uint32_t key_sz,  uint8_t key_type);

	bool GenerateActiveKeys();
	bool RolloverKeyring();

	bool operator=( const KeyRoll& to);
	bool operator==( const KeyRoll& to) const;

	bool SetKeySize( unsigned int key_sz );
	int GetKeySize() const {return m_key_sz;}
	const EncryptionKey* GetActiveKey() const;
	int GetActiveKeyIndex() const {return m_active_key;}
	time_t GetLastRollTime() const { return m_last_roll_time;};
	void SetLastRollTime(time_t time){ m_last_roll_time = time; };
	time_t GetActiveKeyTime() const { return m_cur_key_active_time; };
	void SetActiveKeyTime(time_t time) { m_cur_key_active_time = time; };
	EncryptionKey* GetKey (int key_idx) const;
	bool IsKeyValid(int key_idx) const {return m_keys_valid[key_idx];}
	/**
	 * Set KeyRoll
	 * @param cmd - KeyRoll data
	 * @return
	 */
	bool ApplyCommand(const KeyRollCmd& cmd);

	/**
	 * Extracts KeyRoll data
	 * @param cmd[out] - current KeyRoll status
	 * @return
	 */
	bool ExtractStatus(KeyRollCmd& cmd) const;

	void Zeroize();
	int GetNumValidKeys() const;
	bool IsKeyrollValid() const;

	void Dump( Writable *to ) const;
	void DumpStateOnly( Writable *to ) const;

	const colib::string GetLastError() {
		return m_last_error;
	}

	bool SetKeyWithChksum(const char *pKeyB64);

private:

	EncryptionKey* m_keys[MAX_KEY_INDEX + 1];
	bool m_keys_valid[MAX_KEY_INDEX + 1];

	int m_active_key;
	time_t m_last_roll_time;
	time_t m_cur_key_active_time;

	/**
	 * \brief new each key according to key type
	 */
	bool AllocKeys();
	bool GenerateInitialKeys();

	uint32_t m_key_sz; // length of the key
	uint32_t m_key_type;

	colib::string m_last_error;
};


} // end of namespace

#endif

