#ifndef KEYROLL_MGR_H_ALREADY_INCLUDED
#define KEYROLL_MGR_H_ALREADY_INCLUDED

#include "keyroll.h"
#include <utils/callback.h>

namespace colib {

class KeyRollCmdMssg;

class KeyrollMgrIntf
{
public:
	virtual ~KeyrollMgrIntf();

	virtual bool HasKeyrolls(){
		return false;
	}

	virtual const KeyRoll* GetTxKeyRoll(){
		m_last_error = "Not supported";
		return NULL;
	}

	virtual const KeyRoll* GetRxKeyRoll(){
		m_last_error = "Not supported";
		return NULL;
	}

	virtual const KeyRoll* GetAccKeyRoll(){
		m_last_error = "Not supported";
		return NULL;
	}

	virtual bool ApplyTx(const KeyRollCmdMssg *cmd){
		(void)cmd;
		m_last_error = "Not supported";
		return false;
	}

	virtual bool ApplyRx(const KeyRollCmdMssg *cmd){
		(void)cmd;
		m_last_error = "Not supported";
		return false;
	}

	virtual bool ApplyAcc(const KeyRollCmdMssg *cmd){
		(void)cmd;
		m_last_error = "Not supported";
		return false;
	}

	virtual void DisableTxKeyroll(){
	}

	virtual void DisableRxKeyroll(){
	}

	virtual void DisableAccKeyroll(){
	}

	virtual bool GenerateTx(){
		m_last_error = "Not supported";
		return false;
	}

	virtual bool GenerateRx(){
		m_last_error = "Not supported";
		return false;
	}

	virtual bool GenerateAcc(){
		m_last_error = "Not supported";
		return false;
	}

	virtual bool RolloverTx(){
		m_last_error = "Not supported";
		return false;
	}

	virtual bool RolloverRx(){
		m_last_error = "Not supported";
		return false;
	}

	virtual bool RolloverAcc(){
		m_last_error = "Not supported";
		return false;
	}

	virtual void Zeroize(){
	}

	void Dispatch();

	string GetLastError()const{
		return m_last_error;
	}

	void SetUpdatedNotifyCallback(Callback1<KeyrollMgrIntf*> updated_notify_callback) {
		m_updated_notify = updated_notify_callback;
	}

protected:

	colib::string m_last_error;

private:

	Callback1<KeyrollMgrIntf*> m_updated_notify;
};
} // end of namespace

#endif

