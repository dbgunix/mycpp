#include "enc_keyroll_mgr.h"
#include "keyroll_cmd_mssg.h"

namespace colib {

EncKeyrollMgr::EncKeyrollMgr() {
}

EncKeyrollMgr::~EncKeyrollMgr() {
}

bool EncKeyrollMgr::InitKeyrolls(uint32_t key_len, uint8_t key_type)
{
	if(!m_enc_keyroll.Init(key_len, key_type)){
		m_last_error = m_enc_keyroll.GetLastError();
		return false;
	}
	if(!m_dec_keyroll.Init(key_len, key_type)) {
		m_last_error = m_dec_keyroll.GetLastError();
		return false;
	}
	return true;
}

bool EncKeyrollMgr::HasKeyrolls() {
	return true;
}

const KeyRoll* EncKeyrollMgr::GetTxKeyRoll() {
	return &m_enc_keyroll;
}

const KeyRoll* EncKeyrollMgr::GetRxKeyRoll() {
	return &m_dec_keyroll;
}

bool EncKeyrollMgr::ApplyTx(const KeyRollCmdMssg *cmd) {
	if (cmd){
		if(!m_enc_keyroll.ApplyCommand(cmd->m_keyroll_cmd)){
			m_last_error = m_enc_keyroll.GetLastError();
			return false;
		}
		m_enc_keyroll.SetActiveKeyTime(cmd->m_cur_key_active_time);
		m_enc_keyroll.SetLastRollTime(0);
		return true;
	}
	m_last_error = "NULL pointer argument";
	return false;
}

bool EncKeyrollMgr::ApplyRx(const KeyRollCmdMssg *cmd) {
	if (cmd){
		if(!m_dec_keyroll.ApplyCommand(cmd->m_keyroll_cmd)){
			m_last_error = m_enc_keyroll.GetLastError();
			return false;
		}
		m_dec_keyroll.SetActiveKeyTime(cmd->m_cur_key_active_time);
		m_dec_keyroll.SetLastRollTime(0);
		return true;
	}
	m_last_error = "NULL pointer argument";
	return false;
}

void EncKeyrollMgr::DisableTxKeyroll() {
	m_enc_keyroll.Zeroize();
}

void EncKeyrollMgr::DisableRxKeyroll() {
	m_dec_keyroll.Zeroize();
}

bool EncKeyrollMgr::GenerateTx() {
	 if(!m_enc_keyroll.GenerateActiveKeys()){
		 m_last_error = m_enc_keyroll.GetLastError();
		 return false;
	 }
	return true;
}

bool EncKeyrollMgr::GenerateRx() {
	 if(!m_dec_keyroll.GenerateActiveKeys()){
		 m_last_error = m_dec_keyroll.GetLastError();
		 return false;
	 }
	return true;
}

bool EncKeyrollMgr::RolloverTx() {
	if (!m_enc_keyroll.RolloverKeyring()) {
		m_last_error = m_enc_keyroll.GetLastError();
		return false;
	}
	return true;
}

bool EncKeyrollMgr::RolloverRx() {
	if (!m_dec_keyroll.RolloverKeyring()) {
		m_last_error = m_dec_keyroll.GetLastError();
		return false;
	}
	return true;
}

void EncKeyrollMgr::Zeroize() {
	m_enc_keyroll.Zeroize();
	m_dec_keyroll.Zeroize();
}

bool EncKeyrollMgr::SetKeyWithChksum(const char *pKeyB64) {
	if(!m_enc_keyroll.SetKeyWithChksum(pKeyB64)){
		m_last_error = m_enc_keyroll.GetLastError();
		return false;
	}
	if(!(m_dec_keyroll = m_enc_keyroll)){
		m_last_error = m_dec_keyroll.GetLastError();
		return false;
	}
	return true;
}


} /* namespace colib */
