#include <crypt/keyroll/keyroll_cmd.h>
#include <string.h>

namespace colib {

KeyRollCmd::KeyRollCmd()
	: m_key_num(0)
	, m_key_len(0)
	, m_act_key_idx(0)
	, m_keys(NULL)
{
}

KeyRollCmd::KeyRollCmd(uint32_t key_num, uint32_t key_len, uint32_t act_key_idx)
	: m_key_num(key_num)
	, m_key_len(key_len)
	, m_act_key_idx(act_key_idx)
	, m_keys(NULL)
{
	Allocate();
}

void KeyRollCmd::Allocate(){

	m_keys = new KeyStruct [m_key_num];
	for(uint32_t i = 0; i < m_key_num; i++)
	{
		m_keys[i].m_key = new uint8_t [m_key_len];
	}

}
void KeyRollCmd::Deallocate(){

	for (uint32_t i = 0; i < m_key_num; i++)
	{
		delete [] m_keys[i].m_key;
	}
	delete [] m_keys;
}

void KeyRollCmd::Reallocate(uint32_t key_num, uint32_t key_len) {

	m_act_key_idx = 0;
	if (m_key_num == key_num && m_key_len == key_len) {
		return;
	}

	Deallocate();

	m_key_num = key_num;
	m_key_len = key_len;

	Allocate();

	return;
}

KeyRollCmd& KeyRollCmd::operator=(const KeyRollCmd& cmd){
	if(this != &cmd){
		Reallocate(cmd.m_key_num, cmd.m_key_len);
		for(uint32_t i = 0; i < m_key_num; i++){
			AddKey(i, cmd.m_keys[i].m_idx,
					cmd.m_keys[i].m_key);
		}
		m_act_key_idx = cmd.m_act_key_idx;
	}
	return *this;
}

KeyRollCmd::KeyRollCmd(const KeyRollCmd& cmd){
	m_key_num = cmd.m_key_num;
	m_key_len = cmd.m_key_len;
	Allocate();
	for(uint32_t i = 0; i < m_key_num; i++){
		AddKey(i, cmd.m_keys[i].m_idx,
				cmd.m_keys[i].m_key);
	}
	m_act_key_idx = cmd.m_act_key_idx;
}

bool KeyRollCmd::operator==(const KeyRollCmd& cmd){
	if (m_key_num != cmd.m_key_num || m_key_len != cmd.m_key_len
			|| m_act_key_idx != cmd.m_act_key_idx)
		return false;
	for(uint32_t i = 0; i < m_key_num; i++){
		if(m_keys[i].m_idx != cmd.m_keys[i].m_idx ||
				memcmp(m_keys[i].m_key, cmd.m_keys[i].m_key, m_key_len)){
			return false;
		}
	}
	return true;
}

KeyRollCmd::~KeyRollCmd()
{
	Deallocate();
}

bool KeyRollCmd::AddKey(uint32_t key_pos, uint32_t idx, const uint8_t* key_data)
{
	if (key_pos >= m_key_num) {
		return false;
	}
	if(!m_keys[key_pos].m_key)
		return false;
	m_keys[key_pos].m_idx = idx;
	memcpy(m_keys[key_pos].m_key, key_data, m_key_len);
	return true;
}

const KeyRollCmd::KeyStruct* KeyRollCmd::GetKeyStruct(uint32_t idx) const
{
	if(idx >= m_key_num)
	{
		return NULL;
	}
	return m_keys+idx;
}

bool KeyRollCmd::XdrProc(CXDR* xdr) {

	uint32_t key_num;
	uint32_t key_len;

	if (xdr->GetOp() == CXDR::XDR_ENCODE ) {
		key_num = m_key_num;
		key_len = m_key_len;
	}

	if (!xdr->XdrUint(&key_num) || !xdr->XdrUint(&key_len))
		return false;

	if (xdr->GetOp() == CXDR::XDR_DECODE ) {
		Reallocate(key_num, key_len);
	}

	if (!xdr->XdrUint(&m_act_key_idx))
		return false;

	for (uint32_t i = 0; i < m_key_num; i++) {
		if (!xdr->XdrUint(&m_keys[i].m_idx) ||
				!xdr->XdrBytes((char*) m_keys[i].m_key, m_key_len))
			return false;
	}
	return true;
}


}
