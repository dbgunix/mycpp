#ifndef ENCKEYROLLMGR_H_
#define ENCKEYROLLMGR_H_

#include <crypt/keyroll/keyroll_mgr.h>

namespace colib {

class EncKeyrollMgr: public KeyrollMgrIntf {
public:
	EncKeyrollMgr();
	~EncKeyrollMgr();

	/**
	 * Allocate memory for the Tx and Rx keyrolls
	 */
	bool InitKeyrolls(uint32_t key_len, uint8_t key_type);

	bool HasKeyrolls();

	const KeyRoll* GetTxKeyRoll();
	const KeyRoll* GetRxKeyRoll();

	bool ApplyTx(const KeyRollCmdMssg *cmd);
	bool ApplyRx(const KeyRollCmdMssg *cmd);

	void DisableTxKeyroll();
	void DisableRxKeyroll();

	bool GenerateTx();
	bool GenerateRx();

	bool RolloverTx();
	bool RolloverRx();

	void Zeroize();

	bool SetKeyWithChksum(const char* pKeyB64);

protected:

	colib::string m_last_error;

private:

	KeyRoll m_enc_keyroll;
	KeyRoll m_dec_keyroll;

};

} /* namespace colib */
#endif /* ENCKEYROLLMGR_H_ */
