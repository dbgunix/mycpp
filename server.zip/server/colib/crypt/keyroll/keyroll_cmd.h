#ifndef KEYROLLCMD_H_
#define KEYROLLCMD_H_

#include <stdint.h>
#include <utils/xdr.h>

namespace colib {

class KeyRollCmd {
public:

	struct KeyStruct {
		//Index of the the key in keyroll
		uint32_t m_idx;
		uint8_t* m_key;
	};

	KeyRollCmd();
	KeyRollCmd(uint32_t key_num, uint32_t key_len, uint32_t act_key_idx);
	~KeyRollCmd();
	KeyRollCmd& operator=(const KeyRollCmd& cmd);
	KeyRollCmd(const KeyRollCmd& cmd);

	bool operator==(const KeyRollCmd& cmd);

	void Reallocate(uint32_t key_num, uint32_t key_len);

	bool AddKey(uint32_t pos, uint32_t idx, const uint8_t* key_data);

	uint32_t GetKeyNum() const {
		return m_key_num;
	}
	uint32_t GetKeyLen() const {
		return m_key_len;
	}
	uint32_t GetActiveKeyIdx() const {
		return m_act_key_idx;
	}
	void SetActiveKeyIdx(uint32_t idx){
		m_act_key_idx = idx;
	}
	const KeyStruct* GetKeyStruct(uint32_t idx) const;

	bool XdrProc(CXDR* xdr);

private:

	void Allocate();
	void Deallocate();

	//number of keys in KeyRollCmd
	uint32_t m_key_num;

	//length of a key data
	uint32_t m_key_len;

	// active key index
	uint32_t m_act_key_idx;

	KeyStruct* m_keys;
};
}
#endif /* KEYROLLCMD_H_ */
