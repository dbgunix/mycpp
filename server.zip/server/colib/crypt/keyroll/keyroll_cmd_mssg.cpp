#include <crypt/keyroll/keyroll_cmd_mssg.h>

namespace colib {

KeyRollCmdMssg::KeyRollCmdMssg() :
		m_last_roll_time(-1), m_cur_key_active_time(-1) {
}

bool KeyRollCmdMssg::XdrProc(CXDR* xdr) {

	return xdr->XdrLong(&m_last_roll_time)
			&& xdr->XdrLong(&m_cur_key_active_time)
			&& m_keyroll_cmd.XdrProc(xdr) && xdr->XdrStringPacked(m_key_name);

}

}
