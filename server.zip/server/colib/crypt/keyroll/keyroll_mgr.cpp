#include <crypt/keyroll/keyroll_mgr.h>

namespace colib {

KeyrollMgrIntf::~KeyrollMgrIntf(){
}

void KeyrollMgrIntf::Dispatch() {
	m_updated_notify.Dispatch(this);
}


} // end of namespace

