#include <idirect/crypt/keyroll/keyroll.h>
#include <iostream>
#include <gtest/gtest.h>
#include <stdio.h>
#include <idirect/utils/trace/stdio_writable.h>

using namespace colib;

TEST(KeyRoll, Basic)
{
	colib::StdioWritable output(stdout);

	uint32_t key_len = 32;
	KeyRoll key_roll_1;
	ASSERT_TRUE(key_roll_1.Init(key_len, EncryptionKey::KEY_TYPE_OSSL_AES));
	key_roll_1.Dump(&output);
	key_roll_1.Zeroize();
	EXPECT_TRUE(key_roll_1.GetActiveKeyIndex() == -1);
	key_roll_1.Dump(&output);

	KeyRoll key_roll_2;
	ASSERT_TRUE(key_roll_2.Init(key_len, EncryptionKey::KEY_TYPE_OSSL_AES));
	key_roll_2.Dump(&output);
	key_roll_2.Zeroize();
	EXPECT_TRUE(key_roll_2.GetActiveKeyIndex() == -1);
	key_roll_2.Dump(&output);

	// First rollover
	output.Print("--------------First rollover--------------\n");
	key_roll_1.RolloverKeyring();

	KeyRollCmd cmd;
	EXPECT_TRUE(key_roll_1.ExtractStatus(cmd));
	EXPECT_TRUE(key_roll_2.ApplyCommand(cmd));
	EXPECT_TRUE(key_roll_1 == key_roll_2);
	EXPECT_TRUE(key_roll_1.GetNumValidKeys() == 2);
	EXPECT_TRUE(key_roll_1.GetActiveKeyIndex() == 0);

	key_roll_1.Dump(&output);
	key_roll_2.Dump(&output);

	// KeyRollCmd tests
	KeyRollCmd cmd1;
	EXPECT_TRUE(key_roll_1.ExtractStatus(cmd1));
	KeyRollCmd cmd2(cmd1);
	EXPECT_TRUE(cmd1 == cmd2);

	KeyRollCmd cmd3;
	cmd3 = cmd1;
	EXPECT_TRUE(cmd1 == cmd3);

	//Second rollover
	output.Print("--------------Second rollover-----------------\n");
	key_roll_1.RolloverKeyring();

	EXPECT_TRUE(key_roll_1.ExtractStatus(cmd));
	EXPECT_TRUE(key_roll_2.ApplyCommand(cmd));
	EXPECT_TRUE(key_roll_1 == key_roll_2);
	EXPECT_TRUE(key_roll_1.GetNumValidKeys() == 3);
	EXPECT_TRUE(key_roll_1.GetActiveKeyIndex() == 1);

	key_roll_1.Dump(&output);
	key_roll_2.Dump(&output);

	// Third rollowver
	output.Print("--------------Third rollover-----------------\n");
	key_roll_1.RolloverKeyring();
	EXPECT_TRUE(key_roll_1.ExtractStatus(cmd));
	EXPECT_TRUE(key_roll_2.ApplyCommand(cmd));
	EXPECT_TRUE(key_roll_1 == key_roll_2);
	EXPECT_TRUE(key_roll_1.GetNumValidKeys() == 3);
	EXPECT_TRUE(key_roll_1.GetActiveKeyIndex() == 2);

	key_roll_1.Dump(&output);
	key_roll_2.Dump(&output);

	output.Print("--------------Forth rollover-----------------\n");

	key_roll_1.RolloverKeyring();
	EXPECT_TRUE(key_roll_1.ExtractStatus(cmd));
	EXPECT_TRUE(key_roll_2.ApplyCommand(cmd));
	EXPECT_TRUE(key_roll_1 == key_roll_2);
	EXPECT_TRUE(key_roll_1.GetNumValidKeys() == 3);
	EXPECT_TRUE(key_roll_1.GetActiveKeyIndex() == 3);

	key_roll_1.Dump(&output);
	key_roll_2.Dump(&output);

// Fifth rollover
	output.Print("--------------Fifth rollover-----------------\n");
	key_roll_1.RolloverKeyring();
	EXPECT_TRUE(key_roll_1.ExtractStatus(cmd));
	EXPECT_TRUE(key_roll_2.ApplyCommand(cmd));
	EXPECT_TRUE(key_roll_1 == key_roll_2);
	EXPECT_TRUE(key_roll_1.GetNumValidKeys() == 3);
	EXPECT_TRUE(key_roll_1.GetActiveKeyIndex() == 0);

	key_roll_1.Dump(&output);
	key_roll_2.Dump(&output);

}

