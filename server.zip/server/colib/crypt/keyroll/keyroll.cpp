#include <crypt/key/aes_key.h>
//#include "storage.h"
#include <utils/trace/trace.h>
#include <utils/base_encoder.h>
#include <utils/system/machine.h>
#include <crypt/keyroll/keyroll.h>

#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>

namespace colib {

KeyRoll::KeyRoll() {
	m_key_sz = 0;
	m_active_key = -1;
	m_last_roll_time = 0;
	m_cur_key_active_time = -1;
	for (int at = 0; at <= MAX_KEY_INDEX; ++at){
		m_keys_valid[at] = false;
		m_keys[at] = NULL;
	}
}

KeyRoll::~KeyRoll() {
	for (int at = 0; at <= MAX_KEY_INDEX; ++at) {
		if (m_keys[at])
			delete m_keys[at];
		m_keys[at] = NULL;
	}
}

bool KeyRoll::Init(uint32_t key_sz, uint8_t key_type) {
	m_key_type = key_type;
	m_key_sz = key_sz;
	if (!AllocKeys()) {
		return false;
	}
	return true;
}

bool KeyRoll::AllocKeys() {
	if (m_key_type == EncryptionKey::KEY_TYPE_OSSL_AES) {
		for (int at = 0; at <= MAX_KEY_INDEX; ++at) {
			if (m_keys[at]) {
				delete m_keys[at];
			}
			m_keys[at] = new SAESeKey;
			m_keys_valid[at] = false;
		}
		SetKeySize(m_key_sz);
		return true;
	}
	m_last_error = "Key type not supported";
	return false;
}

/**
 * Generates two keys if m_active_key = -1 and one key otherwise
 * @return true if succeeded;  false if failed
 */
bool KeyRoll::RolloverKeyring() {

	if (m_active_key < 0 || m_active_key > MAX_KEY_INDEX) {

		if(!GenerateInitialKeys()) return false;

	} else {

		int next_key = (m_active_key + 1) % (MAX_KEY_INDEX + 1);
		int gen_key = (m_active_key + 2) % (MAX_KEY_INDEX + 1);
		int to_disable = (m_active_key + 3) % (MAX_KEY_INDEX + 1);

		if (!m_keys_valid[next_key]) {
			m_last_error = "Next key not valid";
			return false;
		}

		//Generate a new key, for future use
		if (!m_keys[gen_key]->GenerateRandomKey()) {
			m_last_error = "Failed To generate random key";
			return false;
		}
		//activate the new key
		m_keys_valid[gen_key] = true;

		//setup the keyroll's active key
		m_active_key = next_key;

		//Disable an old key
		m_keys_valid[to_disable] = false;
	}
	m_last_roll_time = time(NULL);
	m_cur_key_active_time = m_last_roll_time;

	return true;
}
bool KeyRoll::GenerateInitialKeys(){
	if (!m_keys[0] || !m_keys[0]->GenerateRandomKey()
			|| !m_keys[1] || !m_keys[1]->GenerateRandomKey()) {
		m_last_error = "Failed to generate random key";
		return false;
	}
	m_active_key = 0;
	m_keys_valid[0] = true;
	m_keys_valid[1] = true;
	return true;
}
bool KeyRoll::GenerateActiveKeys() {

	if(!GenerateInitialKeys()) return false;

	m_last_roll_time = time(NULL);
	m_cur_key_active_time = m_last_roll_time;
	return true;
}
EncryptionKey* KeyRoll::GetKey(int key_idx) const {
	if (m_keys_valid[key_idx]) {
		return m_keys[key_idx];
	}
	return NULL;
}

const EncryptionKey* KeyRoll::GetActiveKey() const {
	if (m_active_key >= 0 && m_active_key <= MAX_KEY_INDEX) {
		if (m_keys_valid[m_active_key]) {
			return m_keys[m_active_key];
		}
	}
	return NULL;
}

bool KeyRoll::operator=(const KeyRoll& to) {

	m_key_type = to.m_key_type;
	m_key_sz = to.m_key_sz;

	if (!AllocKeys()) {
		return false;
	}

	for (int at = 0; at <= MAX_KEY_INDEX; ++at) {
		if (!m_keys[at] || !to.m_keys[at]){
			m_last_error = colib::string::Format("Key at index %d not exist",
					at);
			return false;
		}
		m_keys[at]->Copy(*to.m_keys[at]);
		m_keys_valid[at] = to.m_keys_valid[at];
	}
	m_active_key = to.m_active_key;
	m_last_roll_time = to.m_last_roll_time;
	m_cur_key_active_time = to.m_cur_key_active_time;
	return true;

}

bool KeyRoll::operator==(const KeyRoll& to) const {
	//TODO: do we need to compare time?
	if (/*m_cur_key_active_time != to.m_cur_key_active_time
	 ||*/m_key_sz != to.m_key_sz || m_active_key != to.m_active_key) {
		return false;
	}
	for (int at = 0; at <= MAX_KEY_INDEX; ++at) {
		// m_key[at] either both NULL or NON-NULL
		if (!m_keys[at] || !to.m_keys[at]) {
			if (m_keys[at] != to.m_keys[at]) {
				return false;
			}
		}
		if (m_keys[at] && to.m_keys[at]) {
			if (m_keys_valid[at] != to.m_keys_valid[at]) {
				return false;
			}

			if (m_keys_valid[at]) {
				// only compare content when key is valid
				if (!(*m_keys[at] == *to.m_keys[at])) {
					return false;
				}
			}
		}
	}
	return true;
}

bool KeyRoll::SetKeySize(unsigned int key_sz) {
	m_key_sz = key_sz;
	m_active_key = -1;
	for (int at = 0; at <= MAX_KEY_INDEX; ++at) {
		m_keys_valid[at] = false;
		if (!m_keys[at] || !m_keys[at]->Reallocate(key_sz))
			return false;
	}
	return true;
}

bool KeyRoll::ApplyCommand(const KeyRollCmd& cmd) {

	uint32_t num_of_keys = cmd.GetKeyNum();
	if (num_of_keys > MAX_KEY_INDEX + 1) {
		m_last_error = "Too many keys";
		return false;
	}
	uint32_t idx;
	m_active_key = cmd.GetActiveKeyIdx();
	for (uint32_t i = 0; i < num_of_keys; i++) {
		idx = cmd.GetKeyStruct(i)->m_idx;
		if (idx > static_cast<unsigned int>(MAX_KEY_INDEX)) {
			m_last_error = "Invalid key index";
			return false;
		}
		if (!m_keys[idx] || !m_keys[idx]->SetData(cmd.GetKeyLen(),
				cmd.GetKeyStruct(i)->m_key)) {
			m_keys_valid[idx] = false;
			m_last_error = "Failed to apply key";
			return false;
		}
		m_keys_valid[idx] = true;
	}
	// Set the key after the "next" to invalid
	m_keys_valid[(m_active_key + 2) % (MAX_KEY_INDEX + 1)] = false;
	return true;
}

bool KeyRoll::ExtractStatus(KeyRollCmd& cmd) const {
	cmd.Reallocate(GetNumValidKeys(), m_key_sz);
	uint32_t key_pos = 0;
	for (int i = 0; i <= MAX_KEY_INDEX; i++) {
		if (m_keys_valid[i]) {
			if (!m_keys[i] || !cmd.AddKey(key_pos++, i, m_keys[i]->GetData())) {
				return false;
			}
		}
	}
	cmd.SetActiveKeyIdx(m_active_key);
	return true;
}

bool KeyRoll::IsKeyrollValid() const {
	return m_active_key >= 0 && m_active_key <= MAX_KEY_INDEX
			&& GetNumValidKeys() > 0;
}

void KeyRoll::Zeroize() {
	for (int i = 0; i <= MAX_KEY_INDEX; i++) {
		m_keys_valid[i] = false;
		if (!m_keys[i]) continue;
		m_keys[i]->Zeroize();
	}
	m_active_key = -1;
	m_last_roll_time = -1;
	m_cur_key_active_time = -1;
}

int KeyRoll::GetNumValidKeys() const {
	int valid_count = 0;
	for (int at = 0; at <= MAX_KEY_INDEX; ++at) {
		if (m_keys[at]) {
			if (m_keys_valid[at]) {
				++valid_count;
			}
		}
	}
	return valid_count;
}

void KeyRoll::Dump(Writable *to) const {
	to->Print("Keyroll: active key = %d\n", m_active_key);
	to->Print("Current key active since: %s",
			m_cur_key_active_time > 0 ?
					ctime(&m_cur_key_active_time) : "N/A\n");
	to->Print("Last roll time: %s",
			m_last_roll_time > 0 ? ctime(&m_last_roll_time) : "N/A\n");
	for (int at = 0; at <= MAX_KEY_INDEX; ++at) {
		to->Print("Key %u, %s\n", at, m_keys_valid[at] ? "VALID" : "INVALID");
		if (!m_keys[at]) {
			to->Print("Key is (Null) at position %u\n", at);
			continue;
		} else {
			m_keys[at]->Dump(to);
		}
	}
}

void KeyRoll::DumpStateOnly(Writable *to) const {
	to->Print("Keyroll: active key = %d\n", m_active_key);
	for (int at = 0; at <= MAX_KEY_INDEX; ++at) {
		to->Print("Key %u, %s\n", at, m_keys_valid[at] ? "VALID" : "INVALID");
	}
}

bool KeyRoll::SetKeyWithChksum(const char *pKeyB64){
	bool bRetVal = false;
	uint32_t ValidKeySize = m_key_sz;
	uint32_t KeyLen;
	uint8_t* pKey;

	Zeroize();
	SetKeySize(ValidKeySize);

	//convert pKeyB64 to bin format
	KeyLen = (unsigned int)BaseEncoder::GetDecode64Len(strlen(pKeyB64));

	if(KeyLen<=0)
	{
		m_last_error = "key is in invalid B64 format";
		return bRetVal;
	}
	if(KeyLen != ValidKeySize + 4)
	{
		m_last_error = "invalid key size";
		return bRetVal;
	}
	pKey = new uint8_t [KeyLen];
	if(!pKey)
	{
		m_last_error = "Out of Memory";
		return bRetVal;
	}

	int decodeLen = BaseEncoder::Decode64(pKey, (int)KeyLen, pKeyB64, strlen(pKeyB64));

	if(decodeLen > 0)
	{
		//validate checksum
		unsigned int Chksum = 0;
		for(unsigned int i=0; (i+4)<=ValidKeySize; i+=4)
		{
			Chksum += FLIP(*(unsigned int*)(pKey + i));
		}
		if(Chksum != FLIP(*(unsigned int*)(pKey + ValidKeySize)))
		{
			bRetVal = false;
			m_last_error = "Failed to validate checksum.";
		}
	}
	else
	{
		bRetVal = false;
		m_last_error = "Failed to convert key to binary.";
	}

	if(bRetVal)
	{
		//save key to m_enc_keyroll.m_keys[0]
		bRetVal = m_keys[0]->SetData(ValidKeySize, pKey);

		if(bRetVal)
		{
			m_active_key = 0;
			m_keys_valid[0]= true;
		}
		else
		{
			m_last_error = "invalid key.";
		}
	}

	//clean up
	memset(pKey, 0, KeyLen);
	delete[] pKey;
	return true;
}

} // end of namespace
