//zeroize_cbk.h

#ifndef ZEROIZE_CBK_H
#define ZEROIZE_CBK_H

#include <utils/string.h>
#include <utils/callback.h>

namespace colib
{

class ZeroizeCbk
{
	public: 
		ZeroizeCbk(colib::string name, Callback cbk);
	   	ZeroizeCbk();
	   	~ZeroizeCbk();

		colib::string m_name;
		Callback m_zeroize_cbk;
};

}	// end of namespace colib

#endif

