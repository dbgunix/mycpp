//zeroizer.cpp

#include <stdlib.h>
#include <string.h>

#include <crypt/zeroize/zeroizer.h>
#include <utils/trace/trace.h>

namespace colib
{

std::set<ZeroizeCbk*> Zeroizer::g_zeroize_cbk_set;

void Zeroizer::Register(ZeroizeCbk *zeroize_cbk)
{
	g_zeroize_cbk_set.insert(zeroize_cbk);
}

void Zeroizer::Unregister(ZeroizeCbk *zeroize_cbk)
{
	g_zeroize_cbk_set.erase(zeroize_cbk);
}

void Zeroizer::ZeroizeAll(ConsoleSession *con)
{
	std::set<ZeroizeCbk*>::iterator iter = g_zeroize_cbk_set.begin();
	while ( iter != g_zeroize_cbk_set.end() )
	{
		ZeroizeCbk *data = *iter;
		if ( con )
		{
		   	con->Print("zeroizing %s(%p)...\n", data->m_name.c_str(), data);
		}
		else
		{
			TRACE(1, "zeroizing %s(%p)...\n", data->m_name.c_str(), data);
		}
		data->m_zeroize_cbk.Dispatch();
		iter++;
	}
}

void Zeroizer::ConCmd(void *ctx, ConsoleSession *con, int argc, char *argv[])
{
	//reviewed by Chao Liu for FIPS
	if ( !con->CSPEnabled() )
	{
		return;
	}
	(void)ctx;
	const char usage[] = "Usage: list|all|zeroize <ID>";

	if ( argc > 1 )
	{
		if ( 0 == strcmp(argv[1], "list") )
		{
			con->Print("ID\t\tName\n");
			con->Print("======================\n");

			std::set<ZeroizeCbk*>::iterator iter = g_zeroize_cbk_set.begin();
			while ( iter != g_zeroize_cbk_set.end() )
			{
				ZeroizeCbk *data = *iter;
				con->Print("%p\t%s\n", data, data->m_name.c_str());
				iter++;
			}
			return;
		}
		else if ( 0 == strcmp(argv[1], "all") )
		{
			TRACE(0, "zeroize console command issued\n");
			ZeroizeAll(con);
			return;
		}
		else if ( 0 == strcmp(argv[1], "zeroize") )
		{
			if ( argc > 2 && ( 0 == strncmp(argv[2], "0x", 2) ) )
			{
				unsigned long id = strtoul(argv[2], 0, 16);
				std::set<ZeroizeCbk*>::iterator iter = g_zeroize_cbk_set.find((ZeroizeCbk*)id);
				if ( iter != g_zeroize_cbk_set.end() )
				{
					ZeroizeCbk *data = (*iter);
					con->Print("zeroizing %s(%p)...\n", data->m_name.c_str(), data);
					data->m_zeroize_cbk.Dispatch();
				}
				else
				{
					con->Print("Can not find zeroize callback\n");
				}
				return;
			}
		}
	}

	con->Print("%s\n", usage);
}

}	// end of namespace colib

