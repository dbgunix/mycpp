//zeroizer.h

#ifndef ZEROIZER_H
#define ZEROIZER_H

#include <utils/system/environ.h>

#ifdef PLATFORM_LINUX
#include <set>
#else
#include <utils/data_struct/dlist.h>
#endif

#include <utils/string.h>
#include <utils/callback.h>
#include <console/session.h>

#include <crypt/zeroize/zeroize_cbk.h>

namespace colib
{

class Zeroizer
{
	public:
		Zeroizer();
		~Zeroizer();

		static void Register(ZeroizeCbk *zeroize_cbk);
		static void Unregister(ZeroizeCbk *zeroize_cbk);

		static  void ZeroizeAll(ConsoleSession *con);
		static void ConCmd(void *ctx, ConsoleSession *con, int argc, char *argv[]);

	private:
		static std::set<ZeroizeCbk*> g_zeroize_cbk_set;
};

}	// end of namespace colib

#endif

