//zeroize_cbk.cpp

#include <crypt/zeroize/zeroize_cbk.h>

#include <crypt/zeroize/zeroizer.h>

namespace colib
{

ZeroizeCbk::ZeroizeCbk()
{
}

ZeroizeCbk::ZeroizeCbk(colib::string name, Callback cbk)
	: m_name(name)
	, m_zeroize_cbk(cbk)
{
	Zeroizer::Register(this);
}

ZeroizeCbk::~ZeroizeCbk()
{
	Zeroizer::Unregister(this);
}

}	// end of namespace colib

