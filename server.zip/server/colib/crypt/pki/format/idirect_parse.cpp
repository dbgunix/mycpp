// idirect_parse.cpp
// vi:set ts=4 sw=4 nowrap:

#include <crypt/pki/format/idirect_parse.h>
#include <utils/Base64.h>

namespace colib
{
	static bool		effect_white(int ch)
	{
		return (
				( ch == ' ' ) || 
				( ch == '\r' ) || 
				( ch == '\n' ) || 
				( ch == '\t' )
			   );
	}
	
	static bool		effect_newl(int ch)
	{
		return ( ch == '\n' );
	}
	
	static bool		is_b64digit(int ch)
	{
		if ( ch < 46 ) return false;
		if ( ch <= 57 )	return true;
		if ( ch < 65 ) return false;
		if ( ch <= 90 )	return true;;
		if ( ch < 97 ) return false;
		if ( ch <= 122 ) return true;
		return false;
	}

	bool		ParseToken(const char **pinp, string &ret, bool until_eol)
	{
		int inch;
		ret.empty();
		//
		// skip whitespace
		// grab non-white characters
begin:

		while ( 0 != (inch = **pinp) )
		{
			++*pinp;
			if ( effect_white(inch) )
				continue;
			break;
		}

		if ( inch == 0 ) return false;

		if ( inch == '#' )
		{
			while ( 0 != (inch = **pinp) )
			{
				++*pinp;
				if ( inch == '\n' )	break;
			}
			goto begin;
		}

		ret += inch;
		while ( 0 != (inch = **pinp) )
		{
			++*pinp;
			if ( until_eol )
			{
				if ( effect_newl(inch) ) break;
			}	
			else
			{
				if ( effect_white(inch) ) break;
			}
			ret += inch;
		}

		if ( until_eol )
		{
			//
			// strip trailing whitespace
			//
			const char *pbegin = ret.c_str();
			const char *pend = pbegin + strlen(pbegin);

			while ( pend > pbegin )
			{
				--pend;
				if ( !effect_white(*pend) )
				{
					++pend;
					break;
				}
			}

			ret.truncate(pend-pbegin);
		}

		return true;
	}


	bool		ParseKeyB64Folded(const char** pinp, EncryptionKey* key, string &err)
	{
		//
		// get tokens containing b64 characters only.
		// if there are any non-b64 characters, fail
		//
		const unsigned int maxlen = 64000;
		unsigned int curlen = 0;
		const char *prev_inp = *pinp;
		const char *current_inp = *pinp;
		bool begun = false;
		string strbuf;
		string cur_tok;
		//
		// get up to 64kbytes of b64 data
		//
		while ( ParseToken(&current_inp, cur_tok) )
		{
			const char *newchp = cur_tok;
			unsigned int newlen = strlen(newchp);

			if ( begun && ( newlen == 0 ) )	break;
			if ( newlen + curlen >= maxlen )
			{
				err = "too much b64 data";
				return false;
			}

			begun = true;

			if ( !is_b64digit(newchp[0]) )
			{
				// back up one token
				current_inp = prev_inp;
				break;
			}

			prev_inp = current_inp;

			strbuf += cur_tok;
			curlen += newlen;
		}
		//
		// parse b64 data
		//
		unsigned int binlen = Base64::GetDecode64Length(curlen);
		if ( !key->Reallocate(binlen) )
		{
			err = "Failed to reset key";
			return false;
		}

		if ( !Base64::Decode64(key->GetData(), (const unsigned char*)strbuf.c_str(), binlen) )
		{
			err = "Failed to parse b64 data";
			return false;
		}

		//update our caller's pointer
		*pinp = current_inp;

		return true;
	}

	bool		FormatKeyB64Folded(string& output, const EncryptionKey* key, string& err)
	{
		output.empty();
	
		//hardcoded 
		const unsigned int linelen = 79;
		const unsigned int maxb64len = 64000;

		//sanity checks
		unsigned int binlen= key->GetLength();
		unsigned int b64len = Base64::GetEncode64Length(binlen);
	
		if ( b64len >= maxb64len )
		{
			err = "too much b64 data";
			return false;
		}
	
		//calculate 
		string b64text;

		if ( !b64text.set_maxlength(b64len) )
		{
			err = string::Format("Failed to setup b64text string, set_maxlength(%d)", b64len);
			return false;
		}

		if ( !Base64::Encode64((unsigned char*)b64text.get_buffer(), key->GetData(), b64len+1, binlen) )
		{
			err = string::Format("Failed to convert to b64, tob64(ptr,ptr,%d,%d)", b64len+1, binlen);
			return false;
		}

		//now break off lines of linelen
		const char* pout = b64text;
		unsigned int curlen = b64len, len = linelen;
		while ( curlen > 0 )
		{
			if ( curlen < linelen )
			len = curlen;
			output.AppendFmt("%s\n", string(pout, len).c_str());
			pout += len;
			curlen -= len;
		}

		output += string("\n",(unsigned int)1);

		return true;
	}

}// end namespace colib

