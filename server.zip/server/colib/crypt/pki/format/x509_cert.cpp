// x509_cert.cpp
// vi:set ts=4 sw=4 nowrap:

#include <crypt/pki/format/x509_cert.h>
#include <crypt/pki/format/x509_rsa_key.h>
#include <crypt/pki/format/x509_csr.h>
#include <crypt/x509utils/ossl_io.h>
#include <crypt/x509utils/ossl_utils.h>

#include <openssl/x509.h>
#include <openssl/x509v3.h>
#include <openssl/pem.h>

namespace colib
{
	x509_Certificate::x509_Certificate()
	{
		m_x509 = 0;
	}
	
	x509_Certificate::~x509_Certificate()
	{
		Clear();
	}
	
	x509_Certificate::x509_Certificate(const x509_Certificate& cert)
	{
		if ( cert.GetX509() )
		{
			m_x509 = X509_dup((X509*)cert.GetX509());
		}
		else
		{
			m_x509 = 0;
		}
	}

	x509_Certificate::x509_Certificate(const X509& x509_cert)
	{
		m_x509 = X509_dup((X509*)&x509_cert);
	}

	bool		x509_Certificate::IsOK() const
	{
		string err;
		return CheckX509(err);
	}

	void		x509_Certificate::Clear()
	{
		if ( m_x509 )
		{
			X509_free(m_x509);
			m_x509 = 0;
		}
	}

	void		x509_Certificate::Zeroize()
	{
		zeroize_x509(m_x509);
	}

	string		x509_Certificate::DumpReadable() const
	{
		string output, err;		
		if ( FormatHumanReadable(output, err) ) return output;
		return "X509 Certificate fail DumpReadable: " + err;
	}
	
	bool		x509_Certificate::XdrDecode(CXDR* xdr, string& err)
	{	
		string data;
		if ( !xdr->XdrStringPacked(data) )
		{
			err = "XDR Decode PEM format string fail";
			return false;
		}
	
		return LoadPEM(data, err);
	}

	bool		x509_Certificate::XdrEncode(CXDR* xdr, string& err) const
	{
		string output;
		if ( !FormatPEM(output, err) ) return false;
		
		if ( !xdr->XdrStringPacked(output) )
		{
			err = "XDR Encode PEM format string fail";
			return false;
		}
	
		return true;	
	}

	bool		x509_Certificate::LoadX509(const X509* x509)
	{
		Clear();	
		if ( !x509 ) return false;
		m_x509 = X509_dup((X509*)x509);
		return m_x509;
	}

	bool		x509_Certificate::CheckX509(string& err) const
	{	
		if ( !m_x509 )
		{
			err = "No X509 certificate";
			return false;
		}
		return true;
	}

	bool		x509_Certificate::GenerateCertificateFromDN(string& err, string* dn, x509_RSAkey& key, string an, unsigned days)
	{
		//
		// "dn" points to a sequence of RelativeDistinguishedName
		// which includes:
		//   subject_name, country_name, province_name, org_name,
		//   org_unit_name, dn_qualifier, serial_number, email_addr
	
		Clear();
		m_x509 = X509_new();
		
		if ( !m_x509 )
		{
			SET_ERROR_HARVEST(err, "Failed to alloc x509");
			return false;
		}

		X509_NAME* pname = X509_get_subject_name(m_x509);
		//
		// DN
		//
		if ( dn[0].is_empty() || !X509_NAME_add_entry_by_NID(pname, NID_commonName, MBSTRING_UTF8, 
					(unsigned char*)dn[0].c_str(), -1, -1, 0) )
		{
			SET_ERROR_HARVEST(err, "Failed to add subject name to cert");
			return false;
		}
	
		if ( !dn[1].is_empty() && !X509_NAME_add_entry_by_NID(pname, NID_countryName, MBSTRING_UTF8,
					(unsigned char *)dn[1].c_str(),	-1, -1, 0) )
		{
			SET_ERROR_HARVEST(err, "Failed to add country name to cert");
			return false;
		}
	
		if ( !dn[2].is_empty() && !X509_NAME_add_entry_by_NID(pname, NID_stateOrProvinceName, MBSTRING_UTF8,
					(unsigned char *)dn[2].c_str(),	-1, -1, 0) )
		{
			SET_ERROR_HARVEST(err, "Failed to add state or province name to cert");
			return false;
		}
	
		if ( !dn[3].is_empty() && !X509_NAME_add_entry_by_NID(pname, NID_organizationName, MBSTRING_UTF8,
					(unsigned char *)dn[3].c_str(), -1, -1, 0) )
		{
			SET_ERROR_HARVEST(err, "Failed to add organization name to cert");
			return false;
		}
	
		if ( !dn[4].is_empty() && !X509_NAME_add_entry_by_NID(pname, NID_organizationalUnitName, MBSTRING_UTF8,
					(unsigned char *)dn[4].c_str(),	-1, -1, 0) )
		{
			SET_ERROR_HARVEST(err, "Failed to add orgnational-unit name to cert");
			return false;
		}
	
		if ( !dn[5].is_empty() && !X509_NAME_add_entry_by_NID(pname, NID_dnQualifier, MBSTRING_UTF8,
					(unsigned char *)dn[5].c_str(),	-1, -1, 0) )
		{
			SET_ERROR_HARVEST(err, "Failed to add distinguished name qualifier to cert");
			return false;
		}
	
		if ( !dn[6].is_empty() && !X509_NAME_add_entry_by_NID(pname, NID_serialNumber, MBSTRING_UTF8,
					(unsigned char *)dn[6].c_str(),	-1, -1, 0) )
		{
			SET_ERROR_HARVEST(err, "Failed to add serial number to cert");
			return false;
		}
	
		if ( !dn[7].is_empty() && !X509_NAME_add_entry_by_NID(pname, NID_pkcs9_emailAddress, MBSTRING_UTF8,
					(unsigned char *)dn[7].c_str(),	-1, -1, 0) )
		{
			SET_ERROR_HARVEST(err, "Failed to add email address to cert");
			return false;
		}

		//
		// Set Subject Alternative Name if necessary
		//
		if ( an != "" )
		{
			X509_EXTENSION* ex = X509V3_EXT_conf_nid(0, 0, NID_subject_alt_name, (char*)an.c_str());
			if ( !ex )
			{
				SET_ERROR_HARVEST(err, "Fail to set alternative name EXTENSION");
				return false;
			}	
			if ( !X509_add_ext(m_x509, ex, -1) )
			{
				SET_ERROR_HARVEST(err, "Fail to add alternative name EXTENSION to X509");
				X509_EXTENSION_free(ex);
				return false;
			}
			X509_EXTENSION_free(ex);
		}
	
		//
		// X509 Extensions
		//
		X509_EXTENSION* ex = X509V3_EXT_conf_nid(0, 0, NID_basic_constraints, (char*)"critical,CA:TRUE");
		if ( !ex )
		{
			SET_ERROR_HARVEST(err, "Fail to set basic constraints EXTENSION");
			return false;
		}
		if ( !X509_add_ext(m_x509, ex, -1) )
		{
			SET_ERROR_HARVEST(err, "Fail to add constraints EXTENSION to X509");
			X509_EXTENSION_free(ex);
			return false;
		}
		X509_EXTENSION_free(ex);

		ex = X509V3_EXT_conf_nid(0, 0, NID_key_usage, (char*)"critical,keyCertSign,cRLSign");
		if ( !ex )
		{
			SET_ERROR_HARVEST(err, "Fail to set key usage EXTENSION");
			return false;
		}	
		if ( !X509_add_ext(m_x509, ex, -1) )
		{
			SET_ERROR_HARVEST(err, "Fail to add key usage EXTENSION to X509");
			X509_EXTENSION_free(ex);
			return false;
		}
		X509_EXTENSION_free(ex);
		//
		// Set Version to X509 V3
		//
		X509_set_version(m_x509, 2);
		//
		// Set Issuer to myself
		//
		X509_set_issuer_name(m_x509, X509_NAME_dup(pname));
		//
		// Valid days
		//
		X509_gmtime_adj(X509_get_notBefore(m_x509), 0);
		X509_gmtime_adj(X509_get_notAfter(m_x509), (long)60*60*24*days);
		//
		// SerialNum
		//
		ASN1_INTEGER_set(X509_get_serialNumber(m_x509), 0);
		//
		// public key portion
		// 
		RSA* prsapub = RSAPublicKey_dup((RSA*)key.GetRSA());
	
		if ( !prsapub )
		{
			SET_ERROR_HARVEST(err, "Failed to extract public portion of key");
			return false;
		}
	
		EVP_PKEY* pkey = EVP_PKEY_new();

		if ( !EVP_PKEY_set1_RSA(pkey, prsapub) )
		{
			SET_ERROR_HARVEST(err, "Failed to add prepared public key to evp");
			EVP_PKEY_free(pkey);
			RSA_free(prsapub);
			return false;
		}

		if ( !X509_set_pubkey(m_x509, pkey) )
		{
			SET_ERROR_HARVEST(err, "Failed to set public key to cert");
			EVP_PKEY_free(pkey);
			RSA_free(prsapub);
			return false;
		}

		RSA_free(prsapub);
		//
		// Sign
		//
		if ( !EVP_PKEY_set1_RSA(pkey, (RSA*)key.GetRSA()) )
		{
			SET_ERROR_HARVEST(err, "Failed to setup rsa key for signing");
			EVP_PKEY_free(pkey);
			return false;
		}
		
		if ( !X509_sign(m_x509, pkey, EVP_sha512()) )
		{
			SET_ERROR_HARVEST(err, "Failed to sign certificate");
			EVP_PKEY_free(pkey);
			return false;
		}
			
		EVP_PKEY_free(pkey);
	
		return true;
	}

	bool		x509_Certificate::GenerateCertificateFromCSR(string& err, x509_CSR& csr, x509_Certificate& ca_cert, x509_RSAkey& ca_key, unsigned serialNum, unsigned days)
	{	
		Clear();
		m_x509 = X509_new();
		
		if ( !m_x509 )
		{			
			SET_ERROR_HARVEST(err, "Failed to alloc x509");
			return false;
		}	
		//
		// COMMENTS: the following code from old implementation, which I have no idea why needed,
		// commented out for now ....
		// 
		/*	
	   	if ( sk_X509_ATTRIBUTE_num(((X509_REQ*)csr.GetX509REQ())->req_info->attributes) != 0 )
		{
			X509_CINF* pcinf= m_x509->cert_info;

			if ( !( pcinf->version = M_ASN1_INTEGER_new() ) )
			{
				SET_ERROR_HARVEST(err, "Failed to alloc ans1 integer");
				return false;
			}
	
			if ( !ASN1_INTEGER_set(pcinf->version, 2) )
			{
				SET_ERROR_HARVEST(err, "Failed to set version");
				return false;
			}
		}
		*/
		//
		// Copy Subject Name from CSR
		//		
		X509_NAME* csr_subject_name = csr.GetSubjectName(err);
		if ( !csr_subject_name ) return false;
		X509_set_subject_name(m_x509, csr_subject_name);
		//
		// Copy X509 Extensions from CSR
		//
		STACK_OF(X509_EXTENSION)* exts = X509_REQ_get_extensions((X509_REQ*)csr.GetX509REQ());
		for ( int i = 0; i < X509v3_get_ext_count(exts); i++ )
		{
			X509_EXTENSION* ext = X509v3_get_ext(exts, i);
			X509_add_ext(m_x509, ext, -1);
		}	
		//
		// Set Version to X509 V3
		//
		X509_set_version(m_x509, 2);	
		//
		// Set Issuer Name from CA cert
		//
		X509_NAME* issuer_name = ca_cert.GetSubjectName(err);
		if ( !issuer_name ) return false;
		X509_set_issuer_name(m_x509, issuer_name);	
		//
		// Valid days
		//
		X509_gmtime_adj(X509_get_notBefore(m_x509), 0);
		X509_gmtime_adj(X509_get_notAfter(m_x509), (long)60*60*24*days);
		//
		// SerialNum
		//
		ASN1_INTEGER_set(X509_get_serialNumber(m_x509), serialNum);
		//
		// public key portion
		//
		EVP_PKEY* pkey = csr.GetPublicKey(err);
		if ( !pkey ) return false;

		if ( !csr.SelfVerify(err) )
		{	
			EVP_PKEY_free(pkey);
			return false;
		}	
	
		if ( !X509_set_pubkey(m_x509, pkey) )
		{
			SET_ERROR_HARVEST(err, "Failed to set public key to cert");
			EVP_PKEY_free(pkey);
			return false;
		}
		EVP_PKEY_free(pkey);
		//
		// Sign
		//
		pkey = EVP_PKEY_new();
		if ( !EVP_PKEY_set1_RSA(pkey, (RSA*)ca_key.GetRSA()) )
		{	
			SET_ERROR_HARVEST(err, "Failed to setup rsa key for signing");
			EVP_PKEY_free(pkey);
			return false;
		}
		
		if ( !X509_sign(m_x509, pkey, EVP_sha512()) )
		{
			SET_ERROR_HARVEST(err, "Failed to sign certificate");
			EVP_PKEY_free(pkey);
			return false;
		}
			
		EVP_PKEY_free(pkey);
	
		return true;
	}
	//
	// Note: the returned RSA must be freed with RSA_free
	//
	RSA*		x509_Certificate::GetRSA(string& err) const
	{
		if ( !CheckX509(err) ) return 0;

		EVP_PKEY* pkey = X509_get_pubkey(m_x509);
		if ( !pkey )
		{
			SET_ERROR_HARVEST(err, "Failed to get pubkey from cert");
   			return 0;
		}

		if ( EVP_PKEY_RSA != EVP_PKEY_type(pkey->type) )
		{
			err = "pubkey is not RSA";
			EVP_PKEY_free(pkey);
			return 0;
		}

		RSA* prsa = EVP_PKEY_get1_RSA(pkey);
		EVP_PKEY_free(pkey);
	
		if ( !prsa )
		{
			SET_ERROR_HARVEST(err, "Failed to extract RSA key from cert");
			return 0;
		}
	
		return prsa;
	}

	bool		x509_Certificate::GetSerialNumber(long& output, string& err) const
	{
		if ( !CheckX509(err) ) return false;
	
		output = ASN1_INTEGER_get(X509_get_serialNumber(m_x509));
	
		if ( output <= 0 )
		{
			SET_ERROR_HARVEST(err, "Serial number error");
			return false;
		}
	
		return true;
	}

	bool		x509_Certificate::GetSerialNumber(string& output, string& err) const
	{
		long serial;
		if ( !GetSerialNumber(serial, err) ) return false;
		output = string::Format("%ld", serial);
		return true;
	}

	bool		x509_Certificate::operator==(const x509_Certificate& cert) const
	{
		return ( X509_cmp(m_x509, cert.m_x509) == 0 );
	}

	//
	// Assign can be failed, use GetX509() to verify if succeed or not
	//
	x509_Certificate&	x509_Certificate::operator=(const x509_Certificate& cert)
	{
		if ( !LoadX509(cert.m_x509) ) Clear();
		return *this;
	}

	bool		x509_Certificate::FormatHumanReadable(string& output, string& err) const
	{
		if ( !CheckX509(err) ) return false;
	
		BIO* bio = CreateWriteOnlyStringBIO(output, err);
	   	if ( !bio ) return false;
		bool ret = X509_print(bio, m_x509);
		if ( !ret ) SET_ERROR_HARVEST(err, "Failed to format cert");
		BIO_free(bio);
		return ret;
	}

	X509_NAME*	x509_Certificate::GetSubjectName(string& err) const
	{	
		X509_NAME* pname = X509_get_subject_name(m_x509);
		if ( !pname )
		{
			SET_ERROR_HARVEST(err, "Failed to extract subject name");
			return 0;
		}
		return pname;
	}

	bool		x509_Certificate::GetSubject(string& output, string& err) const
	{
		if ( !CheckX509(err) ) return false;
		
		X509_NAME* pname = GetSubjectName(err);
		if ( !pname ) return false;

		BIO* bio = CreateWriteOnlyStringBIO(output, err);
	   	if ( !bio ) return false;

		bool ret = X509_NAME_print_ex(bio, pname, 0, XN_FLAG_ONELINE);
		if ( !ret ) SET_ERROR_HARVEST(err, "Failed to format subject");
		BIO_free(bio);
		return ret;
	}
	
	bool		x509_Certificate::GetX509Name(X509_NAME* pname, int nid, string& output, string& err) const
	{
		int index = X509_NAME_get_index_by_NID(pname, nid, -1);

		if ( index < 0 )
		{
			char asciiName[128]; // 128 bytes is enough
			asciiName[0] = 0;
			//
			// Even though X509_NAME_oneline takes care of ending '\0', for safety, 
			// still reserve one character of space in the buffer
			X509_NAME_oneline(pname, asciiName, sizeof(asciiName) - 1);		
			err = string::Format("%s does not contain the field name requested", asciiName);
			return false;
		}

		ASN1_STRING* data = X509_NAME_ENTRY_get_data(X509_NAME_get_entry(pname, index));

		if ( !output.set_maxlength(data->length) )
		{
			err = string::Format("Common name too long (len = %d)",	data->length);
			return false;
		}

		output = string((const char*)data->data, (unsigned)data->length);
		return true;
	}

	bool		x509_Certificate::GetSubjectCommonName(string& output, string& err) const	
	{
		output.clear();
		if ( !CheckX509(err) ) return false;
		X509_NAME* pname = GetSubjectName(err);
		if ( !pname ) return false;
		if ( !GetX509Name(pname, NID_commonName, output, err) ) return false;
		return true;
	}
	
	bool		x509_Certificate::GetSubjectOrganization(string& output, string& err) const
	{
		if ( !CheckX509(err) ) return false;	
		X509_NAME* pname = GetSubjectName(err);
		if ( !pname ) return false;
		if ( !GetX509Name(pname, NID_organizationName, output, err) ) return false;
		return true;
	}
	
	bool		x509_Certificate::GetCertDates(string& range, string& err, bool expirationOnly) const
	{
		if ( !CheckX509(err) ) return false;

		if ( !X509_get_notBefore(m_x509) || !X509_get_notAfter(m_x509) )
		{
			err = "No \"not before\" or \"not after\" info";
			return false;
		}
	
		BIO* bio = CreateWriteOnlyStringBIO(range, err);	
		if ( !bio ) return false;

		bool ret = false;
		if ( expirationOnly )
		{
			ret = ASN1_TIME_print(bio, X509_get_notAfter(m_x509));
		}
		else
		{
			ret = 
				BIO_write(bio, "[", 1) && 
				ASN1_TIME_print(bio, X509_get_notBefore(m_x509)) && 
				BIO_write(bio, ", ", 2) && 
				ASN1_TIME_print(bio, X509_get_notAfter(m_x509)) && 
				BIO_write(bio, "]", 1);
		}
		
		if ( !ret ) SET_ERROR_HARVEST(err, "Failed to format date range");
		BIO_free(bio);
		return ret;
	}

	bool		x509_Certificate::CheckDates(string& status, string& err, time_t now, int offset, bool check_expiration_only) const
	{
		if ( !CheckX509(err) ) return false;
	
		time_t checkTime = now;
		if ( !now ) time(&checkTime);

		bool ret = true;

		if ( !check_expiration_only ) 
		{
			if ( !X509_get_notBefore(m_x509) )
			{
				err = "No \"not before\" info";
				return false;
			}
			checkTime += offset;
			if ( X509_cmp_time(X509_get_notBefore(m_x509), &checkTime) > 0 )
			{
				status = "x509_Certificate not yet valid";
				ret = false;	
			}
			checkTime -= offset;
		}	

		if ( !X509_get_notAfter(m_x509) )
		{
			err = "No \"not after\" info";
			return false;
		}
		if ( X509_cmp_time(X509_get_notAfter(m_x509), &checkTime) <= 0 )
		{
			status = "x509_Certificate already expired";
			ret = false;	
		}

		if ( ret ) 
		{
			status = "x509_Certificate is in valid date range";
		} 
		else 
		{
			string range;
			string err2;
			if ( GetCertDates(range, err2) ) 
			{
				status += string::Format(": x509_Certificate valid between %s but the host's clock is %s GMT",
						range.c_str(), asctime(gmtime(&checkTime))); 
			}
		}
	
		return ret;
	}

	bool		x509_Certificate::GetCertificateHash(unsigned char* hash, unsigned int& len, string& err) const
	{
		if ( !CheckX509(err) ) return false;

		if ( len < SHA512_DIGEST_LENGTH ) 
		{
			err = "Hash buffer size not enough";
			return false;
		}

		len = SHA512_DIGEST_LENGTH;
		if ( !X509_digest(m_x509, EVP_sha512(), hash, &len) )
		{
			SET_ERROR_HARVEST(err, "Failed to get cert hash");
			return false;
		}

		return true;
	}
	
	X509_NAME*	x509_Certificate::GetIssuerName(string& err) const
	{
		X509_NAME* pname = X509_get_issuer_name(m_x509);
	
		if ( !pname )
		{
			SET_ERROR_HARVEST(err, "Failed to extract issuer name");
			return 0;
		}
		return pname;
	}
	
	bool		x509_Certificate::GetIssuer(string& output, string& err) const
	{
		if ( !CheckX509(err) ) return false;

		X509_NAME* pname =  GetIssuerName(err);
		if ( !pname ) return false;

		BIO* bio = CreateWriteOnlyStringBIO(output, err);
		if ( !bio ) return false;
	
		bool ret = X509_NAME_print_ex(bio, pname, 0, XN_FLAG_ONELINE);
		if ( !ret ) SET_ERROR_HARVEST(err, "Failed to format issuer");
		BIO_free(bio);
		return ret;
	}

	bool		x509_Certificate::GetIssuerCommonName(string& output, string& err) const
	{
		output.clear();
		if ( !CheckX509(err) ) return false;
		X509_NAME* pname = GetIssuerName(err);
		if ( !pname ) return false;
		if ( !GetX509Name(pname, NID_commonName, output, err) ) return false;
		return true;
	}

	bool		x509_Certificate::IsSelfSigned() const
	{	
		string issuer;
		string subject;
		string err;
	
		return ( 
				GetSubject(subject, err) &&
				GetIssuer(issuer, err) &&
				( subject == issuer )
			   );
	}

	bool		x509_Certificate::MatchRSA(const RSA* rsa, string& err) const
	{
		if ( !rsa ) return false;
	
		RSA* my_rsa = GetRSA(err);
		if ( !my_rsa ) return false;

		return (
				( BN_cmp(rsa->n, my_rsa->n) == 0 ) &&
				( BN_cmp(rsa->e, my_rsa->e) == 0 )
			   );
	}

	//
	// PEM format
	//
	bool		x509_Certificate::FormatPEM(string& output, string& err) const
	{	
		if ( !CheckX509(err) ) return false;
		BIO* bio = CreateWriteOnlyStringBIO(output, err);
		if ( !bio ) return false;
		bool ret = PEM_write_bio_X509(bio, (X509*)GetX509());
		if( !ret ) SET_ERROR_HARVEST(err, "Failed to format pem cert");
		BIO_free(bio);
		return ret;
	}

	bool		x509_Certificate::LoadPEM(string data, string& err)
	{
		Clear();

		BIO* pbio = BIO_new_mem_buf((void*)data.c_str(), -1);
		if ( !pbio )
		{
			SET_ERROR_HARVEST(err, "Failed to create BIO");
			return false;
		}
	
		bool ret = PEM_read_bio_X509(pbio, &m_x509, 0, (void*)NO_PASSWORD);
		if ( !ret ) SET_ERROR_HARVEST(err, "Failed to parse PEM cert");
		BIO_free(pbio);
		return ret;
	}

	//
	// DER format
	//	
	bool		x509_Certificate::FormatDER(char* data, unsigned& len, string& err) const
	{
		if ( !CheckX509(err) ) return false;
	
		colib::XdrEncode en(data, len);
		BIO* bio = CreateWriteOnlyXDRBIO(&en, err);
		if ( !bio ) return false;
		bool ret = i2d_X509_bio(bio, m_x509);
		if ( !ret )	SET_ERROR_HARVEST(err, "Failed to format DER cert to XDR");
		BIO_free(bio);
		len = en.GetLength();
		return ret;
	}

	bool		x509_Certificate::LoadDER(char* data, unsigned len, string& err)
	{
		Clear();
		m_x509 = X509_new();
		if ( !m_x509 )
		{
			SET_ERROR_HARVEST(err, "Failed to alloc x509");
			return false;
		}

		colib::XdrDecode en(data, len);
		BIO* bio = CreateReadOnlyXDRBIO(&en, err);
		if ( !bio ) return false;
		d2i_X509_bio(bio, &m_x509);
		bool ret =  ( m_x509 != NULL );
		if ( !ret ) SET_ERROR_HARVEST(err, "Failed to parse DER cert from XDR");
		BIO_free(bio);
		return ret;
	}

}//end namespace colib

