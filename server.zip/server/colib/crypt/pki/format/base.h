// base.h
// vi:set ts=4 sw=4 nowrap:

#ifndef PKI_FORMAT_BASE_H_ALREADY_INCLUDED
#define PKI_FORMAT_BASE_H_ALREADY_INCLUDED

#include <utils/string.h>
#include <utils/xdr.h>

namespace colib
{
	//
	// Base class for all PKI formats
	//
	class pki_base
	{
		public:

									pki_base() {};
			virtual					~pki_base() {};

			// 
			// Type (which is defined in const.h)
			//
			virtual const char*		GetType() const = 0;
			//
			// IsOK
			//
			virtual bool			IsOK() const = 0;
			//
			// Xdr Decode
			//
			virtual bool			XdrDecode(CXDR* xdr, string& err) = 0;
			//
			// Xdr Encode
			//
			virtual bool			XdrEncode(CXDR* xdr, string& err) const = 0;
			//
			// Zeroize
			//
			virtual void			Zeroize() = 0;
			//
			// Clear
			//
			virtual void			Clear() = 0;
			//
			// Dump
			//
			virtual string			DumpReadable() const = 0;
	};

	bool	CopyString2Buffer(char* buf, unsigned int& buf_len, string& source, string& err);

}//end namespace colib


#endif

