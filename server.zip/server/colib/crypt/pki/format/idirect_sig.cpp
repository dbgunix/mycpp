// idirect_sig.cpp
// vi:set ts=4 sw=4 nowrap:

#include <crypt/pki/format/idirect_sig.h>
#include <crypt/pki/format/idirect_parse.h>
#include <crypt/sha/sha.h>
#include <crypt/asymif/rsaif.h>

namespace colib
{

	SigBase::SigBase()
	{
	}
	
	SigBase::SigBase(const idirect_pki& to): idirect_pki(to)
	{
	}
	SigBase::~SigBase()
	{
	}

	bool			SigBase::IsOK() const
	{
		return !is_empty();
	}

	bool			SigBase::is_empty() const
	{	
		return m_algorithm.is_empty() || (  m_signature_binary.GetLength() == 0 );
	}

	SigBase&		SigBase::operator=(const SigBase& to)
	{
		*((idirect_pki*)this) = to;	
		m_signer = to.GetSigner();
		m_algorithm = to.GetAlgorithm();
		m_signature_binary.Copy(to.GetSignature());
		return *this;
	}

	void			SigBase::Zeroize()
	{
		idirect_pki::Zeroize();
		m_signer.clear();
		m_algorithm.clear();
		m_signature_binary.Zeroize();
	}

	void			SigBase::Clear()
	{	
		idirect_pki::Clear();
		m_signer.clear();
		m_algorithm.clear();
		m_signature_binary.Zeroize();	
	}

	bool			SigBase::operator==(const SigBase& to)
	{
		return 
			( 
			 ( *((idirect_pki*)this) == to ) &&
			 ( m_signer == to.GetSigner() ) &&
			 ( m_algorithm == to.GetAlgorithm() ) &&
			 ( m_signature_binary == to.GetSignature() )
			);
	}

	bool			SigBase::ParseTag(string tag, const char** pdata, string& err)
	{	
		bool ret;

		if ( tag == IDIRECT_TYPE )
		{
			ret = ParseToken(pdata, m_algorithm);
			if ( !ret ) err = "Missing type record";
		}
		else if ( tag == IDIRECT_SIGNER )
		{
			ret = ParseToken(pdata, m_signer, true);
			if ( !ret ) err = "Missing signer record";
		}
		else ret = idirect_pki::ParseTag(tag, pdata, err);

		return ret;
	}

	bool			SigBase::ParsePKI(const char** pdata, string& err)
	{
		if ( m_algorithm.is_empty() )
		{
			err = "Missing algorithm type, cannot continue";
			return false;
		}

		return ParseKeyB64Folded(pdata, &m_signature_binary, err);
	}

	bool			SigBase::FormatTag(string& data, string& err) const
	{
		bool ret = idirect_pki::FormatTag(data, err);
	
		if ( m_algorithm.is_empty() ) 
		{
			err = "Missing algorithm type, cannot continue";
			return false;
		}
		if ( ret ) data.AppendFmt("%s %s\n", IDIRECT_TYPE, m_algorithm.c_str());

		if ( ret && !m_signer.is_empty() ) data.AppendFmt("%s %s\n", IDIRECT_SIGNER, m_signer.c_str() );

		return ret;
	}

	bool			SigBase::FormatPKI(string& data, string& err) const
	{	
		if ( !m_signature_binary.GetLength() )
		{
			err = "SigBase is empty";
			return false;
		}

		string b64d;
		if ( !FormatKeyB64Folded(b64d, &m_signature_binary, err) ) return false;
		data += b64d;
		return true;
	}

	bool			SigBase::MinimalXdrProc(CXDR* xdr)
	{
		if ( xdr->GetOp() == CXDR::XDR_DECODE ) Clear();
		return xdr->XdrStringPadded(m_algorithm) && m_signature_binary.XdrProc(xdr);
	}

	bool			SigBase::SignRawData(const unsigned char* data, unsigned len, AsymIf* pkeyif, string algorithm, string& err)
	{
		m_algorithm = algorithm;
		//
		// pkeyif must be in status
		//
		if ( pkeyif->GetStatus() != AsymIf::STATUS_KEYPAIR )
		{
			err = "Pkey i/f must have private key to sign";
			return false;
		}
		//
		// setup space for the signature
		//
		if ( !m_signature_binary.Reallocate(pkeyif->GetRequiredSpace()) )
		{
			err = "Out of memory";
			return false;
		}
		//
		// run the pkey alg over the signature
		//
		if ( -1 == pkeyif->private_encrypt(len, data, m_signature_binary.GetData()) )
		{
			err = pkeyif->GetLastError();
			return false;
		}

		return true;
	}

	bool			SigBase::SignObject(string& err, unsigned char* data, unsigned int length, AsymIf* pkeyif)
	{
		return SignObjects(err, pkeyif, 1, data, length);
	}

	bool			SigBase::VerifyRawData(const unsigned char* data, unsigned len, AsymIf* pkeyif, string& err) const
	{
		if ( 
			( pkeyif->GetStatus() != AsymIf::STATUS_PUBKEY ) &&
			( pkeyif->GetStatus() != AsymIf::STATUS_KEYPAIR)
		   )
		{
			err = "Pkey i/f must have public key to verify";
			return false;
		}
		//
		// make room for the decrypt buffer
		//
		EncryptionKey decrypt_buffer;
		if ( !decrypt_buffer.Reallocate(pkeyif->GetRequiredSpace()) )
		{
			err = "Out of memory";
			return false;
		}
	
		unsigned char* dbuf = decrypt_buffer.GetData();
		int decrypt_len;
		//
		// decrypt the signature
		//
		decrypt_len = pkeyif->public_decrypt(m_signature_binary.GetLength(), m_signature_binary.GetData(), dbuf);
		if ( -1 == decrypt_len )
		{
			err = pkeyif->GetLastError();
			return false;
		}

		if ( decrypt_len != (int)len )
		{
			err = "Decrypt output incorrect size";
			return false;
		}

		if ( 0 == memcmp(data, dbuf, len) ) return true;
		else
		{
			err = "Signature fail verification";
			return false;
		}
	}


	bool 			SigBase::VerifyObject(string& err, unsigned char* data, unsigned int length, AsymIf* pkeyif) const
	{
		return VerifyObjects(err, pkeyif, 1, data, length);
	}

}//end namespace colib

