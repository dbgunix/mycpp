// x509_crl.h
// vi:set ts=4 sw=4 nowrap:

#ifndef X509_CRL_H_ALREADY_INCLUDED
#define X509_CRL_H_ALREADY_INCLUDED

#include <crypt/pki/format/base.h>
#include <crypt/pki/format/const.h>

#include <openssl/x509.h>

namespace colib
{
	class x509_RSAkey;
	class x509_Certificate;

	class x509_RevocationList : public pki_base
	{
		public:
		
									x509_RevocationList();
									x509_RevocationList(const x509_RevocationList& crl);
									x509_RevocationList(const X509_CRL& x509_crl);
			virtual					~x509_RevocationList();
			//
			// Implementation of pure virtual functions in base
			//
			virtual const char*		GetType() const { return PKI_TYPE_X509_CRL; } 	
			virtual bool			IsOK() const;
			virtual bool			XdrDecode(CXDR* xdr, string& err);
			virtual bool			XdrEncode(CXDR* xdr, string& err) const;
			virtual void			Zeroize();
			virtual void			Clear();
			virtual string			DumpReadable() const;
			//
			// Other functions
			//
			bool					operator==(const x509_RevocationList& crl) const;
			x509_RevocationList&	operator=(const x509_RevocationList& crl);

			bool					LoadX509CRL(const X509_CRL* crl);
			const X509_CRL*			GetX509CRL() const { return m_crl; }

			bool					RevokeCertificate(const x509_Certificate& cert, string& err);
			bool					IsCertificateRevoked(const x509_Certificate& cert, string& err) const;
			bool					Sign(x509_RSAkey& key, const x509_Certificate& cert, string& err);

			bool					GetIssuerCommonName(string& output, string& err) const;
			bool					GetLastUpdateTime(string& output, string& err) const;
			// if now = 0, use the system time
			bool					CheckDates(string& status, string& err, time_t now = 0, int offset = 0) const;
	
			bool					LoadPEM(string data, string& err);
			bool					FormatPEM(string& output, string& err) const;

			bool					LoadDER(char* data, unsigned len, string& err);
			bool					FormatDER(char* data, unsigned& len, string& err) const;

			bool					FormatHumanReadable(string& output, string& err) const;

		protected:	

			bool					CheckCRL(string& err) const;

		protected:

			X509_CRL*				m_crl;
	};
		
}//end namespace colib


#endif

