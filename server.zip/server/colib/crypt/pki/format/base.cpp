#include <crypt/pki/format/base.h>

#include <string.h>

namespace colib
{
	bool	CopyString2Buffer(char* buf, unsigned int& buf_len, string& data, string& err)
	{	
		if ( buf_len < (data.get_length()+1) )
		{
			err = "Not enough buffer space";
			return false;
		}

		buf_len = data.get_length();
		memcpy(buf, data.c_str(), buf_len);
		buf[buf_len] = '\0';

		return true;
	}

}//end namespace colib
