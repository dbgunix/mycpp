// x509_cert.h
// vi:set ts=4 sw=4 nowrap:

#ifndef X509_CERT_H_ALREADY_INCLUDED
#define X509_CERT_H_ALREADY_INCLUDED

#include <crypt/pki/format/base.h>
#include <crypt/pki/format/const.h>

#include <openssl/x509.h>

namespace colib
{	
	class x509_RSAkey;
	class x509_CSR;

	class x509_Certificate : public pki_base
	{
		public:
									x509_Certificate();
									x509_Certificate(const x509_Certificate& cert);
									x509_Certificate(const X509& x509_cert);
			virtual					~x509_Certificate();
			//
			// Implementation of pure virtual functions in base
			//	
			virtual const char*		GetType() const { return PKI_TYPE_X509_CERT; }
			virtual bool			IsOK() const;
			virtual bool			XdrDecode(CXDR* xdr, string& err);
			virtual bool			XdrEncode(CXDR* xdr, string& err) const;
			virtual void			Zeroize();
			virtual void			Clear();
			virtual string			DumpReadable() const;
			//
			// Other functions
			//	
			bool					operator==(const x509_Certificate& cert) const;
			x509_Certificate&		operator=(const x509_Certificate& cert);
	
			bool					LoadX509(const X509* x509);	
			const X509*				GetX509() const { return m_x509; }

			//
			// Function to generate SelfSigned Certificate from "DN", used by 
			// 		1. Root CA Certificate generation 
			// 		2. Initial SelfSigned Certificate
			//
			bool					GenerateCertificateFromDN(string& err, string* dn, x509_RSAkey& key, string an = "", unsigned days = 365*10);
			//
			// Function to generate Certificate from CSR, used by
			// 		1. Untrusted CA CSR
			// 		2. Encipher CSR
			//
			bool					GenerateCertificateFromCSR(string& err, x509_CSR& csr, x509_Certificate& ca_cert, x509_RSAkey& ca_key, unsigned serialNum, unsigned days = 365*10);
			//
			// Note: the returned RSA must be freed with RSA_free
			//
			RSA* 					GetRSA(string& err) const;

			bool					MatchRSA(const RSA* rsa, string& err) const;
			bool					IsSelfSigned() const;
					
			X509_NAME*				GetSubjectName(string& err) const;
			bool					GetSubject(string& output, string& err) const;
			bool					GetSubjectOrganization(string& output, string& err) const;
			bool					GetSubjectCommonName(string& output, string& err) const;
			
			bool					GetIssuer(string& output, string& err) const;
			bool					GetIssuerCommonName(string& output, string& err) const;
			
			bool					GetCertificateHash(unsigned char* hash, unsigned int& len, string& err) const;
			
			bool					GetSerialNumber(long& output, string& err) const;
			bool					GetSerialNumber(string& output, string& err) const;
		
			bool					GetCertDates(string& range, string& err, bool expirationOnly = false) const;
			//
			// if now = 0, use the system time
			//
			bool					CheckDates(string& status, string& err, time_t now = 0, int offset = 0, bool check_expiration_only = false) const;
	
			bool					LoadPEM(string data, string& err);
			bool					FormatPEM(string& output, string& err) const;

			bool					LoadDER(char* data, unsigned len, string& err);
			bool					FormatDER(char* data, unsigned& len, string& err) const;

			bool					FormatHumanReadable(string& output, string& err) const;

		protected:

			bool					CheckX509(string& err) const;

			X509_NAME*				GetIssuerName(string& err) const;
			bool					GetX509Name(X509_NAME* pname, int nid, string& output, string& err) const;

		protected:

			X509*					m_x509;			
	};

}//end namespace colib


#endif

