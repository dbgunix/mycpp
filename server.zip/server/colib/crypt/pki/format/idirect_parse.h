// idirect_parse.h
// vi:set ts=4 sw=4 nowrap:

#ifndef IDIRECT_PARSE_H_ALREADY_INCLUDED
#define IDIRECT_PARSE_H_ALREADY_INCLUDED

#include <utils/string.h>
#include <crypt/key/key.h>

namespace colib
{
	//	
	// parse/format, newlines end records.
	// skips whitespace. first non-b64 nonwhite-char of a line terminates
	//
	bool	ParseToken(const char** pinp, string& ret, bool until_eol = false);
	bool	ParseKeyB64Folded(const char** pinp, EncryptionKey* key, string& err);
	bool	FormatKeyB64Folded(string& output, const EncryptionKey* key, string& err);	

}//end namespace colib


#endif

