// idirect_krec.cpp

#include <crypt/pki/format/idirect_krec.h>
#include <crypt/pki/format/idirect_parse.h>
#include <crypt/pki/format/x509_rsa_key.h>
#include <crypt/pki/format/x509_cert.h>
#include <crypt/asymif/rsaif.h>
#include <crypt/x509utils/ossl_utils.h>

namespace colib
{
	KeyRecord::KeyRecord()
	{
	}

	KeyRecord::KeyRecord(const KeyRecord& to)
		:
		idirect_pki(to)	
	{
		m_algorithm = to.GetAlgorithm();
		m_key.Copy(to.GetKey());
	}

	KeyRecord&		KeyRecord::operator=(const KeyRecord& to)
	{	
		*((idirect_pki*)this) = to;
		m_algorithm = to.GetAlgorithm();
		m_key.Copy(to.GetKey());
		return *this;
	}

	KeyRecord::~KeyRecord()
	{
	}

	bool			KeyRecord::IsOK() const
	{
		return !is_empty();
	}

	void			KeyRecord::Zeroize()
	{
		idirect_pki::Zeroize();
		m_algorithm.clear();
		m_key.Zeroize();
	}

	void			KeyRecord::Clear()
	{
		idirect_pki::Clear();
		m_algorithm.clear();
		m_key.Zeroize();
	}

	bool			KeyRecord::operator==(const KeyRecord& key_record)
	{
		return 
			( 
			 ( *((idirect_pki*)this) == key_record ) &&
			 ( m_algorithm == key_record.GetAlgorithm() ) &&
			 ( m_key == key_record.GetKey() )
			);
	}
	
	bool			KeyRecord::ParseTag(string tag, const char** pdata, string& err)
	{	
		bool ret;

		if ( tag == IDIRECT_TYPE )
		{
			ret = ParseToken(pdata, m_algorithm);
			if ( !ret ) err = "Missing type record";
		}
		else ret = idirect_pki::ParseTag(tag, pdata, err);

		return ret;
	}

	bool			KeyRecord::ParsePKI(const char** pdata, string& err)
	{
		if ( m_algorithm.is_empty() )
		{
			err = "Missing algorithm type, cannot continue";
			return false;
		}

		return ParseKeyB64Folded(pdata, &m_key, err);
	}

	bool			KeyRecord::FormatTag(string& data, string& err) const
	{
		bool ret = idirect_pki::FormatTag(data, err);

		if ( m_algorithm.is_empty() ) 
		{
			err = "Missing algorithm type, cannot continue";
			return false;
		}

		if ( ret ) data.AppendFmt("%s %s\n", IDIRECT_TYPE, m_algorithm.c_str());

		return ret;
	}

	bool			KeyRecord::FormatPKI(string& data, string& err) const
	{
		if ( !m_key.GetLength() )
		{
			err = "Key is empty";
			return false;
		}

		string b64d;
		if ( !FormatKeyB64Folded(b64d, &m_key, err) ) return false;
		data += b64d;
		return true;
	}

	bool			KeyRecord::LoadKeyFromAsym(AsymIf* pkeyif, string& err, bool public_only)
	{
		int status = pkeyif->GetStatus();
		
		bool to_continue = false;

		if ( status == AsymIf::STATUS_KEYPAIR )
		{
			to_continue = true;
		}
		else if ( status == AsymIf::STATUS_PUBKEY )
		{
			if ( !public_only )
			{
				err = "Asym i/f has no priavte key";
			}
			else to_continue = true;
		}
		else
		{
			err = "Asym i/f has no keys";
		}

		if ( !to_continue ) return false;

		if ( !public_only )
		{
			m_algorithm = IDIRECT_RSA_PRIVKEY;

			if ( !pkeyif->GetPrivateKey(&m_key) )
			{
				err = pkeyif->GetLastError();
				return false;
			}
		}
		else
		{
			m_algorithm = IDIRECT_RSA_PUBKEY;

			if ( !pkeyif->GetPublicKey(&m_key) )
			{
				err = pkeyif->GetLastError();
				return false;
			}
		}

		return true;
	}

	bool			KeyRecord::ApplyKeytoAsym(AsymIf* pkeyif, string& err)
	{
		if ( !m_key.GetLength() )
		{
			err = "Key is empty";
			return false;
		}
	
		if ( m_algorithm == IDIRECT_RSA_PRIVKEY )
		{
			if ( !pkeyif->SetPrivateKey(&m_key) )
			{
				err = pkeyif->GetLastError();
				return false;
			}
		}
		else if ( m_algorithm == IDIRECT_RSA_PUBKEY )
		{
			if ( !pkeyif->SetPublicKey(&m_key) )
			{
				err = pkeyif->GetLastError();
				return false;
			}
		}	
		else
		{
			err = "I am not an asymmetric key, cannot apply";
			return false;
		}

		return true;
	}
	
	bool			KeyRecord::is_empty() const
	{	
		//
		// COMMENTS: I list the old implementation below, which I don't understand the logic
		// 
		//	return !m_algorithm.is_empty() && m_key.get_length();
		//
		return m_algorithm.is_empty() || (  m_key.GetLength() == 0 );
	}

	bool			KeyRecord::LoadPublicKeyFromX509Certificate(const x509_Certificate* cert, string& err)
	{
		if ( !cert ) 
		{
			err = "Invalid x509 Certificate";
			return false;
		}
	
		string name;
		if ( !cert->GetSubject(name, err) )
		{
			err = "Failed to get cert subject: " + err;
			return false;
		}
		idirect_pki::SetName(name);

		string comment;
		if ( !cert->GetIssuer(comment, err) )
		{
			err = "Failed to get cert issuer: " + err;
			return false;
		}
		comment = "Certificate, Issuer: " + comment;
		idirect_pki::SetComment(comment);

		string err1;
		RSA* prsa = cert->GetRSA(err1);
		if ( prsa )
		{
			m_algorithm = IDIRECT_RSA_PUBKEY;
			bool ret = apply_publickey_to(prsa, &m_key);
			RSA_free(prsa);
			if ( !ret )
			{
				err = "Failed to apply RSA key from x509 Certificate";
				return false;
			}
			return true;
		}
		else
		{
			err = "Failed to get RSA key from x509 Certificate";
			return false;
		}
	}
	
	bool			KeyRecord::LoadFromX509RSAkey(string name, x509_RSAkey* key, string& err)
	{
		if ( !key ) 
		{
			err = "Invalid x509 RSA key";
			return false;
		}

		RSA* rsa = (RSA*)key->GetRSA();

		if ( !rsa )
		{
			err = "RSA key uninitialized";
			return false;
		}
	
		idirect_pki::SetName(name);
	
		if ( key->IsPrivate() )
		{
			m_algorithm = IDIRECT_RSA_PRIVKEY;
			if ( !apply_privatekey_to(rsa, &m_key) )
			{
				err = "Failed to apply rsa private key";
				return false;
			}
			idirect_pki::SetComment("RSAkey - Private");
		}
		else
		{
			m_algorithm = IDIRECT_RSA_PUBKEY;
			if ( !apply_publickey_to(rsa, &m_key) )
			{
				err = "Failed to apply rsa public key";
				return false;
			}
			idirect_pki::SetComment("=RSAkey - Public");
		}

		return true;
	}

	bool		ApplyX509CertificatetoAsymIf(AsymIf* pkeyif, const x509_Certificate* cert, string &err)
	{
		if ( !cert ) 
		{
			err = "Invalid x509 Certificate";
			return false;
		}

		EncryptionKey temp;
		
		string err1;
		RSA* prsa = cert->GetRSA(err1);
		if ( prsa )
		{
			bool ret = apply_publickey_to(prsa, &temp);
			RSA_free(prsa);
			if ( !ret )
			{
				err = "Failed to serialize rsa key, out of memory";
				return false;
			}
		}
		else
		{
			err = "Failed to get pubkey from cert";
			return false;
		}

		if ( !pkeyif->SetPublicKey(&temp) )
		{
			err = pkeyif->GetLastError();
			return false;
		}
	
		return true;
	}

}// end namespace colib
