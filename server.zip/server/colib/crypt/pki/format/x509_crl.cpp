// x509_crl.cpp
// vi:set ts=4 sw=4 nowrap:

#include <crypt/pki/format/x509_crl.h>
#include <crypt/pki/format/x509_cert.h>
#include <crypt/pki/format/x509_rsa_key.h>
#include <crypt/x509utils/ossl_io.h>
#include <crypt/x509utils/ossl_utils.h>

#include <openssl/x509.h>
#include <openssl/pem.h>

namespace colib
{
	x509_RevocationList::x509_RevocationList()
	{
		m_crl = 0;
	}

	x509_RevocationList::x509_RevocationList(const x509_RevocationList& crl)
	{	
		if ( crl.m_crl ) 
		{
			m_crl = X509_CRL_dup(crl.m_crl);
		}
		else
		{	
			m_crl = 0;
		}
	}

	x509_RevocationList::x509_RevocationList(const X509_CRL& x509_crl)
	{
		m_crl = X509_CRL_dup((X509_CRL*)&x509_crl);
	}

	x509_RevocationList::~x509_RevocationList()
	{
		Clear();
	}

	void		x509_RevocationList::Clear()
	{
		if( m_crl ) 
		{
			X509_CRL_free(m_crl);
			m_crl = 0;
		}
	}

	bool		x509_RevocationList::IsOK() const
	{
		string err;
		return CheckCRL(err);
	}

	void		x509_RevocationList::Zeroize()
	{
		zeroize_x509_crl(m_crl);
	}
	
	string		x509_RevocationList::DumpReadable() const
	{
		string output, err;		
		if ( FormatHumanReadable(output, err) ) return output;
		return "X509 RevocationList fail DumpReadable: " + err;
	}
	
	bool		x509_RevocationList::XdrDecode(CXDR* xdr, string& err)
	{	
		string data;
		if ( !xdr->XdrStringPacked(data) )
		{
			err = "XDR Decode PEM format string fail";
			return false;
		}
	
		return LoadPEM(data, err);
	}

	bool		x509_RevocationList::XdrEncode(CXDR* xdr, string& err) const
	{
		string output;
		if ( !FormatPEM(output, err) ) return false;
		
		if ( !xdr->XdrStringPacked(output) )
		{
			err = "XDR Encode PEM format string fail";
			return false;
		}
	
		return true;	
	}

	bool		x509_RevocationList::LoadX509CRL(const X509_CRL* crl)
	{
		Clear();
		if ( !crl ) return false;
		m_crl = X509_CRL_dup((X509_CRL*)crl);
		return m_crl;
	}

	bool		x509_RevocationList::CheckCRL(string& err) const
	{	
		if ( !m_crl )
		{
			err = "No revocation list";
			return false;
		}

		return true;
	}

	bool		x509_RevocationList::RevokeCertificate(const x509_Certificate& torevoke, string& err)
	{
		if ( !m_crl )
		{
			m_crl = X509_CRL_new();
			if ( !m_crl )
			{
				SET_ERROR_HARVEST(err, "Failed to allocate revokation list");
				return false;
			}
		}
	
		if ( IsCertificateRevoked(torevoke, err) )
		{	
			err = "Certificate has been revoked before";
			return false;
		}
		else if ( err != "" ) return false;

		X509_REVOKED* pnew_revoke = X509_REVOKED_new();
		if ( !pnew_revoke )
		{
			SET_ERROR_HARVEST(err, "Failed to allocate revokation");
			return false;	
		}

		if ( 
			!X509_REVOKED_set_serialNumber(pnew_revoke, X509_get_serialNumber((X509*)torevoke.GetX509())) ||
			!ASN1_TIME_set(pnew_revoke->revocationDate, time(0))
		   )
		{
			SET_ERROR_HARVEST(err, "Failed to setup revokation attributes");
			X509_REVOKED_free(pnew_revoke);
			return false;
		}

		if ( !X509_CRL_add0_revoked(m_crl, pnew_revoke) )
		{
			SET_ERROR_HARVEST(err, "Failed to add Revocation to CRL");
			return false;
		}
	
		return true;
	}

	bool		x509_RevocationList::IsCertificateRevoked(const x509_Certificate& torevoke, string& err) const
	{
		if ( !m_crl )
		{
			err = "No revokation list";
			return false;
		}
	
		long serialNum;
		if ( !torevoke.GetSerialNumber(serialNum, err) ) return false;

		X509_REVOKED* pnew_revoke = X509_REVOKED_new();
		if ( !pnew_revoke )
		{
			SET_ERROR_HARVEST(err, "Failed to allocate revokation");
			return false;
		}

		ASN1_INTEGER* t_serial = ASN1_INTEGER_new();
		if ( !t_serial)
		{
			X509_REVOKED_free(pnew_revoke);
			SET_ERROR_HARVEST(err, "Failed to allocate ASN1_INTEGER");
			return false;
		}
		ASN1_INTEGER_set(t_serial, serialNum);

		if ( !X509_REVOKED_set_serialNumber(pnew_revoke, t_serial) )
		{
			SET_ERROR_HARVEST(err, "Failed to setup revokation attributes");
			X509_REVOKED_free(pnew_revoke);
			ASN1_INTEGER_free(t_serial);
			return false;
		}

		int t_revoked = sk_X509_REVOKED_find(m_crl->crl->revoked, pnew_revoke);
		X509_REVOKED_free(pnew_revoke);
		ASN1_INTEGER_free(t_serial);
	
		return ( t_revoked >= 0 );
	}

	bool		x509_RevocationList::Sign(x509_RSAkey& ca_key, const x509_Certificate& ca_cert, string& err)
	{	
		static time_t TEN_YEAR_IN_SEC = 10 * 365 * 24 * 60 * 60;

		if ( !CheckCRL(err) ) return false;

		if ( 
			!X509_CRL_set_version(m_crl, 0) ||
			!X509_CRL_set_issuer_name(m_crl, ca_cert.GetSubjectName(err)) ||
			!X509_CRL_sort(m_crl) 
	 	   )
		{
			SET_ERROR_HARVEST(err, "Failed to setup CRL attributes");
			return false;
		}
	
		ASN1_TIME* now = ASN1_TIME_new();
		X509_gmtime_adj(now, 0);
		if ( !X509_CRL_set_lastUpdate(m_crl, now) )
		{	
			SET_ERROR_HARVEST(err, "Failed to setup CRL last update");
			ASN1_TIME_free(now);
			return false;
		}
		ASN1_TIME_free(now);
	
		ASN1_TIME* next = ASN1_TIME_new();
		X509_gmtime_adj(next, TEN_YEAR_IN_SEC);
		if ( !X509_CRL_set_nextUpdate(m_crl, next) )
		{	
			SET_ERROR_HARVEST(err, "Failed to setup CRL next update");
			ASN1_TIME_free(next);
			return false;
		}
		ASN1_TIME_free(next);

		EVP_PKEY* pkey = EVP_PKEY_new();
		if ( !EVP_PKEY_set1_RSA(pkey, (RSA*)ca_key.GetRSA()) )
		{
			SET_ERROR_HARVEST(err, "Failed to setup rsa key for signing");
			EVP_PKEY_free(pkey);
			return false;
		}

		if ( !X509_CRL_sign(m_crl, pkey, EVP_sha512()) )
		{
			SET_ERROR_HARVEST(err, "Failed to sign CRL");
			EVP_PKEY_free(pkey);
			return false;
		}
	
		EVP_PKEY_free(pkey);
		return true;		
	}

	bool		x509_RevocationList::GetIssuerCommonName(string &output, string& err) const
	{
		if ( !CheckCRL(err) ) return false;

		output.clear();
	
		X509_NAME* pname = X509_CRL_get_issuer(m_crl);
		if ( !pname )
		{
			SET_ERROR_HARVEST(err, "Failed to extract issuer name");
			return false;
		}

		int index = X509_NAME_get_index_by_NID(pname, NID_commonName, -1);
		if ( index < 0 )
		{
			SET_ERROR_HARVEST(err, "Issuer name does not contain a common name");
			return false;
		}

		ASN1_STRING* data = X509_NAME_ENTRY_get_data(X509_NAME_get_entry(pname, index));
		if ( !output.set_maxlength(data->length) )
		{
			err = "Common name too long";
			return false;
		}

		output = string((const char*)data->data, (unsigned)data->length);
		return true;
	}

	bool		x509_RevocationList::GetLastUpdateTime(string& output, string& err) const
	{
		if ( !CheckCRL(err) ) return false;

		BIO* bio = CreateWriteOnlyStringBIO(output, err);
		if ( !bio ) return false;
	
		ASN1_TIME_print(bio, X509_CRL_get_lastUpdate(m_crl));
		BIO_free(bio);
		return true;
	}

	bool		x509_RevocationList::CheckDates(string& status, string& err, time_t now, int offset) const
	{
		if ( !CheckCRL(err) ) return false;
	
		time_t checkTime = now;
		if ( !now ) time(&checkTime);
		
		checkTime += offset;
		bool ret = true;

		if ( X509_cmp_time(X509_CRL_get_lastUpdate(m_crl), &checkTime) <= 0 )
		{
			status = "CRL is valid";
		}
		else
		{
			ret = false;
			status = "CRL not yet valid";
			string lastUpdateTime;
			if ( GetLastUpdateTime(lastUpdateTime, err) ) 
			{
				checkTime -= offset;
				status.AppendFmt(": CRL last update time is %s but the host's clock is %s GMT",
						lastUpdateTime.c_str(), asctime(gmtime(&checkTime)));
			}
		}
	
		return ret;
	}

	bool		x509_RevocationList::FormatHumanReadable(string& output, string& err) const 
	{
		if ( !CheckCRL(err) ) return false;

		BIO* bio = CreateWriteOnlyStringBIO(output, err);
		if ( !bio ) return false;

		bool ret = X509_CRL_print(bio, m_crl);
		if ( !ret ) SET_ERROR_HARVEST(err, "Failed to format readable revocation list");
		BIO_free(bio);
		return ret;
	}

	bool		x509_RevocationList::operator==(const x509_RevocationList& crl) const
	{	
		return ( X509_CRL_cmp(m_crl, crl.m_crl) == 0 ); //this OpenSSL api only compare issuer name
	}

	x509_RevocationList&		x509_RevocationList::operator=(const x509_RevocationList& crl)
	{	
		Clear();
		if ( crl.m_crl ) m_crl = X509_CRL_dup(crl.m_crl);
		return *this;
	}
	
	//
	// PEM format
	//
	bool		x509_RevocationList::FormatPEM(string& output, string& err) const
	{		
		if ( !CheckCRL(err) ) return false;
		BIO* bio = CreateWriteOnlyStringBIO(output, err);
	   	if ( !bio ) return false;
		bool ret = PEM_write_bio_X509_CRL(bio, m_crl);
		BIO_free(bio);
		if ( !ret )	SET_ERROR_HARVEST(err, "Failed to format PEM revocation list");
		return ret;
	}

	bool		x509_RevocationList::LoadPEM(string data, string& err)
	{	
		Clear();

		BIO* pbio = BIO_new_mem_buf((void*)data.c_str(), -1);		
		if ( !pbio )
		{
			SET_ERROR_HARVEST(err, "Failed to create BIO");
			return false;
		}
		
		bool ret = PEM_read_bio_X509_CRL(pbio, &m_crl, 0, (void*)NO_PASSWORD);
		if ( !ret ) SET_ERROR_HARVEST(err, "Failed to parse PEM revocation list");
		BIO_free(pbio);
		return ret;
	}

	//
	// DER format
	//	
	bool		x509_RevocationList::FormatDER(char* data, unsigned& len, string& err) const
	{	
		if ( !CheckCRL(err) ) return false;	
	
		colib::XdrEncode en(data, len);
		BIO* bio = CreateWriteOnlyXDRBIO(&en, err);
		if ( !bio ) return false;
		bool ret = i2d_X509_CRL_bio(bio, m_crl);
		if ( !ret )	SET_ERROR_HARVEST(err, "Failed to format DER revocation list to XDR");
		BIO_free(bio);
		len = en.GetLength();
		return ret;
	}

	bool		x509_RevocationList::LoadDER(char* data, unsigned len, string& err)
	{	
		Clear();
		m_crl = X509_CRL_new();	
		if ( !m_crl )
		{
			SET_ERROR_HARVEST(err, "Failed to alloc x509_CRL");
			return false;
		}
	
		colib::XdrDecode en(data, len);
		BIO* bio = CreateReadOnlyXDRBIO(&en, err);
		if ( !bio ) return false;
		d2i_X509_CRL_bio(bio, &m_crl);
		bool ret =  ( m_crl != NULL );
		if ( !ret ) SET_ERROR_HARVEST(err, "Failed to parse DER revocation list from XDR");
		BIO_free(bio);
		return ret;
	}

}//end namespace colib

