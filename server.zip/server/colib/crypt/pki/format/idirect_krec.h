// idirect_krec.h
#ifndef IDIRECT_KREC_H_ALREADY_INCLUDED
#define IDIRECT_KREC_H_ALREADY_INCLUDED

#include <crypt/pki/format/idirect_pki.h>
#include <crypt/pki/format/const.h>
#include <crypt/key/key.h>

namespace colib
{
	class AsymIf;
	class x509_RSAkey;
	class x509_Certificate;

	bool		ApplyX509CertificatetoAsymIf(AsymIf* pkeyif, const x509_Certificate* cert, string &err);

	class KeyRecord : public idirect_pki
	{
		public:
									KeyRecord();
									KeyRecord(const KeyRecord& to);
			virtual					~KeyRecord();
			//
			// Implementation of pure virtual functions in base
			//
			virtual const char*		GetType() const { return PKI_TYPE_IDIRECT_KEY; }		
			virtual bool			IsOK() const; 
			virtual void 			Zeroize();
			virtual void			Clear();
			//
			// Other functions
			//
			const EncryptionKey&	GetKey() const { return m_key; }
			string					GetAlgorithm() const { return m_algorithm; }
	
			bool					LoadKeyFromAsym(AsymIf* pkeyif, string& err, bool public_only);
			bool					ApplyKeytoAsym(AsymIf* pkeyif, string& err);

			bool					is_empty() const;

			bool					LoadPublicKeyFromX509Certificate(const x509_Certificate* cert, string& err);
			bool					LoadFromX509RSAkey(string name, x509_RSAkey* key, string& err);

			bool					operator==(const KeyRecord& key_record);
			KeyRecord&				operator=(const KeyRecord& to);
	
		protected:

			virtual const char*		StartTag() const { return IDIRECT_KEY_BEGIN; }
			virtual const char*		EndTag() const { return IDIRECT_KEY_END; }	
			virtual bool			ParsePKI(const char** pdata, string& err);
			virtual bool			ParseTag(string tag, const char** pdata, string& err);
			virtual bool			FormatPKI(string& data, string& err) const;
			virtual bool			FormatTag(string& data, string& err) const;

		protected:
	
			string					m_algorithm;					
			EncryptionKey			m_key;
	};

}// end namespace colib

#endif

