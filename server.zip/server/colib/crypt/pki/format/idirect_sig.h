// idirect_sig.h
// vi:set ts=4 sw=4 nowrap:

#ifndef IDIRECT_SIG_H_ALREADY_INCLUDED
#define IDIRECT_SIG_H_ALREADY_INCLUDED

#include <crypt/pki/format/idirect_pki.h>
#include <crypt/pki/format/const.h>
#include <crypt/key/key.h>

namespace colib
{
	class AsymIf;

	class SigBase : public idirect_pki
	{
		public:

									SigBase();
									SigBase(const idirect_pki& to);
			virtual					~SigBase();
			//
			// Implementation of pure virtual functions in base
			//
			virtual const char*		GetType() const { return PKI_TYPE_IDIRECT_SIG; }
			virtual bool			IsOK() const;
			virtual void			Zeroize();
			virtual void			Clear();
			//
			// Other functions
			//
			bool					is_empty() const;
			string					GetAlgorithm() const { return m_algorithm; }
			string					GetSigner() const { return m_signer; }
			void					SetSigner(string to) { m_signer = to; }

			bool					MinimalXdrProc(CXDR* xdr); //payload signature only
			//
			// Calculate a signature of "data" using "pkeyif", store the result in this
			//
			bool					SignObject(string& err, unsigned char* data, unsigned int length, AsymIf* pkeyif);
			//
			// Verify that this signature of "data" was signed by "pkeyif"
			//
			bool					VerifyObject(string& err, unsigned char* data, unsigned int length, AsymIf* pkeyif) const;

			// Have to be implemented in derived class
			virtual bool			SignObjects(string& err, AsymIf* pkeyif, unsigned int num, ...) = 0;
			virtual bool			VerifyObjects(string& err, AsymIf* pkeyif, unsigned int num, ...) const = 0;
	
		protected:

			SigBase&				operator=(const SigBase& to);
			bool					operator==(const SigBase& to);

			const char*				StartTag() const { return IDIRECT_SIG_BEGIN; }
			const char*				EndTag() const { return IDIRECT_SIG_END; }	
			bool					ParsePKI(const char** pdata, string& err);
			bool					ParseTag(string tag, const char** pdata, string& err);
			bool					FormatPKI(string& data, string& err) const;
			bool					FormatTag(string& data, string& err) const;

			const EncryptionKey&	GetSignature() const { return m_signature_binary; }

			bool					SignRawData(const unsigned char* data, unsigned len, AsymIf* pkeyif, string algorithm, string& err);
			bool					VerifyRawData(const unsigned char* data, unsigned len, AsymIf* pkeyif, string& err) const;

		protected:

			string					m_signer;
			string					m_algorithm;
			EncryptionKey			m_signature_binary;
	};

	template<typename T>
	class Signature : public SigBase{

	public:

	Signature()
	{
	}

	Signature(const Signature& to) :
			SigBase(to)
		{
			m_signer = to.GetSigner();
			m_algorithm = to.GetAlgorithm();
			m_signature_binary.Copy(to.GetSignature());
		}
		// MultiObject version of SignObject
		// num is set to the number of "data" and "length" pairs that are passed
		// example: SignObjects(pkeyif, num, data1, len1, data2, len2);
		bool					SignObjects(string& err, AsymIf* pkeyif, unsigned int num, ...)
		{
			va_list args;
			va_start(args, num);
			m_hash.CalculateHash(num, args);
			va_end(args);
			return SignRawData(m_hash.GetHashData(), T::DIGEST_LENGTH, pkeyif, m_hash.IDIRECT_SIG_NAME, err);
		}
		// MultiObject version of VerifyObject
		// num is set to the number of "data" and "length" pairs that are passed
		// example: VerifyObjects(pkeyif, num, data1, len1, data2, len2);
		bool					VerifyObjects(string& err, AsymIf* pkeyif, unsigned int num, ...) const
		{
			va_list args;
			va_start(args, num);
			m_hash.CalculateHash(num, args);
			va_end(args);
			return VerifyRawData(m_hash.GetHashData(), T::DIGEST_LENGTH, pkeyif, err);
		}

		virtual void			Zeroize(){
			SigBase::Zeroize();
			m_hash.Zeroize();
		}
		virtual void			Clear(){
			SigBase::Clear();
			m_hash.Zeroize();
		}

		Signature&				operator=(const Signature& to){
			if(this != &to)
				SigBase::operator=(to);
			return *this;
		}
		bool					operator==(const Signature& to){
			return SigBase::operator==(to);
		}

	private:
		mutable T   m_hash;

	};

}//end namespace iDirect


#endif

