// idirect_pki.cpp
// vi:set ts=4 sw=4 nowrap:

#include <crypt/pki/format/idirect_pki.h>
#include <crypt/pki/format/idirect_parse.h>
#include <crypt/pki/format/const.h>

namespace colib
{
	idirect_pki::idirect_pki(const idirect_pki& pki)
	{
		m_name = pki.GetName();
		m_comment = pki.GetComment();
	}

	idirect_pki&	idirect_pki::operator=(const idirect_pki& pki)
	{
		m_name = pki.GetName();
		m_comment = pki.GetComment();
		return *this;
	}

	void			idirect_pki::Zeroize()
	{
		// No need to clean up name and comment
	}

	void			idirect_pki::Clear()
	{
		m_name.clear();
		m_comment.clear();
	}

	bool			idirect_pki::XdrDecode(CXDR* xdr, string& err)
	{	
		string data;
		if ( !xdr->XdrStringPacked(data) )
		{
			err = "XDR Decode string fail";
			return false;
		}
		
		return Load(data, err);
	}

	bool			idirect_pki::Load(string data, string& err)
	{
		const char* p = data.c_str();
		return Parse(&p, err);
	}

	bool			idirect_pki::Parse(const char** pinp, string& err)
	{	
		const char *&charp = *pinp;
		
		Clear();
	
		string tok;
		//	
		//	If first token not start, die
		//
		if ( !ParseToken(&charp, tok, true) || tok != StartTag() )
		{
			err = string::Format("Start Tag %s not found", StartTag());
			return false;
		}
		//
		// Walk through tokens
		//
		while ( true )
		{
			const char* prevcharp = charp;
			if ( !ParseToken(&prevcharp, tok) )
			{
				err = "Token not found, data truncated";
				return false;
			}
			
			string err1;
			if ( !ParseTag(tok, &prevcharp, err1) )
			{
				if ( !err1.is_empty() )
				{
					err = "Parse tag failed: " + err1;
					return false;
				}
				else break;	// token is done								
			}	
			charp = prevcharp;
		}

		string err1;
		if ( !ParsePKI(&charp, err1) )
		{
			err = "Parse PKI failed: " + err1;
			return false;
		}	

		if ( !ParseToken(&charp, tok, true) || tok != EndTag() )
		{
			err = string::Format("End Tag %s not found", EndTag());
			return false;
		}

		return true;
	}

	bool			idirect_pki::ParseTag(string tag, const char** pdata, string& err)
	{
		bool ret;

		if ( tag == IDIRECT_NAME )
		{
			ret = ParseToken(pdata, m_name, true);
			if ( !ret ) err = "Missing name record";
		}
		else if ( tag == IDIRECT_COMMENT )
		{
			string comment;
			ret = ParseToken(pdata, comment, true);
			if ( !ret ) err = "Missing comment record";
			else
			{	
				if ( !m_comment.is_empty() ) m_comment += "\n";
				m_comment += comment;
			}
		}
		else ret = false; // Not supported tag, normal, not error (err not set)

		return ret;
	}

	bool			idirect_pki::XdrEncode(CXDR* xdr, string& err) const
	{
		string output;
		if ( !Format(output, err) ) return false;
	
		if ( !xdr->XdrStringPacked(output) )
		{
			err = "XDR Encode string fail";
			return false;
		}
	
		return true;	
	}

	string			idirect_pki::DumpReadable() const
	{
		string output, err;
		if ( Format(output, err) ) return output;
		return "idirect PKI fail DumpReadable: " + err;
	}

	bool			idirect_pki::Format(string& data, string& err) const
	{
		data.AppendFmt("%s\n", StartTag());

		string err1;
		if ( !FormatTag(data, err1) )
		{
			err = "Fail to format tag: " + err1;
			return false;
		}

		if ( !FormatPKI(data, err1) )
		{
			err = "Fail to format PKI: " + err1;
			return false;
		}

		data.AppendFmt("%s\n", EndTag());

		return true;
	}

	bool			idirect_pki::FormatTag(string& data, string& err) const
	{
		(void)err;

		if ( !m_name.is_empty() ) data.AppendFmt("%s %s\n", IDIRECT_NAME, m_name.c_str());
		
		if ( !m_comment.is_empty() ) 
		{
			const char* pcomment = m_comment.c_str();
			const char* pnext;
			while ( 0 != ( pnext = strchr(pcomment, '\n') ) )
			{
				string add(pcomment, (unsigned)(pnext-pcomment));
				data.AppendFmt("%s %s\n", IDIRECT_COMMENT, add.c_str());
				pcomment = pnext + 1;
			}
			data.AppendFmt("%s %s\n", IDIRECT_COMMENT, pcomment);
		}

		return true;
	}

	bool			idirect_pki::operator==(const idirect_pki& pki) const
	{
		return ( 
				( m_name == pki.GetName() ) &&
				( m_comment == pki.GetComment() )
			   );
	}

}//end namespace colib

