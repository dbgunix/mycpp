// idirect_pki.h
// vi:set ts=4 sw=4 nowrap:

#ifndef IDIRECT_PKI_H_ALREADY_INCLUDED
#define IDIRECT_PKI_H_ALREADY_INCLUDED

#include <crypt/pki/format/base.h>

namespace colib
{
	//
	// idirect_pki is the base class for colib propriatery pki format
	// It starts with StartTag, e.g. "--IDIRECT_KEY_BEGIN--", "--IDIRECT_SIG_BEGIN--" 
	// ends with EndTag, e.g. "--IDIRECT_KEY_END--", "--IDIRECT_SIG_END--"
	// Internal tags are supports, common ones are:
	// 		"Name" - name of the PKI
	// 		"Comment" - comment
	// Inherit class may have its own Tags
	//
	class idirect_pki : public pki_base
	{
		public:

									idirect_pki() {};
									idirect_pki(const idirect_pki& pki);
			virtual					~idirect_pki() {};							
			//
			// Implementation of pure virtual functions in base
			//
			virtual bool			XdrDecode(CXDR* xdr, string& err);
			virtual bool			XdrEncode(CXDR* xdr, string& err) const;
			virtual void			Zeroize();
			virtual void			Clear();
			virtual string			DumpReadable() const;
			//
			// Other functions
			//
			string					GetName() const { return m_name; }
			void					SetName(string name) { m_name = name; }
			string					GetComment() const { return m_comment; }
			void					SetComment(string comment) { m_comment = comment; }

			bool					Load(string data, string& err);
			bool					Format(string& output, string& err) const;

			idirect_pki&			operator=(const idirect_pki& pki);
			bool					operator==(const idirect_pki& pki) const;
			
		protected:
			//
			// Virtual functions
			//
			virtual const char*		StartTag() const = 0;
			virtual const char*		EndTag() const = 0;
			virtual bool			ParsePKI(const char** pdata, string& err) = 0;
			virtual bool			ParseTag(string tag, const char** pdata, string& err);
			virtual bool			FormatPKI(string& data, string& err) const = 0;
			virtual bool			FormatTag(string& data, string& err) const;

		protected:

			bool					Parse(const char** pdata, string& err);
		
		protected:

			string					m_name;
			string					m_comment;
	};

}//end namespace colib


#endif

