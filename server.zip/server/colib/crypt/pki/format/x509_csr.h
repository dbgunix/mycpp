// x509_csr.h
// vi:set ts=4 sw=4 nowrap:

#ifndef X509_CSR_H_ALREADY_INCLUDED
#define X509_CSR_H_ALREADY_INCLUDED

#include <crypt/pki/format/base.h>
#include <crypt/pki/format/const.h>

#include <openssl/x509.h>

namespace colib
{	
	class x509_RSAkey;

	class x509_CSR : public pki_base
	{
		public:

			enum X509CSRType
			{
				TypeSignCert,
				TypeEncipher,
				TypeCount
			};
									x509_CSR();
									x509_CSR(const x509_CSR& csr);
									x509_CSR(const X509_REQ& x509_csr);
			virtual					~x509_CSR();
			//
			// Implementation of pure virtual functions in base
			//	
			virtual const char*		GetType() const { return PKI_TYPE_X509_CSR; }
			virtual bool			IsOK() const;
			virtual bool			XdrDecode(CXDR* xdr, string& err);
			virtual bool			XdrEncode(CXDR* xdr, string& err) const;
			virtual void			Zeroize();
			virtual void			Clear();
			virtual string			DumpReadable() const;
			//
			// Other functions
			//	
			bool					operator==(const x509_CSR& cert) const;
			x509_CSR&				operator=(const x509_CSR& cert);
	
			bool					LoadX509REQ(const X509_REQ* x509_csr);	
			const X509_REQ*			GetX509REQ() const { return m_x509_csr; }

			bool					IsRequest4CA(string& err) const;
			//
			// Generate X509 CSR for Signing or Encrypt purpose
			// Key is local private key pair
			//
			bool					GenerateCSR4SignCert(string& err, x509_RSAkey& key, string* dn, string an = "");
			bool					GenerateCSR4Encipher(string& err, x509_RSAkey& key, string* dn, string an = "");
			
			bool					SelfVerify(string& err) const;
			
			X509_NAME*				GetSubjectName(string& err) const;
			bool					GetSubject(string& output, string& err) const;
			bool					GetSubjectCommonName(string& output, string& err) const;
			//
			// Returned Key MUST be freed by caller
			//
			EVP_PKEY*				GetPublicKey(string& err) const;
					
			bool					LoadPEM(string data, string& err);
			bool					FormatPEM(string& output, string& err) const;

			bool					LoadDER(char* data, unsigned len, string& err);
			bool					FormatDER(char* data, unsigned& len, string& err) const;

			bool					FormatHumanReadable(string& output, string& err) const;

		protected:

			bool					CheckX509REQ(string& err) const;
			bool					GetX509Name(X509_NAME* pname, int nid, string& output, string& err) const;

			bool					GenerateCSR(string& err, x509_RSAkey& key, string* dn, string an, X509CSRType type);
			bool					SetX509REQExt4SignCert(string& err, STACK_OF(X509_EXTENSION)* &exts);
			bool					SetX509REQExt4Encipher(string& err, STACK_OF(X509_EXTENSION)* &exts);

		protected:
	
			X509_REQ*				m_x509_csr;			
	};

}//end namespace colib


#endif

