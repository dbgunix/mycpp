// x509_csr.cpp
// vi:set ts=4 sw=4 nowrap:

#include <crypt/pki/format/x509_csr.h>
#include <crypt/pki/format/x509_rsa_key.h>
#include <crypt/x509utils/ossl_io.h>
#include <crypt/x509utils/ossl_utils.h>

#include <openssl/x509.h>
#include <openssl/x509v3.h>
#include <openssl/pem.h>

namespace colib
{
	x509_CSR::x509_CSR()
	{
		m_x509_csr = 0;
	}
	
	x509_CSR::~x509_CSR()
	{
		Clear();
	}
	
	x509_CSR::x509_CSR(const x509_CSR& csr)
	{
		X509_REQ* x509_csr = (X509_REQ*)csr.GetX509REQ();

		if ( x509_csr )
		{
			m_x509_csr = X509_REQ_dup(x509_csr);
		}
		else
		{
			m_x509_csr = 0;
		}
	}

	x509_CSR::x509_CSR(const X509_REQ& x509_csr)
	{
		m_x509_csr = X509_REQ_dup((X509_REQ*)&x509_csr);
	}

	bool		x509_CSR::IsOK() const
	{
		string err;
		return CheckX509REQ(err);
	}

	void		x509_CSR::Clear()
	{
		if ( m_x509_csr )
		{
			X509_REQ_free(m_x509_csr);
			m_x509_csr = 0;
		}
	}

	void		x509_CSR::Zeroize()
	{
		// Not yet ...
	}

	string		x509_CSR::DumpReadable() const
	{
		string output, err;		
		if ( FormatHumanReadable(output, err) ) return output;
		return "X509 CSR fail DumpReadable: " + err;
	}
	
	bool		x509_CSR::XdrDecode(CXDR* xdr, string& err)
	{	
		string data;
		if ( !xdr->XdrStringPacked(data) )
		{
			err = "XDR Decode PEM format string fail";
			return false;
		}
	
		return LoadPEM(data, err);
	}

	bool		x509_CSR::XdrEncode(CXDR* xdr, string& err) const
	{
		string output;
		if ( !FormatPEM(output, err) ) return false;
		
		if ( !xdr->XdrStringPacked(output) )
		{
			err = "XDR Encode PEM format string fail";
			return false;
		}
	
		return true;	
	}

	bool		x509_CSR::LoadX509REQ(const X509_REQ* x509_csr)
	{
		Clear();	
		if ( !x509_csr ) return false;
		m_x509_csr = X509_REQ_dup((X509_REQ*)x509_csr);
		return m_x509_csr;
	}

	bool		x509_CSR::CheckX509REQ(string& err) const
	{	
		if ( !m_x509_csr )
		{
			err = "No X509 CSR";
			return false;
		}
		return true;
	}

	bool		x509_CSR::IsRequest4CA(string& err) const
	{
		if ( !CheckX509REQ(err) ) return false;
		STACK_OF(X509_EXTENSION)* exts = X509_REQ_get_extensions(m_x509_csr);	
		if ( !exts ) return false;
		// 
		// Check "CA:TRUE"
		//
		void* ext = X509V3_get_d2i(exts, NID_basic_constraints, 0, 0);
		//
		// If not present, not for CA
		//
		if ( !ext ) return false;
		
		return ((BASIC_CONSTRAINTS*)ext)->ca;
	}

	bool		x509_CSR::SetX509REQExt4SignCert(string& err, STACK_OF(X509_EXTENSION)* &exts)
	{
		X509_EXTENSION* ex = X509V3_EXT_conf_nid(0, 0, NID_basic_constraints, (char*)"critical,CA:TRUE");
		if ( !ex )
		{
			SET_ERROR_HARVEST(err, "Fail to set basic constraints EXTENSION");
			return false;
		}
		sk_X509_EXTENSION_push(exts, ex);
		
		ex = X509V3_EXT_conf_nid(0, 0, NID_key_usage, (char*)"critical,keyCertSign,cRLSign");
		if ( !ex )
		{
			SET_ERROR_HARVEST(err, "Fail to set key usage EXTENSION");
			return false;
		}
		sk_X509_EXTENSION_push(exts, ex);

		return true;
	}

	bool		x509_CSR::SetX509REQExt4Encipher(string& err, STACK_OF(X509_EXTENSION)* &exts)
	{
		X509_EXTENSION* ex = X509V3_EXT_conf_nid(0, 0, NID_basic_constraints, (char*)"critical,CA:FALSE");
		if ( !ex )
		{
			SET_ERROR_HARVEST(err, "Fail to set basic constraints EXTENSION");
			return false;
		}
		sk_X509_EXTENSION_push(exts, ex);
		
		ex = X509V3_EXT_conf_nid(0, 0, NID_key_usage, (char*)"critical,keyEncipherment");
		if ( !ex )
		{
			SET_ERROR_HARVEST(err, "Fail to set key usage EXTENSION");
			return false;
		}
		sk_X509_EXTENSION_push(exts, ex);

		return true;
	}

	bool		x509_CSR::GenerateCSR4SignCert(string& err, x509_RSAkey& key, string* dn, string an)
	{
		return GenerateCSR(err, key, dn, an, TypeSignCert);
	}

	bool		x509_CSR::GenerateCSR4Encipher(string& err, x509_RSAkey& key, string* dn, string an)
	{
		return GenerateCSR(err, key, dn, an, TypeEncipher);
	}

	bool		x509_CSR::GenerateCSR(string& err, x509_RSAkey& key, string* dn, string an, X509CSRType type)
	{	
		Clear();
	
		m_x509_csr = X509_REQ_new();
		if ( !m_x509_csr )
		{
			SET_ERROR_HARVEST(err, "Fail to allocate X509 REQ");
			return false;
		}

		/*
		 * COMMENTS: the following code from old implementation, which I have no idea why needed,
		 * commented out for now ....
		 *
		X509_REQ_INFO* pinf = m_x509_csr->req_info;
		pinf->version->length = 1;
		pinf->version->data = (unsigned char *)OPENSSL_malloc(1);
		if ( !pinf->version->data )
		{
			SET_ERROR_HARVEST(err, "Fail to allocate X509 REQ version");
			return false;
		}
		pinf->version->data[0] = 0;
		*/

		X509_NAME* pname = X509_REQ_get_subject_name(m_x509_csr);
		if ( !pname )
		{
			SET_ERROR_HARVEST(err, "Failed to get X509_NAME");
			return false;
		}
		
		if ( dn[0].is_empty() || !X509_NAME_add_entry_by_NID(pname, NID_commonName, MBSTRING_UTF8, 
					(unsigned char*)dn[0].c_str(), -1, -1, 0) )
		{
			SET_ERROR_HARVEST(err, "Failed to add subject name to CSR");
			return false;
		}
	
		if ( !dn[1].is_empty() && !X509_NAME_add_entry_by_NID(pname, NID_countryName, MBSTRING_UTF8,
					(unsigned char *)dn[1].c_str(),	-1, -1, 0) )
		{
			SET_ERROR_HARVEST(err, "Failed to add country name to CSR");
			return false;
		}
	
		if ( !dn[2].is_empty() && !X509_NAME_add_entry_by_NID(pname, NID_stateOrProvinceName, MBSTRING_UTF8,
					(unsigned char *)dn[2].c_str(),	-1, -1, 0) )
		{
			SET_ERROR_HARVEST(err, "Failed to add state or province name to CSR");
			return false;
		}
	
		if ( !dn[3].is_empty() && !X509_NAME_add_entry_by_NID(pname, NID_organizationName, MBSTRING_UTF8,
					(unsigned char *)dn[3].c_str(), -1, -1, 0) )
		{
			SET_ERROR_HARVEST(err, "Failed to add organization name to CSR");
			return false;
		}
	
		if ( !dn[4].is_empty() && !X509_NAME_add_entry_by_NID(pname, NID_organizationalUnitName, MBSTRING_UTF8,
					(unsigned char *)dn[4].c_str(),	-1, -1, 0) )
		{
			SET_ERROR_HARVEST(err, "Failed to add orgnational-unit name to CSR");
			return false;
		}
	
		if ( !dn[5].is_empty() && !X509_NAME_add_entry_by_NID(pname, NID_dnQualifier, MBSTRING_UTF8,
					(unsigned char *)dn[5].c_str(),	-1, -1, 0) )
		{
			SET_ERROR_HARVEST(err, "Failed to add distinguished name qualifier to CSR");
			return false;
		}
	
		if ( !dn[6].is_empty() && !X509_NAME_add_entry_by_NID(pname, NID_serialNumber, MBSTRING_UTF8,
					(unsigned char *)dn[6].c_str(),	-1, -1, 0) )
		{
			SET_ERROR_HARVEST(err, "Failed to add serial number to CSR");
			return false;
		}
	
		if ( !dn[7].is_empty() && !X509_NAME_add_entry_by_NID(pname, NID_pkcs9_emailAddress, MBSTRING_UTF8,
					(unsigned char *)dn[7].c_str(),	-1, -1, 0) )
		{
			SET_ERROR_HARVEST(err, "Failed to add email address to CSR");
			return false;
		}

		STACK_OF(X509_EXTENSION)* exts = sk_X509_EXTENSION_new_null();
		if ( !exts )
		{
			SET_ERROR_HARVEST(err, "Fail to allocate X509_EXTENSION STACK");
			return false;
		}
		//
		// Set Subject Alternative Name if necessary
		//
		if ( an != "" )
		{
			X509_EXTENSION* ex = X509V3_EXT_conf_nid(0, 0, NID_subject_alt_name, (char*)an.c_str());
			if ( !ex )
			{
				SET_ERROR_HARVEST(err, "Fail to set alternative name EXTENSION");
				return false;
			}
			sk_X509_EXTENSION_push(exts, ex);
		}
	
		bool ret = false;

		switch ( type )
		{
			case TypeSignCert :
			{
				ret = SetX509REQExt4SignCert(err, exts);
				break;
			}
			case TypeEncipher :
			{
				ret = SetX509REQExt4Encipher(err, exts);
				break;
			}
			default : 
			{
				err = "Not supported CSR type";
				break;
			}
		}

		if ( ret ) X509_REQ_add_extensions(m_x509_csr, exts);
		sk_X509_EXTENSION_pop_free(exts, X509_EXTENSION_free);
	
		if ( !ret ) return false;

		if ( !key.GetRSA() )
		{
			err = "Invalid key";
			return false;
		}

		if ( !key.IsPrivate() )
		{
			err = "Must have a private keypair to create a CSR";
			return false;
		}
		
		RSA* prsapub = RSAPublicKey_dup((RSA*)key.GetRSA());
		if ( !prsapub )
		{
			SET_ERROR_HARVEST(err, "Fail to replicate RSA key public portion");
			return false;
		}

		EVP_PKEY* pkey = EVP_PKEY_new();
		if ( !pkey )
		{
			SET_ERROR_HARVEST(err, "Fail to allocate EVP key");
			RSA_free(prsapub);
			return false;
		}

		if ( !EVP_PKEY_set1_RSA(pkey, prsapub) )
		{
			SET_ERROR_HARVEST(err, "Fail to assign public portion to EVP key");
			EVP_PKEY_free(pkey);
			RSA_free(prsapub);
			return false;
		}
	
		if ( !X509_REQ_set_pubkey(m_x509_csr, pkey) )
		{
			SET_ERROR_HARVEST(err, "Fail to set X509 REQ with public key");
			EVP_PKEY_free(pkey);
			RSA_free(prsapub);
			return false;
		}
		RSA_free(prsapub);

		if ( !EVP_PKEY_set1_RSA(pkey, (RSA*)key.GetRSA()) )
		{
			SET_ERROR_HARVEST(err, "Fail to assign private portion to EVP key");
			EVP_PKEY_free(pkey);
			return false;
		}
		//
		// Sign
		//
		if ( !X509_REQ_sign(m_x509_csr, pkey, EVP_sha512()) )
		{
			SET_ERROR_HARVEST(err, "Failed to sign CSR");
			EVP_PKEY_free(pkey);
			return false;
		}

		EVP_PKEY_free(pkey);
		return true;
	}
	
	bool		x509_CSR::operator==(const x509_CSR& csr) const
	{	
		//
		// Comment by Hao: what a terrible solution!!!
		//
		string t1, t2, err;
		if ( 
			FormatPEM(t1, err) &&
			csr.FormatPEM(t2, err) &&
			( t1 == t2 ) ) return true;

		return false;
	}

	//
	// Assign can be failed, use GetX509REQ() to verify if succeed or not
	//
	x509_CSR&	x509_CSR::operator=(const x509_CSR& csr)
	{
		if ( !LoadX509REQ((X509_REQ*)csr.GetX509REQ()) ) Clear();
		return *this;
	}

	bool		x509_CSR::FormatHumanReadable(string& output, string& err) const
	{
		if ( !CheckX509REQ(err) ) return false;
	
		BIO* bio = CreateWriteOnlyStringBIO(output, err);
	   	if ( !bio ) return false;
		bool ret = X509_REQ_print(bio, m_x509_csr);
		if ( !ret ) SET_ERROR_HARVEST(err, "Failed to format CSR");
		BIO_free(bio);
		return ret;
	}

	X509_NAME*	x509_CSR::GetSubjectName(string& err) const
	{	
		if ( !CheckX509REQ(err) ) return 0;
		X509_NAME* pname = X509_REQ_get_subject_name(m_x509_csr);
		if ( !pname ) SET_ERROR_HARVEST(err, "Failed to extract subject name");
		return pname;
	}
	
	bool		x509_CSR::GetSubject(string& output, string& err) const
	{
		if ( !CheckX509REQ(err) ) return false;
		
		X509_NAME* pname = GetSubjectName(err);
		if ( !pname ) return false;

		BIO* bio = CreateWriteOnlyStringBIO(output, err);
	   	if ( !bio ) return false;

		bool ret = X509_NAME_print_ex(bio, pname, 0, XN_FLAG_ONELINE);
		if ( !ret ) SET_ERROR_HARVEST(err, "Failed to format subject");
		BIO_free(bio);
		return ret;
	}
	
	bool		x509_CSR::GetSubjectCommonName(string& output, string& err) const	
	{
		output.clear();
		if ( !CheckX509REQ(err) ) return false;
		X509_NAME* pname = GetSubjectName(err);
		if ( !pname ) return false;
		if ( !GetX509Name(pname, NID_commonName, output, err) ) return false;
		return true;
	}
	
	bool		x509_CSR::GetX509Name(X509_NAME* pname, int nid, string& output, string& err) const
	{
		int index = X509_NAME_get_index_by_NID(pname, nid, -1);

		if ( index < 0 )
		{
			char asciiName[128]; // 128 bytes is enough
			asciiName[0] = 0;
			//
			// Even though X509_NAME_oneline takes care of ending '\0', for safety, 
			// still reserve one character of space in the buffer
			X509_NAME_oneline(pname, asciiName, sizeof(asciiName) - 1);		
			err = string::Format("%s does not contain the field name requested", asciiName);
			return false;
		}

		ASN1_STRING* data = X509_NAME_ENTRY_get_data(X509_NAME_get_entry(pname, index));

		if ( !output.set_maxlength(data->length) )
		{
			err = string::Format("Common name too long (len = %d)",	data->length);
			return false;
		}

		output = string((const char*)data->data, (unsigned)data->length);
		return true;
	}

	EVP_PKEY*	x509_CSR::GetPublicKey(string& err) const
	{
		if ( !CheckX509REQ(err) ) return 0;
		EVP_PKEY* pkey = X509_REQ_get_pubkey(m_x509_csr);
		if ( !pkey ) SET_ERROR_HARVEST(err, "Fail to extrat public key");
		return pkey;
	}

	bool		x509_CSR::SelfVerify(string& err) const
	{
		if ( !CheckX509REQ(err) ) return false;
		EVP_PKEY* pkey = GetPublicKey(err);
		if ( !pkey ) return false;
		bool ret = ( X509_REQ_verify(m_x509_csr, pkey) > 0 );
		if ( !ret ) SET_ERROR_HARVEST(err, "Fail to verfiy X509_REQ");
		EVP_PKEY_free(pkey);
		return ret;
	}
	//
	// PEM format
	//
	bool		x509_CSR::FormatPEM(string& output, string& err) const
	{	
		if ( !CheckX509REQ(err) ) return false;
		BIO* bio = CreateWriteOnlyStringBIO(output, err);
		if ( !bio ) return false;
		bool ret = PEM_write_bio_X509_REQ(bio, (X509_REQ*)GetX509REQ());
		if( !ret ) SET_ERROR_HARVEST(err, "Failed to format pem CSR");
		BIO_free(bio);
		return ret;
	}

	bool		x509_CSR::LoadPEM(string data, string& err)
	{
		Clear();

		BIO* pbio = BIO_new_mem_buf((void*)data.c_str(), -1);
		if ( !pbio )
		{
			SET_ERROR_HARVEST(err, "Failed to create BIO");
			return false;
		}
	
		bool ret = PEM_read_bio_X509_REQ(pbio, &m_x509_csr, 0, (void*)NO_PASSWORD);
		if ( !ret ) SET_ERROR_HARVEST(err, "Failed to parse PEM CSR");
		BIO_free(pbio);
		return ret;
	}

	//
	// DER format
	//	
	bool		x509_CSR::FormatDER(char* data, unsigned& len, string& err) const
	{
		if ( !CheckX509REQ(err) ) return false;
	
		colib::XdrEncode en(data, len);
		BIO* bio = CreateWriteOnlyXDRBIO(&en, err);
		if ( !bio ) return false;
		bool ret = i2d_X509_REQ_bio(bio, m_x509_csr);
		if ( !ret )	SET_ERROR_HARVEST(err, "Failed to format DER CSR to XDR");
		BIO_free(bio);
		len = en.GetLength();
		return ret;
	}

	bool		x509_CSR::LoadDER(char* data, unsigned len, string& err)
	{
		Clear();
		m_x509_csr = X509_REQ_new();
		if ( !m_x509_csr )
		{
			SET_ERROR_HARVEST(err, "Failed to alloc x509 CSR");
			return false;
		}

		colib::XdrDecode en(data, len);
		BIO* bio = CreateReadOnlyXDRBIO(&en, err);
		if ( !bio ) return false;
		d2i_X509_REQ_bio(bio, &m_x509_csr);
		bool ret =  ( m_x509_csr != NULL );
		if ( !ret ) SET_ERROR_HARVEST(err, "Failed to parse DER CSR from XDR");
		BIO_free(bio);
		return ret;
	}

}//end namespace colib

