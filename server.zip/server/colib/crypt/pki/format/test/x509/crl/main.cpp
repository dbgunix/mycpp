#include <idirect/crypt/pki/format/x509_rsa_key.h>
#include <idirect/crypt/pki/format/x509_crl.h>
#include <idirect/crypt/pki/format/x509_csr.h>
#include <idirect/crypt/pki/format/x509_cert.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <openssl/ssl.h>

using namespace colib;

int	main()
{	
	SSL_load_error_strings();
	OpenSSL_add_all_algorithms();
		
	string dn[] = {"TestRootCert", "US", "VA", "colib", "Engineer", "NMS", "100", "hcheng@idirect.net"}; 
	string output, err;	
	//
	printf("Generate CA X509 RSA key ...\n");
	x509_RSAkey ca_key;
	if ( !ca_key.GeneratePrivateKeypair(err) )
	{
		printf("Fail to generate X509 RSA key: %s\n", err.c_str());
		return -1;
	}	
	//
	printf("Generate CA X509 Certificate signed by the CA key ...\n");
	x509_Certificate ca_cert;
	if ( !ca_cert.GenerateCertificateFromDN(err, dn, ca_key) )
	{
		printf("Generate X509 certificate fail: %s\n", err.c_str());
		return -1;
	}	
	//
	string subject_name[] = {"II+.8888", "CN", "SZ", "", "", "", "", ""};

	printf("Generate X509 RSA key ...\n");
	x509_RSAkey key;
	if ( !key.GeneratePrivateKeypair(err) )
	{
		printf("Fail to generate X509 RSA key: %s\n", err.c_str());
		return -1;
	}	
	//
	printf("Generate X509 CSR signed by the key ...\n");
	x509_CSR csr;	
	if ( !csr.GenerateCSR4Encipher(err, key, subject_name) ) 
//	if ( !csr.GenerateCSR4SignCert(err, key, subject_name) ) 
	{
		printf("Generate CSR fail: %s\n", err.c_str());
		return -1;
	}
	//
	printf("Sign CSR with CA ...\n");
	x509_Certificate cert;
	if  ( !cert.GenerateCertificateFromCSR(err, csr, ca_cert, ca_key, 12345) )
	{
		printf("Fail to sign CSR: %s\n", err.c_str());
		return -1;
	}
	//
	// Step 3: Generate CRL
	//
	printf("Generate X509 CRL ...\n");
	x509_RevocationList crl;

	printf("Certificate is %srevoked\n", crl.IsCertificateRevoked(cert, err) ? "" : "NOT ");

	printf("Revoke Remote Certificate ...\n");
	err = "";
	if ( !crl.RevokeCertificate(cert, err) )
	{
		printf("Fail to revoke cert: %s\n", err.c_str());
		return -1;
	}
	printf("Sign CRL ...\n");
	if ( !crl.Sign(ca_key, ca_cert, err) )
	{
		printf("Fail to sign CRL: %s\n", err.c_str());
		return -1;
	}

	printf("Certificate is %srevoked\n", crl.IsCertificateRevoked(cert, err) ? "" : "NOT ");
	//
	// Step 4: Dump Readable
	//
	printf("Print X509 CRL ...\n");
	output = crl.DumpReadable();
	printf("%s\n", output.c_str());
	//
	// Step 5: Save to file in PEM
	//
	const char* filename = "crl.pem";
	printf("Save X509 CRL to PEM file %s ...\n", filename);	
	int fd = open(filename, O_CREAT|O_RDWR|O_TRUNC, S_IREAD|S_IWRITE);
	if ( fd == -1 )
	{
		printf("Open file %s for write failed\n", filename);
		return -1;
	}
	if ( !crl.FormatPEM(output, err) )
	{
		printf("Fail format PEM string\n");
		return -1;
	}	
	
	if ( !write(fd, output.c_str(), output.get_length()) )
	{
		printf("Write file %s fail\n", filename);
		return -1;
	}
	printf("Write %d byte to file %s\n", output.get_length(), filename);
	close(fd);	
	//
	// Step 6: Load back PEM
	//	
	printf("Read X509 CRL from PEM file %s ...\n", filename);
	fd = open(filename, 0);
	if ( fd == -1 )
	{
		printf("Open file %s for read fail\n", filename);
		return -1;
	}
	char buf[65535];
	struct stat stat;
	fstat(fd, &stat);
	if ( read(fd, buf, stat.st_size) != stat.st_size )
	{
		printf("Read file %s fail\n", filename);
		return -1;
	}
	unsigned len = stat.st_size;
	close(fd);
	
	x509_RevocationList crl_pem;
	if ( !crl_pem.LoadPEM(string(buf, len), err) )
	{
		printf("crl_pem load from PEM buf fail: %s\n", err.c_str());
		return -1;
	}
	if ( crl_pem == crl )
	{
		printf("crl_pem == crl\n");
	}
	else
	{
		printf("crl_pem != crl\n");
		output = crl_pem.DumpReadable();
		printf("%s\n", output.c_str());
		return -1;
	}
	//
	// Step 7: Save to file in DER
	//
	filename = "crl.der";
	printf("Save X509 CRL to DER file %s ...\n", filename);	
	fd = open(filename, O_CREAT|O_RDWR|O_TRUNC, S_IREAD|S_IWRITE);
	if ( fd == -1 )
	{
		printf("Open file %s for write failed\n", filename);
		return -1;
	}
	len = sizeof(buf);
	if ( !crl.FormatDER(buf, len, err) )
	{
		printf("Fail format DER buf: %s\n", err.c_str());
		return -1;
	}	
	
	if ( !write(fd, buf, len) )
	{
		printf("Write file %s fail\n", filename);
		return -1;
	}
	printf("Write %d byte to file %s\n", len, filename);
	close(fd);	
	//
	// Step 8: Load back DER
	//	
	printf("Read X509 CRL from DER file %s ...\n", filename);
	fd = open(filename, 0);
	if ( fd == -1 )
	{
		printf("Open file %s for read fail\n", filename);
		return -1;
	}
	fstat(fd, &stat);
	if ( read(fd, buf, stat.st_size) != stat.st_size )
	{
		printf("Read file %s fail\n", filename);
		return -1;
	}
	len = stat.st_size;
	close(fd);
	
	x509_RevocationList crl_der;
	if ( !crl_der.LoadDER(buf, len, err) )
	{
		printf("crl_der load from DER buf fail: %s\n", err.c_str());
		return -1;
	}
	if ( crl_der == crl )
	{
		printf("crl_der == crl\n");
	}
	else
	{
		printf("crl_der != crl\n");
		output = crl_der.DumpReadable();
		printf("%s\n", output.c_str());
		return -1;
	}
	//
	// Step 9: Encode to buffer
	//
	printf("Encode X509 CRL to buffer ...\n");
	len = sizeof(buf);
	XdrEncode en(buf, len);
	if ( !crl.XdrEncode(&en, err) )
	{
		printf("Encode fail: %s\n", err.c_str());
		return -1;
	}
	len = en.GetLength();
	printf("Encode cert to buffer with %d bytes\n", len);
	//
	// Step 10: Decode from buffer
	//
	printf("Decode X509 Certificate from buffer ...\n");
	XdrDecode de(buf, len);
	x509_RevocationList crl_de;
	if ( !crl_de.XdrDecode(&de, err) )
	{
		printf("Decode fail: %s\n", err.c_str());
		return -1;
	}
	if ( crl_de == crl )
	{
		printf("crl_decode == crl\n");
	}
	else
	{
		printf("crl_decode != crl\n");
		output = crl_de.DumpReadable();
		printf("%s\n", output.c_str());
		return -1;
	}

	return 0;
}

