#include <idirect/crypt/pki/format/x509_rsa_key.h>
#include <idirect/crypt/pki/format/x509_csr.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <openssl/ssl.h>

using namespace colib;

int	main()
{	
	SSL_load_error_strings();
	OpenSSL_add_all_algorithms();

	string subject_name[] = {"II+.8888", "", "", "", "", "", "", ""};
	string output, err;
	//
	// Step 1: Generate RSA key
	//
	printf("Generate X509 RSA key ...\n");
	x509_RSAkey key;
	if ( !key.GeneratePrivateKeypair(err) )
	{
		printf("Fail to generate X509 RSA key: %s\n", err.c_str());
		return -1;
	}	
	//
	// Step 2: Generate CSR
	//
	printf("Generate X509 CSR signed by the key ...\n");
	x509_CSR csr;
	if ( !csr.GenerateCSR4Encipher(err, key, subject_name) ) 
//	if ( !csr.GenerateCSR4SignCert(err, key, subject_name) ) 
	{
		printf("Generate CSR fail: %s\n", err.c_str());
		return -1;
	}
	printf("csr is%s CA type\n", csr.IsRequest4CA(err) ? "" : " NOT");

	if ( !csr.SelfVerify(err) ) 
	{
		printf("CSR fail SelfVerify: %s\n", err.c_str());
		return -1;
	}
	//
	// Step 3: Dump Readable
	//
	printf("Print X509 CSR ...\n");
	output = csr.DumpReadable();
	printf("%s\n", output.c_str());
	//
	// Step 4: Save to file in PEM
	//
	const char* filename = "csr.pem";
	printf("Save X509 CSR to PEM file %s ...\n", filename);	
	int fd = open(filename, O_CREAT|O_RDWR|O_TRUNC, S_IREAD|S_IWRITE);
	if ( fd == -1 )
	{
		printf("Open file %s for write failed\n", filename);
		return -1;
	}
	if ( !csr.FormatPEM(output, err) )
	{
		printf("Fail format PEM string\n");
		return -1;
	}	
	
	if ( !write(fd, output.c_str(), output.get_length()) )
	{
		printf("Write file %s fail\n", filename);
		return -1;
	}
	printf("Write %d byte to file %s\n", output.get_length(), filename);
	close(fd);	
	//
	// Step 5: Load back PEM
	//	
	printf("Read X509 CSR from PEM file %s ...\n", filename);
	fd = open(filename, 0);
	if ( fd == -1 )
	{
		printf("Open file %s for read fail\n", filename);
		return -1;
	}
	char buf[65535];
	struct stat stat;
	fstat(fd, &stat);
	if ( read(fd, buf, stat.st_size) != stat.st_size )
	{
		printf("Read file %s fail\n", filename);
		return -1;
	}
	unsigned len = stat.st_size;
	close(fd);
	
	x509_CSR csr_pem;
	if ( !csr_pem.LoadPEM(string(buf, len), err) )
	{
		printf("csr_pem load from PEM buf fail: %s\n", err.c_str());
		return -1;
	}
	if ( csr_pem == csr )
	{
		printf("csr_pem == csr\n");
	}
	else
	{
		printf("csr_pem != csr\n");
		output = csr_pem.DumpReadable();
		printf("%s\n", output.c_str());
		return -1;
	}
	//
	// Step 6: Save to file in DER
	//
	filename = "csr.der";
	printf("Save X509 CSR to DER file %s ...\n", filename);	
	fd = open(filename, O_CREAT|O_RDWR|O_TRUNC, S_IREAD|S_IWRITE);
	if ( fd == -1 )
	{
		printf("Open file %s for write failed\n", filename);
		return -1;
	}
	len = sizeof(buf);
	if ( !csr.FormatDER(buf, len, err) )
	{
		printf("Fail format DER buf: %s\n", err.c_str());
		return -1;
	}	
	
	if ( !write(fd, buf, len) )
	{
		printf("Write file %s fail\n", filename);
		return -1;
	}
	printf("Write %d byte to file %s\n", len, filename);
	close(fd);	
	//
	// Step 7: Load back DER
	//	
	printf("Read X509 CSR from DER file %s ...\n", filename);
	fd = open(filename, 0);
	if ( fd == -1 )
	{
		printf("Open file %s for read fail\n", filename);
		return -1;
	}
	fstat(fd, &stat);
	if ( read(fd, buf, stat.st_size) != stat.st_size )
	{
		printf("Read file %s fail\n", filename);
		return -1;
	}
	len = stat.st_size;
	close(fd);
	
	x509_CSR csr_der;
	if ( !csr_der.LoadDER(buf, len, err) )
	{
		printf("csr_der load from DER buf fail: %s\n", err.c_str());
		return -1;
	}
	if ( csr_der == csr )
	{
		printf("csr_der == csr\n");
	}
	else
	{
		printf("csr_der != csr\n");
		output = csr_der.DumpReadable();
		printf("%s\n", output.c_str());
		return -1;
	}
	//
	// Step 8: Encode to buffer
	//
	printf("Encode X509 CSR to buffer ...\n");
	len = sizeof(buf);
	XdrEncode en(buf, len);
	if ( !csr.XdrEncode(&en, err) )
	{
		printf("Encode fail: %s\n", err.c_str());
		return -1;
	}
	len = en.GetLength();
	printf("Encode csr to buffer with %d bytes\n", len);
	//
	// Step 9: Decode from buffer
	//
	printf("Decode X509 CSR from buffer ...\n");
	XdrDecode de(buf, len);
	x509_CSR csr_de;
	if ( !csr_de.XdrDecode(&de, err) )
	{
		printf("Decode fail: %s\n", err.c_str());
		return -1;
	}
	if ( csr_de == csr )
	{
		printf("csr_decode == csr\n");
	}
	else
	{
		printf("csr_decode != csr\n");
		output = csr_de.DumpReadable();
		printf("%s\n", output.c_str());
		return -1;
	}

	return 0;
}

