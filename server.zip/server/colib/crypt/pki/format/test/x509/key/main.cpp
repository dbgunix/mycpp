#include <idirect/crypt/pki/format/x509_rsa_key.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

using namespace colib;

int	main()
{
	string output, err;
	//
	// Step 1: Generate RSA key
	//
	printf("Generate X509 RSA key ...\n");
	x509_RSAkey key;
	if ( !key.GeneratePrivateKeypair(err) )
	{
		printf("Fail to generate X509 RSA key: %s\n", err.c_str());
		return -1;
	}
	//
	// Step 2: Dump Readable
	//
	printf("Print X509 RSA key ...\n");
	output = key.DumpReadable();
	printf("%s\n", output.c_str());
	//
	// Step 3: Save to file in PEM
	//
	const char* filename = "key.pem";
	printf("Save X509 RSA key to PEM file %s ...\n", filename);	
	int fd = open(filename, O_CREAT|O_RDWR|O_TRUNC, S_IREAD|S_IWRITE);
	if ( fd == -1 )
	{
		printf("Open file %s for write failed\n", filename);
		return -1;
	}
	if ( !key.FormatPEM(output, err) )
	{
		printf("Fail format PEM string\n");
		return -1;
	}	
	
	if ( !write(fd, output.c_str(), output.get_length()) )
	{
		printf("Write file %s fail\n", filename);
		return -1;
	}
	printf("Write %d byte to file %s\n", output.get_length(), filename);
	close(fd);	
	//
	// Step 4: Load back PEM
	//	
	printf("Read X509 RSA key from PEM file %s ...\n", filename);
	fd = open(filename, 0);
	if ( fd == -1 )
	{
		printf("Open file %s for read fail\n", filename);
		return -1;
	}
	char buf[65535];
	struct stat stat;
	fstat(fd, &stat);
	if ( read(fd, buf, stat.st_size) != stat.st_size )
	{
		printf("Read file %s fail\n", filename);
		return -1;
	}
	unsigned len = stat.st_size;
	close(fd);
	
	x509_RSAkey key_pem;
	if ( !key_pem.LoadPEM(string(buf, len), err) )
	{
		printf("key_pem load from PEM buf fail: %s\n", err.c_str());
		return -1;
	}
	if ( key_pem == key )
	{
		printf("key_pem == key\n");
	}
	else
	{
		printf("key_pem != key\n");
		output = key_pem.DumpReadable();
		printf("%s\n", output.c_str());
		return -1;
	}
	//
	// Step 5: Save to file in DER
	//
	filename = "key.der";
	printf("Save X509 RSA key to DER file %s ...\n", filename);	
	fd = open(filename, O_CREAT|O_RDWR|O_TRUNC, S_IREAD|S_IWRITE);
	if ( fd == -1 )
	{
		printf("Open file %s for write failed\n", filename);
		return -1;
	}
	len = sizeof(buf);
	if ( !key.FormatDER(buf, len, err) )
	{
		printf("Fail format DER buf: %s\n", err.c_str());
		return -1;
	}	
	
	if ( !write(fd, buf, len) )
	{
		printf("Write file %s fail\n", filename);
		return -1;
	}
	printf("Write %d byte to file %s\n", len, filename);
	close(fd);	
	//
	// Step 6: Load back DER
	//	
	printf("Read X509 RSA key from DER file %s ...\n", filename);
	fd = open(filename, 0);
	if ( fd == -1 )
	{
		printf("Open file %s for read fail\n", filename);
		return -1;
	}
	fstat(fd, &stat);
	if ( read(fd, buf, stat.st_size) != stat.st_size )
	{
		printf("Read file %s fail\n", filename);
		return -1;
	}
	len = stat.st_size;
	close(fd);
	
	x509_RSAkey key_der;
	if ( !key_der.LoadDER(buf, len, err) )
	{
		printf("key_der load from DER buf fail: %s\n", err.c_str());
		return -1;
	}
	if ( key_der == key )
	{
		printf("key_der == key\n");
	}
	else
	{
		printf("key_der != key\n");
		output = key_der.DumpReadable();
		printf("%s\n", output.c_str());
		return -1;
	}
	//
	// Step 7: Encode to buffer
	//
	printf("Encode X509 RSA key to buffer ...\n");
	len = sizeof(buf);
	XdrEncode en(buf, len);
	if ( !key.XdrEncode(&en, err) )
	{
		printf("Encode fail: %s\n", err.c_str());
		return -1;
	}
	len = en.GetLength();
	printf("Encode key to buffer with %d bytes\n", len);
	//
	// Step 8: Decode from buffer
	//
	printf("Decode X509 RSA key from buffer ...\n");
	XdrDecode de(buf, len);
	x509_RSAkey key_de;
	if ( !key_de.XdrDecode(&de, err) )
	{
		printf("Decode fail: %s\n", err.c_str());
		return -1;
	}
	if ( key_de == key )
	{
		printf("key_decode == key\n");
	}
	else
	{
		printf("key_decode != key\n");
		output = key_de.DumpReadable();
		printf("%s\n", output.c_str());
		return -1;
	}

	return 0;
}

