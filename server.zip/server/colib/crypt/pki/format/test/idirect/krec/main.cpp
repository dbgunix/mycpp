#include <idirect/crypt/pki/format/idirect_krec.h>
#include <idirect/crypt/pki/format/x509_rsa_key.h>
#include <idirect/crypt/pki/format/x509_cert.h>
#include <idirect/crypt/pki/format/x509_csr.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <openssl/ssl.h>

using namespace colib;

int	main()
{	
	SSL_load_error_strings();
	OpenSSL_add_all_algorithms();
	
	string dn[] = {"PemTestCert", "US", "VA", "colib", "Engineer", "NMS", "1", "hcheng@idirect.net"}; 
	string output, err;
	//
	printf("Generate CA X509 RSA key ...\n");
	x509_RSAkey ca_key;
	if ( !ca_key.GeneratePrivateKeypair(err) )
	{
		printf("Fail to generate X509 RSA key: %s\n", err.c_str());
		return -1;
	}	
	//
	printf("Generate CA X509 Certificate signed by the CA key ...\n");
	x509_Certificate ca_cert;
	if ( !ca_cert.GenerateCertificateFromDN(err, dn, ca_key) )
	{
		printf("Generate X509 certificate fail: %s\n", err.c_str());
		return -1;
	}	
	//
	string subject_name[] = {"II+.8888", "CN", "SZ", "", "", "", "", ""};

	printf("Generate X509 RSA key ...\n");
	x509_RSAkey key;
	if ( !key.GeneratePrivateKeypair(err) )
	{
		printf("Fail to generate X509 RSA key: %s\n", err.c_str());
		return -1;
	}	
	//
	printf("Generate X509 CSR signed by the key ...\n");
	x509_CSR csr;	
	if ( !csr.GenerateCSR4Encipher(err, key, subject_name) ) 
//	if ( !csr.GenerateCSR4SignCert(err, key, subject_name) ) 
	{
		printf("Generate CSR fail: %s\n", err.c_str());
		return -1;
	}
	//
	printf("Sign CSR with CA ...\n");
	x509_Certificate cert;
	if  ( !cert.GenerateCertificateFromCSR(err, csr, ca_cert, ca_key, 12345) )
	{
		printf("Fail to sign CSR: %s\n", err.c_str());
		return -1;
	}
	
	printf("Create KeyRecord from Certificate ...\n");
	KeyRecord krec;
	if ( !krec.LoadPublicKeyFromX509Certificate(&cert, err) )
	{
		printf("Fail to create KeyRecord from Certificate\n");
		return -1;
	}
	/*
	printf("Create KeyRecord from RSA key ...\n");
	KeyRecord krec;
	if ( !krec.LoadFromX509RSAkey("Test", &key, err) )
	{
		printf("Fail to create KeyRecord from RSA key\n");
		return -1;
	}
	*/
	//
	// Step 3: Dump Readable
	//
	printf("Print KeyRecord ...\n");
	output = krec.DumpReadable();
	printf("%s\n", output.c_str());
	//
	// Step 4: Save to file
	//
	const char* filename = "krec.txt";
	printf("Save KeyRecord to file %s ...\n", filename);	
	int fd = open(filename, O_CREAT|O_RDWR|O_TRUNC, S_IREAD|S_IWRITE);
	if ( fd == -1 )
	{
		printf("Open file %s for write failed\n", filename);
		return -1;
	}
	output = "";
	if ( !krec.Format(output, err) )
	{
		printf("Fail format string\n");
		return -1;
	}	
	
	if ( !write(fd, output.c_str(), output.get_length()) )
	{
		printf("Write file %s fail\n", filename);
		return -1;
	}
	printf("Write %d byte to file %s\n", output.get_length(), filename);
	close(fd);	
	//
	// Step 5: Load back
	//	
	printf("Read KeyRecord from file %s ...\n", filename);
	fd = open(filename, 0);
	if ( fd == -1 )
	{
		printf("Open file %s for read fail\n", filename);
		return -1;
	}
	char buf[65535];
	struct stat stat;
	fstat(fd, &stat);
	if ( read(fd, buf, stat.st_size) != stat.st_size )
	{
		printf("Read file %s fail\n", filename);
		return -1;
	}
	unsigned len = stat.st_size;
	close(fd);
	
	KeyRecord krec_txt;
	if ( !krec_txt.Load(string(buf, len), err) )
	{
		printf("krec_txt load from buf fail: %s\n", err.c_str());
		return -1;
	}
	if ( krec_txt == krec )
	{
		printf("krec_txt == krec\n");
	}
	else
	{
		printf("krec_txt != krec\n");
		output = krec_txt.DumpReadable();
		printf("%s\n", output.c_str());
		return -1;
	}
	//
	// Step 8: Encode to buffer
	//
	printf("Encode KeyRecord to buffer ...\n");
	len = sizeof(buf);
	XdrEncode en(buf, len);
	if ( !krec.XdrEncode(&en, err) )
	{
		printf("Encode fail: %s\n", err.c_str());
		return -1;
	}
	len = en.GetLength();
	printf("Encode krec to buffer with %d bytes\n", len);
	//
	// Step 9: Decode from buffer
	//
	printf("Decode KeyRecord from buffer ...\n");
	XdrDecode de(buf, len);
	KeyRecord krec_de;
	if ( !krec_de.XdrDecode(&de, err) )
	{
		printf("Decode fail: %s\n", err.c_str());
		return -1;
	}
	if ( krec_de == krec )
	{
		printf("krec_decode == krec\n");
	}
	else
	{
		printf("krec_decode != krec\n");
		output = krec_de.DumpReadable();
		printf("%s\n", output.c_str());
		return -1;
	}

	return 0;
}

