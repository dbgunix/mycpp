// x509_rsa_key.cpp
// vi:set ts=4 sw=4 nowrap:

#include <crypt/pki/format/x509_rsa_key.h>
#include <crypt/x509utils/ossl_io.h>
#include <crypt/x509utils/ossl_utils.h>

#include <openssl/x509.h>
#include <openssl/pem.h>

namespace colib
{
	x509_RSAkey::x509_RSAkey()
	{
		m_rsa = 0;
	}
	
	x509_RSAkey::x509_RSAkey(const x509_RSAkey& key)
	{
		RSA* rsa = (RSA*)key.GetRSA();

		if ( !rsa )
		{	
			m_rsa = 0;
			return;
		}
	
		if ( key.IsPrivate() )
		{
			m_rsa = RSAPrivateKey_dup(rsa);
		}
		else
		{
			m_rsa = RSAPublicKey_dup(rsa);
		}
	}
	
	x509_RSAkey::x509_RSAkey(const RSA& rsa)
	{
		if ( rsa.d )
		{
			m_rsa = RSAPrivateKey_dup((RSA*)&rsa);
		}
		else
		{
			m_rsa = RSAPublicKey_dup((RSA*)&rsa);
		}
	}

	x509_RSAkey::~x509_RSAkey()
	{
		Clear();
	}

	void		x509_RSAkey::Clear()
	{
		if ( m_rsa )
		{	
			RSA_free(m_rsa);
			m_rsa = 0;
		}
	}

	bool		x509_RSAkey::IsOK() const
	{
		string err;
		return CheckRSA(err);
	}

	void		x509_RSAkey::Zeroize()
	{
		zeroize_rsa_key(m_rsa);
	}

	string		x509_RSAkey::DumpReadable() const
	{
		string output, err;		
		if ( FormatHumanReadable(output, err) ) return output;
		return "X509 RSA key fail DumpReadable: " + err;
	}

	bool		x509_RSAkey::XdrDecode(CXDR* xdr, string& err)
	{	
		string data;
		if ( !xdr->XdrStringPacked(data) )
		{
			err = "XDR Decode PEM format string fail";
			return false;
		}
	
		return LoadPEM(data, err);
	}

	bool		x509_RSAkey::XdrEncode(CXDR* xdr, string& err) const
	{
		string output;
		if ( !FormatPEM(output, err) ) return false;
		
		if ( !xdr->XdrStringPacked(output) )
		{
			err = "XDR Encode PEM format string fail";
			return false;
		}
	
		return true;	
	}

	bool		x509_RSAkey::CheckRSA(string& err) const
	{	
		if ( !m_rsa )
		{
			err = "No RSA key";
			return false;
		}

		return true;
	}

	bool		x509_RSAkey::GeneratePrivateKeypair(string& err, int numBit, unsigned long exponent)
	{
		Clear();	
		m_rsa = RSA_generate_key(numBit, exponent, 0, 0);
	
		if ( !m_rsa )
		{
			SET_ERROR_HARVEST(err, "Failed to generate RSA keypair");
			return false;
		}

		return true;
	}

	bool		x509_RSAkey::IsPrivate() const
	{
		return ( m_rsa && m_rsa->d );
	}
	
	bool		x509_RSAkey::LoadPEM(string data, string& err)
	{
		return LoadPrivatePEM(data, err);
	}
	
	bool		x509_RSAkey::LoadPublicPEM(string data, string& err)
	{
		Clear();
		BIO* pbio = BIO_new_mem_buf((void*)data.c_str(), -1);
		if ( !pbio )
		{
			SET_ERROR_HARVEST(err, "Failed to create BIO");
			return false;
		}
	
		bool ret = PEM_read_bio_RSAPublicKey(pbio, &m_rsa, 0, (void*)NO_PASSWORD);
		if ( !ret ) SET_ERROR_HARVEST(err, "Failed to parse RSA public key");
		BIO_free(pbio);
		return ret;
	}
	
	bool		x509_RSAkey::LoadPrivatePEM(string data, string& err)
	{
		Clear();
		BIO* pbio = BIO_new_mem_buf((void*)data.c_str(), -1);	
		if ( !pbio )
		{
			SET_ERROR_HARVEST(err, "Failed to create BIO");
			return false;
		}
	
		bool ret = PEM_read_bio_RSAPrivateKey(pbio, &m_rsa, 0, (void*)NO_PASSWORD);
		if ( !ret ) SET_ERROR_HARVEST(err, "Failed to parse RSA private key");
		BIO_free(pbio);
		return ret;
	}
	
	bool		x509_RSAkey::FormatPEM(string& output, string& err) const
	{
		return FormatPrivateUnencryptedPEM(output, err);
	}

	bool		x509_RSAkey::FormatPublicPEM(string& output, string& err) const
	{
		if ( !CheckRSA(err) ) return false;

		BIO* bio = CreateWriteOnlyStringBIO(output, err);
		if ( !bio ) return false;

		bool ret = PEM_write_bio_RSAPublicKey(bio, m_rsa);
		if ( !ret )	SET_ERROR_HARVEST(err, "Failed to format rsa public key");
		BIO_free(bio);
		return ret;
	}

	bool		x509_RSAkey::FormatPrivateUnencryptedPEM(string& output, string& err) const
	{	
		if ( !CheckRSA(err) ) return false;

		BIO* bio = CreateWriteOnlyStringBIO(output, err);
		if ( !bio ) return false;

		bool ret = PEM_write_bio_RSAPrivateKey(bio, m_rsa, NULL, 0, 0, 0, (void*)NO_PASSWORD);
		if ( !ret )	SET_ERROR_HARVEST(err, "Failed to format rsa private key");
		BIO_free(bio);
		return ret;
	}
	
	bool		x509_RSAkey::LoadDER(char* data, unsigned len, string& err) 
	{
		return LoadPrivateDER(data, len, err);
	}
	
	bool		x509_RSAkey::LoadPublicDER(char* data, unsigned len, string& err)
	{
		Clear();

		m_rsa = RSA_new();
		if ( !m_rsa )
		{
			SET_ERROR_HARVEST(err, "Fail to create RSA");
			return false;
		}

		const unsigned char* p = (const unsigned char*)data;
		if ( !d2i_RSAPublicKey(&m_rsa, &p, (long)len) )
		{
			SET_ERROR_HARVEST(err, "Fail to decode DER public key");
			return false;
		}
		
		return true;		
	}

	bool		x509_RSAkey::LoadPrivateDER(char* data, unsigned len, string& err)
	{	
		Clear();

		m_rsa = RSA_new();
		if ( !m_rsa )
		{
			SET_ERROR_HARVEST(err, "Fail to create RSA");
			return false;
		}

		const unsigned char* p = (const unsigned char*)data;
		if ( !d2i_RSAPrivateKey(&m_rsa, &p, (long)len) )
		{
			SET_ERROR_HARVEST(err, "Fail to decode DER private key");
			return false;
		}

		return true;		
	}

	bool		x509_RSAkey::FormatDER(char* data, unsigned& len, string& err) const
	{
		return FormatPrivateUnencryptedDER(data, len, err);
	}

	bool		x509_RSAkey::FormatPublicDER(char* data, unsigned& len, string& err) const
	{
		if ( !CheckRSA(err) ) return false;		
	
		unsigned char* p = (unsigned char*)data;
		len = i2d_RSAPublicKey(m_rsa, &p);
		
		if ( !len ) 
		{
			SET_ERROR_HARVEST(err, "Fail to encode DER public key");
			return false;
		}
		
		return true;
	}

	bool		x509_RSAkey::FormatPrivateUnencryptedDER(char* data, unsigned& len, string& err) const
	{	
		if ( !CheckRSA(err) ) return false;

		unsigned char* p = (unsigned char*)data;
		len = i2d_RSAPrivateKey(m_rsa, &p);

		if ( !len ) 
		{
			SET_ERROR_HARVEST(err, "Fail to encode DER private key");
			return false;
		}
	
		return true;
	}

	bool		x509_RSAkey::operator==(const x509_RSAkey& key) const
	{	
		//
		// Comment by Hao: what a terrible solution!!!
		//
		string t1, t2, err;
		if ( 
			FormatPEM(t1, err) &&
			key.FormatPEM(t2, err) &&
			( t1 == t2 ) ) return true;

		return false;
	}

	x509_RSAkey&	x509_RSAkey::operator=(const x509_RSAkey& key)
	{
		Clear();	
	
		if ( key.IsPrivate() )
		{
			m_rsa = RSAPrivateKey_dup((RSA*)key.GetRSA());
		}
		else
		{
			m_rsa = RSAPublicKey_dup((RSA*)key.GetRSA());
		}
	
		return *this;
	}

	bool			x509_RSAkey::FormatHumanReadable(string& output, string& err) const
	{
		if ( !CheckRSA(err) ) return false;

		BIO* bio = CreateWriteOnlyStringBIO(output, err);
		if ( !bio ) return false;
		//
		// Never print private info, public ONLY!
		//
		RSA* rsa = RSAPublicKey_dup(m_rsa);
		bool ret = RSA_print(bio, rsa, 0);
		RSA_free(rsa);
		if ( !ret ) SET_ERROR_HARVEST(err, "Fail to format RSA key");
		BIO_free(bio);		
		return ret;
	}

}//end namespace colib

