// types.h
// vi:set ts=4 sw=4 nowrap:

#ifndef PKI_CONST_H_ALREADY_INCLUDED
#define PKI_CONST_H_ALREADY_INCLUDED

namespace colib
{
	const char*	const	NO_PASSWORD				=	"no password";
	const char* const	PKI_VERSION				=	"2.0";

	const char* const	PKI_TYPE_X509_CERT		=	"X509_CERTIFICATE";
	const char* const	PKI_TYPE_X509_CRL		=	"X509_REVOCATION_LIST";
	const char* const	PKI_TYPE_X509_RSA_KEY	=	"X509_RSA_KEY";
	const char* const	PKI_TYPE_X509_CSR		=	"X509_CSR";
	
	const char* const	PKI_TYPE_IDIRECT_KEY	=	"IDIRECT_KEY";
	const char*	const	PKI_TYPE_IDIRECT_SIG	=	"IDIRECT_SIGNATURE";
	
	const char* const	IDIRECT_NAME 			=	"Name:";
	const char* const	IDIRECT_SIGNER			=	"Signer:";
	const char* const	IDIRECT_COMMENT			=	"Comment:";
	const char* const	IDIRECT_TYPE			=	"Type:";

	const char* const	IDIRECT_KEY_BEGIN		=	"--IDIRECT_KEY_BEGIN--";
	const char* const	IDIRECT_KEY_END			=	"--IDIRECT_KEY_END--";
	const char* const	IDIRECT_RSA_PUBKEY		=	"IDIRECT_KEY_RSA_PUBKEY";
	const char* const	IDIRECT_RSA_PRIVKEY		=	"IDIRECT_KEY_RSA_PRIVKEY";

	const char* const	IDIRECT_SIG_BEGIN		=	"--IDIRECT_SIG_BEGIN--";
	const char* const	IDIRECT_SIG_END			=	"--IDIRECT_SIG_END--";
	const char* const	IDIRECT_SIG_RSA_SHA1	=	"IDIRECT_SIG_RSA_SHA1";
	const char* const	IDIRECT_SIG_RSA_SHA256  =   "IDIRECT_SIG_RSA_SHA256";
	const char* const	IDIRECT_SIG_RSA_SHA512	=	"IDIRECT_SIG_RSA_SHA512";

}//end namespace colib

#endif

