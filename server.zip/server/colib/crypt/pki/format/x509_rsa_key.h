// x509_rsa_key.h
// vi:set ts=4 sw=4 nowrap:

#ifndef X509_RSA_KEY_H_ALREADY_INCLUDED
#define X509_RSA_KEY_H_ALREADY_INCLUDED

#include <crypt/pki/format/base.h>
#include <crypt/pki/format/const.h>

#include <openssl/rsa.h>

namespace colib
{
	class x509_RSAkey : public pki_base
	{
		public:
		
									x509_RSAkey();
									x509_RSAkey(const x509_RSAkey& key);
									x509_RSAkey(const RSA& x509_key);
			virtual					~x509_RSAkey();
			//
			// Implementation of pure virtual functions in base
			//
			virtual const char*		GetType() const { return PKI_TYPE_X509_RSA_KEY; }	
			virtual bool			IsOK() const;
			virtual bool			XdrDecode(CXDR* xdr, string& err);
			virtual bool			XdrEncode(CXDR* xdr, string& err) const;
			virtual void			Zeroize();
			virtual void			Clear();	
			virtual string			DumpReadable() const;
			//
			// Other functions
			//	
			bool 					operator==(const x509_RSAkey& key) const;
			x509_RSAkey&			operator=(const x509_RSAkey& key);

			const RSA*				GetRSA() const { return m_rsa; }

			bool					IsPrivate() const;
			bool					GeneratePrivateKeypair(string& err, int numBit = 2048, unsigned long exponent = 65537);

			bool					LoadPEM(string data, string& err);
			bool					FormatPEM(string& output, string& err) const;

			bool					LoadDER(char* data, unsigned len, string& err);
			bool					FormatDER(char* data, unsigned& len, string& err) const;
	
			bool					LoadPublicPEM(string data, string& err);
			bool					FormatPublicPEM(string& output, string&err) const;			
	
			bool					LoadPublicDER(char* data, unsigned len, string& err);
			bool					FormatPublicDER(char* data, unsigned& len, string& err) const;
	
			bool					FormatHumanReadable(string& output, string& err) const;

		protected:

			bool					CheckRSA(string& err) const;
	
			bool					LoadPrivatePEM(string data, string& err);	
			bool					FormatPrivateUnencryptedPEM(string&output, string& err) const;
		
			bool					LoadPrivateDER(char* data, unsigned len, string& err);
			bool					FormatPrivateUnencryptedDER(char* datat, unsigned& len, string& err) const;
	
		protected:

			RSA*					m_rsa;
	};
	
}//end namespace colib


#endif

