// idirect_corp_checker_x509.h
// vi:set ts=4 sw=4 nowrap:

#ifndef IDIRECT_CORP_CHECKER_H_ALREADY_INCLUDED
#define IDIRECT_CORP_CHECKER_H_ALREADY_INCLUDED

#include <crypt/pki/checker/x509.h>
#include <crypt/pki/format/x509_cert.h>

//#define DEVELOPMENT_DEBUG

namespace colib
{
	class iDirectCorpX509CertChecker : public X509CertChecker
	{
		public:

			static iDirectCorpX509CertChecker&	GetInstance();

			virtual void						Clear();			
			virtual void						Zeroize();
			virtual bool						AddTrustedCert(pki_base*, string& err) { err = "Not supported"; return false; }
			virtual bool						VerifyCert(pki_base* cert, string& err, time_t check_time);

			const x509_Certificate*				GetCorpX509Cert() const { return &m_idirect_corp_cert_x509; }
#ifdef DEVELOPMENT_DEBUG
			const x509_Certificate*				GetDevelopX509Cert() const { return &m_idirect_develop_cert_x509; }
#endif
		private:

			virtual								~iDirectCorpX509CertChecker();
												iDirectCorpX509CertChecker();
			
			bool								LoadCorpPEMCert(string& err);

		private:
				
			x509_Certificate					m_idirect_corp_cert_x509;		
#ifdef DEVELOPMENT_DEBUG
			x509_Certificate					m_idirect_develop_cert_x509;
#endif
			bool								m_ok;
	};

}//end namespace colib


#endif

