// base.h
// vi:set ts=4 sw=4 nowrap:

#ifndef CHECKER_BASE_H_ALREADY_INCLUDED
#define CHECKER_BASE_H_ALREADY_INCLUDED

#include <crypt/pki/format/base.h>

#include <time.h>

namespace colib
{
	class CertChecker
	{
		public:
			//
			// Values of cert authenticate level, 
			// 0 -- accept everything
			// 1 -- can not be self-signed cert
			// 2 -- cert subject ID must be verified
			//
			static const int	CHAIN_OF_TRUST = 0x0001;
			static const int	REQUIRE_ID = 0x0002;
			static bool			RequireChainOfTrust(int auth_level);
			static bool			RequireVerifyCertID(int auth_level);

		public:
		
								CertChecker() {};
			virtual				~CertChecker() {};

			//
			// Pure virtual functions
			//
			virtual void		Clear() = 0;
			virtual void		Zeroize() = 0;
			virtual bool		AddTrustedCert(pki_base* cert, string& err) = 0;
			virtual bool		AddUntrustedCert(pki_base* cert, string& err) = 0;
			virtual bool		AddRevocationList(pki_base* crl, string& err) = 0;
			virtual bool		VerifyCert(pki_base* cert, string& err, time_t check_time) = 0;
			virtual bool		FindCertBySubject(string subject, pki_base* cert, string& err) = 0;
	};

	inline bool		CertChecker::RequireChainOfTrust(int auth_level)
	{
		return ( auth_level & CHAIN_OF_TRUST );
	}

	inline bool		CertChecker::RequireVerifyCertID(int auth_level)
	{
		return ( auth_level & REQUIRE_ID );
	}

}//end namespace colib


#endif

