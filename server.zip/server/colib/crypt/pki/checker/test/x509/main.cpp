#include <idirect/crypt/pki/format/x509_rsa_key.h>
#include <idirect/crypt/pki/format/x509_cert.h>
#include <idirect/crypt/pki/format/x509_csr.h>
#include <idirect/crypt/pki/format/x509_crl.h>
#include <idirect/crypt/pki/checker/idirect_corp_checker_x509.h>
#include <idirect/crypt/pki/checker/customer_checker_x509.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <openssl/ssl.h>

using namespace colib;

int	main()
{	
	SSL_load_error_strings();
	OpenSSL_add_all_algorithms();
	
	string dn[] = {"RootCert", "US", "VA", "colib", "Engineer", "NMS", "1", "hcheng@idirect.net"}; 
	string untrusted[] = {"SignCert", "US", "VA", "iGT", "", "", "", ""};
	string remote[] = {"Remote", "CN", "SZ", "", "", "", "", ""};
	string output, err;	
	//
	printf("Generate Root CA X509 RSA key ...\n");
	x509_RSAkey ca_key;
	if ( !ca_key.GeneratePrivateKeypair(err) )
	{
		printf("Fail to generate X509 RSA key: %s\n", err.c_str());
		return -1;
	}	
	//
	printf("Generate Root CA X509 Certificate signed by the Root CA key ...\n");
	x509_Certificate ca_cert;
	if ( !ca_cert.GenerateCertificateFromDN(err, dn, ca_key) )
	{
		printf("Generate X509 certificate fail: %s\n", err.c_str());
		return -1;
	}	
	/*
	printf("Print CA X509 Certificate ...\n");
	output = ca_cert.DumpReadable();
	printf("%s\n", output.c_str());	
	*/
	printf("Generate Untrusted CA X509 RSA key ...\n");
	x509_RSAkey ukey;
	if ( !ukey.GeneratePrivateKeypair(err) )
	{
		printf("Fail to generate X509 RSA key: %s\n", err.c_str());
		return -1;
	}	
	//
	printf("Generate Untrusted X509 CSR signed by the ukey ...\n");
	x509_CSR ucsr;
	if ( !ucsr.GenerateCSR4SignCert(err, ukey, untrusted) ) 
	{
		printf("Generate CSR fail: %s\n", err.c_str());
		return -1;
	}
	//
	printf("Sign Untrusted CSR with Root CA ...\n");
	x509_Certificate ucert;
	if  ( !ucert.GenerateCertificateFromCSR(err, ucsr, ca_cert, ca_key, 100) )
	{
		printf("Fail to sign CSR: %s\n", err.c_str());
		return -1;
	}
	/*
	printf("Print Untrusted CA X509 Certificate ...\n");
	output = ucert.DumpReadable();
	printf("%s\n", output.c_str());	
	*/
	//	
	printf("Generate Remote X509 RSA key ...\n");
	x509_RSAkey key;
	if ( !key.GeneratePrivateKeypair(err) )
	{
		printf("Fail to generate X509 RSA key: %s\n", err.c_str());
		return -1;
	}	
	//
	printf("Generate Remote X509 CSR signed by the key ...\n");
	x509_CSR csr;
	if ( !csr.GenerateCSR4Encipher(err, key, remote) ) 
	{
		printf("Generate CSR fail: %s\n", err.c_str());
		return -1;
	}
	//
	printf("Sign CSR with Untrursted CA ...\n");
	x509_Certificate cert;
	if  ( !cert.GenerateCertificateFromCSR(err, csr, ucert, ukey, 12345) )
	{
		printf("Fail to sign CSR: %s\n", err.c_str());
		return -1;
	}
	/*	
	printf("Print X509 Certificate ...\n");
	output = cert.DumpReadable();
	printf("%s\n", output.c_str());
	*/
	//
	err = "";
	if ( !iDirectCorpX509CertChecker::GetInstance().AddTrustedCert(&ca_cert, err) )
	{
		printf("Add Trusted to colib Corp Checker fail: %s\n", err.c_str());
	}	
	else printf("Add Trusted to colib Corp Checker succeed\n");

	err = "";
	if ( !CustomerX509CertChecker::GetInstance().AddTrustedCert(&ca_cert, err) )
	{
		printf("Add Trusted to Customer Checker fail: %s\n", err.c_str());
		return -1;
	}	
	else printf("Add Trusted to Customer Checker succeed\n");
	printf("Add Untrusted to Customer Checker ...\n");

	err = "";	
	if ( !iDirectCorpX509CertChecker::GetInstance().AddUntrustedCert(&ucert, err) )
	{
		printf("Add Untrusted to colib Corp Checker fail: %s\n", err.c_str());
		return -1;
	}	
	else printf("Add Untrusted to colib Corp Checker succeed\n");

	err = "";
	if ( !CustomerX509CertChecker::GetInstance().AddUntrustedCert(&ucert, err) )
	{
		printf("Add Unrusted to Customer Checker fail: %s\n", err.c_str());
		return -1;
	}		
	else printf("Add Untrusted to Customer Checker succeed\n");
	/*
	err = "";
	if ( !iDirectCorpX509CertChecker::GetInstance().VerifyCert(&cert, err, 0) )
	{
		printf("colib Corp Check fail verify remote cert: %s\n", err.c_str());
	}
	else printf("colib Corp Checker successfully verify remote cert\n");
	*/
	err = "";
	if ( !CustomerX509CertChecker::GetInstance().VerifyCert(&cert, err, 0) )
	{
		printf("Customer Checker fail verify cert: %s\n", err.c_str());
	}
	else printf("Customer Checker successfully verify remote cert\n");
	
	x509_RevocationList crl;	
	err = "";
	printf("Revoke remote cert ...\n");
	if ( !crl.RevokeCertificate(cert, err) )
	{
		printf("CRL fail to revoke cert: %s\n", err.c_str());
		return -1;
	}
	printf("Sign CRL ...\n");
	if ( !crl.Sign(ukey, ucert, err) )
	{
		printf("Fail to sign CRL: %s\n", err.c_str());
		return -1;
	}
	printf("Add CRL to Customer Checker ...\n");
	if ( !CustomerX509CertChecker::GetInstance().AddRevocationList(&crl, err) )
	{
		printf("Add CRL to Customer Checker fail: %s\n", err.c_str());
		return -1;
	}
	err = "";
	if ( !CustomerX509CertChecker::GetInstance().VerifyCert(&cert, err, 0) )
	{
		printf("Customer Checker fail verify cert: %s\n", err.c_str());
	}
	else printf("Customer Checker successfully verify remote cert\n");
	
	return 0;
}

