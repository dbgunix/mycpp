// customer_checker_x509.h
// vi:set ts=4 sw=4 nowrap:

#ifndef CUSTOMER_CHECKER_H_ALREADY_INCLUDED
#define CUSTOMER_CHECKER_H_ALREADY_INCLUDED

#include <crypt/pki/checker/x509.h>
#include <crypt/pki/format/x509_cert.h>

namespace colib
{
	class CustomerX509CertChecker : public X509CertChecker
	{
		public:

			static CustomerX509CertChecker&		GetInstance();

		private:

			virtual								~CustomerX509CertChecker() {};
												CustomerX509CertChecker() {};
	};


}//end namespace colib


#endif

