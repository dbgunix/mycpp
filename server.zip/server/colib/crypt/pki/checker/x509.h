// x509.h
// vi:set ts=4 sw=4 nowrap:

#ifndef X509_CHECKER_H_ALREADY_INCLUDED
#define X509_CHECKER_H_ALREADY_INCLUDED

#include <crypt/pki/checker/base.h>

#include <openssl/x509.h>

namespace colib
{
	class X509CertChecker : public CertChecker
	{
		public:

			static const int	MIN_CERT_KEY_BITS = 2048;
		
								X509CertChecker();
			virtual				~X509CertChecker();
			//
			// Implement pure virtual functions
			//
			virtual void		Clear();
			virtual void		Zeroize();
			virtual bool		AddTrustedCert(pki_base* cert, string& err);
			virtual bool		AddUntrustedCert(pki_base* cert, string& err);
			virtual bool		AddRevocationList(pki_base* crl, string& err);
			virtual bool		VerifyCert(pki_base* cert, string& err, time_t check_time);
			virtual bool		FindCertBySubject(string subject, pki_base* cert, string& err);
	
		protected:
		
			void				InternalInit();
			void				InternalClear();
			bool				VerifyX509Cert(pki_base* cert, string& err, const X509* &x509);

		protected:
		
			X509_STORE*			m_x509_store;
			STACK_OF(X509)*		m_untrusted;
	};


}//end namespace colib


#endif

