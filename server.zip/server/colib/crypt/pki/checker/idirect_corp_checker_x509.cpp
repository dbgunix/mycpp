// idrect_corp_checker_x509.cpp
// vi:set ts=4 sw=4 nowrap:

#include <crypt/pki/checker/idirect_corp_checker_x509.h>

namespace colib
{
	const char* idirect_corporate_cert_pem_data =
"-----BEGIN CERTIFICATE-----\n\
MIIDNTCCAh2gAwIBAgIBADANBgkqhkiG9w0BAQUFADBeMSMwIQYDVQQDFBppRGly\n\
ZWN0X0NvcnBvcmF0ZV9LZXlfMjAwNjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAlZB\n\
MRAwDgYDVQQKEwdpRGlyZWN0MQswCQYDVQQLEwJDTTAeFw0wNjA2MjgxNTQ3MTZa\n\
Fw0xNjA2MjUxNTQ3MTZaMF4xIzAhBgNVBAMUGmlEaXJlY3RfQ29ycG9yYXRlX0tl\n\
eV8yMDA2MQswCQYDVQQGEwJVUzELMAkGA1UECBMCVkExEDAOBgNVBAoTB2lEaXJl\n\
Y3QxCzAJBgNVBAsTAkNNMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA\n\
2BL6LhieznpcmbGHRRuS9V2wrmEkoRz3jH1YxkOiakkE/rmC6SXojuTKWHMvKOO4\n\
ezY9MLjuhD0loNKrdiJc5/RcFytIkF6lmPPOeyhzqSquow28lftihuMDrl6agoz4\n\
0Vp37KHJvfuWhmcNUloDfwpCIdBtr/PshGufhi29k74dUheOc4SJ+aPqYY5wjadR\n\
4swkVSLlCNHjrzP88ByLKAfPS7gzN2DowhnmuKMTECFMgXg6O63Yw2Ps2Hg0Lt7T\n\
9IK4UsKILRc0HugChVsGxN9m0RTQ/79vZSZoyRtzybrkwKfgBhWBeXBD3XXGehpV\n\
+rOzedMEYJSSS17mfbfqsQIDAQABMA0GCSqGSIb3DQEBBQUAA4IBAQCvNCA0HVVF\n\
Xhy6VbW4LpnYuO+Yl7Xj+SjEyj4vLnEaYSWOI6ddUQzAXe3Bb+XQyZ8z/rUj7nYt\n\
ts4DnQefXxUuCEgobvR83JmtwufpFxTU8gGEusXrbMKebt7SiAS8bySlxcjYZGl9\n\
H9ZDdlPrX9z6rjZom0DAx4eoVDyIX8A7kEvE4+YUJjFwZwo4OhMrHw1qBe+x69od\n\
TcU4TO98lPqMReywXsMJbYmsmy2KpZfb2JDTLwewLXcsBZPYCDImmJ32HPwS+Cm/\n\
twySztTBVa6/19zMKhPTiT86qF6IsixvQWAKHrV2eY9Vi74n0CR3cf8MhH0ShV3n\n\
PHuWkmBDKOTb\n\
-----END CERTIFICATE-----\n\
"; 

#ifdef DEVELOPMENT_DEBUG
	const char *idirect_development_cert_pem_data =
"-----BEGIN CERTIFICATE-----\n\
MIIELDCCAxSgAwIBAgIBADANBgkqhkiG9w0BAQUFADBxMQswCQYDVQQGEwJVUzEL\n\
MAkGA1UECBMCVkExDzANBgNVBAcTBlJlc3RvbjEQMA4GA1UEChMHaURpcmVjdDEW\n\
MBQGA1UECxMNcHJvdG9jb2wgdGVhbTEaMBgGA1UEAxMRZGV2ZWxvcG1lbnQga2V5\n\
IDEwHhcNMDYwMzI4MTYzOTM3WhcNMDYwNDI3MTYzOTM3WjBxMQswCQYDVQQGEwJV\n\
UzELMAkGA1UECBMCVkExDzANBgNVBAcTBlJlc3RvbjEQMA4GA1UEChMHaURpcmVj\n\
dDEWMBQGA1UECxMNcHJvdG9jb2wgdGVhbTEaMBgGA1UEAxMRZGV2ZWxvcG1lbnQg\n\
a2V5IDEwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQC3bcnc3VCMiNfU\n\
W2ZfOgHPeH6smkn1U3FwlPZ4KA5DAu+3lj0K12dwAFFaSz9lt1EVSkP0LTNINKhy\n\
at4Pa0m/ZWHN8UKE3U+DSgPfcrTt3ikTpLmqO7BqFeLMiOZbDAHyc6OY9sGqr/0+\n\
SYdqkbTCsfOwG61pAn6KjwKDED6EJj+NXXRbTU63/22gwzr8jCF/rUwGihzMEEA+\n\
19OeKdptFeEDMaqcSSi6kR2wm4iv6e8IXUF1az/ToYAXusgGUESo26Jokfk7eXu5\n\
yGHD2OKJG9JF9hccpccHY6OcdY9Lhmy9Hoyttdq09Mc7o7HDkg7x9R9bB3XRS/kP\n\
H6/c9DynAgMBAAGjgc4wgcswHQYDVR0OBBYEFO7Q9lXv+2+eif3JZCnUYmHRpCXe\n\
MIGbBgNVHSMEgZMwgZCAFO7Q9lXv+2+eif3JZCnUYmHRpCXeoXWkczBxMQswCQYD\n\
VQQGEwJVUzELMAkGA1UECBMCVkExDzANBgNVBAcTBlJlc3RvbjEQMA4GA1UEChMH\n\
aURpcmVjdDEWMBQGA1UECxMNcHJvdG9jb2wgdGVhbTEaMBgGA1UEAxMRZGV2ZWxv\n\
cG1lbnQga2V5IDGCAQAwDAYDVR0TBAUwAwEB/zANBgkqhkiG9w0BAQUFAAOCAQEA\n\
hP3xcqBP3jBt5NbMSl0XbCsr9WO+i/ygmv+r6FBtGNmZVuXDzRthzmZa2pwBSE4g\n\
TK+DtAjG781jmgb5IdbYbRYNOCzGvdB+LVO71oxU7BbK8QJo6LbVzedQkOVmx6hn\n\
ivkUjT6fgJTL3rY1VNPlyaNjxktsgJOhqBaWyg3MWIa5x29k6+D5LNgdqEyTkAJM\n\
cDMrUK0fpNbkagCZCBoqiSVCz3zhZ9j3k15tQzJoK1BgsON/9HW9FgW6Em9b+b19\n\
57sTZrwMxRUSuw1nIOI+3K0k23N2Io3ymPfEG21yCxCtJ/xcE5OWMLzsNfuciOm+\n\
wM1SUpGdj84rwRJHum0Fmg==\n\
-----END CERTIFICATE-----\n\
";
#endif

	iDirectCorpX509CertChecker&		iDirectCorpX509CertChecker::GetInstance()
	{
		static iDirectCorpX509CertChecker _instance;
		return _instance;
	}

	iDirectCorpX509CertChecker::iDirectCorpX509CertChecker()
	{
		string err;		
		m_ok = LoadCorpPEMCert(err);
	}

	iDirectCorpX509CertChecker::~iDirectCorpX509CertChecker()
	{
		Zeroize();
	}

	bool		iDirectCorpX509CertChecker::LoadCorpPEMCert(string& err)
	{
		bool ret = m_idirect_corp_cert_x509.LoadPEM(idirect_corporate_cert_pem_data, err);
		if ( ret ) ret = X509CertChecker::AddTrustedCert(&m_idirect_corp_cert_x509, err);
#ifdef DEVELOPMENT_DEBUG
		ret = m_idirect_develop_cert_x509.LoadPEM(idirect_development_cert_pem_data, err);
		if ( ret ) ret = X509CertChecker::AddTrustedCert(&m_idirect_develop_cert_x509, err);
#endif
		return ret;
	}

	void		iDirectCorpX509CertChecker::Zeroize()
	{
		m_idirect_corp_cert_x509.Zeroize();
#ifdef DEVELOPMENT_DEBUG
		m_idirect_develop_cert_x509.Zeroize();
#endif
		X509CertChecker::Zeroize();
		m_ok = false;
	}

	void		iDirectCorpX509CertChecker::Clear()
	{
		X509CertChecker::Clear();	
		string err;		
		m_ok = LoadCorpPEMCert(err);	
	}

	bool		iDirectCorpX509CertChecker::VerifyCert(pki_base* cert, string& err, time_t check_time)
	{
		if ( !m_ok ) 
		{
			err = "iDirectCorpX509CertChecker not in OK state";
			return false;
		}

		return X509CertChecker::VerifyCert(cert, err, check_time);
	}

}//end namespace colib

