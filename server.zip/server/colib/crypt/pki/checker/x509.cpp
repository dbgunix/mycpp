// x509.cpp
// vi:set ts=4 sw=4 nowrap:

#include <crypt/pki/checker/x509.h>
#include <crypt/pki/format/x509_cert.h>
#include <crypt/pki/format/x509_crl.h>
#include <crypt/x509utils/ossl_utils.h>

namespace colib
{
	X509CertChecker::X509CertChecker()
	{
		InternalInit();
	}

	void		X509CertChecker::InternalInit()
	{
		m_x509_store = X509_STORE_new();
	
		if ( m_x509_store )
		{
			X509_STORE_set_verify_cb_func(m_x509_store, 0);
		}

		m_untrusted = sk_X509_new_null();
	}

	X509CertChecker::~X509CertChecker()
	{
		InternalClear();
	}

	void		X509CertChecker::InternalClear()
	{
		if ( m_x509_store )
		{
			X509_STORE_free(m_x509_store);
			m_x509_store = 0;
		}

		if ( m_untrusted )
		{
			sk_X509_pop_free(m_untrusted, X509_free);
			m_untrusted = 0;
		}
	}

	void		X509CertChecker::Clear()
	{
		InternalClear();
		InternalInit();
	}

	void		X509CertChecker::Zeroize()
	{
		zeroize_x509_store(m_x509_store);
		zeroize_sk_of_x509(m_untrusted);
	}

	bool		X509CertChecker::VerifyX509Cert(pki_base* cert, string& err, const X509* &x509)
	{
		x509 = 0;

		if ( 
			!cert || 
			strcmp(cert->GetType(), PKI_TYPE_X509_CERT) ||
			( ( x509 = (static_cast<x509_Certificate*>(cert))->GetX509() ) == 0 )
		   )
		{
			err = "Invalid cert";
			return false;
		}

		return true;
	}
	
	bool		X509CertChecker::AddTrustedCert(pki_base* cert, string& err)
	{
		const X509* x509;
		if ( !VerifyX509Cert(cert, err, x509) ) return false;
		if ( !X509_STORE_add_cert(m_x509_store, (X509*)x509) )
		{
			SET_ERROR_HARVEST(err, "Failed to add trusted cert");
			return false;
		}
		return true;
	}

	bool		X509CertChecker::AddUntrustedCert(pki_base* cert, string& err)
	{	
		const X509* x509;
		if ( !VerifyX509Cert(cert, err, x509) ) return false;
		//
		// make a copy of the cert
		//
		X509* new509 = X509_dup((X509*)x509);
		if ( !new509 )
		{
			SET_ERROR_HARVEST(err, "Failed to replicate untrusted cert");
			return false;
		}
	
		sk_X509_push(m_untrusted, new509);
		return true;
	}

	bool		X509CertChecker::AddRevocationList(pki_base* crl, string& err)
	{	
		const X509_CRL* x509_crl = 0;

		if ( 
			!crl || 
			strcmp(crl->GetType(), PKI_TYPE_X509_CRL) ||
			( ( x509_crl = (static_cast<x509_RevocationList*>(crl))->GetX509CRL() ) == 0 )
		   )
		{
			err = "Invalid CRL";
			return false;
		}

		if ( X509_STORE_add_crl(m_x509_store, (X509_CRL*)x509_crl) )
		{	
			X509_STORE_set_flags(m_x509_store, X509_V_FLAG_CRL_CHECK|X509_V_FLAG_CRL_CHECK_ALL);
			return true;
		}
	
		SET_ERROR_HARVEST(err, "Failed to add CRL");
		return false;
	}

	bool		X509CertChecker::VerifyCert(pki_base* cert, string& err, time_t check_time)
	{	
		const X509* x509;
		if ( !VerifyX509Cert(cert, err, x509) ) return false;
		
		if ( !m_x509_store )
		{
			SET_ERROR_HARVEST(err, "No x509 store to verify x509 cert");
			return false;
		}
		
		X509_STORE_CTX* ctx = X509_STORE_CTX_new();
		if ( !ctx )
		{
   			SET_ERROR_HARVEST(err, "Failed to alloc context to verify x509 cert");
			return false;
		}
	
		if ( !X509_STORE_CTX_init(ctx, m_x509_store, (X509*)x509, m_untrusted) )
		{
			SET_ERROR_HARVEST(err, "Failed to init context to verify x509 cert");
			X509_STORE_CTX_free(ctx);
			return false;
		}
	
		int algo = OBJ_obj2nid(x509->sig_alg->algorithm);

		if ( 
			( algo != NID_sha1WithRSAEncryption ) &&
			( algo != NID_sha512WithRSAEncryption )
		   )
		{
			err = string::Format("Not supported cert algorithm: %s",
					OBJ_nid2sn(algo));
			X509_STORE_CTX_free(ctx);
			return false;
		}

		string err1;
		RSA* prsa = (static_cast<x509_Certificate*>(cert))->GetRSA(err1);
		if ( !prsa )
		{
			err = "Failed to get rsa key from cert: " + err1;
			X509_STORE_CTX_free(ctx);
			return false;
		}

		int bits = BN_num_bits(prsa->n);
		RSA_free(prsa);

		if ( bits < MIN_CERT_KEY_BITS )
		{
			err = string::Format("Reject x509 cert: pubkey has only %d bits", bits);
			X509_STORE_CTX_free(ctx);
			return false;
		}
	
		if ( check_time ) 
		{
			 X509_STORE_CTX_set_time(ctx, 0, check_time);	
		}
	
		int ret = X509_verify_cert(ctx);
		if ( ret < 0 )
		{
			SET_ERROR_HARVEST(err, "Unexpected error during x509 cert verification", ctx);
			X509_STORE_CTX_free(ctx);
			return false;
		}
	
		if ( ret == 0 )
		{
			SET_ERROR_HARVEST(err, "x509 cert could not be verified", ctx);
			X509_STORE_CTX_free(ctx);
			return false;
		}
	
		X509_STORE_CTX_free(ctx);
		return true;
	}
	
	bool		X509CertChecker::FindCertBySubject(string subject, pki_base* cert, string& err)
	{	
		if ( 
			!cert || 
			strcmp(cert->GetType(), PKI_TYPE_X509_CERT) 
		   )
		{
			err = "Invalid cert pointer or type";
			return false;
		}
	
		if ( m_x509_store && m_x509_store->objs )
		{
			STACK_OF(X509_OBJECT)* objs = m_x509_store->objs;
			int total = sk_X509_OBJECT_num(objs);

			for ( int i = 0; i < total; ++i )
			{
				X509_OBJECT* obj = sk_X509_OBJECT_value(objs, i);
				if ( obj->type == X509_LU_X509 )
				{
					x509_Certificate temp_cert(*obj->data.x509);
					string sub, err1;
					if ( temp_cert.GetSubject(sub, err1) && ( sub == subject ) )
					{
						*(static_cast<x509_Certificate*>(cert)) = temp_cert;
						return true;
					}
				}
			}
		}
	
		if ( m_untrusted )
		{
			int total = sk_X509_num(m_untrusted);
			for ( int i = 0; i < total; ++i )
			{
				x509_Certificate temp_cert(*sk_X509_value(m_untrusted, i));
				string sub, err1;
				if ( temp_cert.GetSubject(sub, err1) && ( sub == subject ) )
				{
					*(static_cast<x509_Certificate*>(cert)) = temp_cert;
					return true;
				}
			}
		}
	
		return false;
	}

}//end namespace colib

