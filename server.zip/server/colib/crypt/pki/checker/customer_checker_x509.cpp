// customer_checker_x509.cpp
// vi:set ts=4 sw=4 nowrap:

#include <crypt/pki/checker/customer_checker_x509.h>

namespace colib
{	
	CustomerX509CertChecker&		CustomerX509CertChecker::GetInstance()
	{
		static CustomerX509CertChecker _instance;
		return _instance;
	}

}//end namespace colib

