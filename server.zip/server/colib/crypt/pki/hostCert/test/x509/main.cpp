#include <idirect/crypt/pki/format/x509_rsa_key.h>
#include <idirect/crypt/pki/format/x509_cert.h>
#include <idirect/crypt/pki/format/x509_csr.h>
#include <idirect/crypt/pki/hostCert/x509.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <openssl/ssl.h>

using namespace colib;

int	main()
{	
	SSL_load_error_strings();
	OpenSSL_add_all_algorithms();
	
	string dn[] = {"TestRootCert", "US", "VA", "colib", "Engineer", "NMS", "", "hcheng@idirect.net"}; 
	string subject_name[] = {"II+.8888", "CN", "SZ", "", "", "", "", ""};
	string output, err;
	
	printf("HostCert is%s OK\n", x509_HostCert::GetInstance().IsOK() ? "" : " NOT");
	//
	printf("Generate CA X509 RSA key ...\n");
	x509_RSAkey ca_key;
	if ( !ca_key.GeneratePrivateKeypair(err) )
	{
		printf("Fail to generate X509 RSA key: %s\n", err.c_str());
		return -1;
	}	
	//
	printf("Generate CA X509 Certificate signed by the CA key ...\n");
	x509_Certificate ca_cert;
	if ( !ca_cert.GenerateCertificateFromDN(err, dn, ca_key) )
	{
		printf("Generate X509 certificate fail: %s\n", err.c_str());
		return -1;
	}	
	//
	printf("Generate X509 RSA key ...\n");
	x509_RSAkey key;
	if ( !key.GeneratePrivateKeypair(err) )
	{
		printf("Fail to generate X509 RSA key: %s\n", err.c_str());
		return -1;
	}
	//
	printf("HostCert set Key ...\n");
	if ( !x509_HostCert::GetInstance().SetKey(&key, err) )
	{
		printf("Fail to set HostCert key ...\n");
		return -1;
	}	
	printf("HostCert is%s OK\n", x509_HostCert::GetInstance().IsOK() ? "" : " NOT");
	//
	printf("Generate X509 CSR signed by the key ...\n");
	x509_CSR csr;
	if ( !csr.GenerateCSR4Encipher(err, key, subject_name) ) 
//	if ( !csr.GenerateCSR4SignCert(err, key, subject_name) ) 
	{
		printf("Generate CSR fail: %s\n", err.c_str());
		return -1;
	}
	//
	printf("Sign CSR with CA ...\n");
	x509_Certificate cert;
	if  ( !cert.GenerateCertificateFromCSR(err, csr, ca_cert, ca_key, 12345) )
	{
		printf("Fail to sign CSR: %s\n", err.c_str());
		return -1;
	}
	//
	// Step 3: Dump Readable
	//
	printf("Print X509 Certificate ...\n");
	output = cert.DumpReadable();
	printf("%s\n", output.c_str());
	//
	printf("HostCert set Cert ...\n");	
	if ( !x509_HostCert::GetInstance().SetCert(&cert, err) )
	{
		printf("Fail to set HostCert cert ...\n");
		return -1;
	}	
	printf("HostCert is%s OK\n", x509_HostCert::GetInstance().IsOK() ? "" : " NOT");

	return 0;
}

