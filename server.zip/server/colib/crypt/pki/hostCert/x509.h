// x509.h
// vi:set ts=4 sw=4 nowrap:

#ifndef X509_HOST_CERT_H_ALREADY_INCLUDED
#define X509_HOST_CERT_H_ALREADY_INCLUDED

#include <crypt/pki/hostCert/base.h>
#include <crypt/pki/format/x509_cert.h>
#include <crypt/pki/format/x509_rsa_key.h>
#include <utils/callback.h>

namespace colib
{
	class x509_HostCert : public HostCert
	{
		public:

			static x509_HostCert&		GetInstance();

			virtual void				Zeroize();
			virtual bool				IsOK() const;

			virtual bool				SetCert(pki_base* cert, string& err);
			virtual const pki_base*		GetCert() const { return &m_x509_cert; }
			void						SetCertUpdateCallback(const Callback& cert_update_cbk) { m_cert_update_cbk = cert_update_cbk; }
			virtual	bool				SetKey(pki_base* key, string& err);
			virtual const pki_base*		GetKey() const { return &m_x509_key; }
			void						SetKeyUpdateCallback(const Callback& key_update_cbk) { m_key_update_cbk = key_update_cbk; }

		protected:

			bool						VerifyX509Cert(pki_base* cert, string& err);
			bool						VerifyX509Key(pki_base* cert, string& err);

			x509_Certificate			m_x509_cert;
			Callback					m_cert_update_cbk;
			x509_RSAkey					m_x509_key;
			Callback					m_key_update_cbk;

		private:

										x509_HostCert() {};
			virtual						~x509_HostCert() {};	
	};

}//end namespace colib


#endif

