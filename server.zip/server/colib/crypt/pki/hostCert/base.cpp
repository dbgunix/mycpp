// base.cpp
// vi:set ts=4 sw=4 nowrap:

#include <crypt/pki/hostCert/base.h>

namespace colib
{
	HostCert::HostCert()
	{	
		m_flags = 0;
	}

	HostCert::~HostCert()
	{
	}

	bool		HostCert::IsOK() const
	{	
		return (
				( m_flags & HOSTCERT_HAVE_KEY ) && 
				( m_flags & HOSTCERT_HAVE_CERT )
				);
	}

	void		HostCert::Zeroize()
	{
		m_asym_keypair.Zeroize();
		m_flags = 0;
	}

}//end namespace colib

