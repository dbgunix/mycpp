// x509.cpp
// vi:set ts=4 sw=4 nowrap:

#include <crypt/pki/hostCert/x509.h>

namespace colib
{
	x509_HostCert&		x509_HostCert::GetInstance()
	{
		static x509_HostCert _instance;
		return _instance;
	}

	bool		x509_HostCert::VerifyX509Cert(pki_base* cert, string& err)
	{
		if ( !cert || strcmp(cert->GetType(), PKI_TYPE_X509_CERT) )
		{
			err = "Cert invalid or incorrect type";
			return false; 		  
		}

		return true;
	}

	bool		x509_HostCert::SetCert(pki_base* cert, string& err)
	{
		if ( !VerifyX509Cert(cert, err) ) return false;
		m_x509_cert = *(static_cast<x509_Certificate*>(cert));		
		SetHaveCert();
		m_cert_update_cbk.Dispatch();
		return true;
	}

	bool		x509_HostCert::VerifyX509Key(pki_base* key, string& err)
	{	
		if ( !key || strcmp(key->GetType(), PKI_TYPE_X509_RSA_KEY) )
		{
			err = "Key invalid or incorrect type";
			return false; 		  
		}

		return true;
	}

	bool		x509_HostCert::SetKey(pki_base* key, string& err)
	{
		if ( !VerifyX509Key(key, err) ) return false;
		m_x509_key = *(static_cast<x509_RSAkey*>(key));
		if ( !GetKeyRecord().LoadFromX509RSAkey("local private key", &m_x509_key, err) ) return false;
		SetHaveKey();
		m_key_update_cbk.Dispatch();
		return true;
	}

	void		x509_HostCert::Zeroize()
	{
		m_x509_cert.Zeroize();
		HostCert::Zeroize();
	}

	bool		x509_HostCert::IsOK() const
	{
		string err;
		return HostCert::IsOK() && m_x509_cert.MatchRSA(m_x509_key.GetRSA(), err);
	}

}
