// base.h
// vi:set ts=4 sw=4 nowrap:

#ifndef HOST_CERT_BASE_H_ALREADY_INCLUDED
#define HOST_CERT_BASE_H_ALREADY_INCLUDED

#include <crypt/pki/format/base.h>
#include <crypt/pki/format/idirect_krec.h>

namespace colib
{
	class HostCert
	{
		public:

			static const int			HOSTCERT_HAVE_KEY	=	0x01;
			static const int			HOSTCERT_HAVE_CERT	=	0x02;
		
										HostCert();
			virtual						~HostCert();
	
			virtual void				Zeroize();
			virtual bool				IsOK() const;
			//
			// Pure virtual functions
			//
			virtual bool				SetCert(pki_base* cert, string& err) = 0;
			virtual const pki_base*		GetCert() const = 0;
			virtual bool				SetKey(pki_base* key, string& err) = 0;
			virtual const pki_base*		GetKey() const = 0;

			KeyRecord&					GetKeyRecord() { return m_asym_keypair; }

			void						ClearCert() { ClearHaveCert(); }
			void						ClearKey() { ClearHaveKey(); }

		protected:
		
			void						SetHaveKey() { m_flags |= HOSTCERT_HAVE_KEY; }
			void						SetHaveCert() { m_flags |= HOSTCERT_HAVE_CERT; }
			void						ClearHaveKey() { m_flags &= (~HOSTCERT_HAVE_KEY); }
			void						ClearHaveCert() { m_flags &= (~HOSTCERT_HAVE_CERT); }

		protected:
		
			KeyRecord					m_asym_keypair;
			unsigned char				m_flags;
	};

}//end namespace colib


#endif

