// keygen.h
// vi:set ts=4 sw=4 nowrap:

#ifndef KEYGEN_H_ALREADY_INCLUDED
#define KEYGEN_H_ALREADY_INCLUDED

#include <proc_mgr/async_executor.h>
#include <crypt/pki/format/x509_rsa_key.h>

namespace colib
{
	class KeyGenHandler : public AsyncExecutor
	{
		public:
									KeyGenHandler();
			virtual					~KeyGenHandler();

			bool					GenerateKey(
											const Callback1<pki_base*>& on_succeed, 
											const Callback1<string>& on_failure, 
											unsigned timeout_sec = 5, 
											unsigned retry_times = 3);

			virtual pki_base*		GetKey() = 0;
			virtual bool			RegenerateKey(string& err) = 0;
			virtual const char*		KeyFilename() const = 0;

		protected:

			virtual void			NormalExit(int exit_code);
			virtual void			AbnormalExit(string err);
			virtual int				Execute(int fd);

			void					LoadKeyDataSucceed(char*, int, void*);
			void					LoadKeyDataFailed(string err, void*);

		protected:

			Callback1<pki_base*>	m_on_succeed;
			Callback1<string>		m_on_failure;
	};

	class x509_KeyGenHandler : public KeyGenHandler
	{
		public:

									x509_KeyGenHandler();
			virtual					~x509_KeyGenHandler() {};

			virtual pki_base*		GetKey() { return &m_x509_key; }
			virtual bool			RegenerateKey(string& err) { return m_x509_key.GeneratePrivateKeypair(err); }
			virtual const char*		KeyFilename() const;

		private:

			x509_RSAkey				m_x509_key;	
			string					m_key_filename;
	};

}//end namespace colib


#endif

