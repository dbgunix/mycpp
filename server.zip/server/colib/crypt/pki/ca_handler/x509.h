// x509.h
// vi:set ts=4 sw=4 nowrap:

#ifndef X509_H_ALREADY_INCLUDED
#define X509_H_ALREADY_INCLUDED

#include <crypt/pki/ca_handler/base.h>
#include <crypt/pki/ca_handler/keygen.h>
#include <crypt/pki/manager/x509_global_pki.h>
#include <crypt/pki/manager/x509_local_pki.h>
#include <file_io/file_loader.h>

namespace colib
{
	class x509_CaHandler : public CaHandler
	{
		public:

			static x509_CaHandler&				GetInstance();
	
			virtual string						GetType() { return "X509"; }
			
			virtual void						SetStoreDirectory(string path) { m_pki_store_path = path; }
			
			virtual bool						Init(string& err, bool auto_gen = true);
			virtual bool						RegenerateLocalPKI(string& err, bool auto_gen = true);
			
			void								SetDN(string* dn, int n);
			void								SetAlternativeName(string altName);
	
			void								SetFileIOMgr(FileIoMgr& file_io_mgr);		
			void								StartPKIFileLoader(); // Only when PKI data sharing is ON

			virtual const char*					GetLocalCertHash(unsigned& len, string& err);

			virtual void						SetGlobalPKI(
														char* data, unsigned len, 
														const Callback& on_succeed,
														const Callback1<string>& on_failure);
			virtual void						SetLocalCert(
														char* data, unsigned len, 	
														const Callback& on_succeed,
														const Callback1<string>& on_failure);
		
			virtual pki_base*					GenerateLocalCertSignRequest(
														const Callback1<pki_base*> &on_succeed, 
														const Callback1<string>& on_failure,
														string& err);				
	
			virtual string						ConsoleHelp();
			virtual void						ConsoleCommand(ConsoleSession* con, int argc, char* argv[]);

		protected:

			virtual const global_pki_mgr*		GlobalPKIMgr() const { return &m_x509_global_pki; }
			virtual const local_cert_mgr*		LocalCertMgr() const { return &m_x509_local_cert; }
			
			virtual bool						VerifyLocalPKI();

			virtual void						SetLocalKey(char* data, unsigned len);
	
			void								OnGlobalPKIWriteToDiskSucceed(void*);
			void								OnGlobalPKIWriteToDiskFailure(string err, void*);
		
			void								OnLocalCertWriteToDiskSucceed(void*);
			void								OnLocalCertWriteToDiskFailure(string, void*);
		
			void								OnLocalKeyGenWriteToDiskSucceed(void*);
			void								OnLocalKeyGenWriteToDiskFailure(string err, void*);

			void								OnLocalKeyGenSucceed(pki_base*);
			void								OnLocalKeyGenFailure(string);

			void								UpdateGlobalPKI(char*, int);
			void								UpdateLocalCert(char*, int);
			void								UpdateLocalKey(char*, int);

			bool								IsPKIHashMatch(char*, int, pki_manager&, pki_manager&);

		private:

			x509_global_pki_mgr					m_x509_global_pki;
			x509_local_cert_mgr					m_x509_local_cert;
			x509_local_key_mgr					m_x509_local_key;

			FileLoaderMgr						m_x509_global_pki_loader;
			FileLoaderMgr						m_x509_local_cert_loader;
			FileLoaderMgr						m_x509_local_key_loader;

			x509_KeyGenHandler					m_x509_keygen;				
			string								m_dn[8];
			string								m_altName;
			//
			// Callback copy
			//
			Callback							m_on_succeed_global;
			Callback1<string>					m_on_failure_global;
	
			Callback							m_on_succeed_local_cert;
			Callback1<string>					m_on_failure_local_cert;

			Callback1<pki_base*>				m_on_csr_succeed;
			Callback1<string>					m_on_csr_failure;

			string								m_pki_store_path;
			FileIoMgr*							m_file_io_mgr;

		private:
												x509_CaHandler();
			virtual								~x509_CaHandler();
	};

	void	X509CaHandlerConsoleCommand(void*, ConsoleSession* con, int argc, char* argv[]);

}//end namespace iDirect


#endif

