// base.cpp
// vi:set ts=4 sw=4 nowrap:

#include <crypt/pki/ca_handler/base.h>

namespace colib
{
	static ValueList::ValueHolder	InitStats()
	{
		return 
		{
			Value("num_init_global_pki_failed", 0),
			Value("num_init_local_cert_failed", 0),
			Value("num_get_global_pki_hash_succeed", 0),
			Value("num_get_global_pki_hash_failed", 0),
			Value("num_get_local_cert_hash_succeed", 0),
			Value("num_get_local_cert_hash_failed", 0),
			Value("num_set_global_pki_succeed", 0),
			Value("num_set_global_pki_failed", 0),
			Value("num_set_local_cert_succeed", 0),
			Value("num_set_local_cert_failed", 0),
			Value("latest_operation_error", "")
		};
	};

	CaHandler::CaHandler()
		:
		m_stats(InitStats())
	{
	}

	CaHandler::~CaHandler()
	{
	}

	const char*			CaHandler::GetGlobalPKIHash(unsigned& len, string& err)
	{
		const global_pki_mgr* mgr = GlobalPKIMgr();
		if ( !mgr ) 
		{
			CA_HANDLER_STAT(num_get_global_pki_hash_failed)++;
			err = "No global PKI manager found";			
			m_stats[CaHandler::Stat_latest_operation_error].SetFromString(err.c_str());
			return 0;
		}
		
		const char* ret = mgr->GetHash(len, err);

		if ( ret ) CA_HANDLER_STAT(num_get_global_pki_hash_succeed)++;
		else CA_HANDLER_STAT(num_get_global_pki_hash_failed)++;

		return ret;
	}	
	
	const char*			CaHandler::GetLocalCertHash(unsigned& len, string& err)
	{
		const local_cert_mgr* mgr = LocalCertMgr();
		if ( !mgr ) 
		{
			CA_HANDLER_STAT(num_get_local_cert_hash_failed)++;
			err = "No local cert manager found";			
			m_stats[CaHandler::Stat_latest_operation_error].SetFromString(err.c_str());
			return 0;
		}

		const char* ret = mgr->GetHash(len, err);
	
		if ( ret ) CA_HANDLER_STAT(num_get_local_cert_hash_succeed)++;
		else CA_HANDLER_STAT(num_get_local_cert_hash_failed)++;

		return ret;
	}	

	void				CaHandler::SET_GlobalPKI_ERROR(string err)
	{	
		CA_HANDLER_STAT(num_set_global_pki_failed)++;
		m_stats[CaHandler::Stat_latest_operation_error].SetFromString(err.c_str());	
	}

	void				CaHandler::SetGlobalPKI(
								char* data, unsigned len, 	
								const Callback& succeed_cbk,
								const Callback1<string>& failure_cbk)
	{
		Callback on_succeed = succeed_cbk;
		Callback1<string> on_failure = failure_cbk;

		string err;
		global_pki_mgr* mgr = const_cast<global_pki_mgr*>(GlobalPKIMgr());
		if ( !mgr ) 
		{
			err = "No global PKI manager found";
			SET_GlobalPKI_ERROR(err);			
			on_failure.Dispatch(err);
			return;
		}
		
		bool ret = mgr->Decode(data, len);

		if ( !ret )
		{
			mgr->Clear();	
			err = "Decode global PKI data failed";			
			SET_GlobalPKI_ERROR(err);			
			on_failure.Dispatch(err);
			return;	
		}
		
		CA_HANDLER_STAT(num_set_global_pki_succeed)++;
		on_succeed.Dispatch();
	}
	
	void				CaHandler::SET_LocalCert_ERROR(string err)
	{	
		CA_HANDLER_STAT(num_set_local_cert_failed)++;
		m_stats[CaHandler::Stat_latest_operation_error].SetFromString(err.c_str());
	}

	void				CaHandler::SetLocalCert(
								char* data, unsigned len, 	
								const Callback& succeed_cbk,
								const Callback1<string>& failure_cbk)
	
	{	
		Callback on_succeed = succeed_cbk;
		Callback1<string> on_failure = failure_cbk;

		string err;
		local_cert_mgr* mgr = const_cast<local_cert_mgr*>(LocalCertMgr());
		if ( !mgr ) 
		{
			err = "No local cert manager found";			
			SET_LocalCert_ERROR(err);
			on_failure.Dispatch(err);
			return;
		}
		
		bool ret = mgr->Decode(data, len);

		if ( !ret )
		{	
			mgr->Clear();
			err = "Decode local cert data failed";			
			SET_LocalCert_ERROR(err);
			on_failure.Dispatch(err);
			return;	
		}

		CA_HANDLER_STAT(num_set_local_cert_succeed)++;
		on_succeed.Dispatch();
	}
	
	string				CaHandler::ConsoleHelp()
	{
		return "stats|global_pki|local_cert";
	}

	void				CaHandler::ConsoleCommand(ConsoleSession* con, int argc, char* argv[])
	{
		string usage = "Usage:\t" + ConsoleHelp();

		if ( !con ) return;
		
		if ( argc == 0 )
		{
			con->Print(usage.c_str());
			return;
		}

		if ( !strcmp(argv[0], "stats") )
		{
			m_stats.ConsoleCommand(con, argc-1, argv+1);
		}
		else if ( !strcmp(argv[0], "global_pki") )
		{
			global_pki_mgr* mgr = const_cast<global_pki_mgr*>(GlobalPKIMgr());
			if ( mgr ) mgr->ConsoleCommand(con, argc-1, argv+1);
			else con->Print("No Global PKI manager\n");
		}
		else if ( !strcmp(argv[0], "local_cert") )
		{
			local_cert_mgr* mgr = const_cast<local_cert_mgr*>(LocalCertMgr());
			if ( mgr ) mgr->ConsoleCommand(con, argc-1, argv+1);
			else con->Print("No Local cert manager\n");
		}
		else con->Print(usage.c_str());
	}

}//end namespace colib

