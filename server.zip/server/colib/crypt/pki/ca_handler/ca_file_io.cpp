// ca_file_io.cpp
// vi:set ts=4 sw=4 nowrap:

#include <crypt/pki/ca_handler/ca_file_io.h>
#include <file_io/global_file_io_mgr.h>
#include <file_io/file_io_utils.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

namespace colib
{
	CAFileIOMgr& CAFileIOMgr::GetInstance()
	{
		static CAFileIOMgr instance;
		return instance;
	}

	bool CAFileIOMgr::ReadLocalFile(
							string filename, 
							const Callback3<char*, int, void*>& on_read_succeed, 
							const Callback2<string, void*>& on_read_failed, 
							void* context, 
							string& err)
	{
		return ReadFile(filename, on_read_succeed, on_read_failed, context, err, GlobalFileIoMgr::GetInstance());
	}

	bool CAFileIOMgr::BlockingReadFile(string filename, char* buf, int& len, string& err)
	{	
		int filesize = 0;
		if ( !DiskFile::GetFileSize(filename, filesize, err) ) return false;
		
		if ( filesize > len ) 
		{	
			err = string::Format("Buffer (size=%d) not big enough to read file %s (size=%d)",
					len, filename.c_str(), filesize);
			return false;
		}

		int fd = open(filename.c_str(), O_RDONLY);
		if ( fd <= 0 )
		{
			err = string::Format("Open file %s for read fail", filename.c_str());
			return false;
		}
	
		int bytes_left = filesize;
		int read_offset = 0;	
		while ( bytes_left > 0 )
		{
			int bytes_read = 0;
			if ( !DiskFile::ReadFile(fd, buf + read_offset, bytes_left, bytes_read, err) ) 
			{
				close(fd);
				return false;
			}
			read_offset += bytes_read;
			bytes_left -= bytes_read;
		}

		close(fd);
		return true;
	}
	
	bool CAFileIOMgr::WriteLocalFile(
							string filename, 
							char* data, 
							int len, 
							const Callback1<void*>& on_write_succeed, 
							const Callback2<string, void*>& on_write_failed, 
							void* context, 
							string& err)
	{	
		return WriteFile(filename, data, len, on_write_succeed, on_write_failed, context, err, GlobalFileIoMgr::GetInstance());
	}
	
	bool CAFileIOMgr::SafeWriteLocalFile(
							string filename, 
							char* data, 
							int len, 
							const Callback1<void*>& on_write_succeed, 
							const Callback2<string, void*>& on_write_failed, 
							void* context, 
							string& err)
	{
		return SafeWriteFile(filename, data, len, on_write_succeed, on_write_failed, context, err, GlobalFileIoMgr::GetInstance());	
	}

	bool CAFileIOMgr::BlockingWriteFile(string filename, char* data, int len, string& err)
	{	
		if ( len <= 0 ) 
		{
			err = string::Format("invalid lenght (%d)", len);
			return false;
		}
		// 
		// Create directory if needed
		//
		string dir_path;
		DiskFile::ParseDir(filename, dir_path, err);
		if ( !dir_path.is_empty() && !DiskFile::MakeDir(dir_path, 0777, err) ) return false;
		//
		err.empty();
		//
		// Open file to write
		//
		int fd = open(filename.c_str(), O_CREAT | O_WRONLY | O_TRUNC, S_IREAD | S_IWRITE);
		if ( fd < 0 )
		{
			err = string::Format("Open file %s for write failed", filename.c_str());
			return false;
		}

		int bytes_left = len;
		int write_offset = 0;		
		while ( bytes_left > 0 )
		{
			int bytes_write = 0;
			if ( !DiskFile::WriteFile(fd, data + write_offset, bytes_left, bytes_write, err) ) 
			{
				close(fd);
				return false;
			}
			write_offset += bytes_write;
			bytes_left -= bytes_write;
		}

		close(fd);
		return true;
	}

}//end namespace colib

