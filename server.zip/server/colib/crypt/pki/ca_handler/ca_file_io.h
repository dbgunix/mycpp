// ca_file_io.h
// vi:set ts=4 sw=4 nowrap:

#ifndef CA_FILE_IO_H_ALREADY_INCLUDED
#define CA_FILE_IO_H_ALREADY_INCLUDED

#include <file_io/large_file_io_mgr.h>

namespace colib
{	
	// 
	// Map indexed by filename
	//
	typedef std::map<string, LargeFileIO>	LargeFileIOMAP;
	
	const int MAX_PKI_BUF_SIZE = 64 * 1024;

	class CAFileIOMgr : public LargeFileIoMgr
	{
		public:

			static CAFileIOMgr& GetInstance();
		
			bool ReadLocalFile(
						string filename, 
						const Callback3<char*, int, void*>& on_read_succeed,
						const Callback2<string, void*>& on_read_failed,
						void* context,
						string& err);

			bool BlockingReadFile(
						string filename,
						char* data, int& len,
						string& err);

			bool WriteLocalFile(
						string filename,
						char* data, int len,
						const Callback1<void*>& on_write_succeed,
						const Callback2<string, void*>& on_write_failed,
						void* context,
						string& err);
		
			bool SafeWriteLocalFile(
						string filename,
						char* data, int len,
						const Callback1<void*>& on_write_succeed,
						const Callback2<string, void*>& on_write_failed,
						void* context,
						string& err);
	
			bool BlockingWriteFile(
						string filename,
						char* data, int len,
						string& err);

		private:

			virtual LargeFileIO* GetFileIO(string filename) { return &m_file_io_map[filename]; }

		private:

			LargeFileIOMAP m_file_io_map;

		private:

			CAFileIOMgr() {};
			virtual ~CAFileIOMgr() {};								
	};

}//end namespace colib


#endif

