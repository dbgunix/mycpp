// keygen.cpp
// vi:set ts=4 sw=4 nowrap:

#include "keygen.h"
#include "ca_file_io.h"
#include <utils/xdr.h>
#include <utils/trace/trace.h>

namespace colib
{
	KeyGenHandler::KeyGenHandler()
		: AsyncExecutor()
		, m_on_succeed()
		, m_on_failure()  
	{
	}

	KeyGenHandler::~KeyGenHandler()
	{
	}

	bool		KeyGenHandler::GenerateKey(
											const Callback1<pki_base*>& on_succeed,
											const Callback1<string>& on_failure,
											unsigned timeout_sec,
											unsigned retry_times)
	{
		m_on_succeed = on_succeed;
		m_on_failure = on_failure;
		SetParams(timeout_sec, retry_times);
		ExecuteAndMonitor();
		return true;
	}

	int			KeyGenHandler::Execute(int)
	{
		string err;
		//
		// Exit code explains 
		//
		// 1: RegenerateKeyPair fail
		//
		if ( !RegenerateKey(err) ) return 1;		
		// 
		// 2: Fail to get key	
		//
		pki_base* key = GetKey();
		if ( !key ) return 2;
		//
		// 3. Fail to encode key
		//
		char buf[2048];	// 2048 bytes is more than enough for key
		unsigned len = sizeof(buf);
		colib::XdrEncode en(buf, len);
		if ( !key->XdrEncode(&en, err) ) return 3;
		len = en.GetLength();
		//
		// Key gen data always on local disk
		//
		// 4. Fail to write data to file
		//
		if ( !CAFileIOMgr::GetInstance().BlockingWriteFile(KeyFilename(), buf, len, err) ) return 4;
		//
		// Exit with 0
		//
		return 0;
	}

	void		KeyGenHandler::AbnormalExit(string err)
	{
		TRACE("KeyGen fail: %s\n", err.c_str());
		m_on_failure.Dispatch(err);
	}

	void		KeyGenHandler::NormalExit(int status)
	{
		string err;
		
		if ( status ) 
		{
			err = string::Format("keygen exit code (%d) indicating error", status);
			TRACE("KeyGen fail: %s\n", err.c_str());
			m_on_failure.Dispatch(err);
			return;
		}
		//
		// Key gen data always on local disk. However, it might be moved to other place by CAHandler
		//
		if ( !CAFileIOMgr::GetInstance().ReadLocalFile(
					KeyFilename(), 
					callback(this, &KeyGenHandler::LoadKeyDataSucceed),
					callback(this, &KeyGenHandler::LoadKeyDataFailed),
					0, // context
					err) )
		{
			err = "fail to start read";
			TRACE("KeyGen fail: %s\n", err.c_str());
			m_on_failure.Dispatch(err);
			return;
		}
	}

	void		KeyGenHandler::LoadKeyDataSucceed(char* buf, int len, void*)
	{
		string err;
		// 
		// Delete the temp key file for security reason
		// Also, since this file in local disk, delete will not block
		//
		unlink(KeyFilename());

		pki_base* key = GetKey();
		if ( !key )
		{
			err = "fail to retrieve key to do decode";
			TRACE("KeyGen fail: %s\n", err.c_str());;
			m_on_failure.Dispatch(err);
			return;
		}

		colib::XdrDecode de(buf, len);
		if ( !key->XdrDecode(&de, err) )
		{
			err = "decode key from data fail: " + err;
			TRACE("KeyGen fail: %s\n", err.c_str());
			m_on_failure.Dispatch(err);
			return;
		}

		m_on_succeed.Dispatch(key);
	}

	void		KeyGenHandler::LoadKeyDataFailed(string err, void*)
	{	
		// 
		// Delete the temp key file for security reason
		// Also, since this file in local disk, delete will not block
		//
		unlink(KeyFilename());
		err = "load key data fail: " + err;
		TRACE("KeyGen fail: %s\n", err.c_str());
		m_on_failure.Dispatch(err);
	}

	x509_KeyGenHandler::x509_KeyGenHandler()
		: KeyGenHandler()
	{
		m_key_filename = string::Format("/tmp/x509_key.swap.%u", getpid());
	}

	const char*	x509_KeyGenHandler::KeyFilename() const
	{
		return m_key_filename.c_str();
	}	

}//end namespace colib

