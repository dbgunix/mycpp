// x509.cpp
// vi:set ts=4 sw=4 nowrap:

#include "x509.h"
#include "ca_file_io.h"
#include <crypt/pki/format/x509_csr.h>
#include <crypt/sha/sha.h>
#include <utils/trace/trace.h>
#include <file_io/file_io_utils.h>
#include <console/role.h>

#include <sys/stat.h>

namespace colib
{
	string x509_global_pki_filename = "x509_global.bin";
	string x509_local_cert_filename = "x509_cert.bin";
	string x509_local_key_filename  = "x509_key.bin";

	x509_CaHandler&		x509_CaHandler::GetInstance()
	{
		static x509_CaHandler _instance;
		return _instance;
	}

	x509_CaHandler::x509_CaHandler()
		:
		m_x509_global_pki(/*sync_host =*/true),
		m_x509_local_cert(/*sync_host =*/true),
		m_file_io_mgr(&GlobalFileIoMgr::GetInstance())
	{	
		m_x509_global_pki.SetVersion(PKI_VERSION);
		m_x509_local_cert.SetVersion(PKI_VERSION);
		m_x509_local_key.SetVersion(PKI_VERSION);	
		m_dn[0] = "NameNotSet";
		ConsoleCommand::Register(
				CONSOLE_ROLE_EVERYONE,
				(ConsoleCommand::Handler*)X509CaHandlerConsoleCommand, NULL,
				"x509Cahandler", "X509 Ca Handler");
	}

	x509_CaHandler::~x509_CaHandler()
	{
		m_x509_global_pki.Zeroize();
		m_x509_local_cert.Zeroize();
		m_x509_local_key.Zeroize();
	}

	void				x509_CaHandler::SetFileIOMgr(FileIoMgr& file_io_mgr)
	{
		m_file_io_mgr = &file_io_mgr;
		m_x509_global_pki_loader.SetFileIOMgr(*m_file_io_mgr);
		m_x509_local_cert_loader.SetFileIOMgr(*m_file_io_mgr);
		m_x509_local_key_loader.SetFileIOMgr(*m_file_io_mgr);
	}

	void				x509_CaHandler::SetDN(string* dn, int n)
	{
		int count = n;
		if ( count > 8 ) count = 8;
		for ( int i = 0; i < count; i++ ) m_dn[i] = dn[i];
	}
	
	void				x509_CaHandler::SetAlternativeName(string altName)
	{
		m_altName = altName;
	}

	bool				x509_CaHandler::VerifyLocalPKI()
	{
		x509_RSAkey* key = (x509_RSAkey*)m_x509_local_key.GetKey();
		x509_Certificate* cert = (x509_Certificate*)m_x509_local_cert.GetCert();

		string err;
		bool ret = key && cert && cert->MatchRSA(key->GetRSA(), err);
		
		if ( ret && ( m_dn[0] != "" ) )
		{		
			//
			// Verify certificate common name
			//
			string name;
			if ( !cert->GetSubjectCommonName(name, err) || ( name != m_dn[0] ) )
			{
				TRACE("WARNING: x509_CaHandler::VerifyLocalPKI - certificate common name NOT MATCH!\n");
				//
				// May 09 2013: common name mismatch only raise warning, proceed 
				//
				// err = "fail to verify certificate common name";
				// ret = false;
			}
		}

		return ret;
	}

	const char*			x509_CaHandler::GetLocalCertHash(unsigned& len, string& err)
	{
		if ( VerifyLocalPKI() ) return CaHandler::GetLocalCertHash(len, err);
		err = "Fail verify local PKI";			
		return 0;
	}

	bool				x509_CaHandler::RegenerateLocalPKI(string& err, bool auto_gen)
	{		
		char data[MAX_PKI_BUF_SIZE];
	
		TRACE("Re-generate local key, this may take a while ...\n");
		if ( !m_x509_keygen.RegenerateKey(err) )
		{
			err = string::Format("x509_CaHandler::RegenerateLocalPKI - fatal error: fail to generate local key, %s", err.c_str());
			return false;
		}
		x509_RSAkey x509_key = *((x509_RSAkey*)m_x509_keygen.GetKey());

		TRACE("Re-generate local self-signed certificate ...\n");
		x509_Certificate x509_cert;
			
		if ( !x509_cert.GenerateCertificateFromDN(err, m_dn, x509_key, m_altName) )
		{
			err = string::Format("x509_CaHandler::RegenerateLocalPKI - fatal error: fail to generate local self-signed certificate, %s", err.c_str());
			return false;
		}
		//	
		// Set 
		//
		if ( !m_x509_local_key.SetKey(&x509_key, err) )
		{
			err = string::Format("x509_CaHandler::RegenerateLocalPKI - fatail error: fail to set local key, %s", err.c_str());
			return false;
		}
		if ( !m_x509_local_cert.SetCert(&x509_cert, err) )
		{
			err = string::Format("x509_CaHandler::RegenerateLocalPKI - fatail error: fail to set local cert, %s", err.c_str());
			return false;
		}
		//
		// Verify Local PKI integrity 
		//
		if ( !VerifyLocalPKI() )
		{
			err = string::Format("x509_CaHandler::RegenerateLocalPKI - fatail error: newly generated local PKI integrity verification fail!");
			return false;
		}
		//
		// Generate hash for key
		//
		unsigned length = sizeof(data);
		if ( !m_x509_local_key.EncodeWithoutHeader(data, length) )
		{
			err = string::Format("x509_CaHandler::RegenerateLocalPKI - fatail error: encode local key without header failed!");
			return false;
		}
		unsigned char hash[SHA512_DIGEST_LENGTH];
		iDirect_sha512((const unsigned char*)data, length, hash);
		if ( !m_x509_local_key.SetHash((char*)hash, sizeof(hash), err) )
		{
			err = string::Format("x509_CaHandler::RegenerateLocalPKI - fatail error: set local key hash failed!");
			return false;
		}
		length = sizeof(data);
		if ( !m_x509_local_key.Encode(data, length) )
		{
			err = string::Format("x509_CaHandler::RegenerateLocalPKI - fatail error: encode local key failed!");
			return false;
		}			
		//
		// Save to file
		//	
		if ( auto_gen )
		{
			if ( !CAFileIOMgr::GetInstance().BlockingWriteFile(
						m_pki_store_path + x509_local_key_filename,
						data, (int)length, err) )
			{	
				err = string::Format("x509_CaHandler::RegenerateLocalPKI - fatail error: save local key to file failed: %s!", err.c_str());
				return false;			
			}
			else TRACE("local key save to %s\n", (m_pki_store_path + x509_local_key_filename).c_str());
		}
		//
		// Generate hash for cert
		//
		length = sizeof(data);	
		if ( !m_x509_local_cert.EncodeWithoutHeader(data, length) )
		{
			err = string::Format("x509_CaHandler::RegenerateLocalPKI - fatail error: encode local cert without header failed!");
			return false;
		}
		iDirect_sha512((const unsigned char*)data, length, hash);
		if ( !m_x509_local_cert.SetHash((char*)hash, sizeof(hash), err) )
		{
			err = string::Format("x509_CaHandler::RegenerateLocalPKI - fatail error: set local cert hash failed!");
			return false;
		}
		length = sizeof(data);
		if ( !m_x509_local_cert.Encode(data, length) )
		{
			err = string::Format("x509_CaHandler::RegenerateLocalPKI - fatail error: encode local cert failed!");
			return false;
		}
		if ( auto_gen )
		{
			if ( !CAFileIOMgr::GetInstance().BlockingWriteFile(
						m_pki_store_path + x509_local_cert_filename,
						data, (int)length, err) )
			{	
				err = string::Format("x509_CaHandler::RegenerateLocalPKI - fatail error: save local cert to file failed: %s!", err.c_str());
				return false;			
			}
			else TRACE("local self-signed certificate save to %s\n", (m_pki_store_path + x509_local_cert_filename).c_str());
		}

		return true;
	}

	bool				x509_CaHandler::Init(string& err, bool auto_gen)
	{
		char data[MAX_PKI_BUF_SIZE];
		int len;
		//
		// Make sure the directory created
		//
		if ( m_pki_store_path != "" && !DiskFile::MakeDir(m_pki_store_path, 0777, err) ) return false;

		Callback			no_succeed_cbk;
		Callback1<string>	no_failure_cbk;
		//
		// Load Global PKI
		//
		len = sizeof(data);
		if ( !CAFileIOMgr::GetInstance().BlockingReadFile(
					m_pki_store_path + x509_global_pki_filename,
					data, len, err) )
		{
			TRACE("x509_CaHandler::Init - WARNING: global pki load fail: %s\n", err.c_str());
			TRACE("This process cannot verify chain of trust without global pki\n");
			// continue
		}		
		else CaHandler::SetGlobalPKI(data, len, no_succeed_cbk, no_failure_cbk);
		//
		// Load Local Key
		//
		len = sizeof(data);
		if ( !CAFileIOMgr::GetInstance().BlockingReadFile(
					m_pki_store_path + x509_local_key_filename,
					data, len, err) )
		{
			TRACE("x509_CaHandler::Init - WARNING: local key load fail: %s\n", err.c_str());
			// continue
		}	
		else SetLocalKey(data, len);
		//
		// Load Local Cert
		//
		len = sizeof(data);
		if ( !CAFileIOMgr::GetInstance().BlockingReadFile(
					m_pki_store_path + x509_local_cert_filename,
					data, len, err) )
		{
			TRACE("x509_CaHandler::Init - WARNING: local cert load fail: %s\n", err.c_str());
			// continue
		}
		else CaHandler::SetLocalCert(data, len, no_succeed_cbk, no_failure_cbk);
		//
		// Verify Local PKI integrity
		//
		if ( !VerifyLocalPKI() )
		{
			TRACE("x509_CaHandler::Init - local PKI integrity verification fail\n");
			if ( !RegenerateLocalPKI(err, auto_gen) ) 
			{
				TRACE("%s\n", err.c_str());
				return false;
			}
		}

		return true;
	}	
	
	void				x509_CaHandler::SetGlobalPKI(
												char* data, unsigned len,	
												const Callback& on_succeed,
												const Callback1<string>& on_failure)	
	{
		string err;			
		//
		// Save callbacks
		//
		m_on_succeed_global = on_succeed;
		m_on_failure_global = on_failure;
	
		x509_global_pki_mgr mgr(/*sync_host =*/false);
		if ( IsPKIHashMatch(data, (int)len, mgr, m_x509_global_pki) )
		{
			TRACE(1, "skip setting x509 global pki data: hash MATCH!\n");
			m_on_succeed_global.Dispatch();
			return;
		}	
		//
		// Not that early to declar success
		//
		Callback no_cbk;

		CaHandler::SetGlobalPKI(
				data, len,
				no_cbk, 
				m_on_failure_global);

		if ( m_x509_global_pki.NumOfPKI() )
		{	
			if ( !CAFileIOMgr::GetInstance().SafeWriteFile(
						m_pki_store_path + x509_global_pki_filename, data, len,
						callback(this, &x509_CaHandler::OnGlobalPKIWriteToDiskSucceed),
						callback(this, &x509_CaHandler::OnGlobalPKIWriteToDiskFailure),		
						0, // context
						err,
						*m_file_io_mgr) ) 
			{
				m_x509_global_pki.Clear();
				SET_GlobalPKI_ERROR(err);			
				m_on_failure_global.Dispatch(err);
			}
		}
	}
	
	void				x509_CaHandler::OnGlobalPKIWriteToDiskSucceed(void*)
	{
		TRACE("x509 global pki data write to %s done!\n", 
			(m_pki_store_path + x509_global_pki_filename).c_str());
		// Now it is time to declare victory
		m_on_succeed_global.Dispatch();
	}
		
	void				x509_CaHandler::OnGlobalPKIWriteToDiskFailure(string err, void*)
	{
		TRACE("x509 global pki data write to %s fail: %s\n", 
				(m_pki_store_path + x509_global_pki_filename).c_str(), err.c_str());	
		m_x509_global_pki.Clear();
		SET_GlobalPKI_ERROR(err);			
		m_on_failure_global.Dispatch(err);
	}
	
	void				x509_CaHandler::SetLocalCert(
												char* data, unsigned len,	
												const Callback& on_succeed,
												const Callback1<string>& on_failure)	
	{
		string err;	
		//
		// Save callbacks
		//
		m_on_succeed_local_cert = on_succeed;
		m_on_failure_local_cert = on_failure;
	
		x509_local_cert_mgr mgr(/*sync_host =*/false);	
		if ( IsPKIHashMatch(data, (int)len, mgr, m_x509_local_cert) )
		{
			TRACE(1, "skip setting x509 local cert: hash MATCH!\n");
			m_on_succeed_local_cert.Dispatch();
			return;
		}	
		//
		// Not that early to declar success
		//
		Callback no_cbk;

		CaHandler::SetLocalCert(
				data, len,
				no_cbk, 
				m_on_failure_local_cert);

		if ( m_x509_local_cert.IsOK() )
		{	
			string err;

			if ( !VerifyLocalPKI() )
			{
				m_x509_local_cert.Clear();
				err = "verify local pki fail";
				SET_LocalCert_ERROR(err);
				m_on_failure_local_cert.Dispatch(err);
				return;
			}			
			if ( !CAFileIOMgr::GetInstance().SafeWriteFile(
						m_pki_store_path + x509_local_cert_filename, data, len,
						callback(this, &x509_CaHandler::OnLocalCertWriteToDiskSucceed),
						callback(this, &x509_CaHandler::OnLocalCertWriteToDiskFailure),		
						0, // context
						err,
						*m_file_io_mgr) ) 
			{
				m_x509_local_cert.Clear();
				SET_LocalCert_ERROR(err);
				m_on_failure_local_cert.Dispatch(err);
			}
		}
	}
	
	void				x509_CaHandler::OnLocalCertWriteToDiskSucceed(void*)
	{
		TRACE("x509 local cert write to %s done!\n", 
				(m_pki_store_path + x509_local_cert_filename).c_str());
		// Now it is time to declare victory
		m_on_succeed_local_cert.Dispatch();
	}
		
	void				x509_CaHandler::OnLocalCertWriteToDiskFailure(string err, void*)
	{
		TRACE("x509 local cert write to %s fail: %s\n", 
				(m_pki_store_path + x509_local_cert_filename).c_str(), err.c_str());	
		m_x509_local_cert.Clear();
		SET_LocalCert_ERROR(err);
		m_on_failure_local_cert.Dispatch(err);
	}
	
	void				x509_CaHandler::SetLocalKey(char* data, unsigned len)
	{	
		x509_local_key_mgr mgr;
		if ( IsPKIHashMatch(data, (int)len, mgr, m_x509_local_key) )
		{
			TRACE(1, "skip setting x509 local key data: hash MATCH!\n");
			return;
		}
		bool ret = m_x509_local_key.Decode(data, len);
		if ( !ret )	m_x509_local_key.Clear();
	}

	pki_base*			x509_CaHandler::GenerateLocalCertSignRequest(
												const Callback1<pki_base*> &on_succeed, 
												const Callback1<string>& on_failure,
												string& err)	
	{
		if ( !m_x509_keygen.IsReady() )
		{
			err = "Another keygen in progress";
			return 0;
		}	
		//
		// Save callbacks
		//
		m_on_csr_succeed = on_succeed;
		m_on_csr_failure = on_failure;
		//
		// Start keygen
		//
		m_x509_keygen.GenerateKey(
				callback(this, &x509_CaHandler::OnLocalKeyGenSucceed),
				callback(this, &x509_CaHandler::OnLocalKeyGenFailure));

		return 0;
	}		

	void				x509_CaHandler::OnLocalKeyGenSucceed(pki_base* key)
	{	
		string err;
		if ( !m_x509_local_key.SetKey(key, err) )
		{
			m_on_csr_failure.Dispatch(err);
			return;
		}

		char data[MAX_PKI_BUF_SIZE];
		unsigned length = sizeof(data);	
		//
		// Generate hash for key
		//
		if ( !m_x509_local_key.EncodeWithoutHeader(data, length) )
		{
			m_x509_local_key.Clear();
			err = "encode local key without header fail";	
			m_on_csr_failure.Dispatch(err);
			return;
		}
		unsigned char hash[SHA512_DIGEST_LENGTH];
		iDirect_sha512((const unsigned char*)data, length, hash);
		if ( !m_x509_local_key.SetHash((char*)hash, sizeof(hash), err) )
		{
			m_x509_local_key.Clear();
			err = "set local key hash failed";	
			m_on_csr_failure.Dispatch(err);
			return;
		}
		length = sizeof(data);
		if ( !m_x509_local_key.Encode(data, length) )
		{
			m_x509_local_key.Clear();
			err = "encode local key data fail";
			m_on_csr_failure.Dispatch(err);
			return;
		}
	
		if ( !CAFileIOMgr::GetInstance().SafeWriteFile(
					m_pki_store_path + x509_local_key_filename,
					data, (int)length, 
					callback(this, &x509_CaHandler::OnLocalKeyGenWriteToDiskSucceed),
					callback(this, &x509_CaHandler::OnLocalKeyGenWriteToDiskFailure),
					0, // context
					err,
					*m_file_io_mgr) ) 
		{
			m_x509_local_key.Clear();
			m_on_csr_failure.Dispatch(err);
			return;
		}
	}
	
	void				x509_CaHandler::OnLocalKeyGenFailure(string err)
	{
		m_on_csr_failure.Dispatch(err);
	}	
	
	void				x509_CaHandler::OnLocalKeyGenWriteToDiskSucceed(void*)
	{	
		string err;
		//
		// Get key
		//
		x509_RSAkey x509_key = *((x509_RSAkey*)m_x509_local_key.GetKey());
		//
		// Generate CSR
		//
		x509_CSR csr;
		if ( !csr.GenerateCSR4Encipher(err, x509_key, m_dn, m_altName) ) 
		{
			m_x509_local_key.Clear();
			m_on_csr_failure.Dispatch(err);
			return;
		}
	
		if ( !csr.SelfVerify(err) ) 
		{
			m_x509_local_key.Clear();
			m_on_csr_failure.Dispatch(err);
			return;
		}

		m_on_csr_succeed.Dispatch(&csr);
	}

	void				x509_CaHandler::OnLocalKeyGenWriteToDiskFailure(string err, void*)
	{	
		m_x509_local_key.Clear();
		m_on_csr_failure.Dispatch(err);	
	}

	void				x509_CaHandler::StartPKIFileLoader()
	{
		string err;
		
		if ( !m_x509_global_pki_loader.Init(
					err,
					m_pki_store_path + x509_global_pki_filename,
					callback(this, &x509_CaHandler::UpdateGlobalPKI)) )
		{
			TRACE("WARNING: global pki file loader fail to init: %s\n", err.c_str());
			TRACE("This process cannot automatically load global pki data\n");
			// continue
		}
		
		if ( !m_x509_local_cert_loader.Init(
					err,
					m_pki_store_path + x509_local_cert_filename,
					callback(this, &x509_CaHandler::UpdateLocalCert)) )
		{
			TRACE("WARNING: local cert file loader fail to init: %s\n", err.c_str());
			TRACE("This process cannot automatically load local cert data\n");
			// continue
		}
		
		if ( !m_x509_local_key_loader.Init(
					err,
					m_pki_store_path + x509_local_key_filename,
					callback(this, &x509_CaHandler::UpdateLocalKey)) )
		{
			TRACE("WARNING: local key file loader fail to init: %s\n", err.c_str());
			TRACE("This process cannot automatically load local key data\n");
			// continue
		}
	}

	void				x509_CaHandler::UpdateGlobalPKI(char* data, int len)
	{
		x509_global_pki_mgr mgr(/*sync_host =*/false);
		if ( IsPKIHashMatch(data, len, mgr, m_x509_global_pki) )
		{
			TRACE(1, "skip setting x509 global pki data: hash MATCH!\n");
			return;
		}	
		
		Callback no_succeed_cbk;
		Callback1<string> no_failure_cbk;	
		
		CaHandler::SetGlobalPKI(data, (unsigned)len, no_succeed_cbk, no_failure_cbk);
	}
	
	void				x509_CaHandler::UpdateLocalCert(char* data, int len)
	{	
		x509_local_cert_mgr mgr(/*sync_host =*/false);	
		if ( IsPKIHashMatch(data, (int)len, mgr, m_x509_local_cert) )
		{
			TRACE(1, "skip setting x509 local cert: hash MATCH!\n");
			return;
		}	
		
		Callback no_succeed_cbk;
		Callback1<string> no_failure_cbk;	
		
		CaHandler::SetLocalCert(data, (unsigned)len, no_succeed_cbk, no_failure_cbk);
	}

	void				x509_CaHandler::UpdateLocalKey(char* data, int len)
	{
		SetLocalKey(data, (unsigned)len);
	}

	bool				x509_CaHandler::IsPKIHashMatch(char* data, int len, pki_manager& parser, pki_manager& target)
	{	
		string err;
		if ( !parser.DecodeHeader(data, (unsigned)len) ) return false;
		
		unsigned target_hash_len;
		const char* target_hash_data = parser.GetHash(target_hash_len, err);

		unsigned cur_hash_len;
		const char* cur_hash_data = target.GetHash(cur_hash_len, err);
		
		return 
			target_hash_data && 
			cur_hash_data && 
			( target_hash_len == cur_hash_len ) && 
			( 0 == memcmp(target_hash_data, cur_hash_data, target_hash_len) );
	}

	string				x509_CaHandler::ConsoleHelp()
	{
		string usage = "local_key|loader|path";
		return CaHandler::ConsoleHelp() + "|" + usage;
	}

	void				x509_CaHandler::ConsoleCommand(ConsoleSession* con, int argc, char* argv[])
	{
		const char* loader_usage = "global|cert|key";

		if ( ( argc > 0 ) && !strcmp(argv[0], "local_key") )
		{
			m_x509_local_key.ConsoleCommand(con, argc-1, argv+1);
			return;
		}
		else if ( ( argc > 0 ) && !strcmp(argv[0], "loader") )
		{
			argc--; argv++;
			if ( argc > 0 )
			{
				if ( !strcmp(argv[0], "global") ) m_x509_global_pki_loader.ConsoleCommand(con, argc-1, argv+1);
				else if ( !strcmp(argv[0], "cert") ) m_x509_local_cert_loader.ConsoleCommand(con, argc-1, argv+1);
				else if ( !strcmp(argv[0], "key") ) m_x509_local_key_loader.ConsoleCommand(con, argc-1, argv+1);
				else con->Print(loader_usage);
			}
			else con->Print(loader_usage);

			return;
		}
		else if ( ( argc > 0 ) && !strcmp(argv[0], "path") )
		{
			con->Print("Store path: %s\n", m_pki_store_path.c_str());
			return;
		}
		// 
		// This command is hidden, shortcut to FileIoMgr used
		//
		else if ( ( argc > 0 ) && !strcmp(argv[0], "file_io") )
		{
			m_file_io_mgr->ConsoleCommand(con, argc-1, argv+1);
			return;
		}

		CaHandler::ConsoleCommand(con, argc, argv);
	}

	void				X509CaHandlerConsoleCommand(void*, ConsoleSession* con, int argc, char* argv[])
	{
		x509_CaHandler::GetInstance().ConsoleCommand(con, argc-1, argv+1);
	}
}

