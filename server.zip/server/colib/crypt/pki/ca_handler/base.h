// base.h
// vi:set ts=4 sw=4 nowrap:

#ifndef CA_HANDLER_BASE_H_ALREADY_INCLUDED
#define CA_HANDLER_BASE_H_ALREADY_INCLUDED

#include <crypt/pki/manager/global_pki.h>
#include <crypt/pki/manager/local_pki.h>

namespace colib
{
	class CaHandler
	{
		public:

			enum Stat
			{
				Stat_num_init_global_pki_failed,
				Stat_num_init_local_cert_failed,
				Stat_num_get_global_pki_hash_succeed,
				Stat_num_get_global_pki_hash_failed,	
				Stat_num_get_local_cert_hash_succeed,
				Stat_num_get_local_cert_hash_failed,
				Stat_num_set_global_pki_succeed,
				Stat_num_set_global_pki_failed,	
				Stat_num_set_local_cert_succeed,
				Stat_num_set_local_cert_failed,	
				Stat_latest_operation_error,
				StatCount
			};

												CaHandler();
			virtual								~CaHandler();
			//
			// Pure virtual
			//
			virtual string						GetType() = 0;
			virtual bool						Init(string& err, bool auto_gen = true) = 0;
			virtual bool						RegenerateLocalPKI(string& err, bool auto_gen = true) = 0;
			
			virtual const char*					GetGlobalPKIHash(unsigned& len, string& err);
			virtual const char*					GetLocalCertHash(unsigned& len, string& err);
			//
			// It is very possible CaHandler cannot return true/false immediately
			//
			virtual void						SetGlobalPKI(
														char* data, unsigned len, 
														const Callback& on_succeed,
														const Callback1<string>& on_failure);
			virtual void						SetLocalCert(
														char* data, unsigned len, 	
														const Callback& on_succeed,
														const Callback1<string>& on_failure);
			//
			// Multiple modes support:
			// 1. Return CSR immediately - (who in the future can support this?)
			// 2. Return NULL (case of x509 - Key generation is slow, return result later)
			// 		2.1	err != "", CSR generation failed immediately
			// 		2.2	no err, ca handler will generate CSR in the background
			// 		2.2.1 if succeed, call on_succeed callback
			// 		2.2.2 if failed, call on_failed with error info
			//
			virtual pki_base*					GenerateLocalCertSignRequest(
													const Callback1<pki_base*>& on_succeed, 
													const Callback1<string>& on_failure,
													string& err) = 0;			

			virtual string						ConsoleHelp();
			virtual void						ConsoleCommand(ConsoleSession* con, int argc, char* argv[]);

		protected:
			//
			// Pure virtual
			//
			virtual const global_pki_mgr*		GlobalPKIMgr() const = 0;
			virtual const local_cert_mgr*		LocalCertMgr() const = 0;

			void								SET_GlobalPKI_ERROR(string err);
			void								SET_LocalCert_ERROR(string err);

		protected:

			ValueList							m_stats;	
	};
	#define CA_HANDLER_STAT(stat)	m_stats[CaHandler::Stat_##stat].AsInt()

}//end namespace colib


#endif

