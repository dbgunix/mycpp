#include <idirect/crypt/pki/format/x509_rsa_key.h>
#include <idirect/crypt/pki/format/x509_cert.h>
#include <idirect/crypt/pki/format/x509_csr.h>
#include <idirect/crypt/pki/hostCert/x509.h>
#include <idirect/crypt/pki/checker/x509.h>
#include <idirect/crypt/pki/ca_handler/keygen.h>
#include <idirect/crypt/pki/ca_handler/ca_file_io.h>
#include <idirect/crypt/pki/ca_handler/x509.h>
#include <idirect/crypt/sha/sha.h>
#include <idirect/event_loop/event_loop.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <openssl/ssl.h>

using namespace colib;
	
string dn[] = {"RootCert", "US", "VA", "colib", "Engineer", "NMS", "1", "hcheng@idirect.net"}; 
string untrusted[] = {"SignCert", "US", "VA", "iGT", "", "", "", ""};
string remote_dn[] = {"3100.12345"};
	
class CaFoundryNMS
{
	public:

		CaFoundryNMS();
		~CaFoundryNMS() {};

		bool Init();

		x509_global_pki_mgr		m_global_pki;
		x509_local_key_mgr		m_ca_key;
		x509_local_key_mgr		m_un_key;
		x509_local_cert_mgr		m_remote_pki;
};

class CaHandlerRMT
{
	public:

		CaHandlerRMT() {};
		~CaHandlerRMT() {};

		bool Init();
		x509_CaHandler	m_ca_handler;
};

class CaTest
{
	public:

		CaTest() {};
		~CaTest() {};

		bool Init();

		void RemoteSetGlobalDone() { printf("Remote Set Global PKI succeed\n"); }
		void RemoteSetGlobalFail(string err) { printf("Remote Set Global PKI fail: %s\n", err.c_str()); }

		void RemoteCSRGenerated(pki_base* csr);
		void RemoteCSRFailure(string err) { printf("Remote CSR generation fail: %s\n", err.c_str()); }

		void RemoteSetLocalCertDone() { printf("Remote Set Local Cert succeed\n"); }
		void RemoteSetLocalCertFail(string err) { printf("Remote Set Local Cert fail: %s\n", err.c_str()); }

		CaFoundryNMS	m_ca_foundry;
		CaHandlerRMT	m_ca_handler;
};

CaFoundryNMS::CaFoundryNMS()
	:
	m_global_pki(false),
	m_remote_pki(false)
{
}

bool CaFoundryNMS::Init()
{
	string err;
	char buf[65535];
	
	int length = sizeof(buf);
	if ( CAFileIOMgr::GetInstance().BlockingReadFile(
				"ca_global.bin", buf, length, err))
	{
		if ( !m_global_pki.Decode(buf, length) ) 
		{
			printf("CAFoundry fail to load global pki from file\n");
			return false;
		}
	}	
	length = sizeof(buf);
	if ( CAFileIOMgr::GetInstance().BlockingReadFile(
				"ca_key.bin", buf, length, err))
	{
		if ( !m_ca_key.Decode(buf, length) ) 
		{
			printf("CAFoundry fail to load CA key from file\n");
			return false;
		}
	}
	length = sizeof(buf);
	if ( CAFileIOMgr::GetInstance().BlockingReadFile(
				"un_key.bin", buf, length, err))
	{
		if ( !m_un_key.Decode(buf, length) ) 
		{
			printf("CAFoundry fail to load Untrusted key from file\n");
			return false;
		}
	}
	//
	if ( m_global_pki.NumOfPKI() == 0 )
	{
		printf("CAFoundry global PKI not OK, regenerate them ...\n");
		printf("1. Generate Root CA X509 RSA key ...\n");
		x509_RSAkey ca_key;
		if ( !ca_key.GeneratePrivateKeypair(err) )
		{
			printf("Fail to generate X509 RSA key: %s\n", err.c_str());
			return false;
		}	
		if ( !m_ca_key.SetKey(&ca_key, err) )
		{
			printf("Fail to set key to CA key mgr\n");
			return false;
		}
		unsigned len = sizeof(buf);
		if ( !m_ca_key.Encode(buf, len) )
		{
			printf("Fail to encode CA key mgr\n");
			return false;
		}
		if ( !CAFileIOMgr::GetInstance().BlockingWriteFile(
					"ca_key.bin", buf, (int)len, err) )
		{
			printf("Fail to save CA key data to file\n");
			return false;
		}
		printf("2. Generate Root CA X509 Certificate signed by the Root CA key ...\n");
		x509_Certificate ca_cert;
		if ( !ca_cert.GenerateCertificateFromDN(err, dn, ca_key) )
		{
			printf("Generate X509 certificate fail: %s\n", err.c_str());
			return false;
		}		
		if ( !m_global_pki.AddTrusted(&ca_cert, err) )
		{
			printf("Add Trusted to CA global fail: %s\n", err.c_str());
			return false;
		}
		else printf("Add Trusted to CA global succeed\n");
		//
		printf("3. Generate Untrusted CA X509 RSA key ...\n");
		x509_RSAkey un_key;
		if ( !un_key.GeneratePrivateKeypair(err) )
		{
			printf("Fail to generate X509 RSA key: %s\n", err.c_str());
			return false;
		}	
		if ( !m_un_key.SetKey(&un_key, err) )
		{
			printf("Fail to set key to CA unkey mgr\n");
			return false;
		}
		len = sizeof(buf);
		if ( !m_un_key.Encode(buf, len) )
		{
			printf("Fail to encode CA unkey mgr\n");
			return false;
		}
		if ( !CAFileIOMgr::GetInstance().BlockingWriteFile(
					"un_key.bin", buf, (int)len, err) )
		{
			printf("Fail to save CA unkey data to file\n");
			return false;
		}
		//
		printf("4. Generate Untrusted X509 CSR signed by the unkey ...\n");
		x509_CSR ucsr;
		if ( !ucsr.GenerateCSR4SignCert(err, un_key, untrusted) ) 
		{
			printf("Generate Untrusted CSR fail: %s\n", err.c_str());
			return false;
		}
		//
		printf("Sign Untrusted CSR with Root CA ...\n");
		x509_Certificate ucert;
		if  ( !ucert.GenerateCertificateFromCSR(err, ucsr, ca_cert, ca_key, 100) )
		{
			printf("Fail to sign Untrusted CSR: %s\n", err.c_str());
			return false;
		}
		if ( !m_global_pki.AddUntrusted(&ucert, err) )
		{
			printf("Add Untrusted to CA global fail: %s\n", err.c_str());
			return false;
		}
		else printf("Add Untrusted to CA global succeed\n");
	
		char hash[SHA512_DIGEST_LENGTH];
		m_global_pki.SetVersion(PKI_VERSION);
		len = sizeof(buf);
		if ( !m_global_pki.EncodeWithoutHeader(buf, len) )
		{	
			printf("Encode CA global pki mgr without header fail\n");
			return false;
		}
		else printf("Encode CA global pki mgr no header with %d byte\n", len);
	
		iDirect_sha512((const unsigned char*)buf, len, (unsigned char*)hash);
		if ( !m_global_pki.SetHash(hash, sizeof(hash), err) )
		{
			printf("m_global_pki set hash fail: %s\n", err.c_str());
			return false;
		}
		len = sizeof(buf);
		if ( !m_global_pki.Encode(buf, len) )
		{
			printf("Encode CA global pki mgr fail\n");
			return false;
		}
		else printf("Encode CA global pki mgr with %d byte\n", len);

		if ( !CAFileIOMgr::GetInstance().BlockingWriteFile(
					"ca_global.bin",
					buf, (int)len, err))
		{
			printf("Fail to save CA global pki mgr data to file\n");
			return false;
		}
		else printf("CA global pki data saved to file\n");
	}
	//
	// Remote pki
	//
	length = sizeof(buf);
	if ( CAFileIOMgr::GetInstance().BlockingReadFile(
				"ca_rmt_cert.bin", buf, length, err))
	{
		if ( !m_remote_pki.Decode(buf, length) ) 
		{
			printf("CAFoundry fail to load remote pki from file\n");
			return false;
		}
	}

	return true;	
}

bool CaHandlerRMT::Init()
{
	string err;
	m_ca_handler.SetDN(remote_dn, 1);
	return m_ca_handler.Init(err);
}

bool CaTest::Init()
{
	return m_ca_foundry.Init() && m_ca_handler.Init();
}

void CaTest::RemoteCSRGenerated(pki_base* csr)
{
	string err;
	x509_CSR* x509_csr = (x509_CSR*)csr;
	if ( !x509_csr ) return;
	
	printf("Generate remote certificate by signing CSR with untrusted key\n");
	x509_Certificate cert;
	
	Dlist<pki_base*> list;
	m_ca_foundry.m_global_pki.GetUntrusted(list);
	if ( list.Size() != 1 )
	{
		printf("CA Foundry has untrusted not equal one, cannot proceed\n");
		return;
	}
	x509_Certificate* un_cert = (x509_Certificate*)list.GetHead()->GetData();
	x509_RSAkey* un_key = (x509_RSAkey*)m_ca_foundry.m_un_key.GetKey();
	if ( !cert.GenerateCertificateFromCSR(err, *x509_csr, *un_cert, *un_key, 12345) )
	{
		printf("CA Foundry fail to generate remote cert from CSR: %s\n", err.c_str());
		return;
	}
	if ( !m_ca_foundry.m_remote_pki.SetCert(&cert, err) )
	{
		printf("CA Foundry fail to set generated cert to remote pki mgr\n");
		return;
	}
	
	m_ca_foundry.m_remote_pki.SetVersion(PKI_VERSION);
	
	char hash[SHA512_DIGEST_LENGTH];
	char buf[65535];
	unsigned len = sizeof(buf);
	if ( !m_ca_foundry.m_remote_pki.EncodeWithoutHeader(buf, len) )
	{	
		printf("Encode CA remote pki mgr without header fail\n");
		return;
	}
	else printf("Encode CA remote pki mgr no header with %d byte\n", len);
	
	iDirect_sha512((const unsigned char*)buf, len, (unsigned char*)hash);
	if ( !m_ca_foundry.m_remote_pki.SetHash(hash, sizeof(hash), err) )
	{
		printf("CA foundry m_remote_pki set hash fail: %s\n", err.c_str());
		return;
	}
	
	len = sizeof(buf);
	if ( !m_ca_foundry.m_remote_pki.Encode(buf, len) )
	{
		printf("Encode CA foundry remote pki mgr fail\n");
		return;
	}
	else printf("Encode CA foundry remote pki mgr with %d byte\n", len);

	if ( !CAFileIOMgr::GetInstance().BlockingWriteFile(
				"ca_rmt_cert.bin",
				buf, (int)len, err))
	{
		printf("Fail to save CA foundry local pki mgr data to file\n");
		return;
	}
	else printf("CA foundry local pki data saved to file\n");

	//
	// Set remote side
	//
	m_ca_handler.m_ca_handler.SetLocalCert(buf, len, 
			callback(this, &CaTest::RemoteSetLocalCertDone),	
			callback(this, &CaTest::RemoteSetLocalCertFail));	
}

int	main()
{	
	SSL_load_error_strings();
	OpenSSL_add_all_algorithms();

	EventLoop::GetInstance().Initialize();

	string err;
	CaTest ca_test;
	if ( !ca_test.Init() )
	{
		printf("Fail to init CA test\n");
		return -1;
	}

	{
		printf("HostCert is%s OK\n", x509_HostCert::GetInstance().IsOK()?"":" NOT");	
		x509_Certificate* cert = (x509_Certificate*)x509_HostCert::GetInstance().GetCert();
		x509_RSAkey* key = (x509_RSAkey*)x509_HostCert::GetInstance().GetKey();
		if ( cert && key && cert->MatchRSA(key->GetRSA(), err) )
		{
			printf("Local Cert and Key MATCH\n");
		}
	}	
	//
	// Global PKI
	//
	unsigned ca_gh_len;
	const char* ca_gh_data = ca_test.m_ca_foundry.m_global_pki.GetHash(ca_gh_len, err);
	unsigned rmt_gh_len;
	const char* rmt_gh_data = ca_test.m_ca_handler.m_ca_handler.GetGlobalPKIHash(rmt_gh_len, err);

	if ( 
		ca_gh_len && rmt_gh_len &&	
		( ca_gh_len == rmt_gh_len ) &&
		( memcmp(ca_gh_data, rmt_gh_data, ca_gh_len) == 0 ) 
		)
	{
		printf("CAFoundry and CAHandler Global PKI match!\n");
	}
	else
	{	
		printf("CAFoundry and CAHandler Global PKI mismatch!\n");	
		char buf[65535];
		int length = sizeof(buf);
		if ( CAFileIOMgr::GetInstance().BlockingReadFile(
					"ca_global.bin", buf, length, err))
		{
			ca_test.m_ca_handler.m_ca_handler.SetGlobalPKI(buf, (unsigned)length, 
					callback(&ca_test, &CaTest::RemoteSetGlobalDone),	
					callback(&ca_test, &CaTest::RemoteSetGlobalFail));
		}
	}
	//
	// Local PKI
	//
	unsigned ca_cert_len;
	const char* ca_cert_data = ca_test.m_ca_foundry.m_remote_pki.GetHash(ca_cert_len, err);
	unsigned rmt_cert_len;
	const char* rmt_cert_data = ca_test.m_ca_handler.m_ca_handler.GetLocalCertHash(rmt_cert_len, err);

	if ( 
		ca_cert_len && rmt_cert_len &&	
		( ca_cert_len == rmt_cert_len ) &&
		( memcmp(ca_cert_data, rmt_cert_data, ca_cert_len) == 0 ) 
		)
	{
		printf("CAFoundry and CAHandler Remote Cert match!\n");
	}
	else
	{	
		printf("CAFoundry and CAHandler Remote Cert mismatch!\n");	

		ca_test.m_ca_handler.m_ca_handler.GenerateLocalCertSignRequest(
				callback(&ca_test, &CaTest::RemoteCSRGenerated),
				callback(&ca_test, &CaTest::RemoteCSRFailure),
				err);
	}

	EventLoop::GetInstance().Main();
	
	return 0;
}

