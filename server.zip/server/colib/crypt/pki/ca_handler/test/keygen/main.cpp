#include <idirect/crypt/pki/format/x509_rsa_key.h>
#include <idirect/crypt/pki/format/x509_cert.h>
#include <idirect/crypt/pki/format/x509_csr.h>
#include <idirect/crypt/pki/checker/x509.h>
#include <idirect/crypt/pki/ca_handler/keygen.h>
#include <idirect/event_loop/event_loop.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <openssl/ssl.h>

using namespace colib;

class CAHandler
{
	public:
		CAHandler();
		~CAHandler() {};

		void	PrintKey(pki_base* key);
		void	KeyFailed(string err) { printf("Keygen fail: %s\n", err.c_str()); }

		x509_KeyGenHandler m_keygen_handler;
};

CAHandler::CAHandler()
{
}

void CAHandler::PrintKey(pki_base* key)
{	
	string output = key->DumpReadable();
	printf("%s\n", output.c_str());
}

int	main()
{	
	SSL_load_error_strings();
	OpenSSL_add_all_algorithms();

	EventLoop::GetInstance().Initialize();
	
	CAHandler handler;
	handler.m_keygen_handler.GenerateKey(
			callback(&handler, &CAHandler::PrintKey),
			callback(&handler, &CAHandler::KeyFailed),
			1);

	EventLoop::GetInstance().Main();
	/*	
	string dn[] = {"RootCert", "US", "VA", "colib", "Engineer", "NMS", "1", "hcheng@idirect.net"}; 
	string untrusted[] = {"SignCert", "US", "VA", "iGT", "", "", "", ""};
	string remote[] = {"Remote", "CN", "SZ", "", "", "", "", ""};

	string output, err;	
	//
	printf("Generate Root CA X509 RSA key ...\n");
	x509_RSAkey ca_key;
	if ( !ca_key.GeneratePrivateKeypair(err) )
	{
		printf("Fail to generate X509 RSA key: %s\n", err.c_str());
		return -1;
	}	
	//
	printf("Generate Root CA X509 Certificate signed by the Root CA key ...\n");
	x509_Certificate ca_cert;
	if ( !ca_cert.GenerateCertificateFromDN(err, dn, ca_key) )
	{
		printf("Generate X509 certificate fail: %s\n", err.c_str());
		return -1;
	}	
	x509_global_pki_mgr ca_global(false);
	if ( !ca_global.AddTrusted(&ca_cert, err) )
	{
		printf("Add Trusted to CA global fail: %s\n", err.c_str());
		return -1;
	}
	else printf("Add Trusted to CA global succeed\n");
	//
	printf("Generate Untrusted CA X509 RSA key ...\n");
	x509_RSAkey ukey;
	if ( !ukey.GeneratePrivateKeypair(err) )
	{
		printf("Fail to generate X509 RSA key: %s\n", err.c_str());
		return -1;
	}	
	//
	printf("Generate Untrusted X509 CSR signed by the ukey ...\n");
	x509_CSR ucsr;
	if ( !ucsr.GenerateCSR4SignCert(err, ukey, untrusted) ) 
	{
		printf("Generate CSR fail: %s\n", err.c_str());
		return -1;
	}
	//
	printf("Sign Untrusted CSR with Root CA ...\n");
	x509_Certificate ucert;
	if  ( !ucert.GenerateCertificateFromCSR(err, ucsr, ca_cert, ca_key, 100) )
	{
		printf("Fail to sign CSR: %s\n", err.c_str());
		return -1;
	}	
	if ( !ca_global.AddUntrusted(&ucert, err) )
	{
		printf("Add Untrusted to CA global fail: %s\n", err.c_str());
		return -1;
	}
	else printf("Add Untrusted to CA global succeed\n");
	//	
	printf("Generate Remote X509 RSA key ...\n");
	x509_RSAkey key;
	if ( !key.GeneratePrivateKeypair(err) )
	{
		printf("Fail to generate X509 RSA key: %s\n", err.c_str());
		return -1;
	}	
	//
	printf("Generate Remote X509 CSR signed by the key ...\n");
	x509_CSR csr;
	if ( !csr.GenerateCSR4Encipher(err, key, remote) ) 
	{
		printf("Generate CSR fail: %s\n", err.c_str());
		return -1;
	}
	//
	printf("Sign CSR with Untrursted CA ...\n");
	x509_Certificate cert;
	if  ( !cert.GenerateCertificateFromCSR(err, csr, ucert, ukey, 12345) )
	{
		printf("Fail to sign CSR: %s\n", err.c_str());
		return -1;
	}
	//
	if ( !CustomerX509CertChecker::GetInstance().VerifyCert(&cert, err, 0) )
	{
		printf("Customer X509 Checker fail verify cert\n");
	}
	else
	{
		printf("Customer X509 Checker verify cert succeed\n");
	}

	//				
	char buf[65535];
	unsigned len = sizeof(buf);

	char hash[] = {1,2,3,4,5};
	ca_global.SetVersion("4.0");
	ca_global.SetHash(hash, sizeof(hash), err);
	if ( !ca_global.Encode(buf, len) )
	{
		printf("Encode CA global pki mgr fail\n");
		return  -1;
	}
	else printf("Encode CA global pki mgr with %d byte\n", len);

	//
	x509_global_pki_mgr rmt_global(true);
	if ( !rmt_global.Decode(buf, len) )
	{
		printf("Remote global pki manager decode buf fail\n");
		return -1;
	}
	else printf("Remote global pki manager decode buf succeed\n");
	//
	output = rmt_global.DumpReadable();
	printf("%s\n", output.c_str());

	if ( !CustomerX509CertChecker::GetInstance().VerifyCert(&cert, err, 0) )
	{
		printf("Customer X509 Checker fail verify cert\n");
	}
	else
	{
		printf("Customer X509 Checker verify cert succeed\n");
	}

	//
	x509_RevocationList crl;	
	err = "";
	printf("Revoke remote cert ...\n");
	if ( !crl.RevokeCertificate(cert, err) )
//	if ( !crl.RevokeCertificate(ucert, err) )
	{
		printf("CRL fail to revoke cert: %s\n", err.c_str());
		return -1;
	}
	printf("Sign CRL ...\n");
	if ( !crl.Sign(ukey, ucert, err) )
//	if ( !crl.Sign(ca_key, ca_cert, err) )
	{
		printf("Fail to sign CRL: %s\n", err.c_str());
		return -1;
	}
	if ( !ca_global.AddOrUpdateCRL(&crl, err) )
	{
		printf("AddOrUpdate CA global pki mgr with CRL fail\n");
		return -1;
	}
	else printf("AddOrUpdate CA global pki mgr with CRL succeed\n");
	
	len = sizeof(buf);
	if ( !ca_global.Encode(buf, len) )
	{
		printf("Encode CA global pki mgr fail\n");
		return  -1;
	}
	else printf("Encode CA global pki mgr with %d byte\n", len);

	//
	if ( !rmt_global.Decode(buf, len) )
	{
		printf("Remote global pki manager decode buf fail\n");
		return -1;
	}
	else printf("Remote global pki manager decode buf succeed\n");
	//
	output = rmt_global.DumpReadable();
	printf("%s\n", output.c_str());

	if ( !CustomerX509CertChecker::GetInstance().VerifyCert(&cert, err, 0) )
	{
		printf("Customer X509 Checker fail verify cert\n");
	}
	else
	{
		printf("Customer X509 Checker verify cert succeed\n");
	}
	*/
	return 0;
}

