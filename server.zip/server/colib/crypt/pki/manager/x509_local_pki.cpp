// x509_local_pki.cpp
// vi:set ts=4 sw=4 nowrap:

#include <crypt/pki/manager/x509_local_pki.h>
#include <crypt/pki/hostCert/x509.h>

namespace colib
{
	x509_local_cert_mgr::x509_local_cert_mgr(bool sync_hostCert)
		:
		m_sync_hostCert(sync_hostCert)
	{
	}

	x509_local_cert_mgr::~x509_local_cert_mgr()
	{
		m_cert.Zeroize();
	}
	
	void			x509_local_cert_mgr::Clear()
	{
		if ( m_sync_hostCert ) x509_HostCert::GetInstance().ClearCert();
		local_cert_mgr::Clear();
	}

	bool			x509_local_cert_mgr::SetCert(pki_base* cert, string& err)
	{
		bool ret = ( cert && ( string(cert->GetType()) == PKI_TYPE_X509_CERT ) && cert->IsOK() );
		if ( !ret ) 
		{
			err = "Invalid Certificate";
			return false;
		}

		if ( m_sync_hostCert ) ret = x509_HostCert::GetInstance().SetCert(cert, err);
		if ( ret ) m_cert = *((x509_Certificate*)cert);
		return ret;				
	}

	pki_base*		x509_local_cert_mgr::CreateCert(string type)
	{
		if ( type == PKI_TYPE_X509_CERT) return new x509_Certificate;
		return 0;
	}
	
	x509_local_key_mgr::~x509_local_key_mgr()
	{
		m_key.Zeroize();
	}
		
	void			x509_local_key_mgr::Clear()
	{
		x509_HostCert::GetInstance().ClearKey();
		local_key_mgr::Clear();
	}

	bool			x509_local_key_mgr::SetKey(pki_base* key, string& err)
	{
		bool ret = ( key && ( string(key->GetType()) == PKI_TYPE_X509_RSA_KEY ) && key->IsOK() );
		if ( !ret ) 
		{
			err = "Invalid RSA key";
			return false;
		}
		ret = x509_HostCert::GetInstance().SetKey(key, err);
		if ( ret ) m_key = *((x509_RSAkey*)key);
		return ret;				
	}

	pki_base*		x509_local_key_mgr::CreateKey(string type)
	{
		if ( type == PKI_TYPE_X509_RSA_KEY) return new x509_RSAkey;
		return 0;
	}

}//end namespace colib

