// global_pki.h
// vi:set ts=4 sw=4 nowrap:

#ifndef GLOBAL_PKI_H_ALREADY_INCLUDED
#define GLOBAL_PKI_H_ALREADY_INCLUDED

#include <crypt/pki/manager/base.h>

namespace colib
{
	class global_pki_mgr : public pki_manager
	{
		public:

								global_pki_mgr() {};
			virtual				~global_pki_mgr() {};
			//
			// Implement pure virtual functions
			//	
			virtual bool		EncodePKI(CXDR* xdr, string& err);
			virtual bool		DecodePKI(CXDR* xdr, string& err);
			virtual void		Clear();
			virtual void		Zeroize();
			virtual int			NumOfPKI();
			virtual bool		IsOK();
			virtual string		PKIDumpReadable() const; 	
			//
			// virtual functions
			//
			virtual void		GetTrusted(Dlist<pki_base*>& list) const = 0;
			virtual bool		AddTrusted(pki_base*, string&) = 0;
			virtual bool		DelTrusted(pki_base*, string&) = 0;

			virtual void		GetUntrusted(Dlist<pki_base*>& list) const = 0;
			virtual bool		AddUntrusted(pki_base*, string&) = 0;
			virtual bool		DelUntrusted(pki_base*, string&) = 0;

			virtual void		GetCRL(Dlist<pki_base*>& list) const = 0;
			virtual bool		AddOrUpdateCRL(pki_base*, string&) = 0;
		
		protected:
			//
			// Pure virtual functions
			//
			virtual pki_base*	CreateTrusted(string type) = 0;
			virtual pki_base*	CreateUntrusted(string type) = 0;
			virtual pki_base*	CreateCRL(string type) = 0;
			//
			// Other convenient functions
			//
			void				Clear(Dlist<pki_base*>& list);
			void				Zeroize(Dlist<pki_base*>& list);
			bool				EncodePKI(Dlist<pki_base*>& list, CXDR* xdr, string& err);
			string				PKIDumpReadable(Dlist<pki_base*>& list) const;
	};

}//end namespace colib


#endif

