// local_pki.cpp
// vi:set ts=4 sw=4 nowrap:

#include <crypt/pki/manager/local_pki.h>

namespace colib
{	
	void		local_cert_mgr::Zeroize()
	{
		if ( GetCert() ) GetCert()->Zeroize();
	}

	void		local_cert_mgr::Clear()
	{
		if ( GetCert() ) GetCert()->Clear();
	}

	int			local_cert_mgr::NumOfPKI()
	{
		return ( GetCert() ? 1 : 0 );
	}

	bool		local_cert_mgr::EncodePKI(CXDR* xdr, string& err)
	{	
		pki_base* cert = GetCert();

		if ( !cert || !cert->IsOK() )
		{
			err = "Certificate not present or not OK";
			return false;
		}

		string type = cert->GetType();
		if ( !xdr->XdrStringPacked(type) )
		{
			err = string::Format("Fail to encode cert type (%s)", type.c_str());
			return false;
		}

		if ( !cert->XdrEncode(xdr, err) ) 
		{
			err = string::Format("Fail to encode cert data (%s): ", type.c_str()) + err;
			return false;
		}
		
		return true;
	}
		
	bool		local_cert_mgr::DecodePKI(CXDR* xdr, string& err)
	{
		string type;
		if ( !xdr->XdrStringPacked(type) )
		{
			err = "Fail to decode cert type";
			return false;
		}

		pki_base* cert = CreateCert(type);
		if ( !cert ) 
		{
			err = string::Format("Not supported cert pki type (%s)", type.c_str());
			return false;
		}

		if ( !cert->XdrDecode(xdr, err) )
		{
			err = string::Format("Fail to decode cert pki data (%s): ", type.c_str()) + err;
			delete cert;
			return false;
		}

		bool ret = SetCert(cert, err);
		delete cert;
		return ret;
	}

	string		local_cert_mgr::PKIDumpReadable() const
	{
		string output = "\nLocal Certificate:\n";
		pki_base* cert = GetCert();
		if ( cert ) output += cert->DumpReadable();
		else output += "Not exist yet";	
		return output;
	}

	void		local_key_mgr::Zeroize()
	{
		if ( GetKey() ) GetKey()->Zeroize();
	}

	void		local_key_mgr::Clear()
	{
		if ( GetKey() ) GetKey()->Clear();
	}

	int			local_key_mgr::NumOfPKI()
	{
		return ( GetKey() ? 1 : 0 );
	}

	bool		local_key_mgr::EncodePKI(CXDR* xdr, string& err)
	{	
		pki_base* key = GetKey();

		if ( !key || !key->IsOK() )
		{
			err = "Key not present or not OK";
			return false;
		}

		string type = key->GetType();
		if ( !xdr->XdrStringPacked(type) )
		{
			err = string::Format("Fail to encode key type (%s)", type.c_str());
			return false;
		}

		if ( !key->XdrEncode(xdr, err) ) 
		{
			err = string::Format("Fail to encode key data (%s): ", type.c_str()) + err;
			return false;
		}
		
		return true;
	}
		
	bool		local_key_mgr::DecodePKI(CXDR* xdr, string& err)
	{	
		string type;
		if ( !xdr->XdrStringPacked(type) )
		{
			err = "Fail to decode key type";
			return false;
		}

		pki_base* key = CreateKey(type);
		if ( !key ) 
		{
			err = string::Format("Not supported key pki type (%s)", type.c_str());
			return false;
		}

		if ( !key->XdrDecode(xdr, err) )
		{
			err = string::Format("Fail to decode key pki data (%s): ", type.c_str()) + err;
			delete key;
			return false;
		}

		bool ret = SetKey(key, err);
		delete key;
		return ret;
	}

	string		local_key_mgr::PKIDumpReadable() const
	{
		string output = "\nLocal Key:\n";
		pki_base* key = GetKey();
		if ( key ) output += key->DumpReadable();
		else output += "Not exist yet";	
		return output;
	}

}//end namespace colib

