// x509_gloabl_pki.h
// vi:set ts=4 sw=4 nowrap:

#ifndef X509_GLOABL_PKI_H_ALREADY_INCLUDED
#define X509_GLOABL_PKI_H_ALREADY_INCLUDED

#include <crypt/pki/manager/global_pki.h>
#include <crypt/pki/format/x509_cert.h>
#include <crypt/pki/format/x509_crl.h>

#include <map>

namespace colib
{
	typedef std::map<string, x509_Certificate>		CERT_MAP;
	typedef std::map<string, x509_RevocationList>	CRL_MAP;

	class x509_global_pki_mgr : public global_pki_mgr
	{
		public:

								x509_global_pki_mgr(bool sync_host);
			virtual				~x509_global_pki_mgr();
			//
			// Implement pure virtual functions
			//
			virtual void		GetTrusted(Dlist<pki_base*>& list) const;
			virtual bool		AddTrusted(pki_base*, string&);
			virtual bool		DelTrusted(pki_base*, string&);

			virtual void		GetUntrusted(Dlist<pki_base*>& list) const;
			virtual bool		AddUntrusted(pki_base*, string&);
			virtual bool		DelUntrusted(pki_base*, string&);

			virtual void		GetCRL(Dlist<pki_base*>& list) const;
			virtual bool		AddOrUpdateCRL(pki_base*, string&);
			//
			// Override global_pki_mgr
			//
			virtual void		Clear();

		protected:
			//
			// Pure virtual functions
			//
			virtual pki_base*	CreateTrusted(string type);
			virtual pki_base*	CreateUntrusted(string type);
			virtual pki_base*	CreateCRL(string type);

		private:

			CERT_MAP			m_trusted;
			CERT_MAP			m_untrusted;
			CRL_MAP				m_crl;

			bool				m_sync_host;
	};

}//end namespace colib


#endif

