// local_pki.h
// vi:set ts=4 sw=4 nowrap:

#ifndef LOCAL_PKI_H_ALREADY_INCLUDED
#define LOCAL_PKI_H_ALREADY_INCLUDED

#include <crypt/pki/manager/base.h>

namespace colib
{	
	class local_cert_mgr : public pki_manager
	{
		public:

								local_cert_mgr() {};
			virtual				~local_cert_mgr() {};	
			//
			// Implement pure virtual functions
			//	
			virtual bool		EncodePKI(CXDR* xdr, string& err);
			virtual bool		DecodePKI(CXDR* xdr, string& err);
			virtual void		Clear();
			virtual void		Zeroize();
			virtual int			NumOfPKI();
			virtual bool		IsOK() { return GetCert() && GetCert()->IsOK(); }
			virtual string		PKIDumpReadable() const; 	
			//
			// Pure virtual function
			//
			virtual pki_base*	GetCert() const = 0;
			virtual bool		SetCert(pki_base* cert, string& err) = 0;

		protected:
			
			virtual	pki_base*	CreateCert(string type) = 0;
	};

	class local_key_mgr : public pki_manager
	{
		public:

								local_key_mgr() {};
			virtual				~local_key_mgr() {};	
			//
			// Implement pure virtual functions
			//	
			virtual bool		EncodePKI(CXDR* xdr, string& err);
			virtual bool		DecodePKI(CXDR* xdr, string& err);
			virtual void		Clear();
			virtual void		Zeroize();
			virtual int			NumOfPKI();
			virtual bool		IsOK() { return GetKey() && GetKey()->IsOK(); }
			virtual string		PKIDumpReadable() const; 		
			//
			// Pure virtual function
			//
			virtual pki_base*	GetKey() const = 0;
			virtual bool		SetKey(pki_base* key, string& err) = 0;	
	
		protected:
			
			virtual	pki_base*	CreateKey(string type) = 0;
	};

}//end namespace colib


#endif

