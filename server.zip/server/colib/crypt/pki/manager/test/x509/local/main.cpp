#include <idirect/crypt/pki/format/x509_rsa_key.h>
#include <idirect/crypt/pki/format/x509_cert.h>
#include <idirect/crypt/pki/format/x509_csr.h>
#include <idirect/crypt/pki/hostCert/x509.h>
#include <idirect/crypt/pki/manager/x509_local_pki.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <openssl/ssl.h>

using namespace colib;

int	main()
{	
	SSL_load_error_strings();
	OpenSSL_add_all_algorithms();
		
	string dn[] = {"RootCert", "US", "VA", "colib", "Engineer", "NMS", "1", "hcheng@idirect.net"}; 
	string untrusted[] = {"SignCert", "US", "VA", "iGT", "", "", "", ""};
	string remote[] = {"Remote", "CN", "SZ", "", "", "", "", ""};

	string output, err;	
	//
	printf("Generate Root CA X509 RSA key ...\n");
	x509_RSAkey ca_key;
	if ( !ca_key.GeneratePrivateKeypair(err) )
	{
		printf("Fail to generate X509 RSA key: %s\n", err.c_str());
		return -1;
	}	
	//
	printf("Generate Root CA X509 Certificate signed by the Root CA key ...\n");
	x509_Certificate ca_cert;
	if ( !ca_cert.GenerateCertificateFromDN(err, dn, ca_key) )
	{
		printf("Generate X509 certificate fail: %s\n", err.c_str());
		return -1;
	}	
	
	printf("Generate Untrusted CA X509 RSA key ...\n");
	x509_RSAkey ukey;
	if ( !ukey.GeneratePrivateKeypair(err) )
	{
		printf("Fail to generate X509 RSA key: %s\n", err.c_str());
		return -1;
	}	
	//
	printf("Generate Untrusted X509 CSR signed by the ukey ...\n");
	x509_CSR ucsr;
	if ( !ucsr.GenerateCSR4SignCert(err, ukey, untrusted) ) 
	{
		printf("Generate CSR fail: %s\n", err.c_str());
		return -1;
	}
	//
	printf("Sign Untrusted CSR with Root CA ...\n");
	x509_Certificate ucert;
	if  ( !ucert.GenerateCertificateFromCSR(err, ucsr, ca_cert, ca_key, 100) )
	{
		printf("Fail to sign CSR: %s\n", err.c_str());
		return -1;
	}
	//	
	printf("Generate Remote X509 RSA key ...\n");
	x509_RSAkey key;
	if ( !key.GeneratePrivateKeypair(err) )
	{
		printf("Fail to generate X509 RSA key: %s\n", err.c_str());
		return -1;
	}	
	x509_local_key_mgr rmt_key_pki;
	if ( !rmt_key_pki.SetKey(&key, err) )
	{
		printf("Set remote local pki key manager fail: %s\n", err.c_str());
		return -1;
	}
	else printf("Set remote local pki key manager with RSA key succeed\n");
	printf("HostCert is%s OK\n", x509_HostCert::GetInstance().IsOK() ? "" : " NOT");
	//
	printf("Generate Remote X509 CSR signed by the key ...\n");
	x509_CSR csr;
	if ( !csr.GenerateCSR4Encipher(err, key, remote) ) 
	{
		printf("Generate CSR fail: %s\n", err.c_str());
		return -1;
	}
	//
	printf("Sign CSR with Untrursted CA ...\n");
	x509_Certificate cert;
	if  ( !cert.GenerateCertificateFromCSR(err, csr, ucert, ukey, 12345) )
	{
		printf("Fail to sign CSR: %s\n", err.c_str());
		return -1;
	}
	x509_local_cert_mgr ca_pki(false);
	if ( !ca_pki.SetCert(&cert, err) )
	{
		printf("Set CA local pki cert manager fail: %s\n", err.c_str());
		return -1;
	}
	else printf("Set CA local pki cert manager with cert succeed\n");
	//				
	char buf[65535];
	unsigned len = sizeof(buf);

	char hash[] = {1,2,3,4,5};
	ca_pki.SetVersion("4.0");
	ca_pki.SetHash(hash, sizeof(hash), err);
	if ( !ca_pki.Encode(buf, len) )
	{
		printf("Encode CA local pki cert mgr fail\n");
		return  -1;
	}
	else printf("Encode CA pki cert mgr with %d byte\n", len);
	//
	x509_local_cert_mgr rmt_cert_pki(true);
	if ( !rmt_cert_pki.Decode(buf, len) )
	{
		printf("RMT local cert pki manager decode buf fail\n");
		return -1;
	}
	else printf("RMT local cert pki manager decode buf succeed\n");
	printf("HostCert is%s OK\n", x509_HostCert::GetInstance().IsOK() ? "" : " NOT");

	printf("Key and Cert is%s MATCH\n", ((x509_Certificate*)rmt_cert_pki.GetCert())->MatchRSA(((x509_RSAkey*)rmt_key_pki.GetKey())->GetRSA(), err) ? "" : " NOT");

	output = rmt_cert_pki.DumpReadable();
	printf("%s\n", output.c_str());

	output = rmt_key_pki.DumpReadable();
	printf("%s\n", output.c_str());
	
	return 0;
}

