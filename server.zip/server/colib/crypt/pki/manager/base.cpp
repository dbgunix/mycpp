// base.cpp
// vi:set ts=4 sw=4 nowrap:

#include <crypt/pki/manager/base.h>
#include <utils/dump_hex.h>

namespace colib
{
	static ValueList::ValueHolder InitMgrStats()
	{
		return
		{
			Value("num_decode_succeed", 0),
			Value("num_decode_failed", 0),
			Value("latest_decode_fail_reason", ""),
			Value("num_encode_succeed", 0),
			Value("num_encode_failed", 0),
			Value("latest_encode_fail_reason", ""),
			Value("num_of_pki", 0)
		};
	};

	pki_manager::pki_manager()
		:
		m_hash_buf(0), m_hash_len(0),
		m_mgr_stats(InitMgrStats())
	{
	}

	pki_manager::~pki_manager()
	{
		if ( m_hash_buf ) free(m_hash_buf);
	}

	const char*		pki_manager::GetHash(unsigned& len, string& err) const
	{
		(void)err;
		len = m_hash_len;
		return m_hash_buf;
	}

	bool			pki_manager::SetHash(char* data, unsigned len, string& err)
	{
		if ( !len ) 
		{
			err = "Invalid hash len";
			return false;
		}

		if ( m_hash_len != len )
		{
			if ( m_hash_buf ) free(m_hash_buf);
			m_hash_len = len;
			m_hash_buf = (char*)malloc(m_hash_len);
			if ( !m_hash_buf )
			{
				err = "Fail to allocate buffer to store hash";
				return false;
			}
		}
		
		memcpy(m_hash_buf, data, m_hash_len);
		return true;
	}

	bool			pki_manager::Encode(char* data, unsigned& len) 
	{
		XdrEncode xdr(data, len);
		string err;	
		bool ret = Encode(&xdr, err, false);
		if ( ret ) len = xdr.GetLength();
		return ret;
	}

	bool			pki_manager::EncodeWithoutHeader(char* data, unsigned& len)
	{			
		XdrEncode xdr(data, len);
		string err;		
		bool ret = Encode(&xdr, err, true);
		if ( ret ) len = xdr.GetLength();
		return ret;
	}
	
	bool			pki_manager::EncodeHeader(char* data, unsigned& len)
	{	
		XdrEncode xdr(data, len);
		string err;		
		bool ret = EncodeHeader(&xdr, err);
		if ( ret ) len = xdr.GetLength();
		return ret;
	}

	bool			pki_manager::Encode(CXDR* xdr, string& err, bool no_header)
	{
		bool ret = true;
		
		if ( ret && !no_header ) ret = EncodeHeader(xdr, err);		

		if ( ret ) ret = EncodePKI(xdr, err);
	
		if ( !ret ) 	
		{
			PKI_MGR_STAT(num_encode_failed)++;
			m_mgr_stats[pki_manager::mgrStat_latest_encode_fail_reason].SetFromString(err.c_str());
		}
		else
		{
			PKI_MGR_STAT(num_encode_succeed)++;
		}

		return ret;
	}

	bool			pki_manager::EncodeHeader(CXDR* xdr, string& err)
	{
		if ( 
			!xdr->XdrStringPacked(m_ver) ||
			!xdr->XdrUint(&m_hash_len)
		   )
		{
			err = "Fail to encode header with version or hash length";
			return false;
		}
		
		if ( m_hash_len && !xdr->XdrBytes(m_hash_buf, m_hash_len) )
		{
			err = "Fail to encode header with hash data";
			return false;
		}

		return true;
	}

	bool			pki_manager::Decode(char* data, unsigned len)
	{	
		XdrDecode xdr(data, len);
		string err;
		return Decode(&xdr, err, false);
	}

	bool			pki_manager::DecodeWithoutHeader(char* data, unsigned len)
	{		
		XdrDecode xdr(data, len);
		string err;
		return Decode(&xdr, err, true);
	}

	bool			pki_manager::DecodeHeader(char* data, unsigned len)
	{	
		XdrDecode xdr(data, len);
		string err;
		return DecodeHeader(&xdr, err);	
	}

	bool			pki_manager::Decode(CXDR* xdr, string& err, bool no_header)
	{
		//
		// Clear first
		//
		Clear();

		bool ret = true;
		
		if ( ret && !no_header ) ret = DecodeHeader(xdr, err);

		if ( ret ) ret = DecodePKI(xdr, err);

		if ( !ret ) 	
		{
			PKI_MGR_STAT(num_decode_failed)++;
			m_mgr_stats[pki_manager::mgrStat_latest_decode_fail_reason].SetFromString(err.c_str());
		}
		else
		{
			PKI_MGR_STAT(num_decode_succeed)++;
		}

		return ret;
	}

	bool			pki_manager::DecodeHeader(CXDR* xdr, string& err)
	{
		unsigned hash_len;

		if ( 
			!xdr->XdrStringPacked(m_ver) ||
			!xdr->XdrUint(&hash_len) 
		   )
		{
			err = "Fail to decode header with version or hash length";
			return false;
		}

		if ( m_hash_len != hash_len )
		{
			if ( m_hash_buf ) free(m_hash_buf);
			m_hash_len = hash_len;			
			if ( m_hash_len ) 
			{
				m_hash_buf = (char*)malloc(m_hash_len);
				if ( !m_hash_buf )
				{
					err = "Fail to allocate buffer to store hash";
					return false;
				}
			}
		}

		if ( m_hash_len )
		{
			if ( !xdr->XdrBytes(m_hash_buf, m_hash_len) )
			{		
				err = "Fail to decode hash";
				return false;
			}
		}

		return true;
	}
	
	string			pki_manager::DumpReadable() const
	{
		string output = "Version:\t" + m_ver;
		output.AppendFmt("\nHashLen:\t%u", m_hash_len);
	   	if ( m_hash_len )
		{
			output += "\nHashData:\n";
			output += DumpHex2String(m_hash_buf, m_hash_len);
		}
		output += PKIDumpReadable();
		return output;
	}

	string			pki_manager::ConsoleHelp()
	{
		return "stats|print";
	}

	void			pki_manager::ConsoleCommand(ConsoleSession* con, int argc, char* argv[])
	{
		string usage = "Usage:\t" + ConsoleHelp();

		if ( !con ) return;
		
		if ( argc == 0 )
		{
			con->Print(usage.c_str());
			return;
		}

		if ( !strcmp(argv[0], "stats") )
		{
			PKI_MGR_STAT(num_of_pki) = NumOfPKI();
			m_mgr_stats.ConsoleCommand(con, argc-1, argv+1);
		}
		else if ( !strcmp(argv[0], "print") )
		{
			con->Print("%s\n", DumpReadable().c_str());
		}
		else con->Print(usage.c_str());
	}

}//end namespace colib

