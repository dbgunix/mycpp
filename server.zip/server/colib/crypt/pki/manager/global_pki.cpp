// global_pki.cpp
// vi:set ts=4 sw=4 nowrap:

#include <crypt/pki/manager/global_pki.h>

namespace colib
{
	void		global_pki_mgr::Zeroize()
	{
		Dlist<pki_base*> list;

		list.Clear();
		GetTrusted(list);		
		Zeroize(list);
		
		list.Clear();
		GetUntrusted(list);
		Zeroize(list);

		list.Clear();
		GetCRL(list);
		Zeroize(list);
	}
	
	void		global_pki_mgr::Zeroize(Dlist<pki_base*>& list)
	{	
		for ( Dlist<pki_base*>::Node* node = list.GetHead(); 
			   node != 0; node = list.GetNext(node) )
		{
			node->GetData()->Zeroize();
		}		
	}

	void		global_pki_mgr::Clear()
	{	
		Dlist<pki_base*> list;

		list.Clear();
		GetTrusted(list);		
		Clear(list);
		
		list.Clear();
		GetUntrusted(list);
		Clear(list);

		list.Clear();
		GetCRL(list);
		Clear(list);
	}

	void		global_pki_mgr::Clear(Dlist<pki_base*>& list)
	{	
		for ( Dlist<pki_base*>::Node* node = list.GetHead(); 
			   node != 0; node = list.GetNext(node) )
		{
			 node->GetData()->Clear();
		}
	}

	int			global_pki_mgr::NumOfPKI()
	{
		int n = 0;
		Dlist<pki_base*> list;

		list.Clear();
		GetTrusted(list);		
		n += list.Size();
		
		list.Clear();
		GetUntrusted(list);
		n += list.Size();

		list.Clear();
		GetCRL(list);
		n += list.Size();

		return n;
	}
	
	bool		global_pki_mgr::IsOK()
	{
		Dlist<pki_base*> list;
		
		list.Clear();
		GetTrusted(list);		
		for ( Dlist<pki_base*>::Node* node = list.GetHead();
				node != 0; node = list.GetNext(node) )
		{
			if ( !node->GetData() || !node->GetData()->IsOK() ) return false;
		}
	
		list.Clear();
		GetUntrusted(list);		
		for ( Dlist<pki_base*>::Node* node = list.GetHead();
				node != 0; node = list.GetNext(node) )
		{
			if ( !node->GetData() || !node->GetData()->IsOK() ) return false;
		}
	
		list.Clear();
		GetCRL(list);		
		for ( Dlist<pki_base*>::Node* node = list.GetHead();
				node != 0; node = list.GetNext(node) )
		{
			if ( !node->GetData() || !node->GetData()->IsOK() ) return false;
		}
		
		return true;
	}

	bool		global_pki_mgr::EncodePKI(CXDR* xdr, string& err) 
	{		
		Dlist<pki_base*> list;

		list.Clear();
		GetTrusted(list);		
		if ( !EncodePKI(list, xdr, err) ) return false;

		list.Clear();
		GetUntrusted(list);
		if ( !EncodePKI(list, xdr, err) ) return false;

		list.Clear();
		GetCRL(list);
		if ( !EncodePKI(list, xdr, err) ) return false;
	
		return true;
	}

	bool		global_pki_mgr::EncodePKI(Dlist<pki_base*>& list, CXDR* xdr, string& err)
	{
		unsigned int n = list.Size();
		if ( !xdr->XdrUint(&n) ) 
		{
			err = "Fail to encode number of pki";
			return false;
		}

		for ( Dlist<pki_base*>::Node* node = list.GetHead();
				node != 0; node = list.GetNext(node) )
		{	
			pki_base* pki = node->GetData();

			if ( !pki || !pki->IsOK() )
			{
				err = "PKI data not OK";
				return false;
			}

			string type = pki->GetType();
			if ( !xdr->XdrStringPacked(type) )
			{
				err = string::Format("Fail to encode pki type (%s)", type.c_str());
				return false;	
			}

			if ( !pki->XdrEncode(xdr, err) ) 
			{	
				err = string::Format("Fail to encode pki data (%s): ", type.c_str()) + err;
				return false;
			}
		}

		return true;
	}

	bool		global_pki_mgr::DecodePKI(CXDR* xdr, string& err)
	{
		//
		// Trusted
		//
		unsigned int n;
		if ( !xdr->XdrUint(&n) ) 
		{
			err = "Fail to decode number of trusted pki";
			return false;
		}
		
		for ( unsigned int i = 0; i < n; i++ )
		{
			string type;				
			if ( !xdr->XdrStringPacked(type) )
			{
				err = string::Format("Fail to decode trusted pki type (%s)", type.c_str());
				return false;	
			}

			pki_base* pki = CreateTrusted(type);
			if ( !pki )
			{
				err = string::Format("Not supported trusted pki type (%s)", type.c_str());
				return false;	
			}

			if ( !pki->XdrDecode(xdr, err) )
			{
				err = string::Format("Fail to decode trusted pki data (%s): ", type.c_str()) + err;
				delete pki;	
				return false;
			}	

			string err1;			
			if ( !AddTrusted(pki, err1) )
			{
				err = "Fail to add trusted pki: " + err1;
				delete pki;
				return false;
			}

			delete pki;
		}
	
		//
		// Untrusted
		//
		if ( !xdr->XdrUint(&n) ) 
		{
			err = "Fail to decode number of untrusted pki";
			return false;
		}
		
		for ( unsigned int i = 0; i < n; i++ )
		{
			string type;				
			if ( !xdr->XdrStringPacked(type) )
			{
				err = string::Format("Fail to decode untrusted pki type (%s)", type.c_str());
				return false;	
			}

			pki_base* pki = CreateUntrusted(type);
			if ( !pki )
			{
				err = string::Format("Not supported untrusted pki type (%s)", type.c_str());
				return false;	
			}

			if ( !pki->XdrDecode(xdr, err) )
			{	
				err = string::Format("Fail to decode untrusted pki data (%s): ", type.c_str()) + err;
				return false;
			}	

			string err1;
			if ( !AddUntrusted(pki, err1) )
			{
				err = "Fail to add untrusted pki: " + err1;
				delete pki;
				return false;
			}

			delete pki;
		}
	
		//
		// CRL
		//
		if ( !xdr->XdrUint(&n) ) 
		{
			err = "Fail to decode number of CRL pki";
			return false;
		}
		
		for ( unsigned int i = 0; i < n; i++ )
		{
			string type;				
			if ( !xdr->XdrStringPacked(type) )
			{
				err = string::Format("Fail to decode CRL pki type (%s)", type.c_str());
				return false;	
			}

			pki_base* pki = CreateCRL(type);
			if ( !pki )
			{
				err = string::Format("Not supported CRL pki type (%s)", type.c_str());
				return false;	
			}

			if ( !pki->XdrDecode(xdr, err) )
			{	
				err = string::Format("Fail to decode CRL pki data (%s): ", type.c_str()) + err;
				return false;
			}	

			string err1;
			if ( !AddOrUpdateCRL(pki, err1) )
			{
				err = "Fail to add CRL pki: " + err1;
				delete pki;
				return false;
			}

			delete pki;
		}

		return true;	
	}

	string		global_pki_mgr::PKIDumpReadable() const
	{	
		string output;
		Dlist<pki_base*> list;
		
		output += "\nTrusted Certificate:\n";
		list.Clear();
		GetTrusted(list);		
		output += PKIDumpReadable(list);

		output += "\nUntrusted Certificate:\n";
		list.Clear();
		GetUntrusted(list);	
		output += PKIDumpReadable(list);

		output += "\nRevocation List:\n";
		list.Clear();
		GetCRL(list);	
		output += PKIDumpReadable(list);

		return output;
	}

	string		global_pki_mgr::PKIDumpReadable(Dlist<pki_base*>& list) const
	{	
		string output;

		for ( Dlist<pki_base*>::Node* node = list.GetHead(); 
			   node != 0; node = list.GetNext(node) )
		{
			output += node->GetData()->DumpReadable();
		}	
		
		return output;
	}

}//end namespace colib

