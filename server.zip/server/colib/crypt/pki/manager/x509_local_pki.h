// x509_local_pki.h
// vi:set ts=4 sw=4 nowrap:

#ifndef X509_LOCAL_PKI_H_ALREADY_INCLUDED
#define X509_LOCAL_PKI_H_ALREADY_INCLUDED

#include <crypt/pki/manager/local_pki.h>
#include <crypt/pki/format/x509_cert.h>
#include <crypt/pki/format/x509_rsa_key.h>

namespace colib
{
	class x509_local_cert_mgr : public local_cert_mgr
	{
		public:

								x509_local_cert_mgr(bool sync_hostCert);
			virtual				~x509_local_cert_mgr();
			//
			// Implement pure virtual functions
			//
			virtual pki_base*	GetCert() const { return (pki_base*)&m_cert; }
			virtual bool		SetCert(pki_base* cert, string& err);

			virtual void		Clear();

		protected:

			virtual pki_base*	CreateCert(string type);

		private:

			x509_Certificate	m_cert;
			bool				m_sync_hostCert;
	};
	
	class x509_local_key_mgr : public local_key_mgr
	{
		public:

								x509_local_key_mgr() {};
			virtual				~x509_local_key_mgr();
			//
			// Implement pure virtual functions
			//	
			virtual pki_base*	GetKey() const { return (pki_base*)&m_key; }
			virtual bool		SetKey(pki_base* cert, string& err);
	
			virtual void		Clear();

		protected:

			virtual pki_base*	CreateKey(string type);

		private:

			x509_RSAkey			m_key;
	};

}//end namespace colib


#endif

