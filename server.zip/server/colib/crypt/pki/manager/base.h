// base.h
// vi:set ts=4 sw=4 nowrap:

#ifndef PKI_MGR_BASE_H_ALREADY_INCLUDED
#define PKI_MGR_BASE_H_ALREADY_INCLUDED

#include <crypt/pki/format/base.h>
#include <config/value.h>
#include <console/session.h>
#include <utils/trace/writable.h>

namespace colib
{
	//
	// pki manager will be used by both CA handler and CA foundry
	//
	class pki_manager
	{
		public:			

			enum mgrStats
			{
				mgrStat_num_decode_succeed,
				mgrStat_num_decode_failed,
				mgrStat_latest_decode_fail_reason,
				mgrStat_num_encode_succeed,
				mgrStat_num_encode_failed,
				mgrStat_latest_encode_fail_reason,
				mgrStat_num_of_pki,
				mgrStatCount
			};

									pki_manager();
			virtual					~pki_manager();
			//
			// Public 
			//
			void					SetVersion(string ver) { m_ver = ver; }
			const char*				GetVersion() const { return m_ver.c_str(); }
			bool					SetHash(char* data, unsigned len, string& err);
			const char*				GetHash(unsigned& len, string& err) const;
			bool					Encode(char* data, unsigned& len);
			bool					Decode(char* data, unsigned len);
			string					DumpReadable() const;
			//
			// Header only
			//
			bool					EncodeHeader(char* data, unsigned& len);
			bool					DecodeHeader(char* data, unsigned len);
			//
			// Without header
			//
			bool					EncodeWithoutHeader(char* data, unsigned& len); 
			bool					DecodeWithoutHeader(char* data, unsigned len);
			//
			// Virtual functions
			//
			virtual string			ConsoleHelp();
			virtual void			ConsoleCommand(ConsoleSession* con, int argc, char* argv[]);
			//
			// Pure virtual functions
			//
			virtual bool			EncodePKI(CXDR* xdr, string& err) = 0;
			virtual bool			DecodePKI(CXDR* xdr, string& err) = 0;
			virtual void			Clear() = 0;
			virtual void			Zeroize() = 0;
			virtual int				NumOfPKI() = 0;
			virtual bool			IsOK() = 0;
			virtual string			PKIDumpReadable() const = 0; 

		protected:

			bool					EncodeHeader(CXDR* xdr, string& err);
			bool					DecodeHeader(CXDR* xdr, string& err);

			bool					Encode(CXDR* xdr, string& err, bool no_header);
			bool					Decode(CXDR* xdr, string& err, bool no_header);

		protected:

			string					m_ver;
			char*					m_hash_buf;
			unsigned				m_hash_len;
			ValueList				m_mgr_stats;
	};
	#define PKI_MGR_STAT(stat)		m_mgr_stats[pki_manager::mgrStat_##stat].AsInt()

}//end namespace colib


#endif

