// x509_global_pki.cpp
// vi:set ts=4 sw=4 nowrap:

#include <crypt/pki/manager/x509_global_pki.h>
#include <crypt/pki/checker/idirect_corp_checker_x509.h>
#include <crypt/pki/checker/customer_checker_x509.h>

namespace colib
{
	x509_global_pki_mgr::x509_global_pki_mgr(bool sync_host)
		:
		m_sync_host(sync_host)
	{
	}

	x509_global_pki_mgr::~x509_global_pki_mgr()
	{
		Zeroize();
	}

	void		x509_global_pki_mgr::Clear()
	{
		if ( m_sync_host )
		{	
			iDirectCorpX509CertChecker::GetInstance().Clear();
			CustomerX509CertChecker::GetInstance().Clear();
		}

		m_trusted.clear();
		m_untrusted.clear();
		m_crl.clear();
	}
	
	pki_base*	x509_global_pki_mgr::CreateTrusted(string type)
	{
		if ( type == PKI_TYPE_X509_CERT ) return new x509_Certificate;
		return 0;
	}	
		
	bool		x509_global_pki_mgr::AddTrusted(pki_base* cert, string& err)
	{
		bool ret = ( cert && ( string(cert->GetType()) == PKI_TYPE_X509_CERT ) && cert->IsOK() );
		
		if ( !ret )
		{
			err = "Invalid Trusted Certificate";
			return false;
		}

		if ( m_sync_host )
		{
			ret = CustomerX509CertChecker::GetInstance().AddTrustedCert(cert, err);
			if ( !ret ) 
			{
				err = "Fail to sync CustomerX509CertChecker: " + err;
				return false;
			}
		}

		x509_Certificate* x509_cert = (x509_Certificate*)cert;

		string issuer_name;
		if ( !x509_cert->GetIssuer(issuer_name, err) ) return false;

		string index = issuer_name;
		CERT_MAP::iterator it = m_trusted.find(index);
		if ( it != m_trusted.end() )
		{
			err = "Trusted Certificate already exists";
			return false;
		}

		m_trusted[index] = *x509_cert;
	
		return true;
	}
	
	bool		x509_global_pki_mgr::DelTrusted(pki_base* cert, string& err)
	{
		bool ret = ( cert && ( string(cert->GetType()) == PKI_TYPE_X509_CERT ) && cert->IsOK() );
		if ( !ret )
		{
			err = "Invalid Trusted Certificate";
			return false;
		}

		x509_Certificate* x509_cert = (x509_Certificate*)cert;

		string issuer_name;
		if ( !x509_cert->GetIssuer(issuer_name, err) ) return false;

		string index = issuer_name;
		CERT_MAP::iterator it = m_trusted.find(index);
		if ( it == m_trusted.end() ) 
		{
			err = "Trusted Certificate not found";
			return false;
		}

		it->second.Zeroize();
		m_trusted.erase(it);
	
		return true;
	}

	void		x509_global_pki_mgr::GetTrusted(Dlist<pki_base*>& list) const
	{
		for ( CERT_MAP::const_iterator it = m_trusted.begin();
				it != m_trusted.end(); it++ )
		{
			list.Append((pki_base*)&it->second);
		}
	}
		
	pki_base*	x509_global_pki_mgr::CreateUntrusted(string type)
	{
		if ( type == PKI_TYPE_X509_CERT ) return new x509_Certificate;
		return 0;
	}	
		
	bool		x509_global_pki_mgr::AddUntrusted(pki_base* cert, string& err)
	{
		bool ret = ( cert && ( string(cert->GetType()) == PKI_TYPE_X509_CERT ) && cert->IsOK() );
		if ( !ret )
		{
			err = "Invalid Untrusted Certificate";
			return false;
		}
	
		if ( m_sync_host )
		{
			ret = iDirectCorpX509CertChecker::GetInstance().AddUntrustedCert(cert, err);	
			if ( !ret ) 
			{
				err = "Fail to sync iDirectCorpX509CertChecker: " + err;
				return false;
			}
			ret = CustomerX509CertChecker::GetInstance().AddUntrustedCert(cert, err);	
			if ( !ret ) 
			{
				err = "Fail to sync CustomerX509CertChecker: " + err;
				return false;
			}
		}
	
		x509_Certificate* x509_cert = (x509_Certificate*)cert;

		string issuer_name;
		if ( !x509_cert->GetIssuer(issuer_name, err) ) return false;

		string serialNum;
		if ( !x509_cert->GetSerialNumber(serialNum, err) ) return false;

		string index = string::Format("%s_%s", issuer_name.c_str(), serialNum.c_str());
		CERT_MAP::iterator it = m_untrusted.find(index);
		if ( it != m_untrusted.end() )
		{
			err = "Untrusted Certificate already exists";
			return false;
		}

		m_untrusted[index] = *x509_cert;
	
		return true;
	}
	
	bool		x509_global_pki_mgr::DelUntrusted(pki_base* cert, string& err)
	{
		bool ret = ( cert && ( string(cert->GetType()) == PKI_TYPE_X509_CERT ) && cert->IsOK() );
		if ( !ret )
		{
			err = "Invalid Untrusted Certificate";
			return false;
		}

		x509_Certificate* x509_cert = (x509_Certificate*)cert;

		string issuer_name;
		if ( !x509_cert->GetIssuer(issuer_name, err) ) return false;

		string serialNum;
		if ( !x509_cert->GetSerialNumber(serialNum, err) ) return false;

		string index = string::Format("%s_%s", issuer_name.c_str(), serialNum.c_str());
		CERT_MAP::iterator it = m_untrusted.find(index);
		if ( it == m_untrusted.end() ) 
		{
			err = "Untrusted Certificate not found";
			return false;
		}

		it->second.Zeroize();
		m_untrusted.erase(it);
	
		return true;
	}

	void		x509_global_pki_mgr::GetUntrusted(Dlist<pki_base*>& list) const
	{
		for ( CERT_MAP::const_iterator it = m_untrusted.begin();
				it != m_untrusted.end(); it++ )
		{
			list.Append((pki_base*)&it->second);
		}
	}

	pki_base*	x509_global_pki_mgr::CreateCRL(string type)
	{
		if ( type == PKI_TYPE_X509_CRL ) return new x509_RevocationList;
		return 0;
	}	
		
	bool		x509_global_pki_mgr::AddOrUpdateCRL(pki_base* crl, string& err)
	{
		bool ret = ( crl && ( string(crl->GetType()) == PKI_TYPE_X509_CRL ) && crl->IsOK() );
		if ( !ret )
		{
			err = "Invalid CRL";
			return false;
		}
		
		if ( m_sync_host )
		{
			ret = iDirectCorpX509CertChecker::GetInstance().AddRevocationList(crl, err);
			if ( !ret ) 
			{
				err = "Fail to sync iDirectCorpX509CertChecker: " + err;
				return false;
			}
			ret = CustomerX509CertChecker::GetInstance().AddRevocationList(crl, err);
			if ( !ret ) 
			{
				err = "Fail to sync CustomerX509CertChecker: " + err;
				return false;
			}
		}
	
		x509_RevocationList* x509_crl = (x509_RevocationList*)crl;
		string issuer_name;
		if ( !x509_crl->GetIssuerCommonName(issuer_name, err) ) return false;

		string index = issuer_name;
		m_crl[index] = *x509_crl;
	
		return true;
	}

	void		x509_global_pki_mgr::GetCRL(Dlist<pki_base*>& list) const
	{
		for ( CRL_MAP::const_iterator it = m_crl.begin();
				it != m_crl.end(); it++ )
		{
			list.Append((pki_base*)&it->second);
		}
	}

}//end namespace colib

