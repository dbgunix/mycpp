//hmac.h
// vi:set ts=4 sw=4 nowrap:

#ifndef HMAC_H_ALREADY_INCLUDED
#define HMAC_H_ALREADY_INCLUDED

#include <openssl/sha.h>
#include <openssl/hmac.h>

namespace colib {


//md must point at a buffer 32 bytes long.
bool iDirect_hmac_sha256(const void *key, int key_len,
						 const unsigned char *data, int byte_len, 
						 unsigned char *md, unsigned int *md_len);

//md must point at a buffer 64 bytes long.
bool iDirect_hmac_sha512(const void *key, int key_len,
						 const unsigned char *data, int byte_len, 
						 unsigned char *md, unsigned int *md_len);

}

#endif

