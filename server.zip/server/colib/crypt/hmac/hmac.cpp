//sha1.cpp
// vi:set ts=4 sw=4 nowrap:

#include <openssl/hmac.h>

namespace colib {

bool iDirect_hmac_sha256(const void *key, int key_len,
						 const unsigned char *data, int byte_len, 
						 unsigned char *md, unsigned int *md_len)
{
	if (HMAC(EVP_sha256(), key, key_len, data, byte_len, md, md_len)) {
		return true;
	}
	return false;
}

//md must point at a buffer 64 bytes long.
bool iDirect_hmac_sha512(const void *key, int key_len,
						 const unsigned char *data, int byte_len, 
						 unsigned char *md, unsigned int *md_len)
{

	if (HMAC(EVP_sha512(), key, key_len, data, byte_len, md, md_len)) {
		return true;
	}
	return false;
}

} // namespace
