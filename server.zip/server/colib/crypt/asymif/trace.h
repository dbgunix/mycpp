//ASYM_trace.h
#ifndef ASYM_trace_h_already_included
#define ASYM_trace_h_already_included

#include <stdarg.h>

#ifdef __GNUC__
//PP PLATFORM

#include <utils/trace/trace.h>

//#define DEBUG_ASYM

#ifdef DEBUG_ASYM

		//TODO: undo this
#if 0
#define ASYM0_TRACE(lev,fmt) 				member_TRACE(&m_trace_set,lev,fmt)
#define ASYM1_TRACE(lev,fmt,p1) 				member_TRACE(&m_trace_set,lev,fmt,p1)
#define ASYM2_TRACE(lev,fmt,p1,p2) 			member_TRACE(&m_trace_set,lev,fmt,p1,p2)
#define ASYM3_TRACE(lev,fmt,p1,p2,p3)		member_TRACE(&m_trace_set,lev,fmt,p1,p2,p3)
#define ASYM4_TRACE(lev,fmt,p1,p2,p3,p4)		member_TRACE(&m_trace_set,lev,fmt,p1,p2,p3,p4)
#define ASYM5_TRACE(lev,fmt,p1,p2,p3,p4,p5)	member_TRACE(&m_trace_set,lev,fmt,p1,p2,p3,p4,p5)
#else
#define ASYM_TRACE TRACE
#define ASYM0_TRACE(lev,fmt) 				ASYM_TRACE(lev,fmt)
#define ASYM1_TRACE(lev,fmt,p1) 				ASYM_TRACE(lev,fmt,p1)
#define ASYM2_TRACE(lev,fmt,p1,p2) 			ASYM_TRACE(lev,fmt,p1,p2)
#define ASYM3_TRACE(lev,fmt,p1,p2,p3)		ASYM_TRACE(lev,fmt,p1,p2,p3)
#define ASYM4_TRACE(lev,fmt,p1,p2,p3,p4)		ASYM_TRACE(lev,fmt,p1,p2,p3,p4)
#define ASYM5_TRACE(lev,fmt,p1,p2,p3,p4,p5)	ASYM_TRACE(lev,fmt,p1,p2,p3,p4,p5)
#endif

#else

#define ASYM0_TRACE(lev,fmt)
#define ASYM1_TRACE(lev,fmt,p1)
#define ASYM2_TRACE(lev,fmt,p1,p2)
#define ASYM3_TRACE(lev,fmt,p1,p2,p3)
#define ASYM4_TRACE(lev,fmt,p1,p2,p3,p4)
#define ASYM5_TRACE(lev,fmt,p1,p2,p3,p4,p5)
#endif


#endif

#endif //ASYM_trace_h_already_included

