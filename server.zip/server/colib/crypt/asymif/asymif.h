//asymif.h

#ifndef ASYMIF_H_ALREADY_INCLUDED
#define ASYMIF_H_ALREADY_INCLUDED

#include <utils/system/environ.h>
#include <utils/system/machine.h>
#include <utils/data_struct/dlist.h>
#include <utils/string.h>

#include <crypt/key/key.h>
#include <crypt/triel/triel.h>


namespace colib
{

class AsymIf
{
public:
	//Interface
	AsymIf(){m_mode=PADMODE_PKCS1;}
	virtual ~AsymIf(){}

	virtual bool BlockingGenerateKeyPair( int bits )=0;
	enum Status
	{
		STATUS_NOKEYS,
		STATUS_PUBKEY,
		STATUS_KEYPAIR,
		STATUS_GENERATING
	};
	virtual int GetStatus() const =0;

	virtual bool GetPublicKey( EncryptionKey *to )=0;
	virtual bool SetPublicKey( EncryptionKey *to )=0;
	virtual bool GetPrivateKey( EncryptionKey *to )=0;
	virtual bool SetPrivateKey( EncryptionKey *to )=0;
	
	enum Algorithm
	{
		ALG_NONE=-1,
		//this are asymif algs:
		ALG_RSA=500,
	};
	virtual int GetAlgorithm()=0;

	static colib::string GetAsymmetricAlgName( int a );

	virtual int GetRequiredSpace()=0;
	virtual int GetPayloadMaxsize()=0;
	virtual bool Init()=0;
	virtual void zero()=0;
	virtual bool PairwiseConsistencyCheck();

	enum PADMODE{ PADMODE_PKCS1, PADMODE_NONE }m_mode;
	void SetPaddingMode(PADMODE to ){m_mode=to;}

	virtual int public_encrypt(int len, const unsigned char *from, unsigned char *to)=0;
	virtual int private_decrypt(int len, const unsigned char *from, unsigned char *to)=0;

	virtual int private_encrypt(int len, const unsigned char *from, unsigned char *to)=0;
	virtual int public_decrypt(int len, const unsigned char *from, unsigned char *to)=0;

	virtual const char* GetLastError();

	static const char* StatusStr( int s );

	//Convenience
	bool CryptSymKey(EncryptionKey *key,bool encrypt);
};



} //end namespace colib

#endif

