//asymlink.h
// vi:set ts=4 sw=4 nowrap:

#ifndef ASYMLINK_H_ALREADY_INCLUDED
#define ASYMLINK_H_ALREADY_INCLUDED

#include <crypt/asymif/asymif.h>
#include <crypt/pki/format/x509_cert.h>
#include <crypt/pki/format/idirect_sig.h>
#include <crypt/pki/format/idirect_krec.h>
#include <utils/data_struct/rangeset.h>
#include <crypt/keyroll/keyroll_cmd.h>
#include <crypt/sha/sha1.h>

#include <vector>

namespace colib
{

//AsymIf Protocol objects are typically sent via bypass messages
	
class TransportCmmd
{
public:
	int m_transport_id;
	KeyRollCmd m_cmmd;

	bool XdrProc( CXDR *xdr );
};
class V3TransportCmmd
{
public:
	int m_transport_id;
	int m_sym_alg;
	KeyRollCmd m_cmmd;

	bool XdrProc( CXDR *xdr );
};

enum ReqType
{
	CHANNEL_OPEN_SOLC=1001,
	CHANNEL_OPEN_REQ,
	CHANNEL_OPEN_RESP,
	CHANNEL_CLOSE_CMMD,
	CHANNEL_UPDATE_REQ,
	CHANNEL_UPDATE_CMMD,
	CHANNEL_ROTATE_NOTIFICATION,
	CHANNEL_ROTATE_UPDATE_REQUEST,
	CHANNEL_ROTATE_UPDATE_COMMAND,
	//new protocol:
	V3_SOLICITATION,
	V3_CERTIFICATE_PRESENTATION,
	V3_KEYROLL_COMMAND
};
const int REQ_TAG_LEN = 18;
const char* ReqTypeStr( int req_type );

//This is the base class for all encrypted session request messages
class Request
{
public:
	virtual ~Request();
	virtual ReqType GetType()=0;
	virtual bool XdrProc(CXDR *xdr)=0;

	enum Flags
	{
		FIPS_ENABLED = 0x01
	};

	unsigned int Decode( void *buffer, unsigned int maxlen );
	unsigned int Encode( void *buffer, unsigned int maxlen );
	
	virtual string GetLastError();

	char m_mssg_begin[REQ_TAG_LEN];
};

//Request* AllocateReq( int req_type );

//This message is sent from the remote to the PP
//It indicates that the remote would like to receive and OpenReq message
class OpenSolicitation : public Request
{
	public:
		OpenSolicitation();
		~OpenSolicitation(){}
		ReqType GetType(){return CHANNEL_OPEN_SOLC;}

		//CLEAR
		int m_remote_id;

		bool XdrProc(CXDR *xdr);
};

//This message is sent from the PP to the remote.
//It indicates that the PP would like to open an encrypted channel
//It contains a public key
class OpenReq : public Request
{
	public:
		OpenReq();
		~OpenReq(){}
		ReqType GetType(){return CHANNEL_OPEN_REQ;}

		//CLEAR
		int m_remote_id;
		int m_asym_alg;
		int m_session_id;
		uint32_t m_enc_flags;
		EncryptionKey m_pub_key;

		bool XdrProc(CXDR *xdr);
};

//This message is sent from the remote to the PP.
//It completes a channel opening operation.
//It contains a symmetric key encrypted to a public key.
class OpenResp : public Request
{
	public:
		OpenResp();
		~OpenResp();
		ReqType GetType(){return CHANNEL_OPEN_RESP;}

		//RSA ENCRYPTED
		int m_remote_id;
		int m_sym_alg;
		int m_net_sym_alg;
		int m_session_id;
		uint32_t m_enc_flags;
		Dlist<TransportCmmd> m_commands;

		bool XdrProc(CXDR *xdr);
};


//An update request is deprecated:
//It is a message sent from the remote to the PP, requsting a keyroll update
// for a set of channels
class UpdateRequest : public Request
{
	public:
		UpdateRequest();
		~UpdateRequest(){}
		ReqType GetType(){return CHANNEL_UPDATE_REQ;}

		//SYMMETRIC ENCRYPTED
		int m_remote_id;
		int m_session_id;
		//Set of Transport Id's for which an update is requested
		Dlist<int> m_transport_ids;

		bool XdrProc( CXDR *xdr );
};

//can be solicited or unsolicited
//An update command is deprecated
//It is a message sent from the PP to the remote, containing a 
// set of keyroll update commands, (up to one per channel)
class UpdateCommand : public Request
{
	public:
		UpdateCommand();
		~UpdateCommand(){}
		ReqType GetType(){return CHANNEL_UPDATE_CMMD;}
		bool XdrProc( CXDR *xdr );

		//Set of Transport Commands
		//SYMMETRIC ENCRYPTED
		int m_remote_id;
		int m_session_id;
		Dlist<TransportCmmd> m_commands;
};

//RotateNotification, remote to PP, requests rotate command
class RotateNotification : public Request
{
	public:
		RotateNotification();
		~RotateNotification(){}
		ReqType GetType(){return CHANNEL_ROTATE_NOTIFICATION;}

		//SYMMETRIC ENCRYPTED
		int m_remote_id;
		int m_session_id;

		bool XdrProc( CXDR *xdr );
};

//RotateUpdateRequest, PP to remote, public key
class RotateUpdateRequest : public Request
{
	public:
		RotateUpdateRequest();
		~RotateUpdateRequest(){}
		ReqType GetType(){return CHANNEL_ROTATE_UPDATE_REQUEST;}

		//SYMMETRIC ENCRYPTED
		int m_remote_id;
		int m_session_id;
		EncryptionKey m_pub_key;

		bool XdrProc(CXDR *xdr);
};
//RotateUpdateCommand, remote to PP, contains a keyroll update
class RotateUpdateCommand : public Request
{
	public:
		RotateUpdateCommand();
		~RotateUpdateCommand(){}
		ReqType GetType(){return CHANNEL_ROTATE_UPDATE_COMMAND;}

		//RSA ENCRYPTED
		int m_remote_id;
		int m_session_id;
		Dlist<TransportCmmd> m_commands;

		bool XdrProc(CXDR *xdr);
};

//A close command can be sent from either side.
//It is a request to reset the state of the session to its
//initial mode. If the sesssion is attempting to open an
//initial channel, then it should be ignored.
class CloseCommand : public Request
{
	public:
		CloseCommand();
		~CloseCommand(){}
		ReqType GetType(){return CHANNEL_CLOSE_CMMD;}
		bool XdrProc( CXDR *xdr );

		//CLEAR, non-encrypted
		int m_remote_id;
};


///////////////////////////////////////////////////////////////////////////////////////
// V3 protocol, supports authenitication

class V3_Solicitation: public Request
{
public:
	V3_Solicitation();
	~V3_Solicitation(){}
	ReqType GetType(){return V3_SOLICITATION;}
	bool XdrProc( CXDR *xdr );

	enum session_state { SESSION_UP, SESSION_DOWN, SESSION_OPENING };
	enum cert_state { HAVE_NOT_RXD_CERT, HAVE_RXD_CERT };

	session_state GetRxSessionState()const;
	uint32_t GetRxSessionID()const; //always valid
	uint32_t GetPeerTxSessionID()const; //valid if not SESSION_DOWN

	session_state GetTxSessionState()const;
	uint32_t GetTxSessionID()const; //valid if not SESSION_DOWN
	uint32_t GetPeerRxSessionID()const; //valid if SESSION_UP

	cert_state GetRxCertState()const;
	uint32_t GetRxCertSubjectID()const;
	uint32_t GetTxCertSubjectID()const;

	uint32_t GetNetworkID()const;
	void SetNetworkID( uint32_t to );

	uint32_t GetKeySelector()const { return m_key_selector; }
	void SetKeySelector( uint32_t to ) { m_key_selector = to; }

	uint32_t GetDID()const;
	string GetMessage()const;
	std::vector<uint32_t>* GetSupportedList();

	rangeset_t<int>& GetTransportAcks();

	void SetDID( uint32_t to );
	void SetMessage( string to );

	void SetRxSessionID( uint32_t rx_session_id  );
	void SetRxSessionUP( uint32_t peer_tx_session_id );
	void SetRxSessionOPENING( uint32_t peer_tx_session_id );
	void SetRxSessionDOWN();

	void SetTxSessionUP( uint32_t tx_session_id, uint32_t peer_rx_session_id );
	void SetTxSessionOPENING( uint32_t tx_session_id );
	void SetTxSessionDOWN();

	void SetRxSessionGotCert( uint32_t ident );
	void SetRxSessionHaventGotCert();
	void SetTxCertID( uint32_t ident );

	static const char* session_state_str(session_state st);
	colib::string FormatSummary()const;
private:
	//CLEAR

	uint32_t m_network_id;
	uint32_t m_key_selector;
	uint32_t m_DID;
	//rx session status
	session_state m_rx_session_state;
	uint32_t m_rx_session_id;
	uint32_t m_peer_tx_session_id;

	//tx session status
	session_state m_tx_session_state;
	uint32_t m_tx_session_id;
	uint32_t m_peer_rx_session_id;

	//rx cert status
	cert_state m_rx_cert_state;
	uint32_t m_rx_cert_id;

	//tx cert status
	uint32_t m_tx_cert_id;

	//algorithms 
	std::vector<uint32_t> m_sym_algorithms_supported; //only has meaning if at least one is present

	rangeset_t<int> m_ack_transport_ids;

	//info message
	colib::string m_message;
};
class V3_Certificate_Presentation: public Request
{
public:
	V3_Certificate_Presentation();
	~V3_Certificate_Presentation(){}
	ReqType GetType(){return V3_CERTIFICATE_PRESENTATION;}
	bool XdrProc( CXDR *xdr );

	//CLEAR
	x509_Certificate m_cert;
};

class V3_Keyroll_Command: public Request
{
public:

	class Payload
	{
	public:
		bool XdrProc( CXDR *xdr );

		uint32_t m_tx_keyroll_id;
		uint32_t m_rx_session_id;

		Dlist<V3TransportCmmd> m_commands;
		bool   m_force;
	};

	V3_Keyroll_Command();
	~V3_Keyroll_Command(){}
	ReqType GetType(){return V3_KEYROLL_COMMAND;}

	bool XdrProc( CXDR *xdr );

	bool Encrypt( AsymIf *asym, V3_Keyroll_Command::Payload *payload, 
			x509_Certificate *encrypt_to, KeyRecord *signing_private_key, string &err );

	bool Decrypt( AsymIf *asym, V3_Keyroll_Command::Payload *payload, 
			x509_Certificate *sig_verifier, KeyRecord *decrypting_private_key, string &err );

	bool Encrypt( AsymIf *asym, AsymIf * asym_peer, V3_Keyroll_Command::Payload *payload, 
			x509_Certificate *encrypt_to, KeyRecord *signing_private_key, string &err );

	bool Decrypt( AsymIf *asym, AsymIf * asym_peer, V3_Keyroll_Command::Payload *payload, 
			x509_Certificate *sig_verifier, KeyRecord *decrypting_private_key, string &err );

	uint32_t m_network_id;
	uint32_t m_key_selector;

	//RSA encrypted
	std::vector<uint8_t> m_keyroll_command_payload; 

	//clear
	Signature<SHA1> m_sig; //signature of hash of rsa encrypted bytes
};


} //end namespace colib
#endif

