//asymlink.cpp
// vi:set ts=4 sw=4 nowrap:

#include <crypt/asymif/asymlink.h>
#include <utils/data_struct/dlist_xdr.h>
#include <utils/data_struct/vector_xdr.h>
#include <utils/data_struct/rangeset_xdr.h>
#include <utils/data_struct/rangeset_parser.h>
#include <utils/trace/trace.h>

namespace colib
{

const char* ReqTypeStr( int req_type )
{
	switch( req_type )
	{
	case CHANNEL_OPEN_SOLC:
		return "CHANNEL_OPEN_SOLC\0";
	case CHANNEL_OPEN_REQ:
		return "CHANNEL_OPEN_REQ\0\0";
	case CHANNEL_OPEN_RESP:
		return "CHANNEL_OPEN_RESP\0";
	case CHANNEL_CLOSE_CMMD:
		return "CHANNEL_CLOSE_CMMD";
	case CHANNEL_UPDATE_REQ:
		return "CHANNEL_UPDT_REQ\0\0";
	case CHANNEL_UPDATE_CMMD:
		return "CHANNEL_UPDT_CMMD\0";
	case CHANNEL_ROTATE_NOTIFICATION:
		return "CHANNEL_ROTATE_NOTI";
	case CHANNEL_ROTATE_UPDATE_REQUEST:
		return "CHANNEL_ROTATE_UPRQ";
	case CHANNEL_ROTATE_UPDATE_COMMAND:
		return "CHANNEL_ROTATE_UPCM";
	case V3_SOLICITATION:
		return "V3_SOLICITATION";
	case V3_CERTIFICATE_PRESENTATION:
		return "V3_CERTIFICATE_PRESENTATION";
	case V3_KEYROLL_COMMAND:
		return "V3_KEYROLL_COMMAND";
	default:
		return "UnknownReqType   \0";
	}
}

Request* AllocateReq( int req_type )
{
	switch( req_type )
	{
	case CHANNEL_OPEN_SOLC:
		return new OpenSolicitation;
	case CHANNEL_OPEN_REQ:
		return new OpenReq;
	case CHANNEL_OPEN_RESP:
		return new OpenResp;
	case CHANNEL_CLOSE_CMMD:
		return new CloseCommand;
	case CHANNEL_UPDATE_REQ:
		return new UpdateRequest;
	case CHANNEL_UPDATE_CMMD:
		return new UpdateCommand;
	case CHANNEL_ROTATE_NOTIFICATION:
		return new RotateNotification;
	case CHANNEL_ROTATE_UPDATE_REQUEST:
		return new RotateUpdateRequest;
	case CHANNEL_ROTATE_UPDATE_COMMAND:
		return new RotateUpdateCommand;
	default:
		return 0;
	}
}

Request::~Request()
{
}

string Request::GetLastError()
{
	return string();
}

unsigned int Request::Decode( void *buffer, unsigned int maxlen )
{
	XdrDecode xdr((char*)buffer, maxlen );

	if( !this->XdrProc(&xdr) )
		return 0;

	return xdr.GetLength();
}

unsigned int Request::Encode( void *buffer, unsigned int maxlen )
{
	XdrEncode xdr((char*)buffer, maxlen );

	int type = this->GetType();

	if( !xdr.XdrInt(&type) ||
		!this->XdrProc(&xdr) )
		return 0;

	return xdr.GetLength();
}

OpenSolicitation::OpenSolicitation()
{
	strncpy(m_mssg_begin,ReqTypeStr(CHANNEL_OPEN_SOLC),REQ_TAG_LEN);
}

bool OpenSolicitation::XdrProc(CXDR *xdr)
{
	if( !xdr->XdrBytes(m_mssg_begin,REQ_TAG_LEN) )
		return false;
	
	if( xdr->GetOp() == CXDR::XDR_DECODE )
	{
		if( 0!=strncmp(m_mssg_begin,ReqTypeStr(CHANNEL_OPEN_SOLC),REQ_TAG_LEN) )
			return false;
	}

	if(	!xdr->XdrInt(&m_remote_id) )
		return false;

	return true;
}

OpenReq::OpenReq()
{
	strncpy(m_mssg_begin,ReqTypeStr(CHANNEL_OPEN_REQ),REQ_TAG_LEN);
}

bool OpenReq::XdrProc(CXDR *xdr)
{
	if( !xdr->XdrBytes(m_mssg_begin,REQ_TAG_LEN) )
		return false;
	
	if( xdr->GetOp() == CXDR::XDR_DECODE )
	{
		if( 0!=strncmp(m_mssg_begin,ReqTypeStr(CHANNEL_OPEN_REQ),REQ_TAG_LEN) )
			return false;
	}

	if(	!xdr->XdrInt(&m_remote_id) ||
		!xdr->XdrInt(&m_asym_alg) ||
		!xdr->XdrInt(&m_session_id) ||
		!xdr->XdrUint(&m_enc_flags) ||
		!m_pub_key.XdrProc(xdr)
		)
		return false;

	return true;
}

OpenResp::OpenResp()
{
	strncpy(m_mssg_begin,ReqTypeStr(CHANNEL_OPEN_RESP),REQ_TAG_LEN);
}
OpenResp::~OpenResp()
{
}
bool OpenResp::XdrProc(CXDR *xdr)
{
	if( !xdr->XdrBytes(m_mssg_begin,REQ_TAG_LEN) )
		return false;
	
	if( xdr->GetOp() == CXDR::XDR_DECODE )
	{
		if( 0!=strncmp(m_mssg_begin,ReqTypeStr(CHANNEL_OPEN_RESP),REQ_TAG_LEN) )
			return false;
	}
	
	if(
		!xdr->XdrInt(&m_remote_id) ||
		!xdr->XdrInt(&m_sym_alg) ||
		!xdr->XdrInt(&m_session_id) ||
		!xdr->XdrUint(&m_enc_flags)
			)
		return false;

	if( !XdrDlistType<TransportCmmd>(xdr,m_commands) )
		return false;

	return true;
}

UpdateRequest::UpdateRequest()
{
	strncpy(m_mssg_begin,ReqTypeStr(CHANNEL_UPDATE_REQ),REQ_TAG_LEN);
}
bool UpdateRequest::XdrProc( CXDR *xdr )
{
	return 
		xdr->XdrBytes(m_mssg_begin,REQ_TAG_LEN) &&
		xdr->XdrInt(&m_remote_id) &&
		xdr->XdrInt(&m_session_id) &&
		XdrDlistPrim<int>(xdr,m_transport_ids,&CXDR::XdrInt);
}


bool TransportCmmd::XdrProc( CXDR *xdr )
{
	return 
		xdr->XdrInt(&m_transport_id); //&&
	//	m_cmmd.XdrProc(xdr);
}
bool V3TransportCmmd::XdrProc( CXDR *xdr )
{
	return 
		xdr->XdrInt(&m_transport_id) &&
		xdr->XdrInt(&m_sym_alg); //&&
	//	m_cmmd.XdrProc(xdr);
}

UpdateCommand::UpdateCommand()
{
	strncpy(m_mssg_begin,ReqTypeStr(CHANNEL_UPDATE_CMMD),REQ_TAG_LEN);
}
bool UpdateCommand::XdrProc( CXDR *xdr )
{
	return 
		xdr->XdrBytes(m_mssg_begin,REQ_TAG_LEN) &&
		xdr->XdrInt(&m_remote_id) &&
		xdr->XdrInt(&m_session_id) &&
		XdrDlistType<TransportCmmd>(xdr,m_commands);
}

RotateNotification::RotateNotification()
{
	strncpy(m_mssg_begin,ReqTypeStr(CHANNEL_ROTATE_NOTIFICATION),REQ_TAG_LEN);
}

bool RotateNotification::XdrProc( CXDR *xdr )
{
	if( !xdr->XdrBytes(m_mssg_begin,REQ_TAG_LEN) )
		return false;
	
	if( xdr->GetOp() == CXDR::XDR_DECODE )
	{
		if( 0!=strncmp(m_mssg_begin,ReqTypeStr(CHANNEL_ROTATE_NOTIFICATION),REQ_TAG_LEN) )
			return false;
	}

	if(	!xdr->XdrInt(&m_remote_id) ||
		!xdr->XdrInt(&m_session_id) )
		return false;

	return true;
}

RotateUpdateRequest::RotateUpdateRequest()
{
	strncpy(m_mssg_begin,ReqTypeStr(CHANNEL_ROTATE_UPDATE_REQUEST),REQ_TAG_LEN);
}

bool RotateUpdateRequest::XdrProc( CXDR *xdr )
{
	if( !xdr->XdrBytes(m_mssg_begin,REQ_TAG_LEN) )
		return false;
	
	if( xdr->GetOp() == CXDR::XDR_DECODE )
	{
		if( 0!=strncmp(m_mssg_begin,ReqTypeStr(CHANNEL_ROTATE_UPDATE_REQUEST),REQ_TAG_LEN) )
			return false;
	}

	if(	!xdr->XdrInt(&m_remote_id) ||
		!xdr->XdrInt(&m_session_id) ||
		!m_pub_key.XdrProc(xdr)
		)
		return false;

	return true;
}

RotateUpdateCommand::RotateUpdateCommand()
{
	strncpy(m_mssg_begin,ReqTypeStr(CHANNEL_ROTATE_UPDATE_COMMAND),REQ_TAG_LEN);
}

bool RotateUpdateCommand::XdrProc( CXDR *xdr )
{
	if( !xdr->XdrBytes(m_mssg_begin,REQ_TAG_LEN) )
		return false;
	
	if( xdr->GetOp() == CXDR::XDR_DECODE )
	{
		if( 0!=strncmp(m_mssg_begin,ReqTypeStr(CHANNEL_ROTATE_UPDATE_COMMAND),REQ_TAG_LEN) )
			return false;
	}

	return xdr->XdrInt(&m_remote_id) &&
		xdr->XdrInt(&m_session_id) &&
		XdrDlistType<TransportCmmd>(xdr,m_commands);
}

CloseCommand::CloseCommand()
{
	strncpy(m_mssg_begin,ReqTypeStr(CHANNEL_CLOSE_CMMD),REQ_TAG_LEN);
}

bool CloseCommand::XdrProc( CXDR *xdr )
{
	if( !xdr->XdrBytes(m_mssg_begin,REQ_TAG_LEN) )
		return false;

	if( xdr->GetOp() == CXDR::XDR_DECODE )
	{
		if( 0!=strncmp(m_mssg_begin,ReqTypeStr(CHANNEL_CLOSE_CMMD),REQ_TAG_LEN) )
			return false;
	}

	return xdr->XdrInt(&m_remote_id);
}


//V3 Protocol

uint32_t V3_Solicitation::GetDID()const
{
	return m_DID;
}
V3_Solicitation::session_state V3_Solicitation::GetRxSessionState()const
{
	return m_rx_session_state;
}

uint32_t V3_Solicitation::GetRxSessionID()const
{
	return m_rx_session_id;
}
uint32_t V3_Solicitation::GetPeerTxSessionID()const
{
	return m_peer_tx_session_id;
}

V3_Solicitation::session_state V3_Solicitation::GetTxSessionState()const
{
	return m_tx_session_state;
}
uint32_t V3_Solicitation::GetTxSessionID()const
{
	return m_tx_session_id;
}
uint32_t V3_Solicitation::GetPeerRxSessionID()const
{
	return m_peer_rx_session_id;
}

V3_Solicitation::cert_state V3_Solicitation::GetRxCertState()const
{
	return m_rx_cert_state;
}
uint32_t V3_Solicitation::GetRxCertSubjectID()const
{
	if(m_rx_cert_state!=HAVE_RXD_CERT)
	{
		TRACE("V3_Solicitation::GetRxCertSubjectIdent called when m_rx_cert_state!=HAVE_RDX_CERT\n");
	}
	return m_rx_cert_id;
}

uint32_t V3_Solicitation::GetTxCertSubjectID()const
{
	return m_tx_cert_id;
}

void V3_Solicitation::SetDID( uint32_t to )
{
	m_DID = to;
}
void V3_Solicitation::SetNetworkID( uint32_t to )
{
	m_network_id = to;
}
uint32_t V3_Solicitation::GetNetworkID()const
{
	return m_network_id;
}

void V3_Solicitation::SetRxSessionID( uint32_t rx_session_id )
{
	m_rx_session_id = rx_session_id;
}

void V3_Solicitation::SetRxSessionUP( uint32_t peer_tx_session_id )
{
	m_rx_session_state = SESSION_UP;
	m_peer_tx_session_id = peer_tx_session_id;
}
void V3_Solicitation::SetRxSessionOPENING( uint32_t peer_tx_session_id )
{
	m_rx_session_state = SESSION_OPENING;
	m_peer_tx_session_id = peer_tx_session_id;
}

void V3_Solicitation::SetRxSessionDOWN( )
{
	m_rx_session_state = SESSION_DOWN;
}

void V3_Solicitation::SetTxSessionUP( uint32_t tx_session_id, uint32_t peer_rx_session_id )
{
	m_tx_session_state = SESSION_UP;
	m_tx_session_id = tx_session_id;
	m_peer_rx_session_id = peer_rx_session_id;
}

void V3_Solicitation::SetTxSessionOPENING( uint32_t tx_session_id )
{
	m_tx_session_state = SESSION_OPENING;
	m_tx_session_id = tx_session_id;
}

void V3_Solicitation::SetTxSessionDOWN()
{
	m_tx_session_state = SESSION_DOWN;
}

void V3_Solicitation::SetRxSessionGotCert( uint32_t ident )
{
	m_rx_cert_state = HAVE_RXD_CERT;
	m_rx_cert_id = ident;
}
void V3_Solicitation::SetRxSessionHaventGotCert()
{
	m_rx_cert_state = HAVE_NOT_RXD_CERT;
}

void V3_Solicitation::SetTxCertID( uint32_t ident )
{
	m_tx_cert_id = ident;
}
string V3_Solicitation::GetMessage()const
{
	return m_message;
}

std::vector<uint32_t>* V3_Solicitation::GetSupportedList()
{
	return &m_sym_algorithms_supported;
}

rangeset_t<int>& V3_Solicitation::GetTransportAcks()
{
	return m_ack_transport_ids;
}

void V3_Solicitation::SetMessage( string to )
{
	m_message = to;
}

V3_Solicitation::V3_Solicitation()
{
}

bool V3_Solicitation::XdrProc( CXDR *xdr )
{
	int temp = m_DID;
	if( !xdr->XdrInt(&temp) )
		return false;
	m_DID = temp;

	temp = m_network_id;
	if(!xdr->XdrInt(&temp))
		return false;
	m_network_id = temp;

	temp = m_key_selector;
	if(!xdr->XdrInt(&temp))
		return false;
	m_key_selector = temp;

	temp = (int)m_rx_session_state;
	if( !xdr->XdrInt(&temp) )
		return false;
	m_rx_session_state = (session_state)temp;

	if( !xdr->XdrUint(&m_rx_session_id) ||
		!xdr->XdrUint(&m_peer_tx_session_id) )
		return false;

	temp = (int)m_tx_session_state;
	if( !xdr->XdrInt(&temp) )
		return false;
	m_tx_session_state = (session_state)temp;

	if( !xdr->XdrUint(&m_tx_session_id) ||
		!xdr->XdrUint(&m_peer_rx_session_id) )
		return false;

	temp = (int)m_rx_cert_state;
	if( !xdr->XdrInt(&temp) )
		return false;
	m_rx_cert_state = (cert_state)temp;

	if(!xdr->XdrUint(&m_rx_cert_id))
		return false;

	if( !xdr->XdrUint(&m_tx_cert_id) )
		return false;

	if( !XdrVectorPrim<uint32_t>(xdr,m_sym_algorithms_supported, &CXDR::XdrUint) )
		return false;

	if( !XdrPrimitiveRangeset(xdr,m_ack_transport_ids,&CXDR::XdrIntInOneByte) )
		return false;

    if( !xdr->XdrStringPacked(m_message) )
		return false;

	return true;
}

V3_Certificate_Presentation::V3_Certificate_Presentation()
{
}
bool V3_Certificate_Presentation::XdrProc( CXDR *xdr )
{
	string xdr_err;
	//certificate loading via XDR
	if ( xdr->GetOp() == CXDR::XDR_ENCODE ) return m_cert.XdrEncode(xdr, xdr_err);
	else return m_cert.XdrDecode(xdr, xdr_err);
}

bool V3_Keyroll_Command::Encrypt( AsymIf *asym, V3_Keyroll_Command::Payload *payload, 
			x509_Certificate *encrypt_to, KeyRecord *signing_private_key, string &err )
{
	//check arguments
	if(!asym || !payload || !encrypt_to || !signing_private_key )
	{
		err = "invalid arguments";
		return false;
	}

	// setup asym from cert
	if( !ApplyX509CertificatetoAsymIf(asym,encrypt_to,err) )
	{
		err = "Failed to apply certificate public key to asymif" + err;
		return false;
	}

	// setup array
	unsigned int rsa_sz = asym->GetRequiredSpace();
	unsigned int paysiz = asym->GetRequiredSpace();

	m_keyroll_command_payload.resize(rsa_sz);

	unsigned char *bufptr = m_keyroll_command_payload.data();

	// xdr payload into array
	{
		XdrEncode xdr( (char*)bufptr, paysiz );
		if( !payload->XdrProc(&xdr) )
		{
			err=colib::string::Format("Failed to XDR payload into %u byte space",paysiz);
			return false;
		}

		// rsa encypt payroad of array
		if( -1 == asym->public_encrypt((int)xdr.GetLength(), bufptr, bufptr) )
		{
			err=colib::string::Format("Failed to rsa encrypt payload: %s", asym->GetLastError() );
			return false;
		}
	}

	//at this point our array contains the final encrypted keyroll command.
	// we sign this with the provided rsa private key

	// setup asym from hostkey
	if( !signing_private_key->ApplyKeytoAsym(asym,err) )
	{
		return false;
	}
	if( asym->GetStatus() != AsymIf::STATUS_KEYPAIR )
	{
		err=colib::string::Format("Private key required for signing, asymif status: %d",
				 asym->GetStatus());
		return false;
	}

	// sign payload
	if(!m_sig.SignObject(err,bufptr,rsa_sz,asym) )
	{
		return false;
	}

	return true;
}

bool V3_Keyroll_Command::Decrypt( AsymIf *asym, V3_Keyroll_Command::Payload *payload, 
		x509_Certificate *sig_verifier, KeyRecord *decrypting_private_key, string &err )
{
	//check arguments
	if(!asym || !payload || !sig_verifier || !decrypting_private_key )
	{
		err = "invalid arguments";
		return false;
	}

	// setup asym from cert
	if( !ApplyX509CertificatetoAsymIf(asym,sig_verifier,err) )
	{
		err = "Failed to apply certificate public key to asymif: " + err;
		return false;
	}

	unsigned int rsa_sz = asym->GetRequiredSpace();

	if( m_keyroll_command_payload.size() != rsa_sz )
	{
		err=colib::string::Format("Failed to verify signature: expected length %u obj, not %zu",
				rsa_sz, m_keyroll_command_payload.size() );
		return false;
	}

	unsigned char *bufptr = m_keyroll_command_payload.data();

	if(!bufptr)
	{
		err = "Failed to get bufptr, out of memory";
		return false;
	}

	//check signature:
	if(!m_sig.VerifyObject(err,bufptr,rsa_sz,asym) )
	{
		return false;
	}

	// setup asym from decrypting key
	if( !decrypting_private_key->ApplyKeytoAsym(asym,err) )
	{
		return false;
	}

	if( asym->GetStatus() != AsymIf::STATUS_KEYPAIR )
	{
		err=colib::string::Format("Private key required for decryption, asymif status: %d",
				 asym->GetStatus());
		return false;
	}

	//rsa decrypt payload:
	int decrypt_size = asym->private_decrypt( rsa_sz, bufptr, bufptr);
	if( -1 == decrypt_size)
	{
		err=colib::string::Format("Failed to rsa decrypt payload: %s", asym->GetLastError() );
		return false;
	}

	// xdr decode into payload 
	{
		XdrDecode xdr( (char*)bufptr, decrypt_size );
		if( !payload->XdrProc(&xdr) )
		{
			err=colib::string::Format("Failed to XDR decode payload");
			return false;
		}
	}

	return true;
}


bool V3_Keyroll_Command::Encrypt( AsymIf *asym, AsymIf *asym_peer, V3_Keyroll_Command::Payload *payload, 
			x509_Certificate *encrypt_to, KeyRecord *signing_private_key, string &err )
{
	//check arguments
	if(!asym || !asym_peer || !payload )
	{
		err = "invalid arguments";
		return false;
	}

	// setup asym from cert
	if(encrypt_to &&  !ApplyX509CertificatetoAsymIf(asym_peer,encrypt_to,err) )
	{
		err = "Failed to apply certificate public key to asymif" + err;
		return false;
	}

	// setup array
	unsigned int rsa_sz = asym_peer->GetRequiredSpace();
	unsigned int paysiz = asym_peer->GetRequiredSpace();

	m_keyroll_command_payload.resize(rsa_sz); 

	unsigned char *bufptr = m_keyroll_command_payload.data();

	// xdr payload into array
	{
		XdrEncode xdr( (char*)bufptr, paysiz );
		if( !payload->XdrProc(&xdr) )
		{
			err=colib::string::Format("Failed to XDR payload into %u byte space",paysiz);
			return false;
		}

		// rsa encypt payroad of array
		if( -1 == asym_peer->public_encrypt((int)xdr.GetLength(), bufptr, bufptr) )
		{
			err=colib::string::Format("Failed to rsa encrypt payload: %s", asym_peer->GetLastError() );
			return false;
		}
	}

	//at this point our array contains the final encrypted keyroll command.
	// we sign this with the provided rsa private key

	// setup asym from hostkey
	if( signing_private_key && !signing_private_key->ApplyKeytoAsym(asym,err) )
	{
		return false;
	}
	if( asym->GetStatus() != AsymIf::STATUS_KEYPAIR )
	{
		err=colib::string::Format("Private key required for signing, asymif status: %d",
				 asym->GetStatus());
		return false;
	}

	// sign payload
	if(!m_sig.SignObject(err,bufptr,rsa_sz,asym) )
	{
		return false;
	}

	return true;
}


bool V3_Keyroll_Command::Decrypt( AsymIf *asym, AsymIf *asym_peer, 
		V3_Keyroll_Command::Payload *payload, 
		x509_Certificate *sig_verifier, KeyRecord *decrypting_private_key, string &err )
{
	//check arguments
	if(!asym || !asym_peer || !payload)
	{
		err = "invalid arguments";
		return false;
	}

	// setup asym from cert
	
	if(sig_verifier && !ApplyX509CertificatetoAsymIf(asym_peer,sig_verifier,err) )
	{
		err = "Failed to apply certificate public key to peer asymif: " + err;
		return false;
	}

	unsigned int rsa_sz = asym_peer->GetRequiredSpace();

	if( m_keyroll_command_payload.size() != rsa_sz )
	{
		err=colib::string::Format("Failed to verify signature: expected length %u obj, not %zu",
				rsa_sz, m_keyroll_command_payload.size() );
		return false;
	}

	unsigned char *bufptr = m_keyroll_command_payload.data();

	if(!bufptr)
	{
		err = "Failed to get bufptr, out of memory";
		return false;
	}

	//check signature:
	if(!m_sig.VerifyObject(err,bufptr,rsa_sz,asym_peer) )
	{
		return false;
	}

	// setup asym from decrypting key
	if(decrypting_private_key && !decrypting_private_key->ApplyKeytoAsym(asym,err))
	{
		return false;
	}

	if( asym->GetStatus() != AsymIf::STATUS_KEYPAIR )
	{
		err=colib::string::Format("Private key required for decryption, asymif status: %d",
				 asym->GetStatus());
		return false;
	}

	//rsa decrypt payload:
	int decrypt_size = asym->private_decrypt( rsa_sz, bufptr, bufptr);
	if( -1 == decrypt_size)
	{
		err=colib::string::Format("Failed to rsa decrypt payload: %s", asym->GetLastError() );
		return false;
	}

	// xdr decode into payload 
	{
		XdrDecode xdr( (char*)bufptr, decrypt_size );
		if( !payload->XdrProc(&xdr) )
		{
			err=colib::string::Format("Failed to XDR decode payload");
			return false;
		}
	}

	return true;
}

V3_Keyroll_Command::V3_Keyroll_Command()
{
}
bool V3_Keyroll_Command::XdrProc( CXDR *xdr )
{
	if( !XdrVectorBlock<uint8_t>(xdr,m_keyroll_command_payload) 
		|| !m_sig.MinimalXdrProc(xdr)
		|| !xdr->XdrUint(&m_network_id)
		|| !xdr->XdrUint(&m_key_selector))
		return false;

	return true;
}

bool V3_Keyroll_Command::Payload::XdrProc( CXDR *xdr )
{
	if( !xdr->XdrUint(&m_tx_keyroll_id) )
		return false;

	if( !xdr->XdrUint(&m_rx_session_id) )
		return false;

	if( !XdrDlistType<V3TransportCmmd>(xdr,m_commands) )
		return false;

	if( !xdr->XdrBool(&m_force) )
		return false;

	return true;
}

const char* V3_Solicitation::session_state_str(session_state st)
{
	switch(st)
	{
		case SESSION_UP:
			return "UP";
			break;
		case SESSION_DOWN:
			return "DOWN";
			break;
		case SESSION_OPENING:
			return "OPENING";
			break;
	}
	return "UNKNOWN";
}

colib::string V3_Solicitation::FormatSummary()const
{
	// rx:%s rxid:%d [ptxid:%d]
	// tx:%s [txid:%d] [prxid%d]
	// [no cert| have cert:%u ]
	// message

	colib::string ret;

	ret.AppendFmt("rx:%s rd:%u",
			session_state_str(m_rx_session_state), m_rx_session_id );

	if(m_rx_session_state != SESSION_DOWN )
	{
		ret.AppendFmt(" ptd:%u", m_peer_tx_session_id );
	}

	ret.AppendFmt(" tx:%s",
			session_state_str(m_tx_session_state) );

	if(m_tx_session_state != SESSION_DOWN )
	{
		ret.AppendFmt(" td:%u", m_tx_session_id );

		if(m_tx_session_state == SESSION_UP )
		{
			ret.AppendFmt(" prd:%u", m_peer_rx_session_id );
		}
	}

	if( m_rx_cert_state == HAVE_RXD_CERT )
	{
		ret.AppendFmt(" RC:%u", m_rx_cert_id );
	}
	else
	{
		ret += " NC";
	}

	if( !m_ack_transport_ids.empty() )
	{
		ret += " ";
		ret += format_rangeset(m_ack_transport_ids, FormatInt() );
	}

	if( m_sym_algorithms_supported.size() != 0 )
	{
		ret.AppendFmt( " S(%d", (int)m_sym_algorithms_supported[0] );
		for( unsigned int TEMPat=1; TEMPat<m_sym_algorithms_supported.size(); ++TEMPat)
		{
			ret.AppendFmt( ",%d", (int)m_sym_algorithms_supported[TEMPat] );
		}
		ret += ")";
	}

	return ret;
}

} //end namespace colib
