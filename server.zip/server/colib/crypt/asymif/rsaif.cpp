//rsaif.cpp

#include <crypt/asymif/rsaif.h>
#include <crypt/asymif/trace.h>
#include <utils/system/machine.h>
#include <crypt/x509utils/ossl_utils.h>
#include <signal.h>
#include <errno.h>
#include <stdio.h>
#include <sys/mman.h>
#include <unistd.h>
#include <sys/types.h>

namespace colib
{

RsaIf::RsaIf()
{
	m_ctx=0;
	m_status=STATUS_NOKEYS;
}

RsaIf::~RsaIf()
{
	Reset();
}

void RsaIf::Reset()
{
	if(m_ctx)
	{
		RSA_free((RSA*)m_ctx);
		m_ctx=0;
	}
}

void RsaIf::HarvestLastError()
{
	char buf[125];
	unsigned long err;

	m_last_error.empty();
	while( 0 != (err=ERR_get_error()) )
	{
		buf[0]='\0';
		ERR_error_string(err,buf);
		
		m_last_error.AppendFmt("Rsaif Error: %s  ",buf);
	}
}

bool RsaIf::BlockingGenerateKeyPair( int bits )
{
	m_status=STATUS_NOKEYS;
	
	Reset();

	m_want_bits = bits;
	
	m_ctx = RSA_generate_key(m_want_bits, 0x10001L, 0 , 0);
	
	if(m_ctx)
	{
		m_last_error="";
		//set the status for now, the consistency check needs to know
		//that we have a keypair in order to test it
		m_status=STATUS_KEYPAIR;
		if(!PairwiseConsistencyCheck())
		{
			ASYM0_TRACE(2," Pairwise consistency check failed\r\n");
			m_last_error = colib::string("Pairwise Consistency Check failed: ") + m_last_error;
			m_status=STATUS_NOKEYS;
		}
		return m_status==STATUS_KEYPAIR;
	}
	m_status=STATUS_NOKEYS;
	ASYM0_TRACE(2," But no context found\r\n");
	HarvestLastError();
	return false;
}

bool RsaIf::SetPublicKey( EncryptionKey *to )
{
	Reset();
	
	m_ctx = RSA_new();
	if(!m_ctx)
	{
		HarvestLastError();
		return false;
	}

	if( apply_publickey_to(to,(RSA*)m_ctx) )
	{
		m_status=STATUS_PUBKEY;
		m_want_bits = BN_num_bits(((RSA*)m_ctx)->n);
		return true;
	}
	else
		return false;
}

bool RsaIf::SetPrivateKey( EncryptionKey *to )
{
	Reset();

	m_ctx = RSA_new();
	if(!m_ctx)
	{
		HarvestLastError();
		return false;
	}
	
	if( apply_privatekey_to(to,(RSA*)m_ctx) )
	{
		m_status=STATUS_KEYPAIR;
		m_want_bits = BN_num_bits(((RSA*)m_ctx)->n);

		if(!PairwiseConsistencyCheck())
		{
			ASYM0_TRACE(2," Pairwise consistency check failed\r\n");
			m_last_error = colib::string("Pairwise Consistency Check failed: ") + m_last_error;
			m_status=STATUS_NOKEYS;
			return false;
		}
		
		return true;
	}
	else
		return false;
}


bool RsaIf::GetPublicKey( EncryptionKey *to )
{
	//layout public key into "to"
	if(!m_ctx || m_status==STATUS_NOKEYS )
		return false;

	return apply_publickey_to((RSA*)m_ctx,to);
}

bool RsaIf::GetPrivateKey( EncryptionKey *to )
{
	//layout full key into "to"
	if(!m_ctx || m_status!=STATUS_KEYPAIR )
		return false;

	return apply_privatekey_to((RSA*)m_ctx,to);
}

int RsaIf::GetRequiredSpace()
{
	if(m_ctx)
		return RSA_size((RSA*)m_ctx);
	return 0;
}

int RsaIf::GetPayloadMaxsize()
{
	int ret = RsaIf::GetRequiredSpace();
	if(m_mode == AsymIf::PADMODE_PKCS1)
		//pkcs has 11 bytes of overhead
		return ret - 11;
	return ret;
}

bool RsaIf::Init()
{
	ERR_load_crypto_strings();
	return true;
}

void RsaIf::zero()
{
	m_status = STATUS_NOKEYS;
	RSA_free((RSA*)m_ctx);
	m_ctx = 0;
}

inline bool RsaIf::status_ok( bool need_priv )
{
	if(need_priv)
	{
		if( GetStatus() != STATUS_KEYPAIR )
		{
			m_last_error="Private Key Unavaliable";
			return false;
		}
	}
	else
	{
		if( GetStatus() != STATUS_KEYPAIR &&
			GetStatus() != STATUS_PUBKEY	)
		{
			m_last_error="Public Key Unavaliable";
			return false;
		}
	}
	if(!m_ctx)
	{
		m_last_error="Not Initialized Properly";
		return false;
	}
	return true;
}

int RsaIf::public_encrypt(int len, const unsigned char *from, unsigned char *to)
{
	if(!status_ok(false))
		return -1;

	/*
	int rsalen = GetRequiredSpace();
	
	if(!RSA_padding_add_PKCS1_type_2(to,rsalen,from,len) )
	{
		HarvestLastError();
		return -1;
	}
	
	int ret = RSA_public_encrypt(rsalen,to,to,((RSA*)m_ctx),RSA_NO_PADDING);
	*/

	int padding = m_mode == AsymIf::PADMODE_PKCS1 ? RSA_PKCS1_PADDING : RSA_NO_PADDING;

	int ret = RSA_public_encrypt(len,from,to,((RSA*)m_ctx),padding);
	
	if(ret==-1)
	{
		HarvestLastError();
	}

	return ret;
}

int RsaIf::private_decrypt(int len, const unsigned char *from, unsigned char *to)
{
	if(!status_ok(true))
		return -1;

	//const int lcont=20;
	//ASYM1_TRACE(0,"Decrypting block %dbyte\n", len);
	//for(int at=0; at<len;at+=lcont)
	//{
	//	for(int at2=at; at2<len && at2<at+lcont;++at2)
	//	{
	//		ASYM1_TRACE(0,"%02X ", from[at2] );
	//	}
	//	ASYM0_TRACE(0,"\n" );
	//}

	//All one step, doit broken down now
	//	return RSA_private_decrypt(len,from,to,((RSA*)m_ctx),RSA_PKCS1_PADDING);

	//ASYM0_TRACE(0,"Decrypting block\n");
	int res = RSA_private_decrypt(len,from,to,((RSA*)m_ctx),RSA_NO_PADDING);

	if(res==-1)
	{
		HarvestLastError();
		ASYM1_TRACE(0,"Failed to decrypt %d\n", len);
		return -1;
	}

	//ASYM1_TRACE(0,"Decrypted length %d\n", res);
	//for(int at=0; at<res;at+=lcont)
	//{
	//	for(int at2=at; at2<res && at2<at+lcont;++at2)
	//	{
	//		ASYM1_TRACE(0,"%02X ", to[at2] );
	//	}
	//	ASYM0_TRACE(0,"\n" );
	//}

	if( m_mode == AsymIf::PADMODE_NONE )
		return RSA_size((RSA*)m_ctx);

	//ASYM0_TRACE(0,"PKCS unpadding block\n");
	int upadl = RSA_padding_check_PKCS1_type_2(to,len,to+1,res-1,m_want_bits/8);

	if(upadl==-1)
	{
		HarvestLastError();
		ASYM0_TRACE(0,"Failed to UNPAD input\n");
		return -1;
	}
	//ASYM1_TRACE(0,"Unpadded length %d\n", upadl);
	//for(int at=0; at<upadl;at+=lcont)
	//{
	//	for(int at2=at; at2<upadl && at2<at+lcont;++at2)
	//	{
	//		ASYM1_TRACE(0,"%02X ", to[at2] );
	//	}
	//	ASYM0_TRACE(0,"\n" );
	//}

	return upadl;
}

const char* RsaIf::GetLastError()
{
	return m_last_error;
}

int RsaIf::private_encrypt(int len, const unsigned char *from, unsigned char *to)
{
	if(!status_ok(true))
		return -1;

	int ret = RSA_private_encrypt(len,from,to,((RSA*)m_ctx),RSA_PKCS1_PADDING);
	
	if(ret==-1)
	{
		HarvestLastError();
	}

	return ret;
}

int RsaIf::public_decrypt(int len, const unsigned char *from, unsigned char *to)
{
	if(!status_ok(false))
		return -1;

	int res = RSA_public_decrypt(len,from,to,((RSA*)m_ctx),RSA_NO_PADDING);

	if(res==-1)
	{
		HarvestLastError();
		ASYM1_TRACE(0,"Failed to decrypt %d\n", len);
		return -1;
	}

#if 0
	ASYM1_TRACE(0,"Decrypted length %d\n", res);
	const int lcont=20;
	for(int at=0; at<res;at+=lcont)
	{
		for(int at2=at; at2<res && at2<at+lcont;++at2)
		{
			ASYM1_TRACE(0,"%02X ", to[at2] );
		}
		ASYM0_TRACE(0,"\n" );
	}
	ASYM_TRACE("m_want_bits=%u\n", m_want_bits );
	ASYM_TRACE("RSA_padding_check_PKCS1_type_1("
		"%x=\'%c\',%u,%x=\'%c\',%u,%u)\n",to,*to,len,to+1,*(to+1),res-1,m_want_bits/8);
#endif

	int upadl = RSA_padding_check_PKCS1_type_1(to,len,to+1,res-1,m_want_bits/8);

	if(upadl==-1)
	{
		HarvestLastError();
		ASYM0_TRACE(0,"Failed to UNPAD input\n");
		return -1;
	}

	return upadl;
}

} //end namespace colib


