//rsaif.h

#ifndef RSAIF_H_ALREADY_INCLUDED
#define RSAIF_H_ALREADY_INCLUDED

#include <crypt/asymif/asymif.h>
#include <utils/string.h>

namespace colib
{

class RsaIf : public AsymIf
{

public:
	RsaIf();
	~RsaIf();

	bool BlockingGenerateKeyPair( int bits );

	bool GetPublicKey( EncryptionKey *to );
	bool SetPublicKey( EncryptionKey *to );
	bool GetPrivateKey( EncryptionKey *to );
	bool SetPrivateKey( EncryptionKey *to );
	
	int GetAlgorithm();

	int GetRequiredSpace();
	int GetPayloadMaxsize();
	bool Init();
	void zero();

	bool status_ok( bool need_priv );

	int public_encrypt(int len, const unsigned char *from, unsigned char *to);
	int private_decrypt(int len, const unsigned char *from, unsigned char *to);

	int private_encrypt(int len, const unsigned char *from, unsigned char *to);
	int public_decrypt(int len, const unsigned char *from, unsigned char *to);

	const char* GetLastError();
	
	int GetStatus() const { return (int) m_status; };
private:
	void Reset();
	void HarvestLastError();

	void *m_ctx;

	colib::string m_last_error;
	
	int m_want_bits;

	Status m_status;
};

inline int RsaIf::GetAlgorithm()
{
	return AsymIf::ALG_RSA;
}

} //end namespace colib

#endif

