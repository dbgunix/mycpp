#include <iostream>
#include <idirect/crypt/triel/triel_openssl_aes.h>
#include <gtest/gtest.h>
#include <idirect/utils/dump_hex.h>
#include <idirect/utils/trace/stdio_writable.h>


using namespace colib;



TEST(Triel, Basic)
{

}

