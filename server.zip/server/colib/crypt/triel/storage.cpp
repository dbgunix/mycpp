
// storage.cpp
// vi:set ts=4 sw=4 nowrap:

#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>

#include <xmlutil/treeoptions.h>
#include <crypt/triel/triel_openssl_aes.h>
#include <crypt/key/passwd_to_aes_key.h>
#include <utils/file_util.h>
#include <utils/trace/trace.h>
#include <utils/time.h>

#include<crypt/triel/storage.h>

namespace colib {

colib::string MakeFileName(colib::string base, colib::string ext)
{
	return colib::string::Format("%s.%s", base.c_str(), ext.c_str());
}

const char* SecureStorage::DEFAULT_CHECKPOINT_LOCATION = "/etc/idirect/certs/keyroll_checkpoint";

const char* SecureStorage::TMP_FILE_SUFFIX = "tmp";
const char* SecureStorage::BAK_FILE_SUFFIX = "bak";

const char* SecureStorage::XML_ROOT_TAG = "SecureStorage";
const char* SecureStorage::XML_DATE_TAG = "Date";
const char* SecureStorage::XML_CONTENT_TAG = "Content";
const char* SecureStorage::XML_TIME_FORMAT = "%Y-%m-%d %H:%M:%S";

colib::string SecureStorage::MakeXML(colib::string data)
{
	colib::TreeOptions trOp;
	colib::Time now;
	now.SetToNow();

	trOp.SetName("SecureStorage");
	time_t tim = now.GetSeconds();
	char buf[64];
	struct tm tm_tim;
	gmtime_r(&tim, &tm_tim);
	strftime(buf, sizeof(buf), XML_TIME_FORMAT, &tm_tim);
	trOp.InsertChild(XML_DATE_TAG, buf);
	trOp.InsertChild(XML_CONTENT_TAG, data);
	return trOp.ToXML();
} 

void SecureStorage::DefaultWriteComplete(colib::EvtLoop_WriteFile2_result res)
{
	if (res.m_status) {
		if (m_need_backup) {
			// back up the acc key file
			colib::string backupFile = MakeFileName(m_base_file_name, BAK_FILE_SUFFIX);

			if (rename(m_base_file_name, backupFile.c_str()) != 0) {
				if (errno != ENOENT) {
					m_callback_error = colib::string::Format("failed to backup the old file %s : %s\n",
										m_base_file_name.c_str(), strerror(errno));
					TRACE("SecureStorage: %s\n", m_callback_error.c_str());
				}
			}
		}
		if (rename(res.m_filename.c_str(), m_base_file_name.c_str()) != 0) {
				m_callback_error = colib::string::Format("failed to rename the tmp file %s : %s\n",
									res.m_filename.c_str(), strerror(errno));
			TRACE("SecureStorage: %s\n", m_callback_error.c_str());
		}
	} else {
		m_callback_error = colib::string::Format("failed to save the data: %s\n", res.m_filename.c_str());
		TRACE("SecureStorage: %s\n", m_callback_error.c_str());
	}

	// replace the temporary file name with the real one
	res.m_filename = m_base_file_name;
	m_custom_write_done_cb.Dispatch(res);
}

SecureStorage::RETURN_CODE SecureStorage::DumpToDisk(const char* data, int len, bool isNonBlock)
{
	colib::string tmpFile = MakeFileName(m_base_file_name, TMP_FILE_SUFFIX);	

	if (m_cipher_encoder) {
		if (!m_cipher_encoder->Encrypt(data, len)) {
			m_last_error = m_cipher_encoder->GetLastError();
			return ENCODER_FAILURE;
		}
	} else {
		m_last_error = "no encoder";
		return NO_ENCODER;
	}

	colib::string toStr(m_cipher_encoder->GetData(), (unsigned int)m_cipher_encoder->GetDataLen());

	colib::string xmlStr = MakeXML(toStr);

	if (isNonBlock) {
		EvtLoop_WriteFile2(xmlStr, tmpFile, m_on_done, NULL);
		return OK;
	} else {
		return WriteToDisk(m_base_file_name, m_last_error, xmlStr.c_str(), xmlStr.get_length());
	}
}

SecureStorage::RETURN_CODE SecureStorage::WriteToDisk(const char* path, 
									   colib::string& error, 
									   const char* buf, int len) const
{

	int fd = open (path, O_CREAT|O_RDWR|O_TRUNC, S_IREAD|S_IWRITE);
	
	if (fd == -1) {
		error = colib::string::Format("cannot open file %s: %s", path, strerror(errno));
		return CANNOT_OPEN_FILE_FOR_WRITE;
	}

	bool success = (write(fd, buf, len) == len);
	RETURN_CODE ret = OK;
	if (!success) {
		ret = CANNOT_WRITE_TO_FILE;
		error =  colib::string::Format("Failed to write to all data disk: %s", strerror(errno));
	}
	close(fd);
	return ret;
}

bool SecureStorage::DoesFileExist() const 
{
	return GetFileSize(m_base_file_name, m_last_error) > 0;
}

SecureStorage::RETURN_CODE SecureStorage::LoadFromDisk(char* content, int& len, time_t& date)
{

	int fileLen = GetFileSize(m_base_file_name, m_last_error);
	if (fileLen <= 0) {
		return FILE_DOES_NOT_EXIST;
	} 
	colib::TreeOptions treOp;

	if (!treOp.LoadFromFile(m_base_file_name.c_str(), m_last_error)) {
		return FAILED_TO_LOAD_XML_FILE;
	}

	const colib::TreeOptions* child = treOp.GetChild(XML_DATE_TAG);
	if (!child) {
		m_last_error = "cannot retrieve date";
		return INVALID_XML_FORMAT;
	}
	colib::string strTime = child->GetValue();
	if (strTime.is_empty()) {
		m_last_error = "empty date string";
		return INVALID_XML_FORMAT;
	}
	struct tm tm;
	if (!strptime(strTime.c_str(), XML_TIME_FORMAT, &tm)) {
		m_last_error = "invalid date string";
		return INVALID_XML_FORMAT;
	}
 
	date = mktime(&tm);

	child = treOp.GetChild(XML_CONTENT_TAG);
	if (!child) {
		m_last_error = "empty content";
		return INVALID_XML_FORMAT;
	}
	
	colib::string tmpContent = child->GetValue();
	
	if (m_cipher_encoder) {
		if (!m_cipher_encoder->Decrypt(tmpContent, tmpContent.get_length())) {
			m_last_error = m_cipher_encoder->GetLastError();
			return ENCODER_FAILURE;
		}
	} else {
		return NO_ENCODER;
	}

	if (m_cipher_encoder->GetDataLen() >= len) {
		m_last_error = "buffer is too small";
		return BUFFER_TOO_SMALL;
	}
	memcpy(content, m_cipher_encoder->GetData(), m_cipher_encoder->GetDataLen());
	len = m_cipher_encoder->GetDataLen();

	return OK;
}

void SecureStorage::zeroize() 
{
	colib::string fileName;
	// base file 
	fileName = m_base_file_name;
	if (!ZeroizeFile(fileName)) {
		// maybe only for debug build
		//TRACE("Failed to zeroize %s(file may not exist), %s\n", fileName.c_str(), GetLastError().c_str());
	}
	// backup file
	fileName = MakeFileName(m_base_file_name, BAK_FILE_SUFFIX);
	if (!ZeroizeFile(fileName)) {
		// maybe only for debug build
		//TRACE("Failed to zeroize %s(file may not exist), %s\n", fileName.c_str(), GetLastError().c_str());
	}
}

bool SecureStorage::ZeroizeFile(colib::string fileName)
{
	if (fileName.is_empty()) {
		m_last_error = "ZeroizeFile failed: file name is empty";
		return false;
	}
	int fileLen = GetFileSize(fileName, m_last_error);

	bool ret = false;
	if (fileLen > 0) {
		char* buf = new char[fileLen];		
		if (buf) {
			memset(buf, 0, fileLen);
			ret = (WriteToDisk(fileName, m_last_error, buf, fileLen) == OK);
			delete[] buf;
		}
	}
	colib::string err;
	RemoveFile(fileName, err);
	return ret;
}

} // end of namespace
