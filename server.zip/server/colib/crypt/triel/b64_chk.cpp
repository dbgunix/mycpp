//b64_chk.cpp
// vi:set ts=4 sw=4 nowrap:

#include <utils/trace/trace.h>
#include <utils/base_encoder.h>
#include <crypt/triel/key_chksum.h>
#include <utils/utils.h>
#include <crypt/key/key.h>
#include <crypt/triel/triel.h>
#include <crypt/triel/b64_chk.h>
#include <options/options_node.h>

#include <memory>

//TODO: check if this class is needed

namespace colib
{

bool triel_is_ok_key( colib::string type, const char *key_b64_with_checksum, colib::string &error )
{
	(void)key_b64_with_checksum;
	std::unique_ptr<TrielInterface> ptriel(TrielInterface::AllocAndInit(type,0,error));
	if(!ptriel)
	{
		return false;
	}
//TODO: Move b64_chk.*, key_chksum.*, storage.* to keyroll directory
// use keyroll class instead of trile
	bool ret = true; // = ptriel->is_ok_key(key_b64_with_checksum);
	error = ptriel->GetLastError();
	return ret;
}

bool b64ize_key( EncryptionKey *key, colib::string &b64txt )
{
	unsigned int klen = key->GetLength();
	std::unique_ptr<char[]> binbuf(new char[klen+4]);
	if(!binbuf)
	{
		return false;
	}

	unsigned int b64len = BaseEncoder::GetBase64Len(klen+4, false)+1;
	std::unique_ptr<char[]> b64buf(new char[b64len]);
	if(!b64buf)
	{
		return false;
	}

	memcpy(binbuf.get(),key->GetData(),klen);
	GenerateChksum( (unsigned char*)binbuf.get(), klen, true);
	if( BaseEncoder::Encode64(b64buf.get(), b64len, (unsigned char*)binbuf.get(), klen+4, false) > 0)
	{
		//add a key for this b64 value
		b64txt=b64buf.get();
		if( 0 != strcmp(b64txt.c_str(),b64buf.get()) )
		{
			return false;
		}
	}
	else
	{
		return false;
	}

	memset(b64buf.get(),0,b64len);
	memset(binbuf.get(),0,klen+4);

	return true;
}

bool triel_generate_key( colib::string type, colib::string &b64key, colib::string &error )
{
	b64key.empty();

	std::unique_ptr<TrielInterface> ptriel(TrielInterface::AllocAndInit(type,0,error));
	if(!ptriel)
	{
		return false;
	}
	//TODO: Move b64_chk.*, key_chksum.*, storage.* to keyroll directory
	// use keyroll class instead of trile
	bool ret = true;// = ptriel->generate_key(b64key);
	error = ptriel->GetLastError();
	return ret;
}

} //namespace colib

