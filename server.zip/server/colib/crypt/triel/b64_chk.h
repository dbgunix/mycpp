//b64_chk.h
// vi:set ts=4 sw=4 nowrap:

#ifndef B64_CHK_H_ALREADY_INCLUDED
#define B64_CHK_H_ALREADY_INCLUDED

#include <utils/string.h>
#include <crypt/triel/triel.h>

namespace colib
{


bool triel_is_ok_key( colib::string type, const char *key_b64_with_checksum, colib::string &error );
bool triel_generate_key( colib::string type, colib::string &b64key, colib::string &error );

bool b64ize_key( EncryptionKey *key, colib::string &b64txt );

} //namespace colib


#endif

