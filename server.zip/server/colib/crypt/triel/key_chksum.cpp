#include <crypt/triel/key_chksum.h>
#include <utils/system/machine.h>

namespace colib
{

unsigned int GenerateChksum(unsigned char *pKey, int keylen, bool bUpdate)
{
	unsigned int tempres = 0;
    unsigned int temp;
    for(int i=0; (i+4)<=keylen; i+=4)
    {
        temp = *(unsigned int*)(pKey + i);
        tempres += FLIP(temp);
    }

	if(bUpdate)
	{
		*(unsigned int*)(pKey+ keylen) = FLIP(tempres);
	}

    return tempres;
}

bool VerifyChksum(unsigned char *pKey, int keylen)
{
	unsigned int chksum = GenerateChksum(pKey, keylen, false);
	if(chksum != FLIP(*(unsigned int*)(pKey + keylen)))
	{
		return false;
	}

	return true;
}

}
