
// cipher.cpp
// vi:set ts=4 sw=4 nowrap:

#include <utils/base_encoder.h>
#include <crypt/key/passwd_to_aes_key.h>
#include <crypt/triel/triel_openssl_aes.h>
#include <crypt/keyroll/keyroll.h>
#include <crypt/triel/cipher.h>

namespace colib {

bool B64CipherOP::Encrypt(const char* in, int inLen)
{

	m_out_len  = BaseEncoder::Encode64(m_out, sizeof(m_out), (const unsigned char*)in, inLen, false);
	if (m_out_len <= 0) {
		SetLastError(colib::string::Format("failed to encode to base 64 encoding: %zu, %d",
											  sizeof(m_out), inLen));
		m_out_len = 0;
		return false;
	}

	return true;
}

bool B64CipherOP::Decrypt(const char* in, int inLen)
{

	m_out_len = BaseEncoder::Decode64((unsigned char*)m_out,  (int)sizeof(m_out), in, inLen);

	if (m_out_len <= 0) {
		SetLastError(colib::string::Format("failed to decode base 64 encoding: %zu, %d", 
											 sizeof(m_out), inLen));
		m_out_len = 0;
		return false;
	}
	return true;
}

const uint64_t AESCipherOP::PBKDF2_SALT = 66661207;
const char* AESCipherOP::PBKDF2_PASSPHRASE = "iDirect61236176123619&*1^%$@#*m,<>?49~````+=";

AESCipherOP::AESCipherOP() : m_key_is_ready(false)
{
	memset(m_IV, 0, sizeof(m_IV));
}

bool AESCipherOP::GenerateAesKey(colib::string& errorStr, unsigned int ID)
{
	m_key_is_ready = colib::Passwd2AESKey::GenerateAesKey(ID, PBKDF2_PASSPHRASE, m_aes_key, 
						  (const unsigned char*)&PBKDF2_SALT, sizeof(PBKDF2_SALT),
                          errorStr, PBKDF2_ITER);
	return m_key_is_ready;
}

bool AESCipherOP::Encrypt(const char* in, int inLen)
{

	if(!m_key_is_ready) {
		SetLastError("aes key is not ready");
		return false;
	}
	TrielOsslAes aes;

	char padingLen = AES_BLOCK_SIZE - (inLen % AES_BLOCK_SIZE);

	int encOutLen = inLen + padingLen;

	char* tmpBuf = new char[encOutLen];

	if (!tmpBuf) {
		SetLastError("no enough memory");
		return false;
	}

	memcpy(tmpBuf, in, inLen);
	memset(tmpBuf + inLen, padingLen, padingLen);

	unsigned char IVBuf[sizeof(m_IV)];
	memcpy(IVBuf, m_IV, sizeof(m_IV));

	EncryptionKey IV(IVBuf, sizeof(IVBuf));

	if(!aes.EncryptCBC(&m_aes_key, &IV, tmpBuf, encOutLen)) {
		SetLastError(aes.GetLastError());
		delete[] tmpBuf;
		return false;
	}

	bool ret = B64CipherOP::Encrypt(tmpBuf, encOutLen);
	delete[] tmpBuf;
	return ret;
}

bool AESCipherOP::Decrypt(const char* in, int inLen)
{
	if(!m_key_is_ready) {
		SetLastError("aes key is not ready");
		return false;
	}
	if (!B64CipherOP::Decrypt(in, inLen)) {
		return false;
	}
	if (!GetDataLen() || (GetDataLen() % AES_BLOCK_SIZE)) {
		SetLastError(colib::string::Format("cipher text length not multiple (> 0) of 16: %d", 
									 GetDataLen()));
	}

	unsigned char IVBuf[sizeof(m_IV)];
	memcpy(IVBuf, m_IV, sizeof(m_IV));

	EncryptionKey IV(IVBuf, sizeof(IVBuf));

	TrielOsslAes aes;

	if(!aes.DecryptCBC(&m_aes_key, &IV, GetData(), GetDataLen())) {
		SetLastError(aes.GetLastError());
		return false;
	}

	char pading = (GetData())[GetDataLen() - 1];

	if (pading > 16 || GetDataLen() < pading) {
		SetLastError(colib::string::Format("Invalid padding: %d", pading));
		return false;
	}

	SetDataLen(GetDataLen() - pading); // remove the padding

	return true;
}

} // end of namespace
