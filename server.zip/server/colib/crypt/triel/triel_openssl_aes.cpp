//triel_openssl_aes.cpp

#include <crypt/triel/triel_openssl_aes.h>

namespace colib {

TrielOsslAes::TrielOsslAes() {
}

TrielOsslAes::~TrielOsslAes() {
}


bool TrielOsslAes::SetMode( Mode to )
{
	switch(to)
	{
		case CBC:
			m_current_encrypt=&TrielInterface::EncryptCBC;
			m_current_decrypt=&TrielInterface::DecryptCBC;
			break;
		case CFB:
			m_current_encrypt=&TrielInterface::EncryptCFB;
			m_current_decrypt=&TrielInterface::DecryptCFB;
			break;
		default:
			m_last_error= "Unsupported Cipher Mode";
			return false;
	}
	m_current_mode=to;
	return true;
}

bool TrielOsslAes::IsModeSupported( Mode mode )
{

	switch(mode)
	{
		case CBC:
		case CFB:
			return true;
		default:
			break;
	}

	return false;
}

bool TrielOsslAes::EncryptCBC( EncryptionKey *key, EncryptionKey *iv, void *buffer, unsigned int buffer_size )
{
	if( key->GetType() != GetKeyType() )
	{
		m_last_error="Invalid EncryptionKey passed to TrielOsslAes::EncryptCBC";
		return false;
	}
	SAESeKey *aeskey = (SAESeKey*)key;

	AES_cbc_encrypt(
			(const unsigned char*)buffer, //input
			(unsigned char*)buffer, //output
			buffer_size, //length
			&aeskey->m_enc_ctx, //key
			iv->GetData(), //ivec
			1 //enc
			);

	return true;
}

bool TrielOsslAes::DecryptCBC( EncryptionKey *key, EncryptionKey *iv, void *buffer, unsigned int buffer_size )
{
	if( key->GetType() != GetKeyType() )
	{
		m_last_error="Invalid EncryptionKey passed to TrielOsslAes::DecryptCBC";
		return false;
	}
	SAESeKey *aeskey = (SAESeKey*)key;

	AES_cbc_encrypt(
			(const unsigned char*)buffer, //input
			(unsigned char*)buffer, //output
			buffer_size, //length
			&aeskey->m_dec_ctx, //key
			iv->GetData(), //ivec
			0 //enc
			);
	return true;
}

bool TrielOsslAes::EncryptCFB( EncryptionKey *key, EncryptionKey *iv, void *buffer, unsigned int buffer_size )
{
	if( key->GetType() != GetKeyType() )
	{
		m_last_error="Invalid EncryptionKey passed to TrielOsslAes::EncryptCFB";
		return false;
	}
	SAESeKey *aeskey = (SAESeKey*)key;
	int num=0;

	AES_cfb128_encrypt(
			(const unsigned char*)buffer, //input
			(unsigned char*)buffer, //output
			buffer_size, //length
			&aeskey->m_enc_ctx, //key
			iv->GetData(), //ivec
			&num,
			1 //enc
			);
	return true;
}

bool TrielOsslAes::DecryptCFB( EncryptionKey *key, EncryptionKey *iv, void *buffer, unsigned int buffer_size )
{
	if( key->GetType() != GetKeyType() )
	{
		m_last_error="Invalid EncryptionKey passed to TrielOsslAes::DecryptCFB";
		return false;
	}
	SAESeKey *aeskey = (SAESeKey*)key;
	int num=0;

	AES_cfb128_encrypt(
			(const unsigned char*)buffer, //input
			(unsigned char*)buffer, //output
			buffer_size, //length
			&aeskey->m_enc_ctx, //key (we pass the encrypt context here)
			iv->GetData(), //ivec
			&num,
			0 //enc
			);
	return true;
}

bool TrielOsslAes::EncryptECB( EncryptionKey *key, void *buffer, unsigned int buffer_size )
{
	if ( key->GetType() != GetKeyType() )
	{
		m_last_error = "Invalid EncryptionKey passed to TrielOsslAes::EncryptECB";
		return false;
	}
	if ( 0 != (buffer_size & 0x0F) )
	{
		m_last_error = colib::string::Format("Invalid buffer length %d passed to TrielOsslAes::EncryptECB", buffer_size);
		return false;
	}
	SAESeKey *aeskey = (SAESeKey*)key;
	for( unsigned int i=0; i < buffer_size; i+=16 )
	{
		AES_ecb_encrypt(
				(const unsigned char*)buffer+i, //input buffer
				(unsigned char*)buffer+i, //output buffer
			   	&aeskey->m_enc_ctx, //key 
				1 //encrypt
				);
	}

	return true;
}

bool TrielOsslAes::DecryptECB( EncryptionKey *key, void *buffer, unsigned int buffer_size )
{
	if ( key->GetType() != GetKeyType() )
	{
		m_last_error = "Invalid EncryptionKey passed to TrielOsslAes::DecryptECB";
		return false;
	}
	if ( 0 != (buffer_size & 0x0F) )
	{
		m_last_error = colib::string::Format("Invalid buffer length %d passed to TrielOsslAes::DecryptECB", buffer_size);
		return false;
	}

	SAESeKey *aeskey = (SAESeKey*)key;
	for( unsigned int i=0; i < buffer_size; i+=16 )
	{
		AES_ecb_encrypt(
				(const unsigned char*)buffer+i, //input buffer
				(unsigned char*)buffer+i, //output buffer
			   	&aeskey->m_dec_ctx, //key 
				0 //decrypt
				);
	}
	return true;

}

EncryptionKey* TrielOsslAes::AllocKey()
{
	return new SAESeKey;
}

uint32_t TrielOsslAes::GetReqPaddingOffset( unsigned int buffer_size )
{
	if(m_current_mode == CBC )
		return ( (buffer_size + 15) & ~0x0F) - buffer_size;
	else
		return 0;
}

colib::string TrielOsslAes::GetCipherName()
{
	return "AES_SW";
}
colib::string TrielOsslAes::GetCipherTypeName()
{
	return "AES";
}

} // end of namespace
