//triel_alloc.cpp
// vi:set ts=4 sw=4 nowrap:
//

#include <crypt/triel/triel.h>
#include <crypt/triel/triel_openssl_aes.h>

namespace colib
{


struct typedesc
{
	const char *m_name;
	const char *m_desc;
};

enum typedesc_index
{
	typedesc_index_AES_SW,
	typedesc_index_END_MARKER
};

static typedesc TYPE_NAMES[] = 
{
	{ "AES_SW", "Software AES (openssl)" },
};

static size_t NUM_TYPES = sizeof(TYPE_NAMES)/sizeof(TYPE_NAMES[0]);

static const size_t NOT_FOUND = (size_t) -1;

static size_t FindType( colib::string type )
{
	const char *curnm = type.c_str();
	for(size_t at=0; at < NUM_TYPES; ++at )
	{
		if( 0 == strcmp(TYPE_NAMES[at].m_name, curnm) )
			return at;
	}
	return NOT_FOUND;
}

static TrielInterface* AllocAndInit( size_t type, colib::string mode, colib::string &error )

{
	if( type == typedesc_index_AES_SW )
	{
		TrielInterface *pnew = new TrielOsslAes;
		if(pnew && (!pnew->Init() || !pnew->SetMode(mode)))
		{
			error = pnew->GetLastError();
			delete pnew;
			return 0;
		}
		return pnew;
	}
//	(void) mode;
	return 0;
}

static const size_t typemap_entry_resorts = 4;
struct typemap_entry
{
	const char *m_name;
	const char *m_desc;
	const char *m_resorts[typemap_entry_resorts];
};

static typemap_entry TYPE_MAP[] = 
{
	{ "AES", "First Available AES Impl", {"AES_SW", 0, 0, 0} },
};

static size_t TYPE_MAP_SIZE = sizeof(TYPE_MAP)/sizeof(TYPE_MAP[0]);

static size_t FindMapType( colib::string type )
{
	const char *curnm = type.c_str();
	for(size_t at=0; at < TYPE_MAP_SIZE; ++at )
	{
		if( 0 == strcmp(TYPE_MAP[at].m_name, curnm) )
			return at;
	}
	return NOT_FOUND;
}

colib::string TrielInterface::GetTypeDescription( colib::string type )
{
	size_t srch = colib::FindMapType(type);
	if(srch!=colib::NOT_FOUND)
	{
		return colib::TYPE_MAP[srch].m_desc;
	}

	srch = colib::FindType( type );
	if(srch!=colib::NOT_FOUND)
	{
		return colib::TYPE_NAMES[srch].m_desc;
	}

	return "Not Found";
}
	
TrielInterface* TrielInterface::AllocAndInit( colib::string type, colib::string mode, colib::string &error )
{
	size_t srch = colib::FindMapType(type);
	if(srch!=colib::NOT_FOUND)
	{
		error.empty();
		colib::string current_error;
		colib::typemap_entry *pent = colib::TYPE_MAP + srch;
		for( size_t at=0; at< colib::typemap_entry_resorts; ++at )
		{
			if( !pent->m_resorts[at] )
				break;
			TrielInterface *ret = colib::AllocAndInit( colib::FindType( pent->m_resorts[at] ), mode, current_error);
			if(ret)
				return ret;
			error += current_error;
			error += '\n';
		}
		return 0;
	}

	srch = colib::FindType( type );
	if(srch!=colib::NOT_FOUND)
	{
		return colib::AllocAndInit(srch, mode, error);
	}

	error = colib::string::Format("Symmetric encryption type \"%s\" not found", type.c_str() );
	return 0;
}


} // end of namespace
