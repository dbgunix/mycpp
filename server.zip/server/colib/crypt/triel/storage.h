// storage.h
// vi:set ts=4 sw=4 nowrap:

#ifndef storage_h_already_included
#define storage_h_already_included

#include <crypt/triel/cipher.h>
#include <crypt/zeroize/zeroize_cbk.h>
#include <event_loop/string_file_writer.h>

namespace colib {

class SecureStorage 
{
public:
	static const char* DEFAULT_CHECKPOINT_LOCATION;
	static const char* TMP_FILE_SUFFIX;
	static const char* BAK_FILE_SUFFIX;

	static const char* XML_ROOT_TAG;
	static const char* XML_DATE_TAG;
	static const char* XML_CONTENT_TAG;
	static const char* XML_TIME_FORMAT;

	enum RETURN_CODE {
		OK = 0,
		ERROR, 
		FILE_DOES_NOT_EXIST,
		FAILED_TO_LOAD_XML_FILE,
		CANNOT_OPEN_FILE_FOR_WRITE,
		CANNOT_WRITE_TO_FILE,
		DATA_TOO_OLD,
		NO_ENCODER,
		ENCODER_FAILURE,
		NO_ENOUGH_SPACE,
		BUFFER_TOO_SMALL,
		INVALID_XML_FORMAT,
		RETURN_CODE_COUNT
	};


	static const char* RETURN_CODE_TO_STR[RETURN_CODE_COUNT];

	SecureStorage(CipherIntf*  cipherOp,
				  const char*  baseFileName = DEFAULT_CHECKPOINT_LOCATION, 
				  bool         needBackup         = true) 

		: m_cipher_encoder(cipherOp),
		  m_base_file_name(baseFileName ? baseFileName : DEFAULT_CHECKPOINT_LOCATION),
		  m_need_backup(needBackup),
		  m_zeroize_cbk("SecureStorage", callback(this, &SecureStorage::zeroize)),
		  m_on_done(callback(this, &SecureStorage::DefaultWriteComplete)) {}

	~SecureStorage(){}

	colib::string GetBaseFileName() const { return m_base_file_name; }
	void SetBaseFileName(colib::string baseFile) { m_base_file_name = baseFile; }
	
	CipherIntf* GetEncoder() { return m_cipher_encoder; }
	void SetEncoder(CipherIntf* encoder) { m_cipher_encoder = encoder; }

	RETURN_CODE DumpToDisk(const char* data, int len, bool isNonBlock);	

	// callback of eventloop write file
	void DefaultWriteComplete(colib::EvtLoop_WriteFile2_result res);

	RETURN_CODE WriteToDisk(const char* path, colib::string& error, const char* buf, int len) const;

	RETURN_CODE LoadFromDisk(char* content, int& len, time_t& date);
	
	void zeroize();

	static colib::string MakeXML(colib::string data);
	static colib::string RetCodeToStr(RETURN_CODE code);

	colib::string GetLastError() const { return m_last_error; }	
	colib::string GetCallbackError() const { return m_callback_error; }	

	void SetWriteCompleteCallback(Callback1<colib::EvtLoop_WriteFile2_result> on_done) { m_custom_write_done_cb = on_done; }

	bool DoesFileExist() const;
private:

	// write all zero and remove files
	bool ZeroizeFile(colib::string fileName);

private:
	CipherIntf* m_cipher_encoder;
	colib::string  m_base_file_name;

	bool        m_need_backup;

	mutable colib::string m_last_error;
	mutable colib::string m_callback_error;

	colib::ZeroizeCbk m_zeroize_cbk;
	Callback1<colib::EvtLoop_WriteFile2_result> m_on_done;
	Callback1<colib::EvtLoop_WriteFile2_result> m_custom_write_done_cb;
	
};

} // end of namespace

#endif

