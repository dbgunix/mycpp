//triel_openssl_aes.h

#ifndef TRIEL_OPENSSL_AES_H_ALREADY_INCLUDED
#define TRIEL_OPENSSL_AES_H_ALREADY_INCLUDED

#include <crypt/triel/triel.h>
#include <crypt/key/aes_key.h>
#include <crypt/keyroll/keyroll.h>

namespace colib {

class TrielOsslAes : public TrielInterface
{
public:

	static const int AES_CIPHER_BLOCK_LEN = 16;

	TrielOsslAes();
	~TrielOsslAes();

	bool SetMode( Mode to );

	bool IsModeSupported( Mode mode );
	colib::string GetCipherName();
	colib::string GetCipherTypeName();

	uint32_t GetReqPaddingOffset( unsigned int buffer_size );
	uint32_t GetKeyLengthInBytes();
	uint32_t GetCipherBlockLengthInBytes();
	uint32_t GetKeyType(){return EncryptionKey::KEY_TYPE_OSSL_AES;}


	bool EncryptCBC( EncryptionKey *key, EncryptionKey *iv, void *buffer, unsigned int buffer_size );
	bool DecryptCBC( EncryptionKey *key, EncryptionKey *iv, void *buffer, unsigned int buffer_size );
	bool EncryptCFB( EncryptionKey *key, EncryptionKey *iv, void *buffer, unsigned int buffer_size );
	bool DecryptCFB( EncryptionKey *key, EncryptionKey *iv, void *buffer, unsigned int buffer_size );
	bool EncryptECB( EncryptionKey *key, void *buffer, unsigned int buffer_size );
	bool DecryptECB( EncryptionKey *key, void *buffer, unsigned int buffer_size );

	EncryptionKey* AllocKey();

private:

};

inline uint32_t TrielOsslAes::GetKeyLengthInBytes()
{
	return SAESeKey::AES_KEY_BYTES;
}
inline uint32_t TrielOsslAes::GetCipherBlockLengthInBytes()
{
	return AES_CIPHER_BLOCK_LEN;
}

} // end of namespace

#endif

