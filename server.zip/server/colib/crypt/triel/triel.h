//triel.h

#ifndef TRIEL_H_ALREADY_INCLUDED
#define TRIEL_H_ALREADY_INCLUDED

#include <utils/system/environ.h>
#include <utils/system/machine.h>
#include <utils/system/macros.h>
#include <utils/string.h>
#include <utils/callback.h>
#include <crypt/keyroll/keyroll.h>

namespace colib {

class TrielInterface
{
public:
	TrielInterface();
	virtual ~TrielInterface();

	bool Encrypt( EncryptionKey *key, EncryptionKey *iv, void *buffer, unsigned int buffer_size );
	bool Decrypt( EncryptionKey *key, EncryptionKey *iv, void *buffer, unsigned int buffer_size );

	virtual bool EncryptCBC( EncryptionKey *key, EncryptionKey *iv, void *buffer, unsigned int buffer_size )=0;
	virtual bool DecryptCBC( EncryptionKey *key, EncryptionKey *iv, void *buffer, unsigned int buffer_size )=0;
	virtual bool EncryptCFB( EncryptionKey *key, EncryptionKey *iv, void *buffer, unsigned int buffer_size )=0;
	virtual bool DecryptCFB( EncryptionKey *key, EncryptionKey *iv, void *buffer, unsigned int buffer_size )=0;

	enum Mode
	{
		ECB,
		CBC,
		CFB,
		OFB
	};

	Mode GetMode();
	virtual bool SetMode( Mode to );
	virtual bool SetMode( colib::string to );

	virtual bool IsModeSupported( Mode mode ) = 0;
	static bool NeedsPadding( Mode m );

	bool IsModeSupported( colib::string mode );

	colib::string GetModeName();
	virtual colib::string GetCipherName()=0;
	virtual colib::string GetCipherTypeName()=0;
	virtual uint32_t GetKeyLengthInBytes()=0;
	virtual uint32_t GetCipherBlockLengthInBytes()=0;
	virtual uint32_t GetKeyType()=0;

	//##################################################################################
	// static type allocation api
	static TrielInterface* AllocAndInit( colib::string type, colib::string mode, colib::string &error );

	static colib::string GetTypeDescription( colib::string type );
	//##################################################################################

	virtual uint32_t GetReqPaddingOffset( unsigned int buffer_size )=0;
	virtual EncryptionKey* AllocKey();

	/**
	 *
	 * \brief called by the enc_session to set iv seed len for outbound mssg
	 * iv seed len is in bits, can be 12, 64, 128.
	 */

	const char* GetLastError();

	virtual bool Init();


	//return values: 0==
	enum DecryptResult
	{
		Success=0,
		KeyIndexInvalid=1,
		BadHeader=2,
		OtherError=3
	};

	// 0 means no exhaustion.
	// other numbers are values in packets. For CTR mode,
	// 0 will fail, and other values will succeed, but exhaustion is
	// aways driven by the counter, not traffic
//	virtual bool SetKeyExhaustion( unsigned int param );

	//this notification callback is dispatched whenever the current key
	//in the enc keyroll reaches its ctr limit. The current key will have been
	//automatically disabled, and the keyroll advanced to the next key
	//using the "RolloverEncKeyring" function
//	Callback on_enc_key_exhausted;

protected:

	typedef bool (TrielInterface::*CIPHRFUNC)( EncryptionKey *, EncryptionKey *, void *, unsigned int);
	CIPHRFUNC m_current_encrypt;
	CIPHRFUNC m_current_decrypt;

	Mode m_current_mode;

	colib::string m_last_error;

	//this function can be used by derived classes when a key has been exhausted
	//either based upon a timer, usage count, or iv/ctr exhaustion
//	void KeyExhaustedEvent();

//	unsigned int m_key_exhaustion_param;
//	unsigned int m_iv_seed_usage_counter;

};

inline EncryptionKey* TrielInterface::AllocKey()
{
	return new EncryptionKey;
}

inline const char* TrielInterface::GetLastError()
{
	return m_last_error;
}

inline TrielInterface::Mode TrielInterface::GetMode()
{
	return m_current_mode;
}

inline bool TrielInterface::Encrypt( EncryptionKey *key, EncryptionKey *iv, void *buffer, unsigned int buffer_size )
{
	return (this->*m_current_encrypt)(key,iv,buffer,buffer_size);
}

inline bool TrielInterface::Decrypt( EncryptionKey *key, EncryptionKey *iv, void *buffer, unsigned int buffer_size )
{
	return (this->*m_current_decrypt)(key,iv,buffer,buffer_size);
}
inline bool TrielInterface::NeedsPadding( Mode m )
{
	return (m < CFB);
}


} // end of namespace

#endif


