// cipher.h
// vi:set ts=4 sw=4 nowrap:

#ifndef cipher_h_already_included
#define cipher_h_already_included

#include <utils/string.h>
#include <crypt/key/aes_key.h>

namespace colib {

class CipherIntf {
public:
	CipherIntf() {}
	virtual ~CipherIntf() {}

	virtual bool Encrypt(const char* in, int in_len) = 0;
	virtual bool Decrypt(const char* in, int in_len) = 0;
	virtual char* GetData() = 0;
	virtual int GetDataLen() const = 0;
	virtual void SetDataLen(int len) = 0; 	
	colib::string GetLastError() const { return m_last_error; }
	void SetLastError(const colib::string& err) { m_last_error = err; }
private:
	colib::string m_last_error;
};

class B64CipherOP : public CipherIntf {
public:
	static const int MAX_OUT_LEN = 512;

	B64CipherOP() : m_out_len(0) {}

	void Reset() { m_out_len = 0; }
	virtual bool Encrypt(const char* in, int inLen);
	virtual bool Decrypt(const char* in, int inLen);

	virtual char* GetData() { return m_out; }
	virtual int GetDataLen() const { return m_out_len; }
	virtual void SetDataLen(int len) { m_out_len = len; }

private:
	int  m_out_len;
	char m_out[MAX_OUT_LEN];	
};


class AESCipherOP: public B64CipherOP
{
public:
	static const unsigned int DEFAULT_ID = 67;
public:

	AESCipherOP();
	
	static const int             PBKDF2_ITER = 36;
	static const uint64_t       PBKDF2_SALT;
	static const char*           PBKDF2_PASSPHRASE;
	
	virtual bool Encrypt(const char* in, int inLen);
	virtual bool Decrypt(const char* in, int inLen);

	bool GenerateAesKey(colib::string& error, unsigned int ID = DEFAULT_ID);

private:	

	unsigned char m_IV[AES_BLOCK_SIZE];
	SAESeKey m_aes_key;
	bool m_key_is_ready;
};

} // end of namespace
#endif

