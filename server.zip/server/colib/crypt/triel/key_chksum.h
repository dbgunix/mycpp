#ifndef KEY_CHKSUM
#define KEY_CHKSUM

namespace colib
{

unsigned int GenerateChksum(unsigned char *pKey, int keylen, bool bUpdate);
bool VerifyChksum(unsigned char *pKey, int keylen);

}

#endif

