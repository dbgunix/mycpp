//triel.cpp
//#include<utils/base_encoder.h>
//#include<utils/utils.h>
//#include<crypt/triel/key_chksum.h>
//#include<crypt/triel/b64_chk.h>

#include <crypt/triel/triel.h>
#include <crypt/rng/global_rng.h>
#include <utils/trace/trace.h>

#include <time.h>
#include <openssl/rand.h>
#include <memory>
#include <iostream>

namespace colib {

TrielInterface::TrielInterface() {
	m_current_mode = CBC;
	m_current_encrypt = &TrielInterface::EncryptCBC;
	m_current_decrypt = &TrielInterface::DecryptCBC;

//	m_key_exhaustion_param = 0;
}

TrielInterface::~TrielInterface() {
}

bool TrielInterface::SetMode(Mode to) {
	switch (to) {
	case CBC:
		m_current_encrypt = &TrielInterface::EncryptCBC;
		m_current_decrypt = &TrielInterface::DecryptCBC;
		break;
	case CFB:
		m_current_encrypt = &TrielInterface::EncryptCFB;
		m_current_decrypt = &TrielInterface::DecryptCFB;
		break;
	default:
		m_last_error = "Unsupported Cipher Mode";
		return false;
	}
	m_current_mode = to;
	return true;
}

//TODO: check if can be removed
bool TrielInterface::Init() {
	return true;
}

static struct { const char*a;TrielInterface::Mode b;} mode_names[]=
{
	{"ECB",TrielInterface::ECB},
	{"CBC",TrielInterface::CBC},
	{"CFB",TrielInterface::CFB},
	{"OFB",TrielInterface::OFB}
};

static const size_t num_modes = sizeof(mode_names)/sizeof(mode_names[0]);

bool TrielInterface::SetMode( colib::string to )
{
	for(size_t at=0; at<num_modes; ++at)
	{
		if( 0 == strcmp(to.c_str(),mode_names[at].a) )
		{
			return SetMode(mode_names[at].b);
		}
	}
	m_last_error=colib::string::Format("Unknown Cipher block mode \"%s\"", to.c_str() );

	return false;
}
bool TrielInterface::IsModeSupported( colib::string mode )
{
	for(size_t at=0; at<num_modes; ++at)
	{
		if( 0 == strcmp(mode.c_str(),mode_names[at].a) )
		{
			return IsModeSupported(mode_names[at].b);
		}
	}
	return false;
}
colib::string TrielInterface::GetModeName()
{
	return mode_names[GetMode()].a;
}

/*
bool TrielInterface::SetKeyExhaustion( unsigned int param )
{
	if( param == 0 && m_current_mode == CTR )
		//when in CTR mode, we cannot disable key exhaustion
		return false;

	m_key_exhaustion_param = param;
	return true;
}
*/
} // end of namespace
