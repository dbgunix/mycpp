//kat.cpp
// vi:set ts=4 sw=4 nowrap:

#include <stdio.h>
#include <crypt/fips/rng_kat.h>
#include <crypt/rng/global_rng.h>
#include <crypt/fips/fips.h>

#ifdef HARDWARE_IXP
#include <openssl/rand.h>
#include <openssl/fips_rand.h>
#else
//only here for test comment out for release
//#include </opt/crosstool/armv5b-linux/armv5b-linux/include/openssl/rand.h>
//#include </opt/crosstool/armv5b-linux/armv5b-linux/include/openssl/fips_rand.h>
#endif

namespace colib {

bool Run_Global_PRNG_KAT( Writable *status_output )
{
#ifdef HARDWARE_IXP
	colib::string err;
	if( ! FIPS_selftest_rng() )
	{
		colib::SetErrorState(
			colib::string::Format( "Failed PRNG KAT") );

		status_output->Print( "%s\n", colib::CryptoErrorStatus().c_str() );
		return false;
	}

	status_output->PrintString( "OK\n"  );
	return true;
#else
	status_output->PrintString("No KAT available...");
	return true;
#endif
}

} // end namespcae
