//hmac_sha1_key.h
// vi:set ts=4 sw=4 nowrap:


namespace colib
{

	bool hmac_sha1_KAT(void);

} // end namespace colib
		
