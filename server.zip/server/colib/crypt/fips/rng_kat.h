//kat.h
// vi:set ts=4 sw=4 nowrap:

#ifndef RNG_KAT_H_ALREADY_INCLUDED
#define RNG_KAT_H_ALREADY_INCLUDED

#include <utils/trace/writable.h>

namespace colib {

bool Run_Global_PRNG_KAT( Writable *status_output );

} // end of namespace
#endif

