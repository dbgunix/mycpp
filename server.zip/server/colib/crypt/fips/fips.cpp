//fips.cpp
// vi:set ts=4 sw=4 nowrap:

#include <crypt/fips/fips.h>
#include <version/version.h>
#include <version_registrar/version_registrar.h>
//#include "utils/options.h"
#include <config/fips.h>

#include <stdarg.h>

namespace colib
{

static bool g_in_error_state=false;
static string g_crypto_error_status;

string CryptoErrorStatus()
{
	return g_crypto_error_status;
}

bool InErrorState()
{
	return g_in_error_state;
}
void SetErrorState( string desc )
{
	g_in_error_state=true;
	g_crypto_error_status += desc;

}

void SetErrorStateFmt(const char *fmt, ... )
{
	va_list args;
	va_start (args,fmt);
	string desc = string::vFormat(fmt,args);
	va_end(args);

	SetErrorState(desc);
}

void ConCmdFIPSStatus(void *ctx, Writable *con, int argc, char* argv[])
{
	//reviewed by Chao Liu, this function has no CSP implications
	(void)ctx;
	(void)argc;
	(void)argv;
	//print some global status information
	con->Print("%s\n", VersionRegistrar::GetInstance().GetApplicationName());

	if( InFipsMode() )
	{
		con->PrintString("FIPS mode on" "\n" );
	}
	else
	{
		con->PrintString("Not in FIPS mode" "\n" );
	}
	//print status
	if( InErrorState())
	{
		con->Print("Error Status mode" 
				": %s", colib::CryptoErrorStatus().c_str() );
	}
}

}//namespace colib

