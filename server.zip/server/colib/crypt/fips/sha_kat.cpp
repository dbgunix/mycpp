//sha1.cpp
// vi:set ts=4 sw=4 nowrap:

#include <crypt/sha/sha.h>
#include <utils/utils.h>
#include <utils/base_encoder.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <memory>

namespace colib {

static void hex_hash(int hashlen,unsigned char* hash,char* buf)
{
	for(int at=0;at<hashlen;++at)
	{
		buf+=sprintf(buf,"%02X",*hash++);
	}
	*buf=0;
}

typedef void (*phashfunc)(const unsigned char *data, unsigned long byte_len, unsigned char *output);

static bool DO_SHA_KAT( phashfunc func, int byte_hash_len, const char **vectors, const char**expected )
{
	int test_num = 0;

	while(vectors[test_num] != 0)
	{
		const char* test_msg = vectors[test_num];
		size_t len = strlen(test_msg);
		unsigned int mssgbflen = BaseEncoder::GetColibDecode64Len(len);

		std::unique_ptr<unsigned char[]> message_buf(new unsigned char [mssgbflen]);
		std::unique_ptr<unsigned char[]> observed_hash(new unsigned char [byte_hash_len+1]);
		std::unique_ptr<char[]> observed_hex_hash(new char [2*byte_hash_len+1]);

		if(!message_buf ||!observed_hash ||!observed_hex_hash)
			return false;

		if(BaseEncoder::Decode64Colib(message_buf.get(), mssgbflen, test_msg, strlen(test_msg)) <= 0 )
		{
			return false;
		}

		func(message_buf.get(),mssgbflen,observed_hash.get());
		
		hex_hash(byte_hash_len,observed_hash.get(),observed_hex_hash.get());
		if(strcmp(observed_hex_hash.get(), expected[test_num]))
		{
			return false;
		}
		test_num++;
	}
	return true;
}



static const char* sha1_test_vectors[] =
{
	".Y",
	"..s6./zw.5zzgzy/zz..5zs5k..k.1.1zwy1w.Dzs..",
	"..Dzzw..z5U..0./s..4/z.zs../zzU/zs..1zzs...zz..5zzk5zU.zk.zzTzzk..5z...zzzsTzzU.zs...T",
	"zU..TzTzzk..1zzzs.5zs....zzU.Dzy..5zxzzs..zz....C..5zzU5zzk.5zzz1w5zzw..zzwDzz./zzU..TzzU...1zU.DzzyDzzzw...C.z1zzzz5zz.Dzzzs...",
	"Dzzzk...w....5zzzU....Dzzzz...D..1zzzW..DU.1w....1U....zzzzy.zzzzs../U..5zzzzw...Dzzzw.Tzzzz..1k...1zzzzz../zzzU.5zzzzU..zzzUTzzzU.zzzzk....y../zzk1zzk..1zzzVzk.D.DzzU....",
	0
};
static const char* sha1_expected_hash[] =
{
	"3CDF2936DA2FC556BFA533AB1EB59CE710AC80E5",
	"74C4BC5B26FB4A08602D40CCEC6C6161B6C11478",
	"86BE037C4D509C9202020767D860DAB039CADACE",
	"BE88A6716083EB50ED9416719D6A247661299383",
	"EDE4DEB4293CFE4138C2C056B7C46FF821CC0ACC",
	0
};

bool iDirect_sha1_KAT(void)
{
	return DO_SHA_KAT( &iDirect_sha1, SHA_DIGEST_LENGTH, sha1_test_vectors, sha1_expected_hash );
}

static const int SHA512_BYTE_HASH_LENGTH =  64;

//b64 encoded:
static const char* sha512_test_vectors[] =
{
	"MK7X"
	,
	"/VMaBYNKNbO47XN4JaNqVdMqFZNaRcOKdYNKNbO4ZeOqJaNqVdOahgNaRcOKdfP4pbO4ZeOqlhPaVdOahgPKtjOKdfP4piPr/eOqlhPaxkQ"
	"KhgPKtjQ53mP4piPr/lQbBhPaxkQL7nR4tjQ53mQrFp"
	,
	"5mY4CamBItX9kDGJJeS7Xr/YtRy/dPDG39KUNlPMEAPeAfVZ5JPZ38XPA1HFDsbARstALmOuEsb4UX1cOC3rh6HzbfJAM3ofXxk4QnSp1v"
	"h.V87/.px.BbW8x7BYHbzERTcnS1L4MIWHkkm3mcJopxkHlPuIQFQ8QVuwx45rAM.3HL2CYWRh2kLfTQIB2.MGIxbBcrS5NjyT6REB1arv"
	"/49ZRG/j4y22KMefoY27nzMAoN3i9GdapabM.E9XLwBmLJ7Ej3M5CeJ7xznjV9nHgpKRAisgZmCO55Fok1Irt2VhRKrzAIJ5Gay8UfIOAB"
	"ZgcCd3K4HQ9TOePj1DDa1pShwjL.fCGYZ/b0zOVN.l9XnQN9BuFPLVG9AVutzb1SYw1dhl8RQEuDLtMVeOgAqaAdpGD8CB9B0qqv/P/mZ7"
	"hL5u44x5o.xgdv0X5G4RKPMeUmPXWXiH95wlg8QZLvzSocqffefsYZoe0JXFX99Gtb0NEZsZojpr3j1Dj0cGAfhfhN1eXUvwHylaUtJvFA"
	"FpuVyfDQumhWEJ4Z4OvyKvgD4Hy8Mp9wbiEyHETZBzFXcBRxpN/hNDCTqxUhNTr6Qhn3XjGKRe31tvq3/Du7XIOhQJ5edsT6SSloy6rZjp"
	"rSAi3/lFpG4NVP6mc2E3H6QkVQd6fKje/x0NOdBnVU5BjfX7wcSFqZDInAucVi5eoxyphstDsFgvV1VommR.y4afD9D6TMSf5KOR3N1eq6"
	"2/SwHe/s0k38yIUqslScgIWtPKC2gGqUkIxk70O868IB9HVzIG4/155MuVv6w8ITqosrVtK7GnUR3zv/3HVDmv7sS.mb/YUcKwb.UubG7A"
	"lZHoZ4rtpXOUPGR.Yo2EtbpiyGDx7UW0Vv42lxnDNG7jOzJPZbhsEBCVeWu.EWZoMW.4n0u/0og1oXCdOwUr68xRuAq3jJWRJUQOVo3RyT"
	"vZjCMoZI3vx71c.fq9ECL2QcsVRvel9suZ/CgQI0QZMfAVN0YUl.tR4VL7McnlZxs6ta3UGvyjsalJj5ty4YQL8s9ZrDlqcGxrCZvnc1mi"
	"LVib9MIqmbvJfmQXvDWZvWqfQ/RiOU/4KbmF.XXnNA7sN24YhM/kGO6EM8MkkWpBCp/ZwIoJsgLAnlozdLjirOVjFrDL1CBYCrReDMOtpT"
	"3Rs/3BQxUgtudTt1qU4Ggzfpo4d/3GbL2BOS1yZgmxsgrKeeCt2ulZ2vwkKFZPPmuz07n72GkKx4uTMcOkbBPRV01fasZgMWOq9EzZu85F"
	"aXu6eSdbk9s2oo.VOoUQ5ulVHqdOyv0AdCBQRauiPksiAWDykNkhoNatyBfXqI6k2jN9b2BU7SeZwscmldDm2C77YbuGDUagNJfDwN61qA"
	"66viuboTSXvqiSSe1NfunTAhM.v82hY7zZgyVjHxq/5aazpcIuYWChomcDorw"
	,
	0
};

//hex encoded:
static const char* sha512_expected_hash[] =
{
	"DDAF35A193617ABACC417349AE20413112E6FA4E89A97EA20A9EEEE64B55D39A"
	"2192992A274FC1A836BA3C23A3FEEBBD454D4423643CE80E2A9AC94FA54CA49F"
	,
	"8E959B75DAE313DA8CF4F72814FC143F8F7779C6EB9F7FA17299AEADB6889018"
	"501D289E4900F7E4331B99DEC4B5433AC7D329EEB6DD26545E96E55B874BE909"
	,
	"EBAD464E6D9F1DF7E8AADFF69F52DB40A001B253FBF65A018F29974DCC7FBF8E"
	"58B69E247975FBADB4153D7289357C9B6212752D0AB67DD3D9BBC0BB908AA98C"
	,
	0
};

bool iDirect_sha512_KAT(void)
{
	return DO_SHA_KAT( &iDirect_sha512, SHA512_BYTE_HASH_LENGTH, sha512_test_vectors, sha512_expected_hash );
}

static const int SHA256_BYTE_HASH_LENGTH =  32;
//NIST test vector "abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq"
// iDirect::Base64iDirect::Encode64 -  "43WMqFWMqFZMqFZNaFZNaRZNaRcNaRcOKRcOKdcOKdfOKdfP4dfP4pfP4piP4piPqpiPr/iPr/l"
//TODO: add more test vectors
static const char* sha256_test_vectors[] =
{
	"43WMqFWMqFZMqFZNaFZNaRZNaRcNaRcOKRcOKdcOKdfOKdfP4dfP4pfP4piP4piPqpiPr/iPr/l",
	0
};
//NIST test result
static const char* sha256_expected_hash[] =
{
	"248D6A61D20638B8E5C026930C3E6039A33CE45964FF2167F6ECEDD419DB06C1",
	0
};

bool iDirect_sha256_KAT(void)
{
	return DO_SHA_KAT( &iDirect_sha256, SHA256_BYTE_HASH_LENGTH, sha256_test_vectors, sha256_expected_hash );
}





} // end of namespace
