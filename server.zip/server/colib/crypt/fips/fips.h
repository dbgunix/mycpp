//fips.h
// vi:set ts=4 sw=4 nowrap:

#ifndef FIPS_H_ALREADY_INCLUDED
#define FIPS_H_ALREADY_INCLUDED

#include <utils/system/environ.h>
#include <utils/string.h>
#include <utils/trace/writable.h>

namespace colib
{

bool InErrorState();
void SetErrorState(string desc);
void SetErrorStateFmt(const char *fmt, ... );
string CryptoErrorStatus();

void SetFipsStatus(bool status);

bool PerformAllRelevantKATs( Writable *status_output );

//fips status command
void ConCmdFIPSStatus(void *ctx, Writable *con, int argc, char* argv[]);

}//namespace colib

#endif

