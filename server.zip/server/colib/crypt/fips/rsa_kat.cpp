//kat.cpp
// vi:set ts=4 sw=4 nowrap:

#include <crypt/fips/rsa_kat.h>
#include <crypt/rng/global_rng.h>
#include <crypt/fips/fips.h>
#include <crypt/pki/format/idirect_krec.h>
#include <utils/base_encoder.h>

namespace colib
{

static const char *privkey=
"--IDIRECT_KEY_BEGIN--\n\
Comment: This private key is for Known Answer Testing only\n\
Type: IDIRECT_KEY_RSA_PRIVKEY\n\
.../.E17fmO1S4OANgV.A/kDigMAfO617GCiis.4.qAvXlRHmDGl2RCI1z5pVHjwi4y4Vhr6or0Necx\n\
eEgPUtQ1etclfPIN0rP1IQCHTJ9dloLUCMZkDLj28//9uLqX60zcN1cTupzq4nMeQKqoFytqvphHl61\n\
tQ1j8o5rq4wToSgg1v/jt.b.B9pv.ZlYnCHC4HANZ2FgIGoQQJKFE0Ebjmii3noZ4PoL3LhycvjSAg1\n\
X5ByShQXk84nUFu9xNveIg5fk1gJUq/HSkMjaiv4cnhrOTu4P0Gp65Qr./xrXPjbzr7Zz2lwSMntpc0\n\
5ZlntM0xZ2fzhpuO4f4tHqBUAwv3FADr.....k2..E...E2.kMeKHzKvam898eL.K.jdE6BXVBQU5Sw\n\
8pHdh.Bit1.gxLOfsiUtj80VODtEGKWiI8wBICz8YCxab3ao2euPUiveOUJ7GzVfoJuXgLcgUFRJry9\n\
kcLKwtQl2NwJQZ.iGVwoBEdEgPu/s6JUVuzeMHdCp5Gbe/lzug938CXyM2AFxrBkn9Hjl7UPOIqiF.q\n\
kOnf1guDzLV1y3SmPm4tTprRLiuzIKWIIGE6m4Kht21TKQA9w5jdX5F6socJZFDt7kYUYFDCPWcAZW.\n\
Dz20Y7L4zyRg2uXSnbZ9IfXVDhfF91KRNrjq1/IhA0wc.ahj2M5Yi479.W/OUMEjZjrv1H2YKE...62\n\
.zGmDg1WAAr6DYGbkXIbwhu8sBjMVNC1yCy0AwUqI4DOOEQmMVuZUxOucDfdk.kSZRUtchn0bsyBjap\n\
mUiI/xzJg/WZqWVKA.hB75zVBTVPs.FKwHEKqMvQWfl9YWwajno8MPKkW4JnivSLlFRMAJsbkDeN2m/\n\
0LTSn0svDpNuVI...0/.AjjRIDsQsgG97o2SIBxMrV7AP.TuuFlzoqcu/O7kmvt6nDFEIedQcQ3j5u1\n\
YSwehlfkg6d8Rj.mNEodh0dz8QSpRDHQbrNlGQ7/bPRWfBIYubQ6XpASz7/cw3Qy47JTUeQGf2kaBJq\n\
D.JToj1bboYL4QxXGD4xGKgTAg7jM85HP....U2Lby.I.a1LQKB.AR6yCnaYaJFRLzk09ruR6uO6gTO\n\
Uavt2PbI7MIdq21713WUVA71DYteIiaWoWfvu4NFf/t.U/0DjPjjFpoQkQ/0Hnp5ldOYb/oRxD2xgIT\n\
RZY/L78j7TkFPph9Gg76ofsCALdr12RQ5KloQqnNr5gYWBS2KL/....U21MY7cTKqMWHYhHGxTMz/AM\n\
SlAwsmbo2P2szmi1T8jc1bW.ZZZCHVhz05DK32NDRwyu9jWOCjqTa8.trMwFlZ.tQwcIWGENKx564MJ\n\
VT.3yPciF1Xbd/LV7pTdrlIhW/a7bjdyg4dLsHTsEpDIsg7HxG69iDgR92N0gZcz5WDqr....U3zmNI\n\
8vVJIRWngFPJwbWHaJXRQuAb6ugZG8PH6qq6uytMesc.UGR3HeZ07FSD8AcUlj7gYCBwgcG3gYjoBHy\n\
9S/zyI3.KUAZK2UEbhVrJjbvpmBeV7/zw7UTtJJll8ysXjYT2pXsX1NR.bMIPQHk1xpngU4Tr6QWtz/\n\
rLZt2OzB\n\
\n\
--IDIRECT_KEY_END--\n\
";

static const char *secret_message_b64= 
"J4VdQm/dQm/V65BVPL/gNG/dPb/pR0/YMLFV647gPqBf9Ud7R0/rOKlg647Z64BjPbNZQbFZN0/oPm/\
WBXEUN43oMG/oPkdWNG/pQqJY643n642UPKJnQq3bNG/oPm/ZPaBmSL/o65RdR4UUQbBV8r/fMrA8";
static const char *expected_encrypt_b64=
"106jvNbHswZBCgbUHPbwyE4pgl9MD16l1KrsZ/HAxPB9q9xUFbhTYnuK990J7wRbSyD9TNuYmyXomcEJ\
W653PbAW495j3qm8UCpi7jds9w.KMJYNPhPfS5ByQEhcA4HMdt33oC6zd4H0IeIEFRK5C9XfSr7AK6aLv\
YSUPDXl3ktJH6c.V9aJT5X5A8EdEFL4tWJWa4oCOpALifIJ3QXOPS.Dc0/VvRC4ZvsSm43yjiAY1pCRAz\
.HpsBSJmTc9Hg9dD0k.1cJkuMe6xeZ4eaVSLRPVQmxCVl572pv5hPt1rb/DHygeR.1K43w25psHHaFj91\
a5hcQlCkAyyzRIU0AW4";

static const char *secret_message_hash_b64= "AJmJDHZ6sHG4oskHWopl1BRsQB0";
static const char *expected_signature_b64=
".9ftxoP7/qsErKpj8huFM9GuLRtYzcrJKIka5g1G0WcO4Hkhwou6aVUQSMwVyqoR81wzItgduQc0sP9h\
ccZ2nx0Q/MtKSA6Mb3iP.Vv73q6.zWuZjJsw30Yoe809VsZTmBpHdM7MIma4/wNWE4fLS0.P4JWu0d7dJ\
S1LlLSGSOMHjrOkYZ72K1k4zoXQYG2s8UvUjrvZIVv2NtJB4HzzQ0IJRoIUBBpGL/o7q2Ga7YzdxxWe0m\
HLUsw9PfVV/dDWS3L.lyB9TB46JcBca2hdNEmtEpSgwSygaj/QbYX9yVGSCjKbDi3RETvX3z2xDAbSkSD\
N2Ej/e3Q/9oUY93maei";

static void hex_dump( Writable *pwrit, unsigned char *data, unsigned int len, const char *name )
{
	pwrit->Print("%s:\n", name);
	for(unsigned int at=0;at<len;++at)
	{
		pwrit->Print((at+1)%5?"%02X":"%02X ",*data++);
	}
	pwrit->PrintString("\n");
}

bool Run_RSA_KATs(Writable *status_output )
{
	KeyRecord kr;
	RsaIf rsa,*prsa=&rsa;

	if(!rsa.Init())
	{
		SetErrorState( string( "RSA Init Failed:")+rsa.GetLastError());
		status_output->Print( "%s\n", CryptoErrorStatus().c_str() );
		return false;
	}
	rsa.SetPaddingMode(AsymIf::PADMODE_NONE);
	
	status_output->PrintString("Running RSA KAT...");

	string err;
	if(!kr.Load( string(privkey,false).c_str(), err ) )
	{
		SetErrorStateFmt( "RSA KAT Failed: Failed to parse key: %s", err.c_str() );
		status_output->Print( "%s\n", CryptoErrorStatus().c_str() );
		return false;
	}
	if(!kr.ApplyKeytoAsym(prsa,err))
	{
		SetErrorStateFmt("RSA KAT Failed: Failed to parse key: %s", err.c_str() );
		status_output->Print( "%s\n", CryptoErrorStatus().c_str() );
		return false;
	}

	EncryptionKey binary[4];
	unsigned char *b64text[]=
		{(unsigned char*)secret_message_b64,
		 (unsigned char*)expected_encrypt_b64,
		 (unsigned char*)secret_message_hash_b64,
		 (unsigned char*)expected_signature_b64};

	//Recover Binaries from B64 encoded strings
	for( int at=0; at<4; ++at)
	{
		unsigned int b64len = strlen((const char*)b64text[at]);
		unsigned int binlen = (unsigned int)BaseEncoder::GetColibDecode64Len(b64len);

		if( !binary[at].Reallocate(binlen) )
		{
			SetErrorState("RSA KAT Failed: Failed: oom!\n");
			status_output->Print( "%s\n", CryptoErrorStatus().c_str() );
			return false;
		}

		if(BaseEncoder::Decode64Colib(binary[at].GetData(), binlen, (const char*)b64text[at], strlen((const char*)b64text[at])) <= 0)
		{
			SetErrorState("RSA KAT Failed: Failed to unb64\n");
			status_output->Print( "%s\n", CryptoErrorStatus().c_str() );
			return false;
		}
	}

	EncryptionKey skpad,sk2pad;
	unsigned int rezlen = prsa->GetRequiredSpace();
	if(!skpad.Reallocate(rezlen) || !sk2pad.Reallocate(rezlen))
	{
		SetErrorState("RSA KAT Failed: Failed: oom!\n");
		status_output->Print( "%s\n", CryptoErrorStatus().c_str() );
		return false;
	}
	unsigned char *rezpad=skpad.GetData();
	unsigned char *recpad=sk2pad.GetData();
	int res;
	unsigned int origsz;
	EncryptionKey origb0;

	//pad out secret message to size 256
	origb0.Copy(binary[0]);

	{
		unsigned int len = binary[0].GetLength();
		origsz = len;
		EncryptionKey temp;
		if( !temp.Reallocate(256) )
		{
			SetErrorState("RSA KAT Failed: Failed: oom!\n");
			status_output->Print( "%s\n", CryptoErrorStatus().c_str() );
			return false;
		}
		memcpy(temp.GetData(),binary[0].GetData(),len);
		memset(temp.GetData()+len,0,256-len);

		binary[0].Copy(temp);
	}

	//Run Encrypt Algorithm
	if( prsa->public_encrypt(binary[0].GetLength(),binary[0].GetData(),rezpad)<0 )
	{
		SetErrorStateFmt("RSA KAT Failed: Failed to RSA Enc process: %s\n", prsa->GetLastError() );
		status_output->Print( "%s\n", CryptoErrorStatus().c_str() );
		return false;
	}

	//Decrypt
	if(	(res=prsa->private_decrypt(rezlen,rezpad,recpad))<0 )
	{
		SetErrorStateFmt("RSA KAT Failed: Failed to RSA Dec process: %s\n", prsa->GetLastError() );
		status_output->Print( "%s\n", CryptoErrorStatus().c_str() );
		return false;
	}

	//unpad secret message to original size
	{
		//truncate result, (assumes the size works out)
		res=origsz;
		binary[0].Copy(origb0);
	}

	//Check if expected output matches
	//Check if result matches original
	if( (unsigned int)res!=binary[0].GetLength() )
	{
		SetErrorStateFmt("RSA KAT Failed: RSA dec output length doesnt match (got %u, expected %u)\n",
				res,binary[0].GetLength() );
		status_output->Print( "%s\n", CryptoErrorStatus().c_str() );
		return false;
	}
	if( 0!=memcmp(binary[0].GetData(),recpad,res) )
	{
		SetErrorStateFmt("RSA KAT Failed: RSA dec output doesnt match (sz=%u)\n", res );
		status_output->Print( "%s\n", CryptoErrorStatus().c_str() );
		hex_dump(status_output,binary[0].GetData(),res,"Expected");
		hex_dump(status_output,recpad,res,"Got");
		return false;
	}
	if( rezlen!=binary[1].GetLength() )
	{
		SetErrorStateFmt("RSA KAT Failed: RSA enc output length doesnt match (got %u, expected %u)\n",
				rezlen,binary[1].GetLength() );
		return false;
	}
	if( 0!=memcmp(binary[1].GetData(),rezpad,rezlen) )
	{
		SetErrorState("RSA KAT Failed: RSA enc output doesnt match\n" );
		status_output->Print( "%s\n", CryptoErrorStatus().c_str() );
		hex_dump(status_output,binary[1].GetData(),20/*rezlen*/,"Expected");
		hex_dump(status_output,rezpad,20/*rezlen*/,"Got");
		hex_dump(status_output,binary[0].GetData(),binary[0].GetLength(),"Original input");
		return false;
	}


	//Run Sign Algorithm
	//Verify
	if( prsa->private_encrypt(binary[2].GetLength(),binary[2].GetData(),rezpad)<0 )
	{
		SetErrorStateFmt("RSA KAT Failed: Failed to RSA Sign: %s\n", prsa->GetLastError() );
		status_output->Print( "%s\n", CryptoErrorStatus().c_str() );
		return false;
	}
	if( (res=prsa->public_decrypt(rezlen,rezpad,recpad))<0 )
	{
		SetErrorStateFmt("RSA KAT Failed: Failed to RSA Verify: %s\n", prsa->GetLastError() );
		status_output->Print( "%s\n", CryptoErrorStatus().c_str() );
		return false;
	}

	//Check if expected output matches
	//Check if result matches original
	if( rezlen!=binary[3].GetLength() )
	{
		SetErrorStateFmt("RSA KAT Failed: RSA Signature output length doesnt match (got %u, expected %u)\n",
				rezlen,binary[3].GetLength() );
		status_output->Print( "%s\n", CryptoErrorStatus().c_str() );
		return false;
	}
	if( 0!=memcmp(binary[3].GetData(),rezpad,rezlen) )
	{
		SetErrorState("RSA KAT Failed: RSA Signature output doesnt match\n" );
		status_output->Print( "%s\n", CryptoErrorStatus().c_str() );
		hex_dump(status_output,binary[3].GetData(),rezlen,"Expected");
		hex_dump(status_output,rezpad,rezlen,"Got");
		hex_dump(status_output,binary[2].GetData(),binary[2].GetLength(),"Original input");
		return false;
	}
	if( (unsigned int)res!=binary[2].GetLength() )
	{
		SetErrorStateFmt("RSA KAT Failed: RSA Verify output length doesnt match (got %u, expected %u)\n",
				res,binary[2].GetLength() );
		status_output->Print( "%s\n", CryptoErrorStatus().c_str() );
		return false;
	}
	if( 0!=memcmp(binary[2].GetData(),recpad,res) )
	{
		SetErrorState("RSA KAT Failed: RSA Verify output doesnt match\n" );
		status_output->Print( "%s\n", CryptoErrorStatus().c_str() );
		hex_dump(status_output,binary[2].GetData(),res,"Expected");
		hex_dump(status_output,recpad,res,"Got");
		return false;
	}

	status_output->PrintString( "OK\n"  );
	return true;
}
	
}//end namespace colib

