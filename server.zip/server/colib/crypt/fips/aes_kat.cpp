//kat.cpp
// vi:set ts=4 sw=4 nowrap:

#include <crypt/fips/aes_kat.h>

#include <crypt/key/aes_key.h>
#include <crypt/triel/triel_openssl_aes.h>
#include <options/options_node.h>

namespace colib
{

static const unsigned char ekey_raw[]=
{0x70, 0xE3, 0xE9, 0xF4, 0x85, 0xDC, 0xD5, 0x23,
0xF1, 0x1F, 0xEF, 0xA7, 0x04, 0x0D, 0x51, 0x57, 
0x49, 0x20, 0x1C, 0xD5, 0xCE, 0xF7, 0xBC, 0xF4 }; 

static const unsigned char iv_raw[]=
{0xEB, 0x39, 0x55, 0xC6, 0x52, 0x2C, 0xF6, 0x75};

static void hex_dump( Writable *pwrit, unsigned char *data, unsigned int len, const char *name )
{
	pwrit->Print("%s:\n", name);
	for(unsigned int at=0;at<len;++at)
	{
		pwrit->Print((at+1)%5?"%02X":"%02X ",*data++);
	}
	pwrit->PrintString("\n");
}

bool Run_AES_CFB_KAT(Writable *status_output);

bool Run_AES_KATs(Writable *status_output)
{
	TrielInterface* posslaes = new TrielOsslAes;

	if (!posslaes)
		return false;

	if (!posslaes->Init()) // empty options node
	{
		delete posslaes;
		return false;
	}

	bool result = Run_AES_CBC_KAT(posslaes, status_output) && 
			posslaes->SetMode("CFB") &&
			Run_AES_CFB_KAT(status_output);

	delete posslaes;

	if (!result)
	{
		return false;
	}

	return result;
}

bool Run_AES_CBC_KAT(TrielInterface *ptriel, Writable *status_output)
{
   	// test vector is from http://csrc.nist.gov/cryptval/des.htm, 
	// AES test vectors CBCKeySbox256.fax

	colib::string ciph_mode_name = ptriel->GetCipherName() + "-" +ptriel->GetModeName();
	const char *name=ciph_mode_name.c_str();

	status_output->Print("Running %s KAT...", name);

	unsigned char key[] = {
	   	0xc4,0x7b,0x02,0x94,0xdb,0xbb,0xee,0x0f,
		0xec,0x47,0x57,0xf2,0x2f,0xfe,0xee,0x35,
		0x87,0xca, 0x47,0x30,0xc3,0xd3,0x3b,0x69,
		0x1d,0xf3,0x8b,0xab,0x07,0x6b,0xc5,0x58
	};
	unsigned char iv[] = {
	   	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
		0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00
	};
	unsigned char plain_text[] = {
	   	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
		0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00
	};
	unsigned char cipher_text[] = {
	   	0x46,0xf2,0xfb,0x34,0x2d,0x6f,0x0a,0xb4,
		0x77,0x47,0x6f,0xc5,0x01,0x24,0x2c,0x5f
	};

	const unsigned int eKeySZ=32;
	const unsigned int eIVSZ=16;
	EncryptionKey *eKey = ptriel->AllocKey();
	EncryptionKey eIV;
	if ( !eKey )
	{
		status_output->PrintString("Fail to allocate encryption key\n");
		return false;
	}
	if (!eKey->Reallocate(eKeySZ) ||
		!eIV.Reallocate(eIVSZ) )
	{
		status_output->PrintString("Failed: oom!\n");
		delete eKey;
		return false;
	}

	eKey->SetData(eKeySZ, key);
	eIV.SetData(eIVSZ,iv);

	unsigned char enc_res[16];

	memset(enc_res, 0, 16);

	//encryption
	if(!ptriel->EncryptCBC(eKey, &eIV, enc_res, sizeof(enc_res)) )
	{
		status_output->Print("Failed to encrypt: %s\n", ptriel->GetLastError() );
		delete eKey;
		return false;
	}

	if ( memcmp(cipher_text, enc_res, 16) )
	{
		status_output->Print("AES CBC test failed: Encrypted cipher does not match\n");
		hex_dump(status_output, cipher_text, 16, "Expected");
		hex_dump(status_output, enc_res, 16, "Got");
		delete eKey;
		return false;
	}


	//decryption
	//reset IV if was corrupted
	eIV.SetData(eIVSZ,iv);
	if(!ptriel->DecryptCBC(eKey, &eIV, enc_res, sizeof(enc_res)) )
	{
		status_output->Print("Failed to encrypt: %s\n", ptriel->GetLastError() );
		delete eKey;
		return false;
	}

	if ( memcmp(plain_text, enc_res, sizeof(enc_res)) )
	{
		status_output->Print("AES CBC test failed: Decrypted text does not match\n");
		delete eKey;
		return false;
	}


	status_output->Print("AES CBC test OK\n");
	delete eKey;
	return true;
}

bool Run_AES_CFB_KAT(Writable *status_output)
{
   	// test vector is from http://csrc.nist.gov/cryptval/des.htm, 
	// AES test vectors CFB128KeySbox256.fax

	unsigned char key[] = {
	   	0x28,0xd4,0x6c,0xff,0xa1,0x58,0x53,0x31,
		0x94,0x21,0x4a,0x91,0xe7,0x12,0xfc,0x2b,
		0x45,0xb5,0x18,0x07,0x66,0x75,0xaf,0xfd,
		0x91,0x0e,0xde,0xca,0x5f,0x41,0xac,0x64
	};
	unsigned char iv[] = {
	   	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
		0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00
	};
	unsigned char plain_text[] = {
	   	0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
		0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00
	};
	unsigned char cipher_text[] = {
	   	0x4b,0xf3,0xb0,0xa6,0x9a,0xeb,0x66,0x57,
		0x79,0x4f,0x29,0x01,0xb1,0x44,0x0a,0xd4
	};

	AES_KEY enc_ctx;
	AES_KEY dec_ctx;
	AES_set_encrypt_key(key, 256, &enc_ctx);
	AES_set_decrypt_key(key, 256, &dec_ctx);

	unsigned char enc_res[16];
	unsigned char dec_res[16];
	unsigned char temp_iv[16];

	memset(enc_res, 0, 16);
	memset(dec_res, 0, 16);

	//encryption
	int num = 0;
	memcpy(temp_iv, iv, 16);
	AES_cfb128_encrypt(
		plain_text,
		enc_res,
		16,
		&enc_ctx,
		temp_iv,
		&num,
		1);
	if ( memcmp(cipher_text, enc_res, 16) )
	{
		status_output->Print("AES CFB test failed: Encrypted cipher does not match\n");
		hex_dump(status_output, cipher_text, 16, "Expected");
		hex_dump(status_output, enc_res, 16, "Got");
		return false;
	}

	//decryption
	num = 0;
	memcpy(temp_iv, iv, 16);
	AES_cfb128_encrypt(
		cipher_text,
		dec_res,
		16,
		&enc_ctx, //key (we pass the encrypt context here)
		temp_iv,
		&num,
		0);
	if ( memcmp(plain_text, dec_res, 16) )
	{
		status_output->Print("AES CFB test failed: Decrypted text does not match\n");
		return false;
	}

	status_output->Print("AES CFB test OK\n");
	return true;
}

} //end namespace colib

