//kat.h
// vi:set ts=4 sw=4 nowrap:

#ifndef RSA_KAT_H_ALREADY_INCLUDED
#define RSA_KAT_H_ALREADY_INCLUDED

#include <crypt/asymif/rsaif.h>
#include <utils/trace/writable.h>

namespace colib
{

bool Run_RSA_KATs( Writable *status_output );
	
}//end namespace colib

#endif

