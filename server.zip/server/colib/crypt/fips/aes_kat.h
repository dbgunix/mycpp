//kat.h
// vi:set ts=4 sw=4 nowrap:

#ifndef TRIEL_KAT_H_ALREADY_INCLUDED
#define TRIEL_KAT_H_ALREADY_INCLUDED
#include <crypt/triel/triel.h>
#include <utils/trace/writable.h>
#include <utils/system/environ.h>

namespace colib
{

#ifdef PLATFORM_LINUX
bool Run_AES_CBC_KAT(TrielInterface *ptriel, Writable *status_output);
bool Run_AES_KATs(Writable *status_output);
#endif
	
} //end namespace colib

#endif

