//hmac_sha1_KAT.cpp
// vi:set ts=4 sw=4 nowrap:

#include <utils/base_encoder.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <openssl/sha.h>
#include <openssl/hmac.h>

namespace colib
{

static const char *test_vectors[] =
{
	"Iq3hQ4lZ60Al",
	"Iq3hQ4lZ60Am",
	"Iq3hQ4lZ60An",
	0
};
static const char *key_vector[] =
{
	"...E61/.I4/kU70UgA1EsD2/2G2lEJ3VQM4FcP5/oS5m.V6WAY7GMb80Ye8mkh9WwkAH6nB1IqBnUtCXgwDHsz",
	"1.lAXAoBHMrC1YuCnkxDXx.EI71",
	"/EIJ7HJ3JKJpVNKZhQLJtTM43WMqFZNaRcOKdfP4piPr/lQbBoRLNrS5ZuSrlxTby.UM81V6K4VsW7WciAXMuDY74GYtGJZdSMaNePb7qSbu0VceCYdOObe8aeeumhfeykgP8n",
	0
};

static const char *expected_hash[] =
{
	"4F4CA3D5D68BA7CC0A1208C9C61E9C5DA0403C0A",
	"0922D3405FAA3D194F82A45830737D5CC6C75D24",
	"BCF41EAB8BB2D802F3D05CAF7CB092ECF8D1A3AA",
};


static void hex_hash1(unsigned char* hash,char* buf)
{
	for(int at=0;at<SHA_DIGEST_LENGTH;++at)
	{
		buf+=sprintf(buf,"%02X",*hash++);
	}
	*buf=0;
}

bool hmac_sha1_KAT(void)
{
	int test_num = 0;
	unsigned char message_buf[1000];
	while(test_vectors[test_num] != 0)
	{
		
		unsigned char observed_hash[SHA_DIGEST_LENGTH+1];
		char observed_hex_hash[2*SHA_DIGEST_LENGTH+1];
		const char* test_msg = test_vectors[test_num];
		int msg_len = strlen(test_msg);
		if(BaseEncoder::Decode64Colib((unsigned char*)message_buf, sizeof(message_buf), test_msg, msg_len) <= 0 )
		{
			return false;
		}
		//adjust length;
		msg_len = (msg_len * 6)/8;

		const char* key = key_vector[test_num];

		int key_len = strlen(key);
		char key_buf[200];
		if(BaseEncoder::Decode64Colib((unsigned char*)key_buf, sizeof(key_buf), key, key_len) <= 0)
		{
			return false;
		}
		//adjust length;
		key_len = (key_len * 6)/8;

		HMAC(EVP_sha1(), key_buf, key_len, message_buf, msg_len, observed_hash, NULL);
		
		hex_hash1(observed_hash,observed_hex_hash);
		if(strcmp(observed_hex_hash, expected_hash[test_num]))
		{
			return false;
		}
		test_num++;
	}
	return true;
}

} // end namespace colib
		

		
