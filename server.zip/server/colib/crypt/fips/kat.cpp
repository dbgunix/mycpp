//kat.cpp

#include <crypt/fips/fips.h>
#include <utils/system/environ.h>
#include <utils/system/machine.h>
#include <console/ansi.h>


#include <crypt/fips/hmac_sha1_kat.h>
#include <crypt/fips/rsa_kat.h>
#include <crypt/fips/aes_kat.h>

#include <crypt/fips/rng_kat.h>

namespace colib
{


//This function should be run before any stacks are initialize, so
//it does not do any transitioning of its own, it merely sets
//the error state directly
bool PerformAllRelevantKATs( Writable *status_output )
{
	//sha1
	//Disabled at corsec advice: not required by fips
//	status_output->PrintString("Running SHA1 KAT...");
//	if( !iDirect_sha1_KAT() )
//	{
///		SetErrorState(ANSI_FG_BOLD_RED "SHA1 KAT Failed!!");
//		status_output->Print( "%s\n", CryptoErrorStatus().c_str() );
//		return false;
//	}
//	status_output->PrintString( ANSI_FG_BOLD_GREEN "OK\n" ANSI_DEFAULT );

	//hmac+sha1
	status_output->PrintString("Running HMAC KAT...");
	if( !hmac_sha1_KAT() )
	{
		SetErrorState( ANSI_FG_BOLD_RED "HMAC KAT Failed!!");
		status_output->Print( "%s\n", CryptoErrorStatus().c_str() );
		return false;
	}
	status_output->PrintString( ANSI_FG_BOLD_GREEN "OK\n" ANSI_DEFAULT );

#ifdef PLATFORM_LINUX
	//AES
	{
	   	status_output->PrintString("Running AES KAT...");
		if ( !Run_AES_KATs(status_output) )
		{
			SetErrorState( ANSI_FG_BOLD_RED "Failed" );
			status_output->Print("%s\n", CryptoErrorStatus().c_str());
			return false;
		}
		status_output->PrintString ( ANSI_FG_BOLD_GREEN "OK\n" ANSI_DEFAULT );
	}

	//PRNG KAT
	{
	   	status_output->PrintString("Running PRNG KAT...");
		if(!Run_Global_PRNG_KAT(status_output))
		{
			//error state should be set already
			return false;
		}
	}

#endif
	//rsa
	{
		if(!Run_RSA_KATs(status_output))
		{
			return false;
		}
	}

	return true;
}


}//end namespace colib


