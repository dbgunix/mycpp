//token.cpp
//
// simple generic encryption for passwords

#include <crypt/passwd/token.h>
#include <crypt/sha/sha.h>
#include <utils/base_encoder.h>

#include <stdlib.h>
#include <string.h>
#include <unistd.h>

namespace colib {

colib::string idirect_token_hash_internal (const char* clear_pwd, const char *salt )
{
	unsigned char hash_binary_output[20];
	char hash_b64[40];

	colib::string tempstr = colib::string::Format("%s%s",clear_pwd,salt);
	const char *hash_input = tempstr;
	unsigned long len = strlen(hash_input);
	
	iDirect_sha1((const unsigned char*)hash_input, len, (unsigned char*)hash_binary_output );

	//convert hash_binary_output into ascii
	memset(hash_b64, 0, sizeof(hash_b64));
	BaseEncoder::Encode64Colib(hash_b64, sizeof(hash_b64), hash_binary_output, sizeof(hash_binary_output));

	tempstr = colib::string::Format("$idi2$%s$%s",salt,hash_b64);
	
	// this gives us flexibility to change salt/encoding
	// salts are intended to be exposable to the outside world
	return tempstr;
}
colib::string idirect_token_hash_internal_3 (const char* clear_pwd, const char *salt )
{
	const size_t LENGTH_OF_B64 = 87;
	unsigned char hash_binary_output[SHA512_DIGEST_LENGTH];
	char hash_b64[LENGTH_OF_B64];

	colib::string tempstr = colib::string::Format("%s%s",clear_pwd,salt);
	const char *hash_input = tempstr;
	unsigned long len = strlen(hash_input);
	
	iDirect_sha512((const unsigned char*)hash_input, len, (unsigned char*)hash_binary_output );

	//convert hash_binary_output into ascii
	if(BaseEncoder::Encode64Colib(hash_b64, sizeof(hash_b64), hash_binary_output, SHA512_DIGEST_LENGTH) >= 0)
	{
		tempstr = colib::string::Format("$idi3$%s$%s",salt,hash_b64);
	}
	else
	{
		tempstr = "ERROR: failed to b64 encode";
	}
	
	// this gives us flexibility to change salt/encoding
	// salts are intended to be exposable to the outside world
	return tempstr;
}

// this encoding function returns the following:
// $<encoding>$<salt>$<encrypted password>
colib::string idirect_token_hash (const char* clear_pwd, HashMethod hash)
{
	const char *salt;
	char saltbuf[10];

	//Generate a random salt
	int r = rand();
	BaseEncoder::Encode64Colib(saltbuf, sizeof(saltbuf), (unsigned char*)&r, sizeof(r));
	salt = saltbuf;

	switch(hash)
	{
	case HashMethod_sha1:
		return idirect_token_hash_internal(clear_pwd,salt);
	default:
		return idirect_token_hash_internal_3(clear_pwd,salt);
	}
}


bool idirect_token_verify(const char* clear_pwd, const char *token_hash)
{
	const char *ver_start;
	const char *salt_start;
	const char *salt_stop;
	//Gather version and salt from "token_hash"
	//version determines which hash algorithm to use
	//the b64'd salt value is used to generate a new hash with the clearpwd, which is the strcmp'd to the parameter
	if(*token_hash != '$')
		return false;
	ver_start = token_hash+1;

	salt_start = strchr(ver_start,'$');
	if(!salt_start)
		return false;
	++salt_start;

	salt_stop = strchr(salt_start,'$');
	if(!salt_stop)
		return false;

	//bounds check
	if( salt_stop - salt_start > 512)
	{
		//arbitrary maximum length of salt
		return false;
	}

	colib::string salt(salt_start,(unsigned int)(salt_stop-salt_start));

	//"idi1" was short lived. based on md5, no longer supported

	if( 0 == strncmp("idi2", ver_start, 4) )
		return 0 == strcmp(token_hash, idirect_token_hash_internal(clear_pwd,salt) );
	
	if( 0 == strncmp("idi3", ver_start, 4) )
		return 0 == strcmp(token_hash, idirect_token_hash_internal_3(clear_pwd,salt) );

	return false;
}

colib::string idirect_unix_token_hash_internal (const char* clear_pwd, const char *salt )
{
	colib::string tempstr;

	const char *result = ::crypt(clear_pwd,salt);

	if(result)
		tempstr = result;
	
	return tempstr;
}
colib::string idirect_unix_token_hash (const char* clear_pwd )
{
	const char *salt;
	char saltbuf[] = { '$', '1', '$', 0, 0, 0, 0, 0, 0, '$', 0 };

	//Generate a random salt
	int r = rand();
	BaseEncoder::Encode64Colib(saltbuf+3, 7, (unsigned char*)&r, sizeof(r));
	//fix the null termination of tob64
	saltbuf[9] = '$';
	salt = saltbuf;

	return idirect_unix_token_hash_internal(clear_pwd,salt);
}

bool idirect_unix_token_verify(const char* clear_pwd, const char *token_hash)
{
	const char *salt_start;
	const char *salt_stop;
	//Gather salt from "token_hash"
	if(*token_hash != '$')
		return false;

	salt_start = strchr(token_hash+1,'$');
	if(!salt_start)
		return false;
	++salt_start;

	salt_stop = strchr(salt_start,'$');
	if(!salt_stop)
		return false;
	++salt_stop;

	colib::string salt(token_hash,(unsigned int)(salt_stop-token_hash));

	return 0 == strcmp(token_hash, idirect_unix_token_hash_internal(clear_pwd,salt) );
}

} // end of namespace
