#include <crypt/passwd/rlock_password.h>
#include <crypt/sha/sha.h>
#include <utils/system/machine.h>

namespace colib
{
	colib::string GetPassword(unsigned int DID)
	{
		unsigned char pattern[] = "qwqewurieetufdjgfjgflmbvmcnmvcnvbnz./?.,lalhgAU-_918273645";
		unsigned char sha1_output[20] = {0};
		char pword[64];

		SHA_CTX ctx;

		unsigned int id = FLIP(DID);
		unsigned char *did = (unsigned char*)&id;
		SHA_Init(&ctx);
		SHA_Update(&ctx, did, 4);
		SHA_Update(&ctx, pattern, 59);
		SHA_Final(sha1_output, &ctx);
	
		static unsigned char itoa256[] =
		"-_*#$QWERTYUIOPASDFGHJKLZXCVBNMabcdefghijklmnopqrstuvwxyz123456789qwertyuiopasdfghjklzxcvbnmMNBVCXZASDFGHJKLPOIUYTREWQ123456789-_*$#qwertyuioplkjhgfdsazxcvbnmZXCVBNMLKJHGFDSAQWERTYUIOP987654321-_*$#abcdzxcvbnmlkjhgfdsaqwertyuioplkjhgfdsazxcvbnmpoiuytrewqas";

		for (unsigned int i = 0; i < 8; i++)
		{
			unsigned int index = (i < 4) ? i: (i + 12);
			pword[i] = itoa256[sha1_output[index]];
		}

		pword[8] = '\0';

		colib::string password = colib::string::Format("%s", pword);
		return password;
	}
} // end of namespace colib
