//token.h

#ifndef token_h_already_included
#define token_h_already_included

#include <utils/system/environ.h>
#include <utils/string.h>

namespace colib {

// Authentication token hashing functions

enum HashMethod
{
	HashMethod_sha1,
	HashMethod_sha512
};

//Returns hashed password. This will return a different hash
//everytime its called, even for the same clear_pwd
colib::string idirect_token_hash(const char* clear_pwd, HashMethod hash = HashMethod_sha512);

//Verifies a cleartext string against a password hash
bool idirect_token_verify(const char* clear_pwd, const char *token_hash);

//These are used for generating md5'd o/s shadow passwd entries
colib::string idirect_unix_token_hash(const char* clear_pwd);
bool idirect_unix_token_verify(const char* clear_pwd, const char *token_hash);

} // end namespace

#endif

