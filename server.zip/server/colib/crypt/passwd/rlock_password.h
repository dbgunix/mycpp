// rlock_password.h
#ifndef idirect_rlock_password_h_included
#define idirect_rlock_password_h_included

#include <utils/string.h>

namespace colib
{
	colib::string GetPassword(unsigned int DID); // Generates password based on DID of remote
}
#endif
