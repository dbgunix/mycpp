//global_rng.cpp

#include <config/global_params.h>
#include <crypt/rng/global_rng.h>
#include <utils/system/environ.h>
#include <config/fips.h>

#include <openssl/rand.h>
#include <openssl/opensslv.h>

#if OPENSSL_VERSION_NUMBER < 0x010001000L // (1.0.1)
#include <openssl/fips_rand.h>
#else
#include <openssl/crypto.h>
#endif

namespace colib {

RNG *g_rng=0;

bool iDirect_RAND(unsigned char *buf, unsigned int num_bytes)
{
	if(!g_rng)
	{
		colib::string err;
		if(!iDirect_Setup_RAND(err))
			return false;
	}

	return g_rng->GenerateBlock(buf,num_bytes);
}

bool iDirect_Setup_RAND_callback( void (*callback)(void) )
{
#ifdef HARDWARE_IXP
	if(g_rng)
	{
		return g_rng->SetupCallback(callback);
	}
	else
	{
		return false;
	}
#else
	(void)callback;
	return true;
#endif
}

bool iDirect_Setup_RAND( colib::string &err )
{
	if(g_rng)
	{
		delete g_rng;
	}

#if OPENSSL_VERSION_NUMBER > 0x010001000L // (1.0.1)
	OPENSSL_init();
#else
	RAND_set_rand_method(FIPS_rand_method());
#endif

	FIPS_RNG *new_rng = new FIPS_RNG;

	if(!new_rng)
	{
		err="Failed to alloc FIPS_RNG";
		return false;
	}

#if OPENSSL_VERSION_NUMBER < 0x010001000L // (1.0.1)
	if(!new_rng->Seed())
	{
		err="Failed to init FIPS_RNG";
		delete new_rng;
		return false;
	}
#endif

	g_rng = new_rng;
	return true;
}

bool iDirect_Setup_RAND_DETERMINISTICALLY( colib::string &err )
{
	if(g_rng)
	{
		delete g_rng;
	}

#if OPENSSL_VERSION_NUMBER > 0x010001000L // (1.0.1)
	OPENSSL_init();
#else
	RAND_set_rand_method(FIPS_rand_method());
#endif

	FIPS_RNG *new_rng = new FIPS_RNG;

	if(!new_rng)
	{
		err="Failed to alloc FIPS_RNG";
		return false;
	}
	g_rng = new_rng;
	unsigned char seed[64]={
		 1, 2, 3, 4, 5, 6, 7, 8, 9,10,\
		11,12,13,14,15,16,17,18,19,20,\
		21,22,23,24,25,26,27,28,29,30,\
		31,32,33,34,35,36,37,38,39,40,\
		41,42,43,44,45,46,47,48,49,50,\
		51,52,53,54,55,56,57,58,59,60,\
		61,62,63,64};
	if( !new_rng->SeedManually(seed,sizeof(seed)/sizeof(seed[0]),err) )
	{
		return false;
	}
	if(!new_rng->is_ok())
	{
		err="FIPS_RNG failed contiunous RNG check";
		return false;
	}
	return true;
}

bool iDirect_Setup_WEAK_RAND( colib::string &err )
{
	if( InFipsMode() )
	{
		err="Cannot use WEAK_RAND in FIPS modes";
		return false;
	}

	if(g_rng)
	{
		delete g_rng;
	}

#if OPENSSL_VERSION_NUMBER > 0x010001000L // (1.0.1)
	OPENSSL_init();
#else
	RAND_set_rand_method(RAND_SSLeay());
#endif

	g_rng = new NON_RNG;

	if(!g_rng)
	{
		err="Failed to alloc FIPS_RNG";
		return false;
	}

	return true;
}

} // end of namespace
