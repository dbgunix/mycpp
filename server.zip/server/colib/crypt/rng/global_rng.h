//global_rng.h

#ifndef global_rng_included_already
#define global_rng_included_already

#include <utils/system/machine.h>
#include <crypt/rng/rng.h>

namespace colib {

//Global Entry function for triel
bool iDirect_RAND(unsigned char *buf, unsigned int num_bytes);

//dont use directly
extern RNG *g_rng;

bool iDirect_Setup_RAND( colib::string &err );
bool iDirect_Setup_RAND_callback( void (*callback)(void) );
bool iDirect_Setup_RAND_DETERMINISTICALLY( colib::string &err );

bool iDirect_Setup_WEAK_RAND( colib::string &err );

} // end of namespace
#endif

