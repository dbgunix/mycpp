//rng.cpp
// vi:set ts=4 sw=4 nowrap:

#include <string.h>
#include <crypt/rng/rng.h>
#include <utils/system/environ.h>
#include <utils/trace/trace.h>

#include <stdio.h>
#include <errno.h>

namespace colib {

static unsigned char s_sng_lastbuf[16];
static bool s_rng_lastbuf_inited=false;
static bool s_rng_difference_detected;
static unsigned int s_rng_counter;
bool OS_GenerateSeedBytesCONTRNGD( void *into, unsigned int length, colib::string &err )
{
	if(!s_rng_lastbuf_inited)
	{
		if(!OS_GenerateSeedBytes(s_sng_lastbuf,16,err) )
		{
			return false;
		}
		s_rng_lastbuf_inited=true;
		s_rng_difference_detected=false;
		s_rng_counter=0;
	}

	if(!OS_GenerateSeedBytes(into,length,err) )
	{
		return false;
	}

	unsigned char *newrand = (unsigned char *)into;
	unsigned int cnt=0;

	while(cnt<length)
	{
		if(s_rng_counter>=16)
		{
			if(!s_rng_difference_detected)
			{
				err="OS_GenerateSeedBytesCONTRNGD: cont rng failed";
				return false;
			}
			s_rng_counter=0;
			s_rng_difference_detected=false;
		}
		if(s_sng_lastbuf[s_rng_counter] != newrand[cnt] )
			s_rng_difference_detected = true;

		s_sng_lastbuf[s_rng_counter] = newrand[cnt];

		++s_rng_counter;
		++cnt;
	}

	return true;
}

bool OS_GenerateSeedBytesURANDOM( void *into, unsigned int length, colib::string &err )
{
#if defined(PLATFORM_LINUX)
	//Use O/S random source
	FILE *frnd = fopen("/dev/urandom","r");
	if(frnd)
	{
		unsigned int read = fread(into,1,length,frnd);
		if( read==length )
		{
			fclose(frnd);
			return true;
		}
		
		if(ferror(frnd))
		{
			err = colib::string::Format( "Failed to get random seed data: %s", strerror(errno) );
		}
		
		fclose(frnd);
		return false;
	}
	err = colib::string::Format( "Failed to open OS random source: %s", strerror(errno) );
	return false;
#endif
	return true;
}

bool OS_GenerateSeedBytes( void *into, unsigned int length, colib::string &err )
{
#if defined(PLATFORM_LINUX)
	//Use O/S random source
	FILE *frnd = fopen("/dev/random","r");
	if(frnd)
	{
		unsigned int read = fread(into,1,length,frnd);
		if( read==length )
		{
			fclose(frnd);
			return true;
		}
		
		if(ferror(frnd))
		{
			err = colib::string::Format( "Failed to get random seed data: %s", strerror(errno) );
		}
		
		fclose(frnd);
		return false;
	}
	err = colib::string::Format( "Failed to open OS random source: %s", strerror(errno) );
	return false;
#endif
	return true;
}

bool RNG::SetupCallback(void (*callback)(void))
{
	(void)callback;
	return true;
}

} // end of namespace
