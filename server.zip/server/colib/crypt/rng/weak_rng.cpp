//weak_rng.cpp
// vi:set ts=4 sw=4 nowrap:

#include <crypt/rng/rng.h>

#include <stdlib.h>

//this should never be used for anything but netmodem II's,
//which have no encryption support

namespace colib {

bool NON_RNG::GenerateBlock(unsigned char *output, unsigned int size)
{
	while(size>=4)
	{
		*(int*)output = rand();
		output += 4;
		size -= 4;
	}
	while(size--)
	{
		*output++ = (unsigned char)rand();
	}
	return true;
}

} // end of namespace
