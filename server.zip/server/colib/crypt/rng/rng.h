//rng.h

#ifndef RNG_H_already_included
#define RNG_H_already_included

#include <utils/string.h>
#include <utils/callback.h>

namespace colib {

bool OS_GenerateSeedBytesCONTRNGD( void *into, unsigned int length, colib::string &err );
bool OS_GenerateSeedBytes( void *into, unsigned int length, colib::string &err );
bool OS_GenerateSeedBytesURANDOM( void *into, unsigned int length, colib::string &err );

class RNG
{
public:
	virtual ~RNG() {};
	virtual bool GenerateBlock(unsigned char *output, unsigned int size)=0;

	virtual bool SetupCallback(void (*callback)(void));

	bool Seed();

	virtual bool is_ok(){return false;}
	colib::string GetLastError(){ return m_last_err; }

protected:
	colib::string m_last_err;
};

class FIPS_RNG : public RNG
{
public:
	FIPS_RNG(){m_is_ok = true;};
	virtual ~FIPS_RNG() {};

	bool GenerateBlock(unsigned char *output, unsigned int size);
	bool SetupCallback(void (*callback)(void));
	bool Seed(void);
	bool SeedManually( unsigned char *randbytes, unsigned int rblen, colib::string &err );

	bool is_ok(){return m_is_ok;}

private:
	bool m_is_ok;
};

//super weak, not random RNG, used for netmodem II's, which have
//no encryption support nor hifn chip. calls rand()
class NON_RNG : public RNG
{
public:
	bool GenerateBlock(unsigned char *output, unsigned int size);
};

} // end namespace
#endif

