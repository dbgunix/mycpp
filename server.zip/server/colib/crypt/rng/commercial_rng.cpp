//commercial_rng.cpp
// vi:set ts=4 sw=4 nowrap:

#include <utils/system/environ.h>
#include <crypt/rng/rng.h>


//Openssl
#ifdef PLATFORM_LINUX


#include <openssl/rand.h>
#ifdef HARDWARE_IXP
#include <openssl/fips_rand.h>
#endif

namespace colib {

bool FIPS_RNG::GenerateBlock(unsigned char *output, unsigned int size)
{
	return m_is_ok = (RAND_bytes(output, (int)size) != 0);
}

bool FIPS_RNG::SetupCallback(void (*callback)(void))
{
#ifdef HARDWARE_IXP
	fips_set_callback(callback);
#else
	(void)callback;
#endif
	return true;
}

bool FIPS_RNG::Seed(void)
{
#ifdef HARDWARE_IXP
	return fips_rand_init();
#else
    unsigned char buf[32];

    if(!OS_GenerateSeedBytesURANDOM(buf,32, m_last_err))
    {
        return false;
    }

    RAND_seed(buf,32);
    return true;
#endif
}

bool FIPS_RNG::SeedManually( unsigned char *randbytes, unsigned int rblen, colib::string &err) 
{
#ifdef HARDWARE_IXP
	if(rblen < 64)
	{
		err="FIPS RNG SeedManually failed: need 64 bytes of random data";
		return false;
	}
	FIPS_rand_method()->cleanup();
	FIPS_set_prng_key(randbytes);
	FIPS_rand_seed(randbytes + 32,16);
	FIPS_test_mode(1,randbytes + 48);
	return true;
#else
	//silence warning ?
	RAND_seed(randbytes,rblen);
	err="";
	return true;
#endif
}

} // end namespace

#endif

