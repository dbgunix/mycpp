#if !defined(__VERSION_REGISTRAR_H__)
#define __VERSION_REGISTRAR_H__

#include "version_fields.h"

#include <vector>

namespace colib
{
	class Writable;

	class VersionDesc
	{
		public:
		
			VersionDesc(const char* name, const VersionFieldArray& version_fields);

			const char* GetName() const { return m_name; }
			const char* GetField(VersionField field) const { return field >= 0 && field < NUM_VERSION_FIELDS ? m_fields[field] : ""; }
	
			bool operator==(const VersionDesc&) const;
			bool operator!=(const VersionDesc&) const;

		private:
		
			const char* m_name;
			VersionFieldArray m_fields;
	};

	class VersionRegistrar
	{
		public:
		
			static VersionRegistrar& GetInstance();
			//
			// Build 
			//
			void BuildWith(const VersionDesc& ver) { if ( !GetBuildWith(ver.GetName()) ) m_build_with.push_back(ver); }
			//
			// Link
			//
			void LinkTo(const VersionDesc& ver) { if ( !GetLinkTo(ver.GetName()) ) m_link_to.push_back(ver); }
			//
			// Old API, will obsolete
			//
			void Add(const VersionDesc& ver) { LinkTo(ver); }
			//
			void PrintBrief(Writable* to) const;
			void PrintBrief(const char* name, Writable* to) const;
			void PrintFull(Writable* to) const;
			void PrintFull(const char* name, Writable* to) const;
			//
			void SetApplicationName(const char* name) { m_application_name = name; }
			const char* GetApplicationName() const { return m_application_name; }

			VersionRegistrar(const VersionRegistrar& other) = delete;
			VersionRegistrar& operator=(const VersionRegistrar& other) = delete;

		private:
		
			VersionRegistrar();
			const VersionDesc* GetBuildWith(const char* name) const;
			const VersionDesc* GetLinkTo(const char* name) const;
			const VersionDesc* Find(const char* name, const std::vector<VersionDesc>& v) const;
			
			const char* m_application_name;
			std::vector<VersionDesc> m_build_with;
			std::vector<VersionDesc> m_link_to;
	};

}

#endif // __VERSION_REGISTRAR_H__
