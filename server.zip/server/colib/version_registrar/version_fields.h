#if !defined(__VERSION_FIELDS_H__)
#define __VERSION_FIELDS_H__

#include <array>

namespace colib
{

enum VersionField
{
	APP_VERSION = 0,
	BUILD_TAG,
	BUILD_USER,
	BUILD_HOST,
	BUILD_DATETIME,
	BUILD_SRC_VERSION,
	BUILD_PLATFORM,
	BUILD_GCC_VERSION,
	BUILD_KERNEL_VERSION,
	BUILD_COMMENTS,
	NUM_VERSION_FIELDS
};

typedef std::array<const char*, NUM_VERSION_FIELDS> VersionFieldArray;

const char* VersionFieldToString(VersionField v);

}

#endif
