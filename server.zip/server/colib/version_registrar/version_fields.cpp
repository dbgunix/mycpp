#include "version_fields.h"

namespace colib
{

const char* VersionFieldToString(VersionField v)
{
	switch (v)
	{
		case APP_VERSION: return "AppVersion";
		case BUILD_TAG: return "Tag";
		case BUILD_USER: return "User";
		case BUILD_HOST: return "Host";
		case BUILD_DATETIME: return "Timestamp";
		case BUILD_SRC_VERSION: return "SourceCode version";
		case BUILD_PLATFORM: return "Platform";
		case BUILD_GCC_VERSION: return "gcc version";
		case BUILD_KERNEL_VERSION: return "Kernel version";
		case BUILD_COMMENTS: return "Comment";
		case NUM_VERSION_FIELDS: return "Error";
	}
	return "Unknown";
}

}
