#include "version_registrar.h"
#include <utils/trace/writable.h>

#include <string.h>
#include <stdint.h>

namespace colib
{
	VersionDesc::VersionDesc(const char* name, const VersionFieldArray& version_fields)
		: m_name(name)
		, m_fields(version_fields)
	{
	}

	bool VersionDesc::operator==(const VersionDesc& other) const
	{
		for ( int i = APP_VERSION; i < NUM_VERSION_FIELDS; ++i )
		{
			VersionField idx = static_cast<VersionField>(i);
			if ( strcmp(other.GetField(idx), this->GetField(idx)) ) return false;
		}
		return true;
	}

	bool VersionDesc::operator!=(const VersionDesc& other) const
	{
		return !(*this == other);
	}

	VersionRegistrar::VersionRegistrar()
		: m_application_name("UnsetApplicationName")
		, m_build_with()
		, m_link_to()
	{
	}

	VersionRegistrar& VersionRegistrar::GetInstance()
	{
		static VersionRegistrar instance;
		return instance;
	}

	const VersionDesc* VersionRegistrar::Find(const char* name, const std::vector<VersionDesc>& v) const
	{
		for ( unsigned i = 0; i < v.size(); ++i )
		{
			if ( strcmp(v[i].GetName(), name) == 0 ) return &v[i];
		}
		return 0;
	}
	
	const VersionDesc* VersionRegistrar::GetBuildWith(const char* name) const
	{
		return Find(name, m_build_with);
	}

	const VersionDesc* VersionRegistrar::GetLinkTo(const char* name) const
	{
		return Find(name, m_link_to);
	}

	void VersionRegistrar::PrintBrief(Writable* to) const
	{
		if ( to )
		{
			to->Print("Application: %s\n", m_application_name);
			for ( unsigned i = 0; i < m_link_to.size(); ++i )
			{
				const VersionDesc* link_to = &m_link_to[i];
				const VersionDesc* build_with = GetBuildWith(link_to->GetName());
				char label = ' ';
				if ( !build_with ) label = '?';
				else if ( *build_with != *link_to ) label = '!';
				to->Print("[%c] %s\t%s: %s\n", 
						label, 
						link_to->GetName(),
						VersionFieldToString(APP_VERSION),
						link_to->GetField(APP_VERSION));
			}
		}
	}		

	void VersionRegistrar::PrintBrief(const char* name, Writable* to) const
	{
		if ( to )
		{
			to->Print("Application: %s\n", m_application_name);
			const VersionDesc* link_to = GetLinkTo(name);
			if ( !link_to ) 
			{
				to->Print("Unable to find \"%s\"\n", name);	
				return;
			}
			const VersionDesc* build_with = GetBuildWith(link_to->GetName());
			char label = ' ';
			if ( !build_with ) label = '?';
			else if ( *build_with != *link_to ) label = '!';
			to->Print("[%c] %s\t%s: %s\n", 
					label, 
					link_to->GetName(),
					VersionFieldToString(APP_VERSION),
					link_to->GetField(APP_VERSION));
		}
	}

	void VersionRegistrar::PrintFull(Writable* to) const
	{
		if ( to )
		{
			to->Print("Application: %s\n", m_application_name);
			for ( unsigned i = 0; i < m_link_to.size(); ++i )
			{	
				const VersionDesc* link_to = &m_link_to[i];
				const VersionDesc* build_with = GetBuildWith(link_to->GetName());	
				char label = ' ';
				if ( !build_with ) label = ' '; // old value: '?'
				else if ( *build_with != *link_to ) label = ' '; // old value: '!'
				to->Print("[%c] %s\n", label, link_to->GetName());
				to->Print("[runtime]\n");
				for ( int ii = APP_VERSION; ii < NUM_VERSION_FIELDS; ++ii )
				{
					VersionField idx = static_cast<VersionField>(ii);
					label = ' '; 
					if ( build_with && strcmp(link_to->GetField(idx), build_with->GetField(idx)) ) label = ' '; // old value: '!'
					to->Print("%c\t%s: %s\n",
							label,
 							VersionFieldToString(idx),
 							link_to->GetField(idx));
				}
				to->Print("[buildtime]\n");
				if ( !build_with ) 
				{
					to->Print("\tInformation not available!\n");
				}
				else
				{
					for ( int ii = APP_VERSION; ii < NUM_VERSION_FIELDS; ++ii )
					{
						VersionField idx = static_cast<VersionField>(ii);	
						label = ' '; 
						if ( strcmp(link_to->GetField(idx), build_with->GetField(idx)) ) label = ' '; // old value: '!'
						to->Print("%c\t%s: %s\n", 
								label,
								VersionFieldToString(idx),
								build_with->GetField(idx));
					}
				}	
			}
		}
	}

	void VersionRegistrar::PrintFull(const char* name, Writable* to) const
	{
		if ( to )
		{
			to->Print("Application: %s\n", m_application_name);	
			const VersionDesc* link_to = GetLinkTo(name);
			if ( !link_to ) 
			{
				to->Print("Unable to find \"%s\"\n", name);	
				return;
			}
			const VersionDesc* build_with = GetBuildWith(link_to->GetName());		
			char label = ' ';
			if ( !build_with ) label = '?';
			else if ( *build_with != *link_to ) label = '!';
			to->Print("[%c] %s\n", label, link_to->GetName());
			to->Print("[runtime]\n");
			for ( int ii = APP_VERSION; ii < NUM_VERSION_FIELDS; ++ii )
			{
				VersionField idx = static_cast<VersionField>(ii);	
				label = ' '; 
				if ( build_with && strcmp(link_to->GetField(idx), build_with->GetField(idx)) ) label = '!';
				to->Print("%c\t%s: %s\n",
						label,
						VersionFieldToString(idx),
						link_to->GetField(idx));
			}
			to->Print("[buildtime]\n");	
			if ( !build_with ) 
			{
				to->Print("\tInformation not available!\n");
			}
			else
			{	
				for ( int ii = APP_VERSION; ii < NUM_VERSION_FIELDS; ++ii )
				{
					VersionField idx = static_cast<VersionField>(ii);	
					label = ' '; 
					if ( strcmp(link_to->GetField(idx), build_with->GetField(idx)) ) label = '!';
					to->Print("%c\t%s: %s\n", 
							label,
							VersionFieldToString(idx),
							build_with->GetField(idx));
				}
			}	
		}		
	}

}
