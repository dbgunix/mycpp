////////////////////////////////////////////////////////////////////////////////
//  Description: Contains the base class of all monitor and control messages
//
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
#include<message/message.h>
#include<utils/system/macros.h>

namespace colib
{

////////////////////////////////////////////////////////////////////////////////
//
// Class: Message
//
// Format of a message:
//
// |  4 bytes    |  4 bytes    | variable         ... |
//
// +-------------+------+------+----------------- ... +
// | length      |  ver | type | message specific ... |
// +-------------+------+------+----------------- ... +
//
// When reading a message off a socket, we first read the length, then the
// type, then dispatch a handling function that creates a message of the
// correct type.
//
// Originally the type was four bytes long. For future backward compatibility,
// we shortened the type to 2 bytes and made the first two bytes a version
// field. We still xdr these four bytes as an int so all messages present and
// remain the same size on the wire.
//
////////////////////////////////////////////////////////////////////////////////

// CTOR
Message::Message (int type, int version)
	: m_tv(version<<VERSION_SHIFT|type)
{
}

////////////////////////////////////////////////////////////////////////////////
Message& Message::operator=(const Message &that)
{
	this->m_tv = that.m_tv;
	return (*this);
}

////////////////////////////////////////////////////////////////////////////////
void Message::SetType(unsigned short newType)
{
	m_tv = (m_tv & ~TYPE_MASK) | (newType & TYPE_MASK);
}

void Message::SetVersion (unsigned short newVersion)
{
	m_tv = (m_tv & ~VERSION_MASK) | (newVersion << VERSION_SHIFT);
}

////////////////////////////////////////////////////////////////////////////////
// Decode the message type and version number
int Message::DecodeMsgType (const char* buffer)
{
	// we know that the "type" is the second short
	return NET_GET16(buffer + 2);
}

int Message::DecodeVersion (const char* buffer)
{
	// we know that the version is the first short
	return NET_GET16(buffer + 0);
}

////////////////////////////////////////////////////////////////////////////////
//
// protected
//
////////////////////////////////////////////////////////////////////////////////

bool Message::XdrProc (CXDR* xdr)
{
	return (xdr->XdrUint (&m_tv));
}


////////////////////////////////////////////////////////////////////////////////
//
//      Class Name: MessageTimeStamp
//
// Encapsulate the contents of a return code. Response messages should derive
// from this class if they want to return a status code.
//
////////////////////////////////////////////////////////////////////////////////
MessageTimeStamp::MessageTimeStamp (int type, int version)
	: Message(type, version)
	, m_time_stamp(0)
{
}

bool MessageTimeStamp::XdrProc (CXDR* xdr)
{
	return (Message::XdrProc(xdr) && xdr->XdrUint (&m_time_stamp));
}

////////////////////////////////////////////////////////////////////////////////
//
//      Class Name: ResponseMessage
//
// Encapsulate the contents of a return code. Response messages should derive
// from this class if they want to return a status code.
//
////////////////////////////////////////////////////////////////////////////////
ResponseMessage::ResponseMessage (int type)
	: Message(type)
	, m_code(0)
{
}

ResponseMessage::ResponseMessage (int type, int code)
	: Message(type)
	, m_code(code)
{
}

void ResponseMessage::SetResponseCode(int code)
{
	m_code = code;
}

bool ResponseMessage::XdrProc(CXDR* xdr)
{
	return Message::XdrProc(xdr) && xdr->XdrInt(&m_code);
}

}
