#ifndef MESSAGE_H
#define MESSAGE_H

////////////////////////////////////////////////////////////////////////////////
//
// include files
//
////////////////////////////////////////////////////////////////////////////////

#include<utils/xdr.h>

namespace colib
{

////////////////////////////////////////////////////////////////////////////////
//
// Convenience macro for the simplest type of requests: just an ID requesting
// an action to be performed with no parameters, e.g. ModemStatusReqMsg.
//
// WARNING: depends on the following assumption: the variable name of the
//			message type is of the form <message name>ID. For example,
//			a request message named ModemStatusReqMsg would have a type called
//			ModemStatusReqMsgID.
//
// NOTE:	We split this into two different macros due to a Diab compiler
//			problem	(we think) that prevents us from having inlined CTORs
//			and DTORs.
//
////////////////////////////////////////////////////////////////////////////////

// Use this macro in header files to declare request messages
//
#define DECLARE_SIMPLE_REQUEST_MSG(name)					\
	class name : public Message								\
	{														\
			public:											\
				name ();									\
				name (char* buf, int len);					\
				~name ();									\
			private:										\
		        virtual bool XdrProc(CXDR* pXDR);			\
	};

// Use this macro in cpp files to define request messages
#define DEFINE_SIMPLE_REQUEST_MSG(name)						\
name::name () : Message (name ## ID) {}						\
															\
name::name (char* buf, int len) : Message (name ## ID)		\
{ Decode (buf, len); }										\
															\
name::~name () {}			 								\
															\
bool name::XdrProc(CXDR* pXDR)								\
{ return Message::XdrProc (pXDR); }


#define DECLARE_SIMPLE_RESPONSE_MSG(name)					\
	class name : public Message								\
	{														\
	public:													\
		name();												\
		name(bool bStatus);									\
		virtual ~name();									\
															\
		bool getStatus() const;								\
		void setStatus(bool bStatus);						\
	private:												\
		virtual bool XdrProc(CXDR* pXDR);					\
		bool m_bStatus;										\
	};

#define DEFINE_SIMPLE_RESPONSE_MSG(name)					\
name::name()												\
: Message(name ## ID)										\
, m_bStatus(false)											\
{															\
}															\
															\
name::name(bool bStatus)									\
: Message(name ## ID)										\
, m_bStatus(bStatus)										\
{															\
}															\
															\
name::~name ()												\
{															\
}			 												\
															\
bool name::XdrProc(CXDR *pXDR)								\
{															\
	return (Message::XdrProc (pXDR) && 						\
			pXDR->XdrBool(&m_bStatus));						\
}															\
															\
bool name::getStatus() const								\
{															\
	return m_bStatus;										\
}															\
															\
void name::setStatus(bool bStatus)							\
{															\
	m_bStatus = bStatus;									\
}

class Message : public CEncodableItem
{
public:
	static const int HEADER_LENGTH = 4;

	Message(int type = 0, int version = 0);
	virtual ~Message() {}

	// what type are we?
	unsigned short GetType() const { return (m_tv & TYPE_MASK); }
	void SetType(unsigned short newType);

	// what version are we?
	unsigned short GetVersion() const { return (m_tv & VERSION_MASK) >> VERSION_SHIFT; }
	void SetVersion(unsigned short newVersion);

	// Decode the message type
	static int DecodeMsgType(const char* buffer);
	static int DecodeVersion(const char* buffer);

	virtual Message& operator=(const Message &that);

	bool GetMsgPermissions() const { return false; }

protected:
	static const int VERSION_SHIFT = 16;
	static const unsigned int VERSION_MASK = 0xFFFF0000;
	static const unsigned int TYPE_MASK = 0x0000FFFF;
	virtual bool XdrProc(CXDR* xdr);

private:
	// message type and version in one int
	unsigned int m_tv;
};

class MessageTimeStamp : public Message
{
public:
	MessageTimeStamp(int type = 0, int version = 0);
	virtual ~MessageTimeStamp() {}

	unsigned int GetTimeStamp() const { return m_time_stamp; }
	void SetTimeStamp (unsigned int newTS) {m_time_stamp = newTS;}

protected:
	virtual bool XdrProc(CXDR* xdr);

private:
	unsigned int m_time_stamp;
};


////////////////////////////////////////////////////////////////////////////////
//
//      Class Name: ResponseMessage
//
// Encapsulate the contents of a return code. Response messages should derive
// from this class if they want to return a status code.
//
////////////////////////////////////////////////////////////////////////////////
//
class ResponseMessage : public Message
{
public:
	ResponseMessage	(int type);
	ResponseMessage	(int type, int code);
	virtual ~ResponseMessage() {}
	void SetResponseCode(int code);
	int GetResponseCode() { return m_code; }

protected:
	virtual bool XdrProc(CXDR* xdr);

private:
	int m_code;
};

}

#endif
