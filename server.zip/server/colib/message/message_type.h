/*
   Any use of the Material is governed by the terms of the actual license
   agreement between colib, Inc. and the user. Any reproduction or
   redistribution, by any means - whether mechanical or electronic -
   without the express written permission of colib, Inc. is strictly
   prohibited.

   THESE MATERIALS ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
   EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO, THE IMPLIED
   WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR
   NON-INFRINGEMENT.

   ? Copyright 2006, colib Inc., 13865 sunrise Valley Drive, Suite 100
   Herndon, VA 20171

   All rights reserved. Any rights not expressly granted herein are
   reserved.
*/
#ifndef MESSAGE_TYPE_H
#define MESSAGE_TYPE_H

namespace colib
{

// Keep a TCP connection alive
const int	TCPConnectionKeepAliveMsgID	= 0xF001;

// colib Child Process heartbeat
const int	ChildHeartbeatMsgID			= 0xF002;

}//end namespace colib

#endif

