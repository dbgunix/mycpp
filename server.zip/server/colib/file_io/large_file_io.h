// large_file_io.h
// vi:set ts=4 sw=4 nowrap:

#ifndef LARGE_FILE_IO_H_ALREADY_INCLUDED
#define LARGE_FILE_IO_H_ALREADY_INCLUDED

#include "file_io_mgr.h"
#include "global_file_io_mgr.h"

#include <vector>
#include <map>

namespace colib
{	
	class LargeFileIO;

	//
	// LargeFileIoReleaser
	//
	class LargeFileIoReleaser
	{
		public:

			LargeFileIoReleaser() {};
			virtual ~LargeFileIoReleaser() {};

			virtual void Release(LargeFileIO*) = 0;
	};

	//
	// LargeFileIO can be used standalone
	//
	class LargeFileIO
	{
		public:
		
			static const int LARGE_FILE_WARNING_SIZE = 256 * 1024 * 1024;		// 256M
			static const int INITIAL_BUFFER_SIZE = 4 * 1024;	// 4K
			
			LargeFileIO(LargeFileIoReleaser* releaser = 0);
			LargeFileIO(const LargeFileIO&);
			virtual	~LargeFileIO() {};
			//
			bool InProgress() const { return m_in_progress; }
			// 
			// Read
			//		
			bool Read(
					string filename,
					const Callback1<const AsyncReaderBase&>& requester_cb,
					void* context = 0,
					FileIoMgr& file_io_mgr = GlobalFileIoMgr::GetInstance());	
	
			bool Read(
					string filename,
					const Callback3<char*, int, void*>& on_read_succeed,
					const Callback2<string, void*>& on_read_failed,
					void* context,
					string& err,
					FileIoMgr& file_io_mgr = GlobalFileIoMgr::GetInstance());		
			//
			// Write
			//
			bool Write(
					string filename,
					char* data, int len,
					const Callback1<const AsyncWriterBase&>& requester_cb,
					void* context = 0,
					FileIoMgr& file_io_mgr = GlobalFileIoMgr::GetInstance());	
	
			bool Write(
					string filename,
					char* data, int len,
					const Callback1<void*>& on_write_succeed,
					const Callback2<string, void*>& on_write_failed,
					void* context,
					string& err,
					FileIoMgr& file_io_mgr = GlobalFileIoMgr::GetInstance());		
			//
			// SafeWrite
			//
			bool SafeWrite(
					string filename,
					char* data, int len,
					const Callback1<const AsyncWriterBase&>& requester_cb,
					void* context = 0,
					FileIoMgr& file_io_mgr = GlobalFileIoMgr::GetInstance());
				
			bool SafeWrite(
					string filename,
					char* data, int len,
					const Callback1<void*>& on_write_succeed,
					const Callback2<string, void*>& on_write_failed,
					void* context,
					string& err,
					FileIoMgr& file_io_mgr = GlobalFileIoMgr::GetInstance());
	
		private:

			bool StoreWriteRequest(
					string filename,
					char* data, int len,	
					const Callback1<const AsyncWriterBase&>& requester_cb,
					bool safe_write,
					FileIoMgr& file_io_mgr);

			void WriteLeft(unsigned limit, void* context);

			void ReadCb(const AsyncReaderBase& rdr);
			void WriteCb(const AsyncWriterBase& wtr);
	
			void OnReadComplete(const AsyncReaderBase& rdr);
			void OnWriteComplete(const AsyncWriterBase& wtr);

			void Done();

		private:

			FileIoMgr* m_file_io_mgr;
			LargeFileIoReleaser* m_releaser;

			Callback1<const AsyncReaderBase&> m_read_complete_cbk;
			Callback1<const AsyncWriterBase&> m_write_complete_cbk;

			Callback3<char*, int, void*> m_read_succeed_cbk;
			Callback2<string, void*> m_read_failed_cbk;

			Callback1<void*> m_write_succeed_cbk;
			Callback2<string, void*> m_write_failed_cbk;

			string m_filename;
			string m_tmp_filename;
			bool m_in_progress;
			std::vector<char> m_data_buffer;
			unsigned m_write_offset;
			bool m_safe_write;
	};

}//end namespace iDirect


#endif

