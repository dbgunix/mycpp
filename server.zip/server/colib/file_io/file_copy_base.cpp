#include "file_copy_base.h"

namespace colib
{
	FileCopyBase::FileCopyBase()
		: FileIoBase()
		, m_target_name()  
		, m_requester_cb()
	{
	}

	FileCopyBase::FileCopyBase(string file_name, string target_name, const Callback1<const FileCopyBase&>& requester_cb, void* context)
		: FileIoBase(file_name, context)
		, m_target_name(target_name)  
		, m_requester_cb(requester_cb)
	{
	}

	string FileCopyBase::Print() const
	{
		return FileIoBase::Print() + string::Format(
											"Target name: %s\n"
											"Callback is %sset\n", 
											m_target_name.c_str(),
											m_requester_cb.IsSet() ? "" : "not ");
	}

}
