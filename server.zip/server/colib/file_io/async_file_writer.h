#if !defined(__IDIRECT_ASYNC_FILE_WRITER_H__)
#define __IDIRECT_ASYNC_FILE_WRITER_H__

#include "file_write_base.h"
#include "io_job.h"
#include <event_loop/activity_hld.h>

namespace colib
{
	class GlobalFileIoMgr;
	class DiskFileWriterMgr;

	class DiskFileWriter : public AsyncWriterBase
	{
		public:
			
			static const int MAX_DISK_FILE_WRITE_LENGTH = 32 * 1024;

			virtual ~DiskFileWriter();
	
			virtual string Print() const;
			virtual const char* GetData() const { return m_data; }	
			virtual unsigned MaxWriteLimit() const { return MAX_DISK_FILE_WRITE_LENGTH; }
			virtual bool FailMaxWriteLimit() const { return m_fail_write_limit; }
			
			DiskFileWriter(const DiskFileWriter&) = delete;
			DiskFileWriter& operator=(const DiskFileWriter&) = delete;

		protected:
		
			DiskFileWriter();
	
			void Init(
					string file_name, 
					AsyncWriterBase::WriteMode mode, 
					const char* data,
					int length, 
					const Callback1<const AsyncWriterBase&>& requester_cb, 
					void* context,
					string target_file_name);

			virtual bool Start();
			virtual void Stop();
			virtual void Complete() { DispatchCB(); }

			bool WriteData(int to_write, string& err, int& error_code);
			eCallbackRt StartTask();
			eCallbackRt DoTask();
		
			virtual bool WriteInitialize(int flag, string& err, int& error_code);
			virtual bool WriteFinish(string& err, int& error_code);	

			virtual void WriteComplete() = 0;

			virtual void Reset();
			void CloseFile();

		protected:
			
			char m_data[MAX_DISK_FILE_WRITE_LENGTH];
			ActivityHold m_start_act;
			ActivityHold m_act;
			//
			string m_target_file_name;
			int m_fd;
			int m_write_offset;
			int m_bytes_to_write;
			bool m_fail_write_limit;

		friend class DiskFileWriterMgr;
	};

	class DiskFileWriterSA : public DiskFileWriter
	{
		public:

			DiskFileWriterSA();
			virtual ~DiskFileWriterSA() {};	
			//
			// Write with full arguments
			//
			bool WriteFile(
					string file_name, 
					AsyncWriterBase::WriteMode mode,
					const char* data,
					int length, 
					const Callback1<const AsyncWriterBase&>& requester_cb, 
					void* context,
					string target_file_name);
			//
			// Overwrite
			//
			bool WriteFile(
					string file_name, 
					const char* data,
					int length, 
					const Callback1<const AsyncWriterBase&>& requester_cb, 
					void* context);
			//
			// Overwrite with rename
			//
			bool WriteFileWithMove(
					string file_name, 
					const char* data,
					int length, 
					const Callback1<const AsyncWriterBase&>& requester_cb, 
					void* context,
					string target_file_name);
			//
			// Append
			//
			bool AppendFile(
					string file_name, 
					const char* data,
					int length, 
					const Callback1<const AsyncWriterBase&>& requester_cb, 
					void* context);
			//
			// Append with rename
			//
			bool AppendFileWithMove(
					string file_name, 
					const char* data,
					int length, 
					const Callback1<const AsyncWriterBase&>& requester_cb, 
					void* context,
					string target_file_name);
			//
			// Stop
			//
			void StopTask() { m_job.Stop(); }
	
			virtual string Print() const;

			DiskFileWriterSA(const DiskFileWriterSA&) = delete;
			DiskFileWriterSA& operator=(const DiskFileWriterSA&) = delete;

		protected:

			virtual void WriteComplete(); 	

		protected:

			IoJobMgrSA m_job;
	};	

	class DiskFileWriterMgd : public DiskFileWriter
	{
		public:

			virtual ~DiskFileWriterMgd() {};

			virtual string Print() const;

		protected:

			DiskFileWriterMgd(unsigned job_id, IoJobMgrGlobal&);
	
			unsigned GetJobID() { return m_job_id; }	
			virtual void Stop() {}; // Not allowed to stop by itself
			virtual void WriteComplete() { m_job_mgr.JobDone(m_job_id); }

		protected:

			unsigned m_job_id;
			IoJobMgrGlobal& m_job_mgr;

		friend class DiskFileWriterMgr;
	};

	class DiskFileWriterMgr : public IoJobMgrGlobal
	{
		public:

			virtual ~DiskFileWriterMgr() {};		
			//
			// Write with full arguments
			//
			bool WriteFile(
					string file_name, 
					AsyncWriterBase::WriteMode mode,
					const char* data,
					int length, 
					const Callback1<const AsyncWriterBase&>& requester_cb, 
					void* context,
					string target_file_name);
			//
			// Overwrite
			//
			bool WriteFile(
					string file_name, 
					const char* data,
					int length, 
					const Callback1<const AsyncWriterBase&>& requester_cb, 
					void* context);
			//
			// Overwrite with rename
			//	
			bool WriteFileWithMove(
					string file_name, 
					const char* data,
					int length, 
					const Callback1<const AsyncWriterBase&>& requester_cb, 
					void* context,
					string target_file_name);
			//
			// Append
			//
			bool AppendFile(
					string file_name, 
					const char* data,
					int length, 
					const Callback1<const AsyncWriterBase&>& requester_cb, 
					void* context);
			//
			// Append with rename
			//
			bool AppendFileWithMove(
					string file_name, 
					const char* data,
					int length, 
					const Callback1<const AsyncWriterBase&>& requester_cb, 
					void* context,
					string target_file_name);

		protected:
			
			DiskFileWriterMgr(MemberSet& trace_set, unsigned max_limit);
			void SetMaxLimit(unsigned max_limit) { m_max_limit = max_limit; }

			virtual IoBase* CreateIo(unsigned/*type(ignored)*/, unsigned job_id, IoJobMgrGlobal& mgr);
			virtual unsigned MaximumJobLimit() const { return m_max_limit; }

		protected:

			unsigned m_max_limit;
	};

	class DiskFileWriteFifo : public DiskFileWriterMgr
	{
		public:

			DiskFileWriteFifo(MemberSet&, unsigned max_limit = 1);
			virtual ~DiskFileWriteFifo() {};

		protected:
		
			virtual unsigned ConcurrentJobLimit() const { return 1; }	
			void SetParams(unsigned max_limit) { SetMaxLimit(max_limit); }

		friend class GlobalFileIoMgr;
	};

	class DiskFileWriteGeneral : public DiskFileWriterMgr
	{
		public:

			DiskFileWriteGeneral(MemberSet&, unsigned concurrent_limit = 1, unsigned max_limit = 1);
			virtual ~DiskFileWriteGeneral() {};
		
		protected:

			virtual unsigned ConcurrentJobLimit() const { return m_concurrent_limit; }		
			void SetParams(unsigned concurrent_limit, unsigned max_limit) 
			{ m_concurrent_limit = concurrent_limit; SetMaxLimit(max_limit); }	
		
		protected:

			unsigned m_concurrent_limit;	

		friend class GlobalFileIoMgr;
	};

}
#endif
