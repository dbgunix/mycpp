#if !defined(__IDIRECT_FILE_IO_BASE_H__)
#define __IDIRECT_FILE_IO_BASE_H__

#include "io_base.h"

namespace colib
{
	//
	// Base class for file IO operations
	//
	class FileIoBase : public IoBase
	{
		public:
			//
			// Type
			//
			enum IoType
			{
				READ,
				WRITE,
				STATS,
				DELETE,
				RENAME,
				COPY
			};

			virtual ~FileIoBase() {};

			virtual IoType GetType() const = 0;
			const char* GetTypeStr() const;
			string GetFileName() const { return m_file_name; }
			int GetFileSize() const { return m_file_size; }
			virtual string Print() const;
			virtual string PrintFile() const;

			FileIoBase(const FileIoBase&) = delete;
			FileIoBase& operator=(const FileIoBase&) = delete;

		protected:
		
			FileIoBase();
			FileIoBase(string file_name, void* context);

			void SetFileName(string file_name) { m_file_name = file_name; }
			void SetFileSize(int size) { m_file_size = size; }
			
			virtual void Reset();
		
		protected:

			string m_file_name;
			int m_file_size;
	};

	inline void FileIoBase::Reset()
	{	
		IoBase::Reset(); 
		m_file_name.clear(); 
		m_file_size = -1; 	
	}

}

#endif
