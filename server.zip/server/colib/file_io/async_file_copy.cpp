#include "async_file_copy.h"
#include "file_io_utils.h"
#include <event_loop/event_loop.h>

namespace colib
{
	DiskFileCopy::DiskFileCopy()
		: FileCopyBase()
		, m_act(callbackRt(this, &DiskFileCopy::DoTask), "TaskAct")
	{
	}

	DiskFileCopy::~DiskFileCopy()
	{
		Stop();
	}

	string DiskFileCopy::Print() const
	{
		return FileCopyBase::Print() + string::Format(
													"Task activity is %sactive\n", 
													m_act.IsActive() ? "" : "not ");
	}

	void DiskFileCopy::Init(
							string file_name, 
							string target_name,
							const Callback1<const FileCopyBase&>& requester_cb, 
							void* context)
	{
		Reset();
		SetFileName(file_name);
		SetTargetName(target_name);
		SetCallback(requester_cb);
		SetContext(context);
	}
	
	bool DiskFileCopy::Start()
	{	
		//
		// Add activity
		//
		bool ret = EventLoop::GetInstance().AddActivity(&m_act);
		if ( ret ) SetStatus(IoBase::IN_PROGRESS);
		return ret;
	}

	void DiskFileCopy::Stop()
	{
		EventLoop::GetInstance().DeleteActivity(&m_act);
	}

	bool DiskFileCopy::Copy(string& err, int& error_code)
	{	
	   	return DiskFile::CopyFile(GetFileName(), GetTargetName(), err, error_code);
	}
	
	eCallbackRt DiskFileCopy::DoTask()
	{
		string err;
		int error_code;

		if ( !Copy(err, error_code) )
		{
			SetError(err);
			SetErrorCode(error_code);
			SetStatus(IoBase::FAILED);
		}
		else
		{
			SetError("Task complete");
			SetStatus(IoBase::SUCCEEDED);
		}
		
		CopyComplete();
		return DontRunAgain;
	}

	DiskFileCopySA::DiskFileCopySA()
		: DiskFileCopy()
		, m_job(*this)
	{
	}
	
	bool DiskFileCopySA::CopyFile(
								string file_name, 
								string target_name,
								const Callback1<const FileCopyBase&>& requester_cb, 
								void* context)
	{
		Init(file_name, target_name, requester_cb, context);
		return m_job.Start();
	}
	
	void DiskFileCopySA::CopyComplete()
	{
		m_job.Complete();
	}
		
	string DiskFileCopySA::Print() const
	{
		return DiskFileCopy::Print() + "Job type: SA\n";
	}
	
	DiskFileCopyMgd::DiskFileCopyMgd(unsigned job_id, IoJobMgrGlobal& job_mgr)
		: DiskFileCopy()
		, m_job_id(job_id)
		, m_job_mgr(job_mgr)
	{
	}
	
	string DiskFileCopyMgd::Print() const
	{
		return DiskFileCopy::Print() + "Job type: Mgd\n";
	}

	DiskFileCopyMgr::DiskFileCopyMgr(MemberSet& trace_set, unsigned max_limit)
		: IoJobMgrGlobal(trace_set)
	 	, m_max_limit(max_limit)
	{
	}

	bool DiskFileCopyMgr::CopyFile(
								string file_name, 
								string target_name,
								const Callback1<const FileCopyBase&>& requester_cb, 
								void* context)
	{
		DiskFileCopyMgd* job = static_cast<DiskFileCopyMgd*>(AddJob(/*type(ignored)*/0));
		if ( !job ) return false;
		job->Init(file_name, target_name, requester_cb, context);
		return true;
	}

	IoBase* DiskFileCopyMgr::CreateIo(unsigned/*type(ignored)*/, unsigned job_id, IoJobMgrGlobal& mgr)
	{
		return new DiskFileCopyMgd(job_id, mgr);
	}

	DiskFileCopyFifo::DiskFileCopyFifo(MemberSet& trace_set, unsigned max_limit)
		: DiskFileCopyMgr(trace_set, max_limit)
	{
	}

	DiskFileCopyGeneral::DiskFileCopyGeneral(MemberSet& trace_set, unsigned concurrent_limit, unsigned max_limit)
		: DiskFileCopyMgr(trace_set, max_limit)
		, m_concurrent_limit(concurrent_limit)
	{
	}

}

