#include "file_delete_base.h"

namespace colib
{
	FileDeleteBase::FileDeleteBase()
		: FileIoBase()
		, m_requester_cb()
	{
	}

	FileDeleteBase::FileDeleteBase(string file_name, const Callback1<const FileDeleteBase&>& requester_cb, void* context)
		: FileIoBase(file_name, context)
		, m_requester_cb(requester_cb)
	{
	}

	string FileDeleteBase::Print() const
	{
		return FileIoBase::Print() + string::Format("Callback is %sset\n", m_requester_cb.IsSet() ? "" : "not ");
	}

}
