#if !defined(__IDIRECT_FILE_READ_BASE_H__)
#define __IDIRECT_FILE_READ_BASE_H__

#include "file_io_base.h"
#include <utils/callback.h>

namespace colib
{
	class AsyncReaderBase : public FileIoBase
	{
		public:
		
			virtual ~AsyncReaderBase() {};

			virtual IoType GetType() const { return READ; }
			virtual string Print() const;
			
			virtual const char* GetData() const = 0;
			virtual unsigned MaxReadLimit() const = 0;
			virtual bool FailMaxReadLimit() const = 0;
			int GetDataLength() const { return m_data_length; }
			int GetOffset() const { return m_offset; }

			AsyncReaderBase(const AsyncReaderBase&) = delete;
			AsyncReaderBase& operator=(const AsyncReaderBase&) = delete;

		protected:
		
			AsyncReaderBase();
			AsyncReaderBase(string file_name, int offset, int length, const Callback1<const AsyncReaderBase&>& requester_cb, void* context);
	
			void SetDataLength(int data_length) { m_data_length = data_length; }
			void SetOffset(int offset) { m_offset = offset; }
			void SetCallback(const Callback1<const AsyncReaderBase&>& requester_cb) { m_requester_cb = requester_cb; }
			
			virtual void Reset(); 

			void DispatchCB() { m_requester_cb.Dispatch(*this); }

		protected:

			int m_data_length;
			int m_offset;
			Callback1<const AsyncReaderBase&> m_requester_cb;
	};

	inline void AsyncReaderBase::Reset()
	{	
		FileIoBase::Reset(); 
		m_data_length = 0; 
		m_offset = 0; 
		m_requester_cb.Clear(); 	
	}
}

#endif
