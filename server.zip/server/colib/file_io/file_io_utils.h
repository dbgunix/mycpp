// file_io_utils.h
// vi:set ts=4 sw=4 nowrap:

#ifndef FILE_IO_UTILS_H_ALREADY_INCLUDED
#define FILE_IO_UTILS_H_ALREADY_INCLUDED

#include <utils/string.h>

#include <stdlib.h>

namespace colib
{
	namespace DiskFile
	{
		extern const int DEFAULT_FILE_PERMISSION;
		extern const int DEFAULT_DIR_PERMISSION;

		bool	GetFileSize(
					string filename, 
					int& filesize, 
					string& err,
					int& error_code);
	
		bool	GetFileSize(
					string filename, 
					int& filesize, 
					string& err);
		
		bool	GetFileModifyTime(
					string filename, 
					int64_t& modify_time, 
					string& err, int& error_code);
		
		bool	GetFileModifyTime(
					string filename, 
					int64_t& modify_time, 
					string& err);
		
		bool	IsDirectory(
					string path, 
					bool& is_directory, 
					string& err, 
					int& error_code);

		bool	IsDirectory(
					string path, 
					bool& is_directory, 
					string& err);
		
		bool	GetStats(
					string path,
					bool& is_directory,
					int& size,
					int64_t& access_time,
					int64_t& modify_time,
					int64_t& change_time,
					string& err,
					int& error_code);

		bool	GetStats(
					string path,
					bool& is_directory,
					int& size,
					int64_t& access_time,
					int64_t& modify_time,
					int64_t& change_time,
					string& err);
		
		bool	RemoveFile(
					string filename, 
					string& err,
					int& error_code);

		bool	RemoveFile(
					string filename, 
					string& err);
		
		bool	RenameFile(
					string filename, 
					string target_filename, 
					string& err,
					int& error_code);

		bool	RenameFile(
					string filename, 
					string target_filename, 
					string& err);
		
		bool	ReadFile(
					int fd,
					char* buffer,
					int to_read,
					int& bytes_read,
					string& err,
					int& error_code);

		bool	ReadFile(
					int fd,
					char* buffer,
					int to_read,
					int& bytes_read,
					string& err);
		
		bool	WriteFile(
					int fd,
					char* buffer,
					int to_write,
					int& bytes_write,
					string& err,
					int& error_code);

		bool	WriteFile(
					int fd,
					char* buffer,
					int to_write,
					int& bytes_write,
					string& err);
		
		bool    CopyFile(
					string filename,
					string target_filename,
					string& err,
					int& error_code);

		bool    CopyFile(
					string filename,
					string target_filename,
					string& err);

		bool	ParseDir(
					string path,
					string& dir,
					string& err,
					int& error_code);

		bool	ParseDir(
					string path,
					string& dir,
					string& err);

		bool	MakeDir(
					string path,
					int mode,
					string& err,
					int& error_code);

		bool	MakeDir(
					string path,
					int mode,
					string& err);
	}

}//end namespace iDirect


#endif

