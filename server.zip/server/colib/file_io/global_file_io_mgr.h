#if !defined(__GLOBAL_FILE_IO_MGR_H__)
#define __GLOBAL_FILE_IO_MGR_H__

#include "file_io_mgr.h"
#include "async_file_reader.h"
#include "async_file_writer.h"
#include "async_file_stats.h"
#include "async_file_delete.h"
#include "async_file_rename.h"
#include "async_file_copy.h"
#include "async_dir_list.h"

#include <console/session.h>
#include <config/value.h>
#include <options/options.h>

namespace colib
{
	class GlobalFileIoMgr : public FileIoMgr
	{		
		public:
		
			enum Params
			{
				Param_concurrent_file_read_limit,
				Param_max_file_read_limit,	
				Param_concurrent_file_write_limit,
				Param_max_file_write_limit,	
				Param_concurrent_file_delete_limit,
				Param_max_file_delete_limit,	
				Param_concurrent_file_rename_limit,
				Param_max_file_rename_limit,			
				Param_concurrent_file_copy_limit,
				Param_max_file_copy_limit,			
				Param_concurrent_file_stats_limit,
				Param_max_file_stats_limit,
				Param_concurrent_dir_list_limit,
				Param_max_dir_list_limit
			};

			static GlobalFileIoMgr& GetInstance();

			bool Init();
			bool Reload(const Options* opt, string& err);
	
			/* **************************** */
			/*        Read File             */
			/* **************************** */
			//
			// Read whole file
			//
			virtual bool ReadFile(
							string file_name, 
							const Callback1<const AsyncReaderBase&>& requester_cb, 
							void* context = 0) 
			{ return m_general_reader.ReadFile(file_name, requester_cb, context); }
			//
			// Read reset of file from offset
			//
			virtual bool ReadFile(
							string file_name,
						   	int offset,	
							const Callback1<const AsyncReaderBase&>& requester_cb, 
							void* context = 0) 
			{ return m_general_reader.ReadFile(file_name, offset, requester_cb, context); }
			//
			// Read file with offset with desired length
			//
			virtual bool ReadFile(
							string file_name, 
							int offset, 
							int length, 
							const Callback1<const AsyncReaderBase&>& requester_cb, 
							void* context = 0) 
			{ return m_general_reader.ReadFile(file_name, offset, length, requester_cb, context); }
			//
			// Read whole file - FIFO
			//
			virtual bool QueueReadFile(
							string file_name, 
							const Callback1<const AsyncReaderBase&>& requester_cb, 
							void* context = 0)
			{ return m_fifo_reader.ReadFile(file_name, requester_cb, context); }
			//
			// Read reset of file from offset - FIFO
			//
			virtual bool QueueReadFile(
							string file_name,
						   	int offset,	
							const Callback1<const AsyncReaderBase&>& requester_cb, 
							void* context = 0)
			{ return m_fifo_reader.ReadFile(file_name, offset, requester_cb, context); }
			//
			// Read file with offset with desired length - FIFO
			//
			virtual bool QueueReadFile(
							string file_name, 
							int offset, 
							int length, 
							const Callback1<const AsyncReaderBase&>& requester_cb, 
							void* context = 0)
			{ return m_fifo_reader.ReadFile(file_name, offset, length, requester_cb, context); }
			//
			// Maximum read limit
			//
			virtual unsigned MaxReadLimit() const { return DiskFileReader::MAX_DISK_FILE_READ_LENGTH; }
			
			/* **************************** */
			/*        Write File            */
			/* **************************** */
			//
			// Overwrite a file
			//
			virtual bool WriteFile(
							string file_name, 
							const char* data,
							int length, 
							const Callback1<const AsyncWriterBase&>& requester_cb, 
							void* context = 0)
			{ return m_general_writer.WriteFile(file_name, data, length, requester_cb, context); }
			//
			// Overwrite a file, when succeed, rename to new filename
			//	
			virtual bool WriteFileWithMove(
							string file_name, 
							string target_file_name,
							const char* data,
							int length, 
							const Callback1<const AsyncWriterBase&>& requester_cb, 
							void* context = 0)
			{ return m_general_writer.WriteFileWithMove(file_name, data, length, requester_cb, context, target_file_name); }
			//
			// Append to a file
			//
			virtual bool AppendFile(
							string file_name, 
							const char* data,
							int length, 
							const Callback1<const AsyncWriterBase&>& requester_cb, 
							void* context = 0)
			{ return m_general_writer.AppendFile(file_name, data, length, requester_cb, context); }
			//
			// Append to a file, when succeed, rename to new filename
			//
			virtual bool AppendFileWithMove(
							string file_name, 
							string target_file_name,
							const char* data,
							int length, 
							const Callback1<const AsyncWriterBase&>& requester_cb, 
							void* context = 0)
			{ return m_general_writer.AppendFileWithMove(file_name, data, length, requester_cb, context, target_file_name); }
			//
			// Overwrite a file - FIFO
			//
			virtual bool QueueWriteFile(
							string file_name, 
							const char* data,
							int length, 
							const Callback1<const AsyncWriterBase&>& requester_cb, 
							void* context = 0)
			{ return m_fifo_writer.WriteFile(file_name, data, length, requester_cb, context); }
			//
			// Overwrite a file, when succeed, rename to new filename - FIFO
			//	
			virtual bool QueueWriteFileWithMove(
							string file_name, 
							string target_file_name,
							const char* data,
							int length, 
							const Callback1<const AsyncWriterBase&>& requester_cb, 
							void* context = 0)
			{ return m_fifo_writer.WriteFileWithMove(file_name, data, length, requester_cb, context, target_file_name); }
			//
			// Append to a file - FIFO
			//
			virtual bool QueueAppendFile(
							string file_name, 
							const char* data,
							int length, 
							const Callback1<const AsyncWriterBase&>& requester_cb, 
							void* context = 0)
			{ return m_fifo_writer.AppendFile(file_name, data, length, requester_cb, context); }
			//
			// Append to a file, when succeed, rename to new filename - FIFO
			//
			virtual bool QueueAppendFileWithMove(
							string file_name, 
							string target_file_name,
							const char* data,
							int length, 
							const Callback1<const AsyncWriterBase&>& requester_cb, 
							void* context = 0)
			{ return m_fifo_writer.AppendFileWithMove(file_name, data, length, requester_cb, context, target_file_name); }
			//
			// Maximum write limit
			//
			virtual unsigned MaxWriteLimit() const { return DiskFileWriter::MAX_DISK_FILE_WRITE_LENGTH; }
	
			/* **************************** */
			/*        Delete File           */
			/* **************************** */
			//
			// Delete a file
			//
			virtual bool DeleteFile(
							string file_name, 
							const Callback1<const FileDeleteBase&>& requester_cb, 
							void* context = 0)
			{ return m_general_file_remover.DeleteFile(file_name, requester_cb, context); }
			//
			// Delete a file - FIFO
			//
			virtual bool QueueDeleteFile(
							string file_name, 
							const Callback1<const FileDeleteBase&>& requester_cb, 
							void* context = 0)
			{ return m_fifo_file_remover.DeleteFile(file_name, requester_cb, context); }
	
			/* **************************** */
			/*        Rename File           */
			/* **************************** */
			//
			// Rename a file
			//
			virtual	bool RenameFile(
							string file_name, 
							string target_name,
							const Callback1<const FileRenameBase&>& requester_cb, 
							void* context = 0)
			{ return m_general_file_renamer.RenameFile(file_name, target_name, requester_cb, context); }
			//
			// Rename a file - FIFO
			//
			virtual	bool QueueRenameFile(
							string file_name, 
							string target_name,
							const Callback1<const FileRenameBase&>& requester_cb, 
							void* context = 0)
			{ return m_fifo_file_renamer.RenameFile(file_name, target_name, requester_cb, context); }
	
			/* **************************** */
			/*        Copy File             */
			/* **************************** */
			//
			// Copy a file
			//
			virtual	bool CopyFile(
							string file_name, 
							string target_name,
							const Callback1<const FileCopyBase&>& requester_cb, 
							void* context = 0)
			{ return m_general_file_copier.CopyFile(file_name, target_name, requester_cb, context); }
			//
			// Copy a file - FIFO
			//
			virtual	bool QueueCopyFile(
							string file_name, 
							string target_name,
							const Callback1<const FileCopyBase&>& requester_cb, 
							void* context = 0)
			{ return m_fifo_file_copier.CopyFile(file_name, target_name, requester_cb, context); }

			/* **************************** */
			/*        Stats File            */
			/* **************************** */
			//
			// Get a file stats
			//
			virtual bool StatsFile(
							string file_name, 
							const Callback1<const FileStatsBase&>& requester_cb, 
							void* context = 0)
			{ return m_general_file_stats_collector.StatsFile(file_name, requester_cb, context); }
			//
			// Get a file stats - FIFO
			//
			virtual bool QueueStatsFile(
							string file_name, 
							const Callback1<const FileStatsBase&>& requester_cb, 
							void* context = 0)
			{ return m_fifo_file_stats_collector.StatsFile(file_name, requester_cb, context); }

			/* **************************** */
			/*        Dir List Files        */
			/* **************************** */
			//
			// List files of a directory
			//
			virtual bool ListDir(
							string dir_name, 
							const Callback1<const DirListBase&>& requester_cb, 
							void* context = 0)
			{ return m_general_dir_lister.ListDir(dir_name, requester_cb, context); }
			//
			// List files of a directory - FIFO
			//
			virtual bool QueueListDir(
							string dir_name, 
							const Callback1<const DirListBase&>& requester_cb, 
							void* context = 0)
			{ return m_fifo_dir_lister.ListDir(dir_name, requester_cb, context); }
			//
			// Console Command
			//
			virtual void ConsoleCommand(Writable* con, int argc, char* argv[]);

		private:
		
			GlobalFileIoMgr();

			void ReloadParams();
		
			MemberSet m_trace_set;
			//
			DiskFileReadGeneral m_general_reader;
			DiskFileReadFifo m_fifo_reader;
			//
			DiskFileWriteGeneral m_general_writer;
			DiskFileWriteFifo m_fifo_writer;	
			//
			DiskFileDeleteGeneral m_general_file_remover;
			DiskFileDeleteFifo m_fifo_file_remover;
			//
			DiskFileRenameGeneral m_general_file_renamer;
			DiskFileRenameFifo m_fifo_file_renamer;	
			//
			DiskFileCopyGeneral m_general_file_copier;
			DiskFileCopyFifo m_fifo_file_copier;	
			//
			DiskFileStatsGeneral m_general_file_stats_collector;
			DiskFileStatsFifo m_fifo_file_stats_collector;
			//
			DiskDirListGeneral m_general_dir_lister;
			DiskDirListFifo m_fifo_dir_lister;
			//
			ValueList m_params;
	};
	#define GLOBALFILEIOMGR_PARAM(param) m_params[GlobalFileIoMgr::Param_##param].AsInt()

	void GlobalFileIoMgrConsoleCommand(void*, ConsoleSession* con, int argc, char* argv[]);
}

#endif
