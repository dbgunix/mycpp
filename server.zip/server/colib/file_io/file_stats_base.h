#if !defined(__IDIRECT_FILE_STATS_BASE_H__)
#define __IDIRECT_FILE_STATS_BASE_H__

#include "file_io_base.h"
#include <utils/callback.h>

#include <stdlib.h>

namespace colib
{
	class FileStatsBase: public FileIoBase
	{
		public:

			virtual ~FileStatsBase() {}

			virtual IoType GetType() const { return STATS; }
			virtual string Print() const;
			virtual string PrintFile() const;

			bool IsDirectory() const { return m_is_directory; }
			int64_t GetAccessTime() const { return m_access_time; }
			int64_t GetModifyTime() const { return m_modify_time; }
			int64_t GetChangeTime() const { return m_change_time; }
	
			FileStatsBase(const FileStatsBase&) = delete;
			FileStatsBase& operator=(const FileStatsBase&) = delete;

		protected:
		
			FileStatsBase();
			FileStatsBase(string file_name, const Callback1<const FileStatsBase&>& requester_cb, void* context);
		
			void SetDirectory(bool is_directory) { m_is_directory = is_directory; }
			void SetAccessTime(int64_t access_time) { m_access_time = access_time; }
			void SetModifyTime(int64_t modify_time) { m_modify_time = modify_time; }
			void SetChangeTime(int64_t change_time) { m_change_time = change_time; }
			void SetCallback(const Callback1<const FileStatsBase&>& requester_cb) { m_requester_cb = requester_cb; }
	
			virtual void Reset();
	
			void DispatchCB() { m_requester_cb.Dispatch(*this); }

		protected:
		
			bool m_is_directory;
			int64_t m_access_time;
			int64_t m_modify_time;
			int64_t m_change_time;
			Callback1<const FileStatsBase&> m_requester_cb;
	};
	
	inline void FileStatsBase::Reset() 
	{ 
		FileIoBase::Reset(); 
		m_is_directory = false; 
		m_access_time = 0; 
		m_modify_time = 0; 
		m_change_time = 0;
		m_requester_cb.Clear();
	}
	
}

#endif
