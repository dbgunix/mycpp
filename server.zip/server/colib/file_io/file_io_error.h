#ifndef FILE_IO_ERROR_H
#define FILE_IO_ERROR_H

namespace colib 
{
	namespace FileIoError 
	{
		const int SUCCESS 					= 0;

		// errors common to all local file io operations
		const int ADD_ACTIVITY_FAILED 		= 1001;

		// errors common to read/write operations
		const int RW_SIZE_EXCEEDS_LIMIT		= 1101;

		// errors to write operations
		const int WRITE_SIZE_INVALID 		= 1301;
	}
}

#endif
