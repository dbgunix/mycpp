// large_file_io_mgr.h
// vi:set ts=4 sw=4 nowrap:

#ifndef LARGE_FILE_IO_MGR_H_ALREADY_INCLUDED
#define LARGE_FILE_IO_MGR_H_ALREADY_INCLUDED

#include "large_file_io.h"
#include <event_loop/activity_hld.h>

#include <vector>

namespace colib
{	
	class LargeFileIoMgr
	{
		public:
	
			bool ReadFile(
						string filename, 
						const Callback1<const AsyncReaderBase&>& requester_cb,
						void* context = 0,
						FileIoMgr& file_io_mgr = GlobalFileIoMgr::GetInstance());
	
			bool ReadFile(
						string filename, 
						const Callback3<char*, int, void*>& on_read_succeed,
						const Callback2<string, void*>& on_read_failed,
						void* context,
						string& err,
						FileIoMgr& file_io_mgr = GlobalFileIoMgr::GetInstance());
		
			bool WriteFile(
						string filename,
						char* data, int len,
						const Callback1<const AsyncWriterBase&>& requester_cb,
						void* context = 0,
						FileIoMgr& file_io_mgr = GlobalFileIoMgr::GetInstance());
	
			bool WriteFile(
						string filename,
						char* data, int len,
						const Callback1<void*>& on_write_succeed,
						const Callback2<string, void*>& on_write_failed,
						void* context,
						string& err,
						FileIoMgr& file_io_mgr = GlobalFileIoMgr::GetInstance());
		
			bool SafeWriteFile(
						string filename,
						char* data, int len,
						const Callback1<const AsyncWriterBase&>& requester_cb,
						void* context = 0,
						FileIoMgr& file_io_mgr = GlobalFileIoMgr::GetInstance());
		
			bool SafeWriteFile(
						string filename,
						char* data, int len,
						const Callback1<void*>& on_write_succeed,
						const Callback2<string, void*>& on_write_failed,
						void* context,
						string& err,
						FileIoMgr& file_io_mgr = GlobalFileIoMgr::GetInstance());
	
		protected:

			virtual LargeFileIO* GetFileIO(string filename) = 0;	
	
			LargeFileIoMgr() {};
			virtual ~LargeFileIoMgr() {};
	};	

	class GlobalLargeFileIoMgr : public LargeFileIoMgr, public LargeFileIoReleaser
	{
		public:

			static GlobalLargeFileIoMgr& GetInstance();
		
			virtual void Release(LargeFileIO* io);
			
			bool QueueReadFile(
						string file_name, 
						const Callback1<const AsyncReaderBase&>& requester_cb, 
						void* context = 0,
						FileIoMgr& file_io_mgr = GlobalFileIoMgr::GetInstance());
			
			bool QueueReadFile(
						string filename, 
						const Callback3<char*, int, void*>& on_read_succeed,
						const Callback2<string, void*>& on_read_failed,
						void* context,
						string& err,
						FileIoMgr& file_io_mgr = GlobalFileIoMgr::GetInstance());

			bool QueueWriteFile(
						string file_name, 
						char* data,
						int length, 
						const Callback1<const AsyncWriterBase&>& requester_cb, 
						void* context = 0,
						FileIoMgr& file_io_mgr = GlobalFileIoMgr::GetInstance());
		
			bool QueueWriteFile(
						string filename,
						char* data, int len,
						const Callback1<void*>& on_write_succeed,
						const Callback2<string, void*>& on_write_failed,
						void* context,
						string& err,
						FileIoMgr& file_io_mgr = GlobalFileIoMgr::GetInstance());
		
			bool QueueSafeWriteFile(
						string filename,
						char* data, int len,
						const Callback1<const AsyncWriterBase&>& requester_cb,
						void* context = 0,
						FileIoMgr& file_io_mgr = GlobalFileIoMgr::GetInstance());
		
			bool QueueSafeWriteFile(
						string filename,
						char* data, int len,
						const Callback1<void*>& on_write_succeed,
						const Callback2<string, void*>& on_write_failed,
						void* context,
						string& err,
						FileIoMgr& file_io_mgr = GlobalFileIoMgr::GetInstance());

		private:

			virtual LargeFileIO* GetFileIO(string filename);
			eCallbackRt Cleanup();

		private:
			
			ActivityHold m_file_io_clean_act;
			std::vector<LargeFileIO*> m_file_io_to_remove;

		private:
			//
			// RequestBase
			//
			class LargeFileIORequestBase
			{
				public:

					LargeFileIORequestBase();
					virtual ~LargeFileIORequestBase() {};
	
				public:

					FileIoMgr* m_file_io_mgr;
					string m_filename;
					void* m_context;
			};
			//
			// Queue Read
			//
			class LargeFileIOReadRequest : public LargeFileIORequestBase
			{
				public:

					LargeFileIOReadRequest();
					LargeFileIOReadRequest(const LargeFileIOReadRequest&);
					virtual ~LargeFileIOReadRequest() {};

				public:

					Callback1<const AsyncReaderBase&> m_read_complete_cbk;
					Callback3<char*, int, void*> m_read_succeed_cbk;
					Callback2<string, void*> m_read_failed_cbk;
			};
			Dlist<LargeFileIOReadRequest> m_queue_read_request;
			void QueueReadComplete(const AsyncReaderBase& rdr);
			void StartNextQueueRead();
			//
			// Queue Write
			//
			class LargeFileIOWriteRequest : public LargeFileIORequestBase
			{
				public:

					LargeFileIOWriteRequest();
					LargeFileIOWriteRequest(const LargeFileIOWriteRequest&);
					virtual ~LargeFileIOWriteRequest() {};

				public:
				
					std::vector<char> m_data_buffer;
					bool m_safe_write;

					Callback1<const AsyncWriterBase&> m_write_complete_cbk;
					Callback1<void*> m_write_succeed_cbk;
					Callback2<string, void*> m_write_failed_cbk;
			};
			Dlist<LargeFileIOWriteRequest> m_queue_write_request;
			void QueueWriteComplete(const AsyncWriterBase& wtr);
			void StartNextQueueWrite();
			
		private:

			GlobalLargeFileIoMgr();
			virtual ~GlobalLargeFileIoMgr();	
	};

}//end namespace iDirect


#endif

