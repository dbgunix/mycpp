#include "async_file_reader.h"
#include "file_io_error.h"
#include "file_io_utils.h"
#include <event_loop/event_loop.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>

namespace colib
{
	DiskFileReader::DiskFileReader()
		: AsyncReaderBase()
		, m_start_act(callbackRt(this, &DiskFileReader::StartTask), "StartTaskAct")
		, m_act(callbackRt(this, &DiskFileReader::DoTask), "TaskAct")
		, m_fd(-1)
	 	, m_read_offset(0)	
	 	, m_bytes_to_read(0)
		, m_fail_read_limit(false)  
	{
	}

	DiskFileReader::~DiskFileReader()
	{
		Stop();
	}

	string DiskFileReader::Print() const
	{
		return AsyncReaderBase::Print() + string::Format(
												"Fd: %d\n"
												"Bytes to read: %d\n"
												"Read offset: %d\n"
												"Start task activity is %sactive\n" 
												"Task activity is %sactive\n", 
												m_fd,
												m_bytes_to_read,
												m_read_offset,
												m_start_act.IsActive() ? "" : "not ",
												m_act.IsActive() ? "" : "not ");
	}

	void DiskFileReader::CloseFile()
	{
		if ( m_fd > 0 ) close(m_fd);
		m_fd = -1;
	}

	void DiskFileReader::Reset()
	{
		AsyncReaderBase::Reset();
		CloseFile();
		m_read_offset = 0;
	   	m_bytes_to_read = 0;
		m_fail_read_limit = false;
	}

	void DiskFileReader::Init(
							string file_name, 
							int offset, 
							int length, 
							const Callback1<const AsyncReaderBase&>& requester_cb, 
							void* context)
	{
		Reset();
		SetFileName(file_name);
		SetOffset(offset);
		SetDataLength(length);
		SetCallback(requester_cb);
		SetContext(context);
	}
	
	bool DiskFileReader::ReadInitialize(int flag, string& err, int& error_code)
	{	
		//
		// Get filesize
		//
		int filesize = 0;
		if ( !DiskFile::GetFileSize(GetFileName(), filesize, err, error_code) )
		{
			err = "Fail to get filesize: " + err;
			return false;
		}
		SetFileSize(filesize);
		//
		// Calculate bytes to read
		//	
		int bytes_left = GetFileSize() - GetOffset();
		m_bytes_to_read = ( GetDataLength() == -1 ) ? bytes_left : GetDataLength();
		if ( m_bytes_to_read > bytes_left ) m_bytes_to_read = bytes_left;
		//
		// Sanity check
		//
		if ( m_bytes_to_read > static_cast<int>(MaxReadLimit()) ) 
		{
			m_fail_read_limit = true;	
			err = string::Format("bytes to read (%d) exceed max allowed read limit (%u)", m_bytes_to_read, MaxReadLimit());
			error_code = FileIoError::RW_SIZE_EXCEEDS_LIMIT;
			return false;	
		}
		//
		// Open file to read
		//
		m_fd = open(GetFileName().c_str(), flag);
		if ( m_fd <= 0 )
		{	
			err = string::Format("Fail to open file: %s (%d)", strerror(errno), errno);
			error_code = errno;
			return false;
		}	
		//
		// Offset
		//
		if ( -1 == lseek(m_fd, GetOffset(), SEEK_SET) )
		{	
			err = string::Format("Fail to lseek: %s (%d)", strerror(errno), errno);
			error_code = errno;
			CloseFile();
			return false;	
		}

		return true;
	}

	eCallbackRt DiskFileReader::StartTask()
	{	
		bool ret = true;
		string err;
		int error_code;
		//
		// Initialize
		//
		if ( ret && !ReadInitialize(O_RDONLY | O_NONBLOCK, err, error_code) )
		{	
			SetError(err);
			SetErrorCode(error_code);
			ret = false;
		}
		//
		// Add activity
		//
		if ( ret && !EventLoop::GetInstance().AddActivity(&m_act) )
		{	
			SetError("Fail to add task activity");
			SetErrorCode(FileIoError::ADD_ACTIVITY_FAILED);
			ret = false;
		}

		if ( !ret )
		{
			SetStatus(IoBase::FAILED);
			CloseFile();
			ReadComplete();
		}
		
		return DontRunAgain;
	}

	bool DiskFileReader::Start()
	{
		bool ret = EventLoop::GetInstance().AddActivity(&m_start_act);	
		if ( ret ) SetStatus(IoBase::IN_PROGRESS);
		return ret;
	}	

	void DiskFileReader::Stop()
	{
		CloseFile();
		EventLoop::GetInstance().DeleteActivity(&m_act);
	}

	bool DiskFileReader::ReadData(int to_read, string& err, int& error_code)
	{
		//
		// Read data
		//
		int bytes_read = 0;
		if ( !DiskFile::ReadFile(m_fd, m_data + m_read_offset, to_read, bytes_read, err, error_code) ) return false;
		m_read_offset += bytes_read;
		m_bytes_to_read -= bytes_read;
		return true;
	}

	eCallbackRt DiskFileReader::DoTask()
	{
		const int BLOCK_SIZE = 1024;
		int to_read = std::min(BLOCK_SIZE, m_bytes_to_read);
		
		string err;
		int error_code;
		if ( !ReadData(to_read, err, error_code) )
		{
			SetError(err);
			SetErrorCode(error_code);
			SetStatus(IoBase::FAILED);
			CloseFile();
			ReadComplete();
			return DontRunAgain;
		}
		if ( m_bytes_to_read > 0 ) return RunAgain;
		//		
		// Read complete
		//
		SetError("Task complete");
		SetStatus(IoBase::SUCCEEDED);
		CloseFile();
		//
		// Finish
		//
		SetDataLength(m_read_offset);
		ReadComplete();
		return DontRunAgain;
	}

	DiskFileReaderSA::DiskFileReaderSA()
		: DiskFileReader()
		, m_job(*this)
	{
	}
	
	bool DiskFileReaderSA::ReadFile(
								string file_name, 
								const Callback1<const AsyncReaderBase&>& requester_cb, 
								void* context)
	{
		return ReadFile(file_name, 0, -1, requester_cb, context);
	}
	
	bool DiskFileReaderSA::ReadFile(
								string file_name, 
								int offset,
								const Callback1<const AsyncReaderBase&>& requester_cb, 
								void* context)
	{
		return ReadFile(file_name, offset, -1, requester_cb, context);
	}

	bool DiskFileReaderSA::ReadFile(
								string file_name, 
								int offset, 
								int length, 
								const Callback1<const AsyncReaderBase&>& requester_cb, 
								void* context)
	{
		Init(file_name, offset, length, requester_cb, context);
		return m_job.Start();
	}

	void DiskFileReaderSA::ReadComplete()
	{
		m_job.Complete();
	}
		
	string DiskFileReaderSA::Print() const
	{
		return DiskFileReader::Print() + "Job type: SA\n";
	}
	
	DiskFileReaderMgd::DiskFileReaderMgd(unsigned job_id, IoJobMgrGlobal& job_mgr)
		: DiskFileReader()
		, m_job_id(job_id)
		, m_job_mgr(job_mgr)
	{
	}
	
	string DiskFileReaderMgd::Print() const
	{
		return DiskFileReader::Print() + string::Format(
											"Job type: Mgd\n"
											"Job ID: %u\n",
											m_job_id);
	}

	DiskFileReaderMgr::DiskFileReaderMgr(MemberSet& trace_set, unsigned max_limit)
		: IoJobMgrGlobal(trace_set)
	 	, m_max_limit(max_limit)
	{
	}

	bool DiskFileReaderMgr::ReadFile(
								string file_name, 
								const Callback1<const AsyncReaderBase&>& requester_cb, 
								void* context)
	{
		return ReadFile(file_name, 0, -1, requester_cb, context);
	}
	
	bool DiskFileReaderMgr::ReadFile(
								string file_name, 
								int offset,
								const Callback1<const AsyncReaderBase&>& requester_cb, 
								void* context)
	{
		return ReadFile(file_name, offset, -1, requester_cb, context);
	}

	bool DiskFileReaderMgr::ReadFile(
								string file_name, 
								int offset, 
								int length, 
								const Callback1<const AsyncReaderBase&>& requester_cb, 
								void* context)
	{
		DiskFileReaderMgd* job = static_cast<DiskFileReaderMgd*>(AddJob(/*type(ignored)*/0));
		if ( !job ) return false;
		job->Init(file_name, offset, length, requester_cb, context);
		return true;
	}

	IoBase* DiskFileReaderMgr::CreateIo(unsigned/*type(ignored)*/, unsigned job_id, IoJobMgrGlobal& mgr)
	{
		return new DiskFileReaderMgd(job_id, mgr);
	}

	DiskFileReadFifo::DiskFileReadFifo(MemberSet& trace_set, unsigned max_limit)
		: DiskFileReaderMgr(trace_set, max_limit)
	{
	}

	DiskFileReadGeneral::DiskFileReadGeneral(MemberSet& trace_set, unsigned concurrent_limit, unsigned max_limit)
		: DiskFileReaderMgr(trace_set, max_limit)
		, m_concurrent_limit(concurrent_limit)
	{
	}	
}

