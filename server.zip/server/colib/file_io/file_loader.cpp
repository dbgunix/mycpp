// file_loader.cpp
// vi:set ts=4 sw=4 nowrap:

#include "file_loader.h"

namespace colib
{
	static ValueList::ValueHolder InitStats()
	{
		return
		{
			Value("num_load_succeed", 0 ),
			Value("num_load_skip", 0),	
			Value("num_load_fail", 0 ),
			Value("fail_reason", "" )
		};
	};

	FileLoaderMgr::FileLoaderMgr(FileIoMgr& file_io_mgr)
		: m_file_io_mgr(&file_io_mgr)
		, m_auto_load_timer("FileAutoLoadTimer")
		, m_file_reader()  
		, m_file_mtime(0)
		, m_file_stat_in_progress(false)
		, m_filename()
		, m_on_load()
		, m_freq_sec(0)  
		, m_stats(InitStats())
	{
		m_auto_load_timer.SetExpireCb(callback(this, &FileLoaderMgr::AutoLoad));
	}	

	FileLoaderMgr::~FileLoaderMgr()
	{
	}	

	bool FileLoaderMgr::Init(string&, string filename, const Callback2<char*, int>& cbk, int freq_sec)
	{	
		m_filename = filename;	
		m_on_load = cbk;
		m_freq_sec = freq_sec;
		m_auto_load_timer.Start(m_freq_sec*1000);
		return true;
	}

	void FileLoaderMgr::AutoLoad(unsigned, void*)
	{	
		if ( m_file_stat_in_progress || m_file_reader.InProgress() ) 
		{
			++LOADER_STAT(num_load_skip);
			return;
		}
		m_file_stat_in_progress = true;
		m_file_io_mgr->StatsFile(m_filename, callback(this, &FileLoaderMgr::CheckFile));
	}

	void FileLoaderMgr::CheckFile(const FileStatsBase& stats)
	{
		m_file_stat_in_progress = false;

		if ( stats.GetStatus() != IoBase::SUCCEEDED ) 
		{	
			++LOADER_STAT(num_load_fail);
			m_stats[FileLoaderMgr::Stat_fail_reason].SetFromString(stats.GetError().c_str());
			return;
		}

		int64_t file_mtime = m_file_mtime;
		m_file_mtime = stats.GetModifyTime();
		if ( m_file_mtime != file_mtime ) 
		{
			string err;
			if ( !m_file_reader.Read(
						m_filename, 
						callback(this, &FileLoaderMgr::ReadSucceed),
						callback(this, &FileLoaderMgr::ReadFailed),
						/*context =*/0,
						err,
						*m_file_io_mgr) )
			{
				++LOADER_STAT(num_load_fail);
				m_stats[FileLoaderMgr::Stat_fail_reason].SetFromString(err.c_str());
			}
		}
	}

	void FileLoaderMgr::ReadSucceed(char* data, int len, void*)
	{
		++LOADER_STAT(num_load_succeed);
		m_on_load.Dispatch(data, len);
	}

	void FileLoaderMgr::ReadFailed(string err, void*)
	{	
		++LOADER_STAT(num_load_fail);
		m_stats[FileLoaderMgr::Stat_fail_reason].SetFromString(err.c_str());
	}

	void FileLoaderMgr::ConsoleCommand(ConsoleSession* con, int argc, char* argv[])
	{
		const char* usage = "Usage:\tstats|status";

		if ( argc == 0 )
		{
			con->PrintString(usage);
			return;
		}

		if ( !strcmp(argv[0], "stats") )
		{
			m_stats.ConsoleCommand(con, argc-1, argv+1);
		}
		else if ( !strcmp(argv[0], "status") )
		{
			con->Print(
					"m_auto_load_timer is %sactive\n"
					"m_filename = %s\n"
					"m_file_mtime = %ld\n"
					"m_file_stat_in_progress = %s\n"
					"m_file_read_in_progress = %s\n"
					"m_on_load is %sset\n"
					"m_freq_sec = %d\n",
					m_auto_load_timer.IsActive() ? "" : "not ",
					m_filename.c_str(),
					(long int)m_file_mtime,
					m_file_stat_in_progress ? "true" : "false",
					m_file_reader.InProgress() ? "true" : "false",
					m_on_load.IsSet() ? "" : "not ",
					m_freq_sec);
		}
		else con->PrintString(usage);
	}

}//end namespace iDirect

