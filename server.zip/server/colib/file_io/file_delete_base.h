#if !defined(__IDIRECT_FILE_DELETE_BASE_H__)
#define __IDIRECT_FILE_DELETE_BASE_H__

#include "file_io_base.h"
#include <utils/callback.h>

namespace colib
{
	class FileDeleteBase : public FileIoBase
	{
		public:
			
			virtual ~FileDeleteBase() {};

			virtual IoType GetType() const { return DELETE; }
			virtual string Print() const;

			FileDeleteBase(const FileDeleteBase&) = delete;
			FileDeleteBase& operator=(const FileDeleteBase&) = delete;

		protected:
			
			FileDeleteBase();
			FileDeleteBase(string file_name, const Callback1<const FileDeleteBase&>& requester_cb, void* context);

			void SetCallback(const Callback1<const FileDeleteBase&>& requester_cb) { m_requester_cb = requester_cb; }

			virtual void Reset();

			void DispatchCB() { m_requester_cb.Dispatch(*this); }

		protected:
		
			Callback1<const FileDeleteBase&> m_requester_cb;
	};
	
	inline void FileDeleteBase::Reset()
	{
		FileIoBase::Reset();
		m_requester_cb.Clear();
	}

}

#endif
