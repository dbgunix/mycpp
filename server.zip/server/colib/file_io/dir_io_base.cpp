#include "dir_io_base.h"

namespace colib
{
	DirIoBase::DirIoBase()
		: IoBase()
		, m_dir_name()
	{
	}

	DirIoBase::DirIoBase(string dir_name, void* context)
		: IoBase(context)
		, m_dir_name(dir_name)
	{
	}
	
	const char* DirIoBase::GetTypeStr() const
	{
		switch ( GetType() ) 
		{
			case LIST: return "LIST";
			default: return "UNKNOWN";			 
		}
	}

	string DirIoBase::PrintDir() const
	{	
		return string::Format(
					"DirName: %s\n",
					GetDirName().c_str());
	}

	string DirIoBase::Print() const
	{
		string type = string::Format("IoType: %s\n", GetTypeStr());
		return PrintDir() + type + IoBase::Print();
	}

}
