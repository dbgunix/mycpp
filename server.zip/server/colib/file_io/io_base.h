#if !defined(__IDIRECT_IO_BASE_H__)
#define __IDIRECT_IO_BASE_H__

#include <utils/string.h>

namespace colib
{
	class IoJobBase;
	//
	// Base class for file/directory IO operations
	//
	class IoBase
	{
		public:
			//
			// Status
			//
			enum Status
			{
				IDLE,
				IN_PROGRESS,
				SUCCEEDED,
				FAILED
			};

			virtual ~IoBase() {};

			Status GetStatus() const { return m_status; }
			const char* GetStatusStr() const;
			string GetError() const { return m_last_error; }
			int GetErrorCode() const { return m_error_code; }
			void* GetContext() const { return m_context; }
			virtual string Print() const;
			
			IoBase(const IoBase&) = delete;
			IoBase& operator=(const IoBase&) = delete;

		protected:
		
			IoBase();
			IoBase(void* context);
			//
			// Virtual functions called by IoJobBase
			//
			virtual bool Start() = 0;
			virtual void Stop() = 0;
			virtual void Complete() = 0;
			//
			void SetContext(void* context) { m_context = context; }
			void SetStatus(Status status) { m_status = status; }
			void SetError(string error) { m_last_error = error; }
			void SetErrorCode(int error_code) { m_error_code = error_code; }
			//
			virtual void Reset();

		protected:
		
			void* m_context;
			Status m_status;
			int m_error_code;
			string m_last_error;

		friend class IoJobBase;	
	};

	inline void IoBase::Reset()
	{
		m_context = 0;
		m_status = IDLE;
		m_error_code = 0;
		m_last_error.clear();
	}
}

#endif
