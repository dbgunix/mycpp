#include "file_io_test.h"
#include <event_loop/event_loop.h>
#include <file_io/async_file_reader.h>

#include <cstdio>
#include <signal.h>

static void sigterm_handler(int)
{
	static bool called = false;
	if ( called ) abort();
	colib::EventLoop::GetInstance().Terminate(called = true);
}

int main()
{
	signal(SIGTERM, sigterm_handler);
	signal(SIGINT,  sigterm_handler);

	if (!colib::EventLoop::GetInstance().Initialize())
	{
		fprintf(stderr, "Failed to init event loop\n");
		return 1;
	}

	colib::FileIoTest fio_test;
	fio_test.Init();

	colib::EventLoop::GetInstance().Main();

	return 0;
}
