#if !defined(__FILE_IO_TEST_H__)
#define __FILE_IO_TEST_H__

#include "../async_file_reader.h"
#include "../async_file_writer.h"

namespace colib
{

class FileIoTest
{
public:
	FileIoTest();
	void Init();

private:
	static const int BIN_DATA_SIZE = 1024;

	eCallbackRt StartBinaryTest();
	eCallbackRt StartTextTest();

	void BinaryWriteComplete(const AsyncWriterBase& writer);
	void BinaryReadComplete(const AsyncReaderBase& reader);
	void TextWriteComplete(const AsyncWriterBase& writer);
	void TextReadComplete(const AsyncReaderBase& reader);

	// binary test data
	char m_bin_data[1024];
	// text test data
	string m_text_data;

	AsyncReaderSA m_sa_rdr;
	AsyncWriterSA m_sa_writer;

	ActivityHold m_bin_test_start_act;
	ActivityHold m_text_test_start_act;
};

}

#endif
