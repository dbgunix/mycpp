#include "file_io_test.h"
//#include "../global_read_mgr.h"
#include <utils/dump_hex.h>
#include <event_loop/event_loop.h>

#include <cstdio>

namespace colib
{

FileIoTest::FileIoTest()
	: m_bin_data()
	, m_text_data("The quick brown fox jumps over the lazy dog")
	, m_sa_rdr()
	, m_sa_writer()
	, m_bin_test_start_act(callbackRt(this, &FileIoTest::StartBinaryTest), "FileIoBinTest")
	, m_text_test_start_act(callbackRt(this, &FileIoTest::StartTextTest), "FileIoTextTest")
{
	for (int ii(0); ii < BIN_DATA_SIZE; ++ii)
	{
		m_bin_data[ii] = ii;
	}
}

void FileIoTest::Init()
{
	// add activity for binary test
	EventLoop::GetInstance().AddActivity(&m_bin_test_start_act);
}

eCallbackRt FileIoTest::StartBinaryTest()
{
	// write using global manager, with file move/rename
	GlobalFileIoMgr::GetInstance().WriteFileWithMove("./test_bin_tmp_out", "./test_bin_final_out", m_bin_data, BIN_DATA_SIZE, callback(this, &FileIoTest::BinaryWriteComplete));
	return DontRunAgain;
}

eCallbackRt FileIoTest::StartTextTest()
{
	// write using standalone writer
	m_sa_writer.Start("text_test.txt", m_text_data.c_str(), m_text_data.get_length(), callback(this, &FileIoTest::TextWriteComplete), NULL);
	return DontRunAgain;
}

void FileIoTest::BinaryWriteComplete(const AsyncWriterBase& writer)
{
	if (writer.GetStatus() != AsyncFileIoBase::SUCCEEDED)
	{
		std::printf("binary write failed (%s)\n", writer.GetError().c_str());
	}
	else
	{
		std::printf("binary write succeeded\n");
		// read back using standalone reader
		// since we did a move/rename need to use the "final" file name, not the temporary one
		m_sa_rdr.Start(writer.GetMoveToName(), callback(this, &FileIoTest::BinaryReadComplete), NULL);
	}
}

void FileIoTest::BinaryReadComplete(const AsyncReaderBase& reader)
{
	if (reader.GetStatus() != AsyncFileIoBase::SUCCEEDED)
	{
		std::printf("binary read failed (%s)\n", reader.GetError().c_str());
	}
	else
	{
		std::printf("binary read succeeded, contents are:\n");
		DumpHex(reader.GetData(), reader.GetFileSize());
		std::printf("\n");
		EventLoop::GetInstance().AddActivity(&m_text_test_start_act);
	}
}

void FileIoTest::TextWriteComplete(const AsyncWriterBase& writer)
{
	if (writer.GetStatus() != AsyncFileIoBase::SUCCEEDED)
	{
		std::printf("text write failed (%s)\n", writer.GetError().c_str());
	}
	else
	{
		std::printf("text write succeeded\n");
		// read it back using global manager
		GlobalFileIoMgr::GetInstance().QueueFileRead(writer.GetFileName(), callback(this, &FileIoTest::TextReadComplete), NULL);
	}
}

void FileIoTest::TextReadComplete(const AsyncReaderBase& reader)
{
	if (reader.GetStatus() != AsyncFileIoBase::SUCCEEDED)
	{
		std::printf("text read failed (%s)\n", reader.GetError().c_str());
	}
	else
	{
		std::printf("text read succeeded, contents are:\n");
		std::printf("%s\n", reader.GetData());
	}
}

}
