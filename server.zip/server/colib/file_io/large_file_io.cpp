// large_file_io.cpp
// vi:set ts=4 sw=4 nowrap:

#include "large_file_io.h"
#include <utils/trace/trace.h>

namespace colib
{	
	//
	// LargeFileReaderBase
	//
	class LargeFileReaderBase : public AsyncReaderBase
	{
		public:

			LargeFileReaderBase(const AsyncReaderBase& rdr, const char* data, int len);
			virtual ~LargeFileReaderBase() {}
			// 
			virtual const char* GetData() const { return m_data; }
			virtual unsigned MaxReadLimit() const { return static_cast<unsigned>(-1); }
			virtual bool FailMaxReadLimit() const { return false; }

		private:

			virtual bool Start() { return true; }
			virtual void Stop() {};
			virtual void Complete() {};

		private:

			const char* m_data;
	};

	LargeFileReaderBase::LargeFileReaderBase(const AsyncReaderBase& rdr, const char* data, int len)
		: AsyncReaderBase()
		, m_data(data)
	{
		//
		// IoBase
		//
		SetContext(rdr.GetContext());
		SetStatus(rdr.GetStatus());
		SetError(rdr.GetError());
		SetErrorCode(rdr.GetErrorCode());
		//
		// FileIoBase
		//
		SetFileName(rdr.GetFileName());
		SetFileSize(rdr.GetFileSize());
		//
		// AsyncReaderBase
		//
		SetDataLength(len);
		SetOffset(rdr.GetOffset());
	}

	LargeFileIO::LargeFileIO(LargeFileIoReleaser* releaser)
		: m_file_io_mgr(0)
		, m_releaser(releaser)		  
		, m_read_complete_cbk()
		, m_write_complete_cbk()  
		, m_read_succeed_cbk()
		, m_read_failed_cbk()
		, m_write_succeed_cbk()
		, m_write_failed_cbk()
		, m_filename()  
		, m_tmp_filename()  
		, m_in_progress(false)
		, m_data_buffer()
		, m_write_offset(0)  
		, m_safe_write(false)  
	{
		m_data_buffer.reserve(INITIAL_BUFFER_SIZE);
	}
	
	LargeFileIO::LargeFileIO(const LargeFileIO&)
		: m_file_io_mgr(0)	
		, m_releaser(0)		  
		, m_read_complete_cbk()
		, m_write_complete_cbk()  	
		, m_read_succeed_cbk()
		, m_read_failed_cbk()
		, m_write_succeed_cbk()
		, m_write_failed_cbk()	
		, m_filename()  
		, m_tmp_filename()  
		, m_in_progress(false)
		, m_data_buffer()
		, m_write_offset(0)  
		, m_safe_write(false)  
	{
		m_data_buffer.reserve(INITIAL_BUFFER_SIZE);
	}
	
	bool LargeFileIO::Read(
					string filename,
					const Callback1<const AsyncReaderBase&>& requester_cb,
					void* context, 
					FileIoMgr& file_io_mgr)
	{
		if ( InProgress() ) return false;
	
		m_file_io_mgr = &file_io_mgr;
		m_read_complete_cbk = requester_cb;
		m_filename = filename;
		m_in_progress = true;
		m_data_buffer.clear();
		//
		// Request to read whole file
		//
		m_file_io_mgr->ReadFile(m_filename, callback(this, &LargeFileIO::ReadCb), context);
		//
		return true;
	}

	bool LargeFileIO::Read(
					string filename,
					const Callback3<char*, int, void*>& on_read_succeed, 
					const Callback2<string, void*>& on_read_failed, 
					void* context, 
					string& err,
					FileIoMgr& file_io_mgr)
	{
		if ( InProgress() )
		{
			err = m_filename + " read/write in progress, reject";
			return false;
		}
		
		m_read_succeed_cbk = on_read_succeed;
		m_read_failed_cbk = on_read_failed;
	
		if ( !Read(filename, callback(this, &LargeFileIO::OnReadComplete), context, file_io_mgr) )
		{
			err = "fail to start reading process";
			return false;
		}

		return true;
	}

	void LargeFileIO::OnReadComplete(const AsyncReaderBase& rdr)
	{
		if ( rdr.GetStatus() == IoBase::SUCCEEDED ) 
		{
			m_read_succeed_cbk.Dispatch(const_cast<char*>(rdr.GetData()), rdr.GetDataLength(), rdr.GetContext());
		}
		else
		{
			m_read_failed_cbk.Dispatch(rdr.GetError(), rdr.GetContext());
		}
	}

	void LargeFileIO::ReadCb(const AsyncReaderBase& rdr)
	{
		if ( rdr.GetStatus() != IoBase::SUCCEEDED )
		{
			if ( rdr.FailMaxReadLimit() )
			{
				//
				// Only fail the first time
				//
				if ( rdr.GetFileSize() > LARGE_FILE_WARNING_SIZE )
				{
					TRACE(
						"WARNING: trying to read a very large file %s (%d bytes) once\n"
						"This could cause major memory issue - consider refactor your code!\n",
						m_filename.c_str(), rdr.GetFileSize());
				}
				m_file_io_mgr->ReadFile(
						m_filename,
						m_data_buffer.size(),
						rdr.MaxReadLimit(),
						callback(this, &LargeFileIO::ReadCb),
						rdr.GetContext());
				return;
			}
			LargeFileReaderBase reader(rdr, &m_data_buffer[0], m_data_buffer.size());
			m_read_complete_cbk.Dispatch(reader);
			Done();
			return;
		}

		const char* data = rdr.GetData();
		int data_length = rdr.GetDataLength();
		//
		// Save data
		//
		m_data_buffer.insert(m_data_buffer.end(), data, data + data_length);
		//
		// Check if finished
		//
		unsigned filesize = rdr.GetFileSize();
		if ( m_data_buffer.size() >= filesize )
		{	
			LargeFileReaderBase reader(rdr, &m_data_buffer[0], m_data_buffer.size());
			m_read_complete_cbk.Dispatch(reader);
			Done();
			return;
		}
		//
		// Need read more
		//
		m_file_io_mgr->ReadFile(m_filename, m_data_buffer.size(), rdr.MaxReadLimit(), callback(this, &LargeFileIO::ReadCb), rdr.GetContext());
	}

	bool LargeFileIO::StoreWriteRequest(
					string filename,
					char* data, int len, 
					const Callback1<const AsyncWriterBase&>& requester_cb,
					bool safe_write,
					FileIoMgr& file_io_mgr)
	{	
		if ( InProgress() ) return false;
	
		m_file_io_mgr = &file_io_mgr;
		m_write_complete_cbk = requester_cb;
		m_filename = filename;
		m_in_progress = true;
		m_safe_write = safe_write;
		if ( m_safe_write ) m_tmp_filename = m_filename + string::Format(".tmp.%u", getpid());

		if ( len > LARGE_FILE_WARNING_SIZE ) 
		{
			TRACE(
				"WARNING: trying to write a file %s with large volumn of data (%d bytes) once\n"
				"This could cause major memory issue - consider refactor your code!\n",
				m_filename.c_str(), len);
		}
		//
		// Copy data
		//
		m_data_buffer.clear();
		m_data_buffer.insert(m_data_buffer.end(), data, data + len);
		m_write_offset = 0;
		//
		return true;
	}
	
	bool LargeFileIO::Write(
					string filename,
					char* data, int len, 
					const Callback1<const AsyncWriterBase&>& requester_cb, 
					void* context, 
					FileIoMgr& file_io_mgr)
	{
		if ( !StoreWriteRequest(
					filename,
					data, len, 
					requester_cb, 
					/*safe_write = */false, 
					file_io_mgr) )  return false;
		//
		// Request to write all
		//
		m_file_io_mgr->WriteFile(m_filename, &m_data_buffer[0], m_data_buffer.size(), callback(this, &LargeFileIO::WriteCb), context);
		
		return true;
	}

	bool LargeFileIO::Write(
					string filename,
					char* data, int len, 
					const Callback1<void*>& on_write_succeed, 
					const Callback2<string, void*>& on_write_failed, 
					void* context, 
					string& err,
					FileIoMgr& file_io_mgr)
	{	
		if ( InProgress() )
		{
			err = m_filename + " read/write in progress, reject";
			return false;
		}

		m_write_succeed_cbk = on_write_succeed;
		m_write_failed_cbk = on_write_failed;

		if ( !Write(filename, data, len, callback(this, &LargeFileIO::OnWriteComplete), context, file_io_mgr) )
		{
			err = "fail to start writing process";
			return false;
		}

		return true;
	}
		
	bool LargeFileIO::SafeWrite(
					string filename,
					char* data, int len, 
					const Callback1<const AsyncWriterBase&>& requester_cb, 
					void* context, 
					FileIoMgr& file_io_mgr)
	{
		if ( !StoreWriteRequest(
					filename,
					data, len, 
					requester_cb, 
					/*safe_write = */true, 
					file_io_mgr) )  return false;
		//
		// Request to write all
		//
		m_file_io_mgr->WriteFileWithMove(m_tmp_filename, m_filename, &m_data_buffer[0], m_data_buffer.size(), callback(this, &LargeFileIO::WriteCb), context);
	
		return true;
	}
	
	bool LargeFileIO::SafeWrite(
					string filename,
					char* data, int len, 
					const Callback1<void*>& on_write_succeed, 
					const Callback2<string, void*>& on_write_failed, 
					void* context, 
					string& err,
					FileIoMgr& file_io_mgr)
	{	
		if ( InProgress() )
		{
			err = m_filename + " read/write in progress, reject";
			return false;
		}

		m_write_succeed_cbk = on_write_succeed;
		m_write_failed_cbk = on_write_failed;

		if ( !SafeWrite(filename, data, len, callback(this, &LargeFileIO::OnWriteComplete), context, file_io_mgr) )
		{
			err = "fail to start writing process";
			return false;
		}

		return true;
	}

	void LargeFileIO::OnWriteComplete(const AsyncWriterBase& wtr)
	{
		if ( wtr.GetStatus() == IoBase::SUCCEEDED ) 
		{
			m_write_succeed_cbk.Dispatch(wtr.GetContext());
		}
		else
		{
			m_write_failed_cbk.Dispatch(wtr.GetError(), wtr.GetContext());
		}
	}

	void LargeFileIO::WriteLeft(unsigned limit, void* context)
	{	
		unsigned byte_left = m_data_buffer.size() - m_write_offset;
		char* data_left = &m_data_buffer[m_write_offset];

		if ( byte_left <= limit )
		{
			if ( m_safe_write ) 
			{
				m_file_io_mgr->AppendFileWithMove(
											m_tmp_filename, 
											m_filename, 
											data_left,
											byte_left,
											callback(this, &LargeFileIO::WriteCb),
											context);
			}
			else
			{	
				m_file_io_mgr->AppendFile(
									m_filename,
									data_left,
									byte_left,
									callback(this, &LargeFileIO::WriteCb),
									context);
			}
		}
		else
		{
			if ( m_safe_write )
			{
				m_file_io_mgr->AppendFile(
									m_tmp_filename,
									data_left,
									limit,
									callback(this, &LargeFileIO::WriteCb),
									context);
			}
			else
			{
				m_file_io_mgr->AppendFile(
									m_filename,
									data_left,
									limit,
									callback(this, &LargeFileIO::WriteCb),
									context);
			}
		}
	}

	void LargeFileIO::WriteCb(const AsyncWriterBase& wtr)
	{
		if ( wtr.GetStatus() != IoBase::SUCCEEDED )
		{
			if ( wtr.FailMaxWriteLimit() )
			{
				//
				// Only fail the first time
				//
				if ( m_safe_write ) 	
				{
					m_file_io_mgr->WriteFile(
									m_tmp_filename, 
									&m_data_buffer[0], 
									wtr.MaxWriteLimit(),
									callback(this, &LargeFileIO::WriteCb),
									wtr.GetContext());
				}
				else
				{	
					m_file_io_mgr->WriteFile(
									m_filename, 
									&m_data_buffer[0], 
									wtr.MaxWriteLimit(),
									callback(this, &LargeFileIO::WriteCb),
									wtr.GetContext());
				}
				return;
			}
			m_write_complete_cbk.Dispatch(wtr);
			Done();
			return;
		}
		//
		m_write_offset += wtr.GetDataLength();
		//
		// Check if finished
		//
		if ( m_write_offset >= m_data_buffer.size() )
		{
			m_write_complete_cbk.Dispatch(wtr);
			Done();
			return;
		}
		//
		// Need write more
		//
		WriteLeft(wtr.MaxWriteLimit(), wtr.GetContext());
	}

	void LargeFileIO::Done()
	{
		//
		// Note: when mirgrate to C++ 11, use the following code instead
		//
		// m_data_buffer.resize(0);
		// m_data_buffer.shrink_to_fit();
		//
		std::vector<char> empty;
		m_data_buffer.swap(empty);
		//
		m_in_progress = false;
		//
		if ( m_releaser ) m_releaser->Release(this);
	}

}//end namespace iDirect

