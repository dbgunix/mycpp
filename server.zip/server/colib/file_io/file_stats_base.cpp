#include "file_stats_base.h"

namespace colib
{
	FileStatsBase::FileStatsBase()
		: FileIoBase()
		, m_is_directory(false)
		, m_access_time(0)
		, m_modify_time(0)
		, m_change_time(0)
		, m_requester_cb()
	{
	}

	FileStatsBase::FileStatsBase(string file_name, const Callback1<const FileStatsBase&>& requester_cb, void* context)
		: FileIoBase(file_name, context)	
		, m_is_directory(false)
		, m_access_time(0)
		, m_modify_time(0)
		, m_change_time(0)
		, m_requester_cb(requester_cb)
	{
	}
		
	string FileStatsBase::PrintFile() const
	{
		return FileIoBase::PrintFile() + string::Format(
											"Filetype: %s\n"
											"Access Time: %ld\n"
											"Modify Time: %ld\n"
											"Change Time: %ld\n",
											IsDirectory() ? "directory" : "file",
											(long int)GetAccessTime(),
											(long int)GetModifyTime(),
											(long int)GetChangeTime());
	}

	string FileStatsBase::Print() const
	{
		return FileIoBase::Print() + string::Format("Callback is %sset\n", m_requester_cb.IsSet() ? "" : "not ");
	}

}
