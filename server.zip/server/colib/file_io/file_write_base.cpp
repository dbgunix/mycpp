#include "file_write_base.h"

namespace colib
{

	AsyncWriterBase::AsyncWriterBase()
		: FileIoBase()
		, m_mode(OVERWRITE)
		, m_data_length(0)  
		, m_requester_cb()
	{
	}

	AsyncWriterBase::AsyncWriterBase(
								string file_name, 
								WriteMode mode, 
								int length, 
								const Callback1<const AsyncWriterBase&>& requester_cb, 
								void* context)
		: FileIoBase(file_name, context)
		, m_mode(mode)
		, m_data_length(length)
		, m_requester_cb(requester_cb)
	{
	}
	
	string AsyncWriterBase::Print() const
	{
		return FileIoBase::Print() + string::Format(
											"Write Mode: %s\n"
											"Data: <%p, %d>\n"
											"Write max limit: %u\n"
											"Write fail max limit: %s\n"
											"Callback is %sset\n",
											( m_mode == OVERWRITE ) ? "OVERWRITE" : ( m_mode == APPEND ) ? "APPEND" : "UNKNOWN",
											GetData(), GetDataLength(),
											MaxWriteLimit(),
											FailMaxWriteLimit() ? "true" : "false",
											m_requester_cb.IsSet() ? "" : "not ");
	}

}
