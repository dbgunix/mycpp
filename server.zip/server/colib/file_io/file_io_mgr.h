#if !defined(__IDIRECT_FILE_IO_MGR_H__)
#define __IDIRECT_FILE_IO_MGR_H__

#include "file_read_base.h"
#include "file_write_base.h"
#include "file_stats_base.h"
#include "file_delete_base.h"
#include "file_rename_base.h"
#include "file_copy_base.h"
#include "dir_list_base.h"

#include <utils/trace/writable.h>

namespace colib
{
	class FileIoMgr
	{
		public:
		
			FileIoMgr() {};
			virtual ~FileIoMgr() {};	

			/* **************************** */
			/*        Read File             */
			/* **************************** */
			//
			// Read whole file
			//
			virtual bool ReadFile(
							string file_name, 
							const Callback1<const AsyncReaderBase&>& requester_cb, 
							void* context = 0) = 0;
			//
			// Read reset of file from offset
			//
			virtual bool ReadFile(
							string file_name,
						   	int offset,	
							const Callback1<const AsyncReaderBase&>& requester_cb, 
							void* context = 0) = 0;
			//
			// Read file with offset with desired length
			//
			virtual bool ReadFile(
							string file_name, 
							int offset, 
							int length, 
							const Callback1<const AsyncReaderBase&>& requester_cb, 
							void* context = 0) = 0;
			//
			// Read whole file - FIFO
			//
			virtual bool QueueReadFile(
							string file_name, 
							const Callback1<const AsyncReaderBase&>& requester_cb, 
							void* context = 0) = 0;
			//
			// Read reset of file from offset - FIFO
			//
			virtual bool QueueReadFile(
							string file_name,
						   	int offset,	
							const Callback1<const AsyncReaderBase&>& requester_cb, 
							void* context = 0) = 0;
			//
			// Read file with offset with desired length - FIFO
			//
			virtual bool QueueReadFile(
							string file_name, 
							int offset, 
							int length, 
							const Callback1<const AsyncReaderBase&>& requester_cb, 
							void* context = 0) = 0;
			//
			// Maximum read limit
			//
			virtual unsigned MaxReadLimit() const = 0;

			/* **************************** */
			/*        Write File            */
			/* **************************** */
			//
			// Overwrite a file
			//
			virtual bool WriteFile(
							string file_name, 
							const char* data,
							int length, 
							const Callback1<const AsyncWriterBase&>& requester_cb, 
							void* context = 0) = 0;
			//
			// Overwrite a file, when succeed, rename to new filename
			//	
			virtual bool WriteFileWithMove(
							string file_name, 
							string target_file_name,
							const char* data,
							int length, 
							const Callback1<const AsyncWriterBase&>& requester_cb, 
							void* context = 0) = 0;
			//
			// Append to a file
			//
			virtual bool AppendFile(
							string file_name, 
							const char* data,
							int length, 
							const Callback1<const AsyncWriterBase&>& requester_cb, 
							void* context = 0) = 0;
			//
			// Append to a file, when succeed, rename to new filename
			//
			virtual bool AppendFileWithMove(
							string file_name, 
							string target_file_name,
							const char* data,
							int length, 
							const Callback1<const AsyncWriterBase&>& requester_cb, 
							void* context = 0) = 0;
			//
			// Overwrite a file - FIFO
			//
			virtual bool QueueWriteFile(
							string file_name, 
							const char* data,
							int length, 
							const Callback1<const AsyncWriterBase&>& requester_cb, 
							void* context = 0) = 0;
			//
			// Overwrite a file, when succeed, rename to new filename - FIFO
			//	
			virtual bool QueueWriteFileWithMove(
							string file_name, 
							string target_file_name,
							const char* data,
							int length, 
							const Callback1<const AsyncWriterBase&>& requester_cb, 
							void* context = 0) = 0;
			//
			// Append to a file - FIFO
			//
			virtual bool QueueAppendFile(
							string file_name, 
							const char* data,
							int length, 
							const Callback1<const AsyncWriterBase&>& requester_cb, 
							void* context = 0) = 0;
			//
			// Append to a file, when succeed, rename to new filename - FIFO
			//
			virtual bool QueueAppendFileWithMove(
							string file_name, 
							string target_file_name,
							const char* data,
							int length, 
							const Callback1<const AsyncWriterBase&>& requester_cb, 
							void* context = 0) = 0;
			//
			// Maximum write limit
			//
			virtual unsigned MaxWriteLimit() const = 0;

			/* **************************** */
			/*        Delete File           */
			/* **************************** */
			//
			// Delete a file
			//
			virtual bool DeleteFile(
							string file_name, 
							const Callback1<const FileDeleteBase&>& requester_cb, 
							void* context = 0) = 0;
			//
			// Delete a file - FIFO
			//
			virtual bool QueueDeleteFile(
							string file_name, 
							const Callback1<const FileDeleteBase&>& requester_cb, 
							void* context = 0) = 0;
	
			/* **************************** */
			/*        Rename File           */
			/* **************************** */
			//
			// Rename a file
			//
			virtual	bool RenameFile(
							string file_name, 
							string target_name,
							const Callback1<const FileRenameBase&>& requester_cb, 
							void* context = 0) = 0;	
			//
			// Rename a file - FIFO
			//
			virtual	bool QueueRenameFile(
							string file_name, 
							string target_name,
							const Callback1<const FileRenameBase&>& requester_cb, 
							void* context = 0) = 0;
	
			/* **************************** */
			/*        Copy  File            */
			/* **************************** */
			//
			// Copy a file
			//
			virtual	bool CopyFile(
							string file_name, 
							string target_name,
							const Callback1<const FileCopyBase&>& requester_cb, 
							void* context = 0) = 0;	
			//
			// Copy a file - FIFO
			//
			virtual	bool QueueCopyFile(
							string file_name, 
							string target_name,
							const Callback1<const FileCopyBase&>& requester_cb, 
							void* context = 0) = 0;

			/* **************************** */
			/*        Stats File            */
			/* **************************** */
			//
			// Get a file stats
			//
			virtual bool StatsFile(
							string file_name, 
							const Callback1<const FileStatsBase&>& requester_cb, 
							void* context = 0) = 0;
			//
			// Get a file stats - FIFO
			//
			virtual bool QueueStatsFile(
							string file_name, 
							const Callback1<const FileStatsBase&>& requester_cb, 
							void* context = 0) = 0;

			/* **************************** */
			/*        Dir List Files        */
			/* **************************** */
			//
			// List files of a directory
			//
			virtual bool ListDir(
							string dir_name, 
							const Callback1<const DirListBase&>& requester_cb, 
							void* context = 0) = 0;
			//
			// List files of a directory - FIFO
			//
			virtual bool QueueListDir(
							string dir_name, 
							const Callback1<const DirListBase&>& requester_cb, 
							void* context = 0) = 0;
			//
			// Console Command
			//
			virtual void ConsoleCommand(Writable* con, int argc, char* argv[]) = 0;
	};

}

#endif
