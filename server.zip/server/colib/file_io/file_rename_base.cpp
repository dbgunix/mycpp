#include "file_rename_base.h"

namespace colib
{
	FileRenameBase::FileRenameBase()
		: FileIoBase()
		, m_target_name()  
		, m_requester_cb()
	{
	}

	FileRenameBase::FileRenameBase(string file_name, string target_name, const Callback1<const FileRenameBase&>& requester_cb, void* context)
		: FileIoBase(file_name, context)
		, m_target_name(target_name)  
		, m_requester_cb(requester_cb)
	{
	}

	string FileRenameBase::Print() const
	{
		return FileIoBase::Print() + string::Format(
											"Target name: %s\n"
											"Callback is %sset\n", 
											m_target_name.c_str(),
											m_requester_cb.IsSet() ? "" : "not ");
	}

}
