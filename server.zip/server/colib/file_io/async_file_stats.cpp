#include "async_file_stats.h"
#include "file_io_utils.h"
#include <event_loop/event_loop.h>

namespace colib
{
	DiskFileStats::DiskFileStats()
		: FileStatsBase()
		, m_act(callbackRt(this, &DiskFileStats::DoTask), "TaskAct")
	{
	}

	DiskFileStats::~DiskFileStats()
	{
		Stop();
	}

	string DiskFileStats::Print() const
	{
		return FileStatsBase::Print() + string::Format(
													"Task activity is %sactive\n", 
													m_act.IsActive() ? "" : "not ");
	}

	void DiskFileStats::Init(
							string file_name, 
							const Callback1<const FileStatsBase&>& requester_cb, 
							void* context)
	{
		Reset();
		SetFileName(file_name);
		SetCallback(requester_cb);
		SetContext(context);
	}
	
	bool DiskFileStats::Start()
	{	
		//
		// Add activity
		//
		bool ret = EventLoop::GetInstance().AddActivity(&m_act);
		if ( ret ) SetStatus(IoBase::IN_PROGRESS);
		return ret;
	}

	void DiskFileStats::Stop()
	{
		EventLoop::GetInstance().DeleteActivity(&m_act);
	}

	bool DiskFileStats::GetFileStats(string& err, int& error_code)
	{	
		bool is_directory;
		int filesize;
		int64_t access_time, modify_time, change_time;
		
	   	bool ret = DiskFile::GetStats(
									GetFileName(),
									is_directory,
									filesize,
									access_time,
									modify_time, 
									change_time,
									err,
									error_code);	

		if ( ret )
		{
			SetFileSize(filesize);
			SetDirectory(is_directory);
			SetAccessTime(access_time);
			SetModifyTime(modify_time);
			SetChangeTime(change_time);
		}

		return ret;
	}

	eCallbackRt DiskFileStats::DoTask()
	{
		string err;
		int error_code;

		if ( !GetFileStats(err, error_code) )
		{
			SetError(err);
			SetErrorCode(error_code);
			SetStatus(IoBase::FAILED);
		}
		else
		{
			SetError("Task complete");
			SetStatus(IoBase::SUCCEEDED);
		}
		
		StatsComplete();
		return DontRunAgain;
	}

	DiskFileStatsSA::DiskFileStatsSA()
		: DiskFileStats()
		, m_job(*this)
	{
	}
	
	bool DiskFileStatsSA::StatsFile(
								string file_name, 
								const Callback1<const FileStatsBase&>& requester_cb, 
								void* context)
	{
		Init(file_name, requester_cb, context);
		return m_job.Start();
	}
	
	void DiskFileStatsSA::StatsComplete()
	{
		m_job.Complete();
	}
		
	string DiskFileStatsSA::Print() const
	{
		return DiskFileStats::Print() + "Job type: SA\n";
	}
	
	DiskFileStatsMgd::DiskFileStatsMgd(unsigned job_id, IoJobMgrGlobal& job_mgr)
		: DiskFileStats()
		, m_job_id(job_id)
		, m_job_mgr(job_mgr)
	{
	}
	
	string DiskFileStatsMgd::Print() const
	{
		return DiskFileStats::Print() + "Job type: Mgd\n";
	}

	DiskFileStatsMgr::DiskFileStatsMgr(MemberSet& trace_set, unsigned max_limit)
		: IoJobMgrGlobal(trace_set)
	 	, m_max_limit(max_limit)
	{
	}

	bool DiskFileStatsMgr::StatsFile(
								string file_name, 
								const Callback1<const FileStatsBase&>& requester_cb, 
								void* context)
	{
		DiskFileStatsMgd* job = static_cast<DiskFileStatsMgd*>(AddJob(/*type(ignored)*/0));
		if ( !job ) return false;
		job->Init(file_name, requester_cb, context);
		return true;
	}

	IoBase* DiskFileStatsMgr::CreateIo(unsigned/*type(ignored)*/, unsigned job_id, IoJobMgrGlobal& mgr)
	{
		return new DiskFileStatsMgd(job_id, mgr);
	}

	DiskFileStatsFifo::DiskFileStatsFifo(MemberSet& trace_set, unsigned max_limit)
		: DiskFileStatsMgr(trace_set, max_limit)
	{
	}

	DiskFileStatsGeneral::DiskFileStatsGeneral(MemberSet& trace_set, unsigned concurrent_limit, unsigned max_limit)
		: DiskFileStatsMgr(trace_set, max_limit)
		, m_concurrent_limit(concurrent_limit)
	{
	}

}

