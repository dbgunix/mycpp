#if !defined(__IDIRECT_ASYNC_FILE_READER_H__)
#define __IDIRECT_ASYNC_FILE_READER_H__

#include "file_read_base.h"
#include "io_job.h"
#include <event_loop/activity_hld.h>

namespace colib
{
	class GlobalFileIoMgr;
	class DiskFileReaderMgr;

	class DiskFileReader : public AsyncReaderBase
	{
		public:

			static const unsigned int MAX_DISK_FILE_READ_LENGTH = 32 * 1024;

			virtual ~DiskFileReader();
	
			virtual string Print() const;
			virtual const char* GetData() const { return m_data; }	
			virtual unsigned MaxReadLimit() const { return MAX_DISK_FILE_READ_LENGTH; }
			virtual bool FailMaxReadLimit() const { return m_fail_read_limit; }
			
			DiskFileReader(const DiskFileReader&) = delete;
			DiskFileReader& operator=(const DiskFileReader&) = delete;

		protected:
		
			DiskFileReader();
	
			void Init(
					string file_name, 
					int offset, 
					int length, 
					const Callback1<const AsyncReaderBase&>& requester_cb, 
					void* context);

			virtual bool Start();
			virtual void Stop();
			virtual void Complete() { DispatchCB(); }

			bool ReadData(int to_read, string& err, int& error_code);
			eCallbackRt StartTask();
			eCallbackRt DoTask();
			
			bool ReadInitialize(int flag, string&, int& error_code);
			
			static int TranslateErrorCode(int code);
			virtual void ReadComplete() = 0; 	

			virtual void Reset();
			void CloseFile();

		protected:
			
			char m_data[MAX_DISK_FILE_READ_LENGTH];
			ActivityHold m_start_act;
			ActivityHold m_act;
			//
			int m_fd;
			int m_read_offset;
			int m_bytes_to_read;
			bool m_fail_read_limit;

		friend class DiskFileReaderMgr;
	};

	class DiskFileReaderSA : public DiskFileReader
	{
		public:

			DiskFileReaderSA();
			virtual ~DiskFileReaderSA() {};
			//
			// Read file with offset, desired length specified
			//
			bool ReadFile(
					string file_name, 
					int offset, 
					int length, 
					const Callback1<const AsyncReaderBase&>& requester_cb, 
					void* context);
			//
			// Read whole file
			//
			bool ReadFile(
					string file_name, 
					const Callback1<const AsyncReaderBase&>& requester_cb, 
					void* context);
			//
			// Read reset of file from offset
			//
			bool ReadFile(
					string file_name,
				   	int offset,	
					const Callback1<const AsyncReaderBase&>& requester_cb, 
					void* context);
			//
			// Stop
			//
			void StopTask() { m_job.Stop(); }
	
			virtual string Print() const;

			DiskFileReaderSA(const DiskFileReaderSA&) = delete;
			DiskFileReaderSA& operator=(const DiskFileReaderSA&) = delete;

		protected:

			virtual void ReadComplete(); 	

		protected:

			IoJobMgrSA m_job;
	};	

	class DiskFileReaderMgd : public DiskFileReader
	{
		public:

			virtual ~DiskFileReaderMgd() {};

			virtual string Print() const;

		protected:

			DiskFileReaderMgd(unsigned job_id, IoJobMgrGlobal&);
		
			virtual void Stop() {}; // Not allowed to stop by itself
			virtual void ReadComplete() { m_job_mgr.JobDone(m_job_id); }

		protected:

			unsigned m_job_id;
			IoJobMgrGlobal& m_job_mgr;

		friend class DiskFileReaderMgr;
	};

	class DiskFileReaderMgr : public IoJobMgrGlobal
	{
		public:

			virtual ~DiskFileReaderMgr() {};
			//
			// Read file with offset, desired length specified
			//
			bool ReadFile(
					string file_name, 
					int offset, 
					int length, 
					const Callback1<const AsyncReaderBase&>& requester_cb, 
					void* context);
			//
			// Read whole file
			//
			bool ReadFile(
					string file_name, 
					const Callback1<const AsyncReaderBase&>& requester_cb, 
					void* context);
			//
			// Read reset of file from offset
			//
			bool ReadFile(
					string file_name,
				   	int offset,	
					const Callback1<const AsyncReaderBase&>& requester_cb, 
					void* context);

		protected:
			
			DiskFileReaderMgr(MemberSet& trace_set, unsigned max_limit);
			void SetMaxLimit(unsigned max_limit) { m_max_limit = max_limit; }

			virtual IoBase* CreateIo(unsigned/*type(ignored)*/, unsigned job_id, IoJobMgrGlobal& mgr);
			virtual unsigned MaximumJobLimit() const { return m_max_limit; }

		protected:

			unsigned m_max_limit;
	};

	class DiskFileReadFifo : public DiskFileReaderMgr
	{
		public:

			DiskFileReadFifo(MemberSet&, unsigned max_limit = 1);
			virtual ~DiskFileReadFifo() {};

		protected:
		
			virtual unsigned ConcurrentJobLimit() const { return 1; }	
			void SetParams(unsigned max_limit) { SetMaxLimit(max_limit); }

		friend class GlobalFileIoMgr;
	};

	class DiskFileReadGeneral : public DiskFileReaderMgr
	{
		public:

			DiskFileReadGeneral(MemberSet&, unsigned concurrent_limit = 1, unsigned max_limit = 1);
			virtual ~DiskFileReadGeneral() {};
	
		protected:

			virtual unsigned ConcurrentJobLimit() const { return m_concurrent_limit; }		
			void SetParams(unsigned concurrent_limit, unsigned max_limit) 
			{ m_concurrent_limit = concurrent_limit; SetMaxLimit(max_limit); }	
		
		protected:

			unsigned m_concurrent_limit;	

		friend class GlobalFileIoMgr;
	};

}

#endif
