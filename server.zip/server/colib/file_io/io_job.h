#if !defined(__IDIRECT_IO_JOB_BASE_H__)
#define __IDIRECT_IO_JOB_BASE_H__

#include "io_base.h"
#include <utils/trace/writable.h>
#include <event_loop/activity_hld.h>
#include <config/value.h>

#include <map>

namespace colib
{
	class IoJobMgrSA;
	class IoJobMgrGlobal;

	class IoJobBase
	{
		public:
	
			virtual ~IoJobBase() {};
	
			IoJobBase(const IoJobBase&) = delete;
			IoJobBase& operator=(const IoJobBase&) = delete;

		protected:
	
			IoJobBase(IoBase& io);

			virtual bool Start() { return m_io.Start(); }
			virtual void Stop() { m_io.Stop(); }
			virtual void Complete() { m_io.Complete(); }
			virtual string Print() const;
	
		protected:

			IoBase& m_io;

		friend class IoJobMgrSA;
		friend class IoJobMgrGlobal;
	};

	class IoJobMgd : public IoJobBase	
	{		
		public:

			virtual ~IoJobMgd() {};
	
			unsigned GetJobID() const { return m_job_id; }

			IoJobMgd(const IoJobMgd&) = delete;
			IoJobMgd& operator=(const IoJobMgd&) = delete;
		
		protected:
		
			IoJobMgd(IoBase& io, unsigned job_id);
 
			virtual string Print() const;
		 
		protected:
	
			unsigned m_job_id;

		friend class IoJobMgrGlobal;
	};

	class IoJobMgr
	{
		public:

			virtual ~IoJobMgr();

			IoJobMgr(const IoJobMgr&) = delete;
			IoJobMgr& operator=(const IoJobMgr&) = delete;

		protected:
	
			IoJobMgr();

			bool StartNextJobActivity(); 
			void StopNextJobActivity(); 
			eCallbackRt NextJob() { return StartNextJob(); }
			virtual eCallbackRt StartNextJob() = 0;

		protected:
			
			ActivityHold m_next_job_act;
	};

	//
	// Standalone Job
	//
	class IoJobMgrSA : public IoJobMgr
	{
		public:

			IoJobMgrSA(IoBase&);
			virtual ~IoJobMgrSA() {};

			virtual bool Start();
			virtual void Stop();
			virtual void Complete();

			IoJobMgrSA(const IoJobMgrSA&) = delete;
			IoJobMgrSA& operator=(const IoJobMgrSA&) = delete;

		protected:

			virtual eCallbackRt StartNextJob();

		protected:
	
			IoJobBase m_job;		
	};

	class IoJobMgrGlobal : public IoJobMgr
	{
		public:

			enum Stats
			{
				Stat_num_reject,
				Stat_num_create_io_fail,
				Stat_num_start_succeed,
				Stat_num_start_fail,
				Stat_num_complete,
				Stat_num_cleanup,
				Stat_job_done_active,
				Stat_job_done_waiting,
				Stat_job_done_invalid
			};

			virtual ~IoJobMgrGlobal();

			void JobDone(unsigned job_id);			

			virtual string ConsoleHelp() const;
			virtual void ConsoleCommand(Writable* to, int argc, char* argv[]);

			IoJobMgrGlobal(const IoJobMgrGlobal&) = delete;
			IoJobMgrGlobal& operator=(const IoJobMgrGlobal&) = delete;

		protected:
	
			IoJobMgrGlobal(MemberSet& trace_set);

			virtual IoBase* CreateIo(unsigned type, unsigned job_id, IoJobMgrGlobal&) = 0;
			virtual void DestroyIo(IoBase* io) { delete io; } // default to delete
			virtual unsigned ConcurrentJobLimit() const = 0;
			virtual unsigned MaximumJobLimit() const = 0;

			IoBase* AddJob(unsigned type);
			void DelJob(unsigned job_id);

			virtual eCallbackRt StartNextJob();
			eCallbackRt JobCleanup();


		protected:

			unsigned m_next_job_id;
			//
			std::map<unsigned, IoJobMgd*> m_io_jobs_active;
			std::list<IoJobMgd*> m_io_jobs_waiting;
			std::list<unsigned> m_io_jobs_to_remove;
			//
			std::map<unsigned, IoBase*> m_io_created;
			//
			// Activity
			//
			ActivityHold m_job_cleanup_act;
			MemberSet& m_trace_set;

			ValueList m_stats;
	};
	#define IOJOBMGRGLOBAL_STAT(stat) m_stats[IoJobMgrGlobal::Stat_##stat].AsInt()

}

#endif
