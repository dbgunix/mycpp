#include "global_file_io_mgr.h"
#include <console/command/debug.h>
#include <console/role.h>

namespace colib
{
	static ValueList::ValueHolder   InitParams()
	{
		return
		{
			//
			// TODO: What are the good values for those params?
			//
			Value("concurrent_file_read_limit", 512),
			Value("max_file_read_limit", 4096),					
			Value("concurrent_file_write_limit", 512),
			Value("max_file_write_limit", 4096),
			Value("concurrent_file_delete_limit", 512),
			Value("max_file_delete_limit", 4096),
			Value("concurrent_file_rename_limit", 512),
			Value("max_file_rename_limit", 4096),	
			Value("concurrent_file_copy_limit", 512),
			Value("max_file_copy_limit", 4096),	
			Value("concurrent_file_stats_limit", 512),
			Value("max_file_stats_limit", 4096),
			Value("concurrent_dir_list_limit", 512),
			Value("max_dir_list_limit", 4096)	
		};
	};

	GlobalFileIoMgr& GlobalFileIoMgr::GetInstance()
	{
		static GlobalFileIoMgr instance;

		static bool initialized = false;
		if ( !initialized ) initialized = instance.Init();

		return instance;
	}

	GlobalFileIoMgr::GlobalFileIoMgr()
		: m_general_reader(m_trace_set)
		, m_fifo_reader(m_trace_set)
		, m_general_writer(m_trace_set)
		, m_fifo_writer(m_trace_set)			
	    , m_general_file_remover(m_trace_set)
		, m_fifo_file_remover(m_trace_set)
		, m_general_file_renamer(m_trace_set)
		, m_fifo_file_renamer(m_trace_set)	
	    , m_general_file_copier(m_trace_set)
		, m_fifo_file_copier(m_trace_set)
		, m_general_file_stats_collector(m_trace_set)
		, m_fifo_file_stats_collector(m_trace_set)
		, m_general_dir_lister(m_trace_set)
		, m_fifo_dir_lister(m_trace_set)
		, m_params(InitParams())  
	{
		ReloadParams();
	}

	bool GlobalFileIoMgr::Init()
	{	
		ConsoleCommand::Register(
				CONSOLE_ROLE_EVERYONE,
				(ConsoleCommand::Handler*)GlobalFileIoMgrConsoleCommand, NULL,
				"global_fio", "Global File Io Manager");
		return true;
	}

	bool GlobalFileIoMgr::Reload(const Options* opt, string&)
	{
		if ( !opt ) return false;
		m_params.LoadFromOptions(opt->GetOptionsNode("GLOBAL_IO_MGR"));
		ReloadParams();
		return true;
	}

	void GlobalFileIoMgr::ReloadParams()
	{
		// file read
		m_general_reader.SetParams(GLOBALFILEIOMGR_PARAM(concurrent_file_read_limit), GLOBALFILEIOMGR_PARAM(max_file_read_limit));
		m_fifo_reader.SetParams(GLOBALFILEIOMGR_PARAM(max_file_read_limit));
		// file write
		m_general_writer.SetParams(GLOBALFILEIOMGR_PARAM(concurrent_file_write_limit), GLOBALFILEIOMGR_PARAM(max_file_write_limit));
		m_fifo_writer.SetParams(GLOBALFILEIOMGR_PARAM(max_file_write_limit));
		// file delete
		m_general_file_remover.SetParams(GLOBALFILEIOMGR_PARAM(concurrent_file_delete_limit), GLOBALFILEIOMGR_PARAM(max_file_delete_limit));
		m_fifo_file_remover.SetParams(GLOBALFILEIOMGR_PARAM(max_file_delete_limit));
		// file rename
		m_general_file_renamer.SetParams(GLOBALFILEIOMGR_PARAM(concurrent_file_rename_limit), GLOBALFILEIOMGR_PARAM(max_file_rename_limit));
		m_fifo_file_renamer.SetParams(GLOBALFILEIOMGR_PARAM(max_file_rename_limit));	
		// file copy
		m_general_file_copier.SetParams(GLOBALFILEIOMGR_PARAM(concurrent_file_copy_limit), GLOBALFILEIOMGR_PARAM(max_file_copy_limit));
		m_fifo_file_copier.SetParams(GLOBALFILEIOMGR_PARAM(max_file_copy_limit));
		// file stats
		m_general_file_stats_collector.SetParams(GLOBALFILEIOMGR_PARAM(concurrent_file_stats_limit), GLOBALFILEIOMGR_PARAM(max_file_stats_limit));
		m_fifo_file_stats_collector.SetParams(GLOBALFILEIOMGR_PARAM(max_file_stats_limit));
		// dir list
		m_general_dir_lister.SetParams(GLOBALFILEIOMGR_PARAM(concurrent_dir_list_limit), GLOBALFILEIOMGR_PARAM(max_dir_list_limit));
		m_fifo_dir_lister.SetParams(GLOBALFILEIOMGR_PARAM(max_dir_list_limit));
	}

	void GlobalFileIoMgr::ConsoleCommand(Writable* con, int argc, char* argv[])
	{
		const char* usage = 
			"Usage:\tparams|debug|read_g|read_q|write_g|write_q|stats_g|stats_q|rename_g|rename_q|copy_g|copy_q|delete_g|delete_q|dir_g|dir_q\n";
	
		if ( !con )	return;
	
		if ( argc < 1 )
		{
			con->PrintString(usage);
			return;
		}
		
		if ( strcmp(argv[0], "params") == 0 )
		{
			m_params.ConsoleCommand(con, argc-1, argv+1);
			// In case we change params from console
			if ( argc > 1 ) ReloadParams();
		}
		else if ( strcmp(argv[0], "debug") == 0 )
		{
			HandleDebugCommand(con, argc-1, argv+1, m_trace_set, "GlobalFileIoMgr");
		}
		else if ( strcmp(argv[0], "read_g") == 0 )
		{
			m_general_reader.ConsoleCommand(con, argc-1, argv+1);
		}							
		else if ( strcmp(argv[0], "read_q") == 0 )
		{
			m_fifo_reader.ConsoleCommand(con, argc-1, argv+1);
		}
		else if ( strcmp(argv[0], "write_g") == 0 )
		{
			m_general_writer.ConsoleCommand(con, argc-1, argv+1);
		}
		else if ( strcmp(argv[0], "write_q") == 0 )
		{
			m_fifo_writer.ConsoleCommand(con, argc-1, argv+1);
		}
		else if ( strcmp(argv[0], "stats_g") == 0 )
		{
			m_general_file_stats_collector.ConsoleCommand(con, argc-1, argv+1);
		}
		else if ( strcmp(argv[0], "stats_q") == 0 )
		{
			m_fifo_file_stats_collector.ConsoleCommand(con, argc-1, argv+1);
		}
		else if ( strcmp(argv[0], "rename_g") == 0 )
		{
			m_general_file_renamer.ConsoleCommand(con, argc-1, argv+1);
		}
		else if ( strcmp(argv[0], "rename_q") == 0 )
		{
			m_fifo_file_renamer.ConsoleCommand(con, argc-1, argv+1);
		}	
		else if ( strcmp(argv[0], "copy_g") == 0 )
		{
			m_general_file_copier.ConsoleCommand(con, argc-1, argv+1);
		}
		else if ( strcmp(argv[0], "copy_q") == 0 )
		{
			m_fifo_file_copier.ConsoleCommand(con, argc-1, argv+1);
		}
		else if ( strcmp(argv[0], "delete_g") == 0 )
		{
			m_general_file_remover.ConsoleCommand(con, argc-1, argv+1);
		}
		else if ( strcmp(argv[0], "delete_q") == 0 )
		{
			m_fifo_file_remover.ConsoleCommand(con, argc-1, argv+1);
		}
		else if ( strcmp(argv[0], "dir_g") == 0 )
		{
			m_general_dir_lister.ConsoleCommand(con, argc-1, argv+1);
		}
		else if ( strcmp(argv[0], "dir_q") == 0 )
		{
			m_fifo_dir_lister.ConsoleCommand(con, argc-1, argv+1);
		}
		else con->PrintString(usage);
	}

	void GlobalFileIoMgrConsoleCommand(void*, ConsoleSession* con, int argc, char* argv[])
	{
		GlobalFileIoMgr::GetInstance().ConsoleCommand(con, argc-1, argv+1);
	}

}
