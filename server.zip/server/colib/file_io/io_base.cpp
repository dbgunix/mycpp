#include "io_base.h"

#include <stdlib.h>

namespace colib
{
	IoBase::IoBase()
		: m_context(NULL)
	  	, m_status(IDLE)
		, m_error_code(0)
		, m_last_error()
	{
	}

	IoBase::IoBase(void* context)
		: m_context(context)
		, m_status(IDLE)
		, m_error_code(0)
		, m_last_error()
	{
	}

	const char* IoBase::GetStatusStr() const
	{
		switch ( m_status )
		{
			case IDLE: return "IDLE";
			case IN_PROGRESS: return "IN_PROGRESS";
			case SUCCEEDED: return "SUCCEEDED";
			case FAILED: return "FAILED";
			default: return "UNKNOWN";			 
		}
	}

	string IoBase::Print() const
	{
		return string::Format(
					"Context: %p\n"
					"Status: %s\n"
					"ErrorCode: %d\n"
					"Last info: %s\n", 
					GetContext(),
					GetStatusStr(), 
					GetErrorCode(),
					GetError().c_str());
	}

}
