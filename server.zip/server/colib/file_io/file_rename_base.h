#if !defined(__IDIRECT_FILE_RENAME_BASE_H__)
#define __IDIRECT_FILE_RENAME_BASE_H__

#include "file_io_base.h"
#include <utils/callback.h>

namespace colib
{
	class FileRenameBase : public FileIoBase
	{
		public:
			
			virtual ~FileRenameBase() {};

			virtual IoType GetType() const { return RENAME; }
			virtual string Print() const;

			string GetTargetName() const { return m_target_name; }

			FileRenameBase(const FileRenameBase&) = delete;
			FileRenameBase& operator=(const FileRenameBase&) = delete;

		protected:
			
			FileRenameBase();
			FileRenameBase(string file_name, string target_name, const Callback1<const FileRenameBase&>& requester_cb, void* context);

			void SetTargetName(string target_name) { m_target_name = target_name; }
			void SetCallback(const Callback1<const FileRenameBase&>& requester_cb) { m_requester_cb = requester_cb; }

			virtual void Reset();

			void DispatchCB() { m_requester_cb.Dispatch(*this); }

		protected:
		
			string m_target_name;
			Callback1<const FileRenameBase&> m_requester_cb;
	};
	
	inline void FileRenameBase::Reset()
	{
		FileIoBase::Reset();
		m_target_name.clear();
		m_requester_cb.Clear();
	}

}

#endif
