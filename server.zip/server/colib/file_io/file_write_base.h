#if !defined(__IDIRECT_FILE_WRITE_BASE_H__)
#define __IDIRECT_FILE_WRITE_BASE_H__

#include "file_io_base.h"
#include <utils/callback.h>

namespace colib
{
	class AsyncWriterBase: public FileIoBase
	{
		public:

			enum WriteMode
			{
				OVERWRITE,
				APPEND
			};

			virtual ~AsyncWriterBase() {}

			virtual IoType GetType() const { return WRITE; }
			virtual string Print() const;
			
			WriteMode GetMode() const { return m_mode; }
			virtual const char* GetData() const = 0;
			virtual unsigned MaxWriteLimit() const = 0;
			virtual bool FailMaxWriteLimit() const = 0;
			int GetDataLength() const { return m_data_length; }
			
			AsyncWriterBase(const AsyncWriterBase&) = delete;
			AsyncWriterBase& operator=(const AsyncWriterBase&) = delete;

		protected:
	
			AsyncWriterBase();
			AsyncWriterBase(string file_name, WriteMode mode, int length, const Callback1<const AsyncWriterBase&>& requester_cb, void* context);

			void SetMode(WriteMode mode) { m_mode = mode; } 
			void SetDataLength(int data_length) { m_data_length = data_length; }
			void SetCallback(const Callback1<const AsyncWriterBase&>& requester_cb) { m_requester_cb = requester_cb; }
			
			virtual void Reset();

			void DispatchCB() { m_requester_cb.Dispatch(*this); }

		protected:
		
			WriteMode m_mode;
			int m_data_length;
			Callback1<const AsyncWriterBase&> m_requester_cb;
	};
	
	inline void AsyncWriterBase::Reset() 
	{ 
		FileIoBase::Reset(); 
		m_mode = OVERWRITE; 
		m_data_length = 0; 
		m_requester_cb.Clear(); 
	}

}

#endif
