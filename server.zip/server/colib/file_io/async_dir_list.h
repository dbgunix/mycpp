#if !defined(__IDIRECT_ASYNC_DIR_LIST_H__)
#define __IDIRECT_ASYNC_DIR_LIST_H__

#include "dir_list_base.h"
#include "async_file_stats.h"
#include "io_job.h"
#include <event_loop/activity_hld.h>

#include <vector>

namespace colib
{
	class GlobalFileIoMgr;
	class DiskDirListMgr;

	class DiskDirList : public DirListBase
	{
		public:
			
			/** For this class ERROR CODE RANGE [NOT YET DEFINED] **/

			virtual ~DiskDirList();

			virtual string Print() const;
		
			virtual unsigned GetFilesCount() const { return m_dir_files.size(); }
			virtual FileStatsBase* GetFile(unsigned idx);
			virtual const FileStatsBase* GetFile(unsigned idx) const;

			DiskDirList(const DiskDirList&) = delete;
			DiskDirList& operator=(const DiskDirList&) = delete;

		protected:
		
			DiskDirList();

			virtual bool Start();
			virtual void Stop();
			virtual void Complete() { DispatchCB(); }

			virtual void Reset();

			void Init(
					string dir_name, 
					const Callback1<const DirListBase&>& requester_cb, 
					void* context);

			bool GetDirFiles(string&, int& error_code);
			eCallbackRt DoTask();
			
			virtual void ListComplete() = 0; 	
			void CleanFiles();

		protected:
			
			ActivityHold m_act;
			//
			std::vector<DiskFileStatsSA*> m_dir_files;

		friend class DiskDirListMgr;
	};
	
	class DiskDirListSA : public DiskDirList
	{
		public:

			DiskDirListSA();
			virtual ~DiskDirListSA() {};
			//
			bool ListDir(
					string dir_name, 
					const Callback1<const DirListBase&>& requester_cb, 
					void* context);
			//
			// Stop
			//
			void StopTask() { m_job.Stop(); }
	
			virtual string Print() const;

			DiskDirListSA(const DiskDirListSA&) = delete;
			DiskDirListSA& operator=(const DiskDirListSA&) = delete;

		protected:

			virtual void ListComplete(); 	

		protected:

			IoJobMgrSA m_job;
	};	

	class DiskDirListMgd : public DiskDirList
	{
		public:

			virtual ~DiskDirListMgd() {};

			virtual string Print() const;

		protected:

			DiskDirListMgd(unsigned job_id, IoJobMgrGlobal&);
		
			virtual void Stop() {}; // Not allowed to stop by itself
			virtual void ListComplete() { m_job_mgr.JobDone(m_job_id); }

		protected:

			unsigned m_job_id;
			IoJobMgrGlobal& m_job_mgr;

		friend class DiskDirListMgr;
	};

	class DiskDirListMgr : public IoJobMgrGlobal
	{
		public:

			virtual ~DiskDirListMgr() {};	
			//
			bool ListDir(
					string dir_name, 
					const Callback1<const DirListBase&>& requester_cb, 
					void* context);

		protected:
			
			DiskDirListMgr(MemberSet& trace_set, unsigned max_limit);
			void SetMaxLimit(unsigned max_limit) { m_max_limit = max_limit; }

			virtual IoBase* CreateIo(unsigned/*type(ignored)*/, unsigned job_id, IoJobMgrGlobal& mgr);
			virtual unsigned MaximumJobLimit() const { return m_max_limit; }

		protected:

			unsigned m_max_limit;
	};

	class DiskDirListFifo : public DiskDirListMgr
	{
		public:

			DiskDirListFifo(MemberSet&, unsigned max_limit = 1);
			virtual ~DiskDirListFifo() {};
		
		protected:
		
			virtual unsigned ConcurrentJobLimit() const { return 1; }	
			void SetParams(unsigned max_limit) { SetMaxLimit(max_limit); }

			friend class GlobalFileIoMgr;
	};

	class DiskDirListGeneral : public DiskDirListMgr
	{
		public:

			DiskDirListGeneral(MemberSet&, unsigned concurrent_limit = 1, unsigned max_limit = 1);
			virtual ~DiskDirListGeneral() {};
		
		protected:

			virtual unsigned ConcurrentJobLimit() const { return m_concurrent_limit; }		
			void SetParams(unsigned concurrent_limit, unsigned max_limit) 
			{ m_concurrent_limit = concurrent_limit; SetMaxLimit(max_limit); }	
		
		protected:

			unsigned m_concurrent_limit;	
		
		friend class GlobalFileIoMgr;	
	};

}

#endif
