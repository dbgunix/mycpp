#include "async_dir_list.h"
#include "file_io_utils.h"
#include <event_loop/event_loop.h>

#include <dirent.h>
#include <errno.h>
#include <string.h>

namespace colib
{
	DiskDirList::DiskDirList()
		: DirListBase()
		, m_act(callbackRt(this, &DiskDirList::DoTask), "TaskAct")
	{
	}

	DiskDirList::~DiskDirList()
	{
		Stop();
		CleanFiles();
	}

	void DiskDirList::CleanFiles()
	{
		unsigned size = m_dir_files.size();
		for ( unsigned i = 0; i < size; ++i )
		{
			delete m_dir_files[i];
		}
		m_dir_files.clear();
	}

	FileStatsBase* DiskDirList::GetFile(unsigned idx)
	{
		if ( idx >= m_dir_files.size() ) return 0;
		return m_dir_files[idx];
	}
	
	const FileStatsBase* DiskDirList::GetFile(unsigned idx) const
	{
		if ( idx >= m_dir_files.size() ) return 0;
		return m_dir_files[idx];
	}

	void DiskDirList::Reset()
	{
		DirListBase::Reset();
		CleanFiles();
	}

	string DiskDirList::Print() const
	{
		return DirListBase::Print() + string::Format(
													"Task activity is %sactive\n", 
													m_act.IsActive() ? "" : "not ");
	}

	void DiskDirList::Init(
						string dir_name, 
						const Callback1<const DirListBase&>& requester_cb, 
						void* context)
	{
		Reset();
		SetDirName(dir_name);
		SetCallback(requester_cb);
		SetContext(context);
	}
	
	bool DiskDirList::Start()
	{
		//
		// Add activity
		//
		bool ret = EventLoop::GetInstance().AddActivity(&m_act);
		if ( ret ) SetStatus(IoBase::IN_PROGRESS);
		return ret;
	}

	void DiskDirList::Stop()
	{
		EventLoop::GetInstance().DeleteActivity(&m_act);
	}

	bool DiskDirList::GetDirFiles(string& err, int& error_code)
	{
		//
		// First sanity check
		//
		bool is_directory;
		if ( !DiskFile::IsDirectory(GetDirName().c_str(), is_directory, err, error_code) ) return false;
		if ( !is_directory )
		{
			err = GetDirName() + " is NOT a directory";
			error_code = ENOTDIR;
			return false;
		}
		//
		string dir_path;
		DiskFile::ParseDir(GetDirName(), dir_path, err, error_code);
		err.empty();
		//
		// Open directory
		//
		DIR *pDir = opendir(dir_path.c_str());
		if ( !pDir )
		{
			err = string::Format("Unable to open directory %s: %s", dir_path.c_str(), strerror(errno));
			error_code = errno;
			return false;
		}
		//
		// Read
		//
		bool ret = true;
		while ( ret )
		{
			struct dirent* pEntry = readdir(pDir);
			if ( !pEntry ) break; // Done
			// skip "."
			if ( 0 == strncmp(pEntry->d_name, ".", 1) ) continue;
			// skip ".."
			if ( 0 == strncmp(pEntry->d_name, "..", 2) ) continue;
			//
			string filename = dir_path + "/" + pEntry->d_name;
			DiskFileStatsSA* file = new DiskFileStatsSA;
			file->SetFileName(filename);

			if ( !file->GetFileStats(err, error_code) )
			{
				ret = false;
				delete file;
			}
			else
			{	
				m_dir_files.push_back(file);
			}
		}
		// 
		// Clean up
		//
		closedir(pDir);

		return ret;
	}

	eCallbackRt DiskDirList::DoTask()
	{
		string err;
		int error_code;

		if ( !GetDirFiles(err, error_code) )
		{
			SetError(err);
			SetErrorCode(error_code);
			SetStatus(IoBase::FAILED);
		}
		else
		{
			SetError("Task complete");
			SetStatus(IoBase::SUCCEEDED);
		}
		
		ListComplete();
		return DontRunAgain;
	}

	DiskDirListSA::DiskDirListSA()
		: DiskDirList()
		, m_job(*this)
	{
	}
	
	bool DiskDirListSA::ListDir(
								string dir_name, 
								const Callback1<const DirListBase&>& requester_cb, 
								void* context)
	{
		Init(dir_name, requester_cb, context);
		return m_job.Start();
	}
	
	void DiskDirListSA::ListComplete()
	{
		m_job.Complete();
	}
		
	string DiskDirListSA::Print() const
	{
		return DiskDirList::Print() + "Job type: SA\n";
	}
	
	DiskDirListMgd::DiskDirListMgd(unsigned job_id, IoJobMgrGlobal& job_mgr)
		: DiskDirList()
		, m_job_id(job_id)
		, m_job_mgr(job_mgr)
	{
	}
	
	string DiskDirListMgd::Print() const
	{
		return DiskDirList::Print() + "Job type: Mgd\n";
	}

	DiskDirListMgr::DiskDirListMgr(MemberSet& trace_set, unsigned max_limit)
		: IoJobMgrGlobal(trace_set)
	 	, m_max_limit(max_limit)
	{
	}

	bool DiskDirListMgr::ListDir(
								string dir_name, 
								const Callback1<const DirListBase&>& requester_cb, 
								void* context)
	{
		DiskDirListMgd* job = static_cast<DiskDirListMgd*>(AddJob(/*type(ignored)*/0));
		if ( !job ) return false;
		job->Init(dir_name, requester_cb, context);
		return true;
	}

	IoBase* DiskDirListMgr::CreateIo(unsigned/*type(ignored)*/, unsigned job_id, IoJobMgrGlobal& mgr)
	{
		return new DiskDirListMgd(job_id, mgr);
	}

	DiskDirListFifo::DiskDirListFifo(MemberSet& trace_set, unsigned max_limit)
		: DiskDirListMgr(trace_set, max_limit)
	{
	}

	DiskDirListGeneral::DiskDirListGeneral(MemberSet& trace_set, unsigned concurrent_limit, unsigned max_limit)
		: DiskDirListMgr(trace_set, max_limit)
		, m_concurrent_limit(concurrent_limit)
	{
	}

}

