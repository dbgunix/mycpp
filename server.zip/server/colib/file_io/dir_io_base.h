#if !defined(__IDIRECT_DIR_IO_BASE_H__)
#define __IDIRECT_DIR_IO_BASE_H__

#include "io_base.h"

namespace colib
{
	//
	// Base class for dir IO operations
	//
	class DirIoBase : public IoBase
	{
		public:
			//
			// Type
			//
			enum IoType
			{
				LIST	
			};

			virtual ~DirIoBase() {};

			virtual IoType GetType() const = 0;
			const char* GetTypeStr() const;
			string GetDirName() const { return m_dir_name; }
			virtual string Print() const;
			virtual string PrintDir() const;
		
			DirIoBase(const DirIoBase&) = delete;
			DirIoBase& operator=(const DirIoBase&) = delete;

		protected:
		
			DirIoBase();
			DirIoBase(string dir_name, void* context);

			void SetDirName(string dir_name) { m_dir_name = dir_name; }
			
			virtual void Reset();

			string m_dir_name;
	};
	
	inline void DirIoBase::Reset() 
	{ 
		IoBase::Reset(); 
		m_dir_name.clear(); 
	}

}

#endif
