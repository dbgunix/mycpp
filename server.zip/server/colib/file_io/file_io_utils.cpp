// file_io_utils.cpp
// vi:set ts=4 sw=4 nowrap:

#include "file_io_utils.h"

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>

namespace colib
{
	namespace DiskFile
	{
		const int DEFAULT_FILE_PERMISSION = S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH;
		const int DEFAULT_DIR_PERMISSION = S_IRUSR | S_IWUSR | S_IXUSR | S_IRGRP | S_IXGRP | S_IROTH | S_IXOTH;
		
		bool	GetStats(
						string path,
						bool& is_directory,
						int& size, 
						int64_t& access_time, 
						int64_t& modify_time, 
						int64_t& change_time, 
						string& err)
		{
			int error_code;
			return GetStats( path, is_directory, size, access_time, modify_time, change_time, err, error_code);
		}

		bool	GetStats(
						string path,
						bool& is_directory,
						int& size, 
						int64_t& access_time, 
						int64_t& modify_time, 
						int64_t& change_time, 
						string& err,
						int& error_code)
		{
			struct stat stat_buf;
			if ( -1 == stat(path.c_str(), &stat_buf) )
		    {
				err = string::Format("Fail to stat \"%s\": %s", path.c_str(), strerror(errno));
				error_code = errno;
				return false;
			}

			is_directory = S_ISDIR(stat_buf.st_mode);
			size = stat_buf.st_size;
			access_time = stat_buf.st_atime;
			modify_time = stat_buf.st_mtime;
			change_time = stat_buf.st_ctime;
			
			return true;
		}
		
		bool	GetFileSize(string filename, int& size, string& err, int& error_code)
		{
			bool is_directory;
			int64_t access_time, modify_time, change_time;
			return GetStats(filename, is_directory, size, access_time, modify_time, change_time, err, error_code);
		}
		
		bool	GetFileSize(string filename, int& size, string& err) 
		{
			int error_code;
			return GetFileSize(filename, size, err, error_code);
		}
	
		bool	GetFileModifyTime(string filename, int64_t& modify_time, string& err)
		{
			int error_code;
			return GetFileModifyTime(filename, modify_time, err, error_code);
		}

		bool	GetFileModifyTime(string filename, int64_t& modify_time, string& err, int& error_code)
		{
			int size;
			bool is_directory;
			int64_t access_time, change_time;
			return GetStats(filename, is_directory, size, access_time, modify_time, change_time, err, error_code);
		}
		
		bool	IsDirectory(string path, bool& is_directory, string& err, int& error_code)
		{	
			int size;
			int64_t access_time, modify_time, change_time;
			return GetStats(path, is_directory, size, access_time, modify_time, change_time, err, error_code);	
		}

		bool	IsDirectory(string path, bool& is_directory, string& err)
		{
			int error_code;
			return IsDirectory(path, is_directory, err, error_code);
		}
		
		bool	RemoveFile(string filename, string& err, int& error_code)
		{
			if ( -1 == remove(filename.c_str()) ) 
			{
				err = string::Format("Failed to remove file \"%s\": %s", filename.c_str(), strerror(errno));
				error_code = errno;
				return false;
			}
			return true;
		}

		bool	RemoveFile(string filename, string& err)
		{
			int error_code;
			return RemoveFile(filename, err, error_code);
		}
		
		bool	RenameFile(string filename, string target_filename, string& err, int& error_code)
		{
			if ( -1 == rename(filename.c_str(), target_filename.c_str()) )
			{
				err = string::Format("Failed to rename file \"%s\" to \"%s\": %s", filename.c_str(), target_filename.c_str(), strerror(errno));
				error_code = errno;
				return false;
			}
			return true;
		}

		bool	RenameFile(string filename, string target_filename, string& err)
		{
			int error_code;
			return RenameFile(filename, target_filename, err, error_code);
		}

		bool	CopyFile(string filename, string target_filename, string& err, int& error_code)
		{
            struct stat stat_buf;

			if ( -1 != stat(target_filename.c_str(), &stat_buf) )
			{
				remove(target_filename.c_str());
			}

			if ( -1 == link(filename.c_str(), target_filename.c_str()) )
			{
				err = string::Format("Failed to rename file \"%s\" to \"%s\": %s", filename.c_str(), target_filename.c_str(), strerror(errno));
				error_code = errno;
				return false;
			}
			return true;
		}
		
		bool	CopyFile(string filename, string target_filename, string& err)
		{
			int error_code;
			return CopyFile(filename, target_filename, err, error_code);
		}

		bool	ReadFile(int fd, char* buffer, int to_read, int& bytes_read, string& err, int& error_code)
		{
			bytes_read = read(fd, buffer, to_read);
			if ( bytes_read > 0 ) return true;
			if ( ( bytes_read == 0 ) && ( errno == EAGAIN ) ) return true;
			err = string::Format("Failed to read: %s", strerror(errno));
			error_code = errno;
			return false;
		}

		bool	ReadFile(int fd, char* buffer, int to_read, int& bytes_read, string& err)
		{
			int error_code;
			return ReadFile(fd, buffer, to_read, bytes_read, err, error_code);
		}

		bool	WriteFile(int fd, char* buffer, int to_write, int& bytes_write, string& err, int& error_code)
		{
			bytes_write = write(fd, buffer, to_write);
			if ( bytes_write > 0 ) return true;
			if ( ( bytes_write == 0 ) && ( errno == EAGAIN ) ) return true;
			err = string::Format("Failed to write: %s", strerror(errno));
			error_code = errno;
			return false;
		}

		bool	WriteFile(int fd, char* buffer, int to_write, int& bytes_write, string& err)
		{
			int error_code;
			return WriteFile(fd, buffer, to_write, bytes_write, err, error_code);
		}
		
		bool	ParseDir(string path, string& dir, string& err, int& error_code)
		{
			const char* ph = path.c_str();
			const char* p = strrchr(ph, '/');
			if ( !p ) 
			{
				err = string::Format("Fail to parse dir: invalid path \"%s\"", ph);
				error_code = ENOTDIR;
				return false;
			}
			while ( ( *p == '/' ) && ( p > ph ) )  p--; // fix bad format like "/etc/idirect//x509_cert.bin"
			unsigned len = p - path.c_str() + 1;
			dir = string(path.c_str(), len);
			return true;
		}

		bool	ParseDir(string path, string& dir, string& err)
		{
			int error_code;
			return ParseDir(path, dir, err, error_code);
		}
	
		//
		// Internal function
		//
		bool	do_mkdir(const char *path, int mode, string& err, int& error_code)
		{
			struct stat st;
			if ( stat(path, &st) != 0 )
			{
				/* Directory does not exist, create */
				if ( mkdir(path, mode) != 0 ) 
				{
					err = string::Format("Fail to mkdir (\"%s\"): %s", path, strerror(errno));
					error_code = errno;
					return false;
				}
			}
			else if ( !S_ISDIR(st.st_mode) )
			{
				err = string::Format("Fail to mkdir (\"%s\"): path exist but not directory", path);
				error_code = ENOTDIR;
				return false;
			}
	
			return true;
		}

		bool	do_mkdir(const char *path, int mode, string& err)
		{
			int error_code;
			return do_mkdir(path, mode, err, error_code);
		}

		bool	MakeDir(string path, int mode, string& err, int& error_code)
		{
			char* copypath = strdup(path.c_str());
			const char* pp = copypath;
			
			bool ret = true;
			while ( ret )
			{
				char* sp = const_cast<char*>(strchr(pp, '/'));
				if ( !sp ) break;
				if ( sp != pp )
				{
					*sp = '\0';
					ret = do_mkdir(copypath, mode, err);
					*sp = '/';
				}
				pp = sp + 1;
			}
			if ( ret ) ret = do_mkdir(path, mode, err, error_code);
			free(copypath);
			return ret;
		}
		
		bool	MakeDir(string path, int mode, string& err)
		{
			int error_code;
			return MakeDir(path, mode, err, error_code);
		}
	}

}//end namespace iDirect

