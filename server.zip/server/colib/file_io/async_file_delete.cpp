#include "async_file_delete.h"
#include "file_io_utils.h"
#include <event_loop/event_loop.h>

namespace colib
{
	DiskFileDelete::DiskFileDelete()
		: FileDeleteBase()
		, m_act(callbackRt(this, &DiskFileDelete::DoTask), "TaskAct")
	{
	}

	DiskFileDelete::~DiskFileDelete()
	{
		Stop();
	}

	string DiskFileDelete::Print() const
	{
		return FileDeleteBase::Print() + string::Format(
													"Task activity is %sactive\n", 
													m_act.IsActive() ? "" : "not ");
	}

	void DiskFileDelete::Init(
							string file_name, 
							const Callback1<const FileDeleteBase&>& requester_cb, 
							void* context)
	{
		Reset();
		SetFileName(file_name);
		SetCallback(requester_cb);
		SetContext(context);
	}
	
	bool DiskFileDelete::Start()
	{	
		//
		// Add activity
		//
		bool ret = EventLoop::GetInstance().AddActivity(&m_act);
		if ( ret ) SetStatus(IoBase::IN_PROGRESS);
		return ret;
	}

	void DiskFileDelete::Stop()
	{
		EventLoop::GetInstance().DeleteActivity(&m_act);
	}

	bool DiskFileDelete::Delete(string& err, int& error_code)
	{	
	   	return DiskFile::RemoveFile(GetFileName(), err, error_code);
	}
	
	eCallbackRt DiskFileDelete::DoTask()
	{
		string err;
		int error_code;

		if ( !Delete(err, error_code) )
		{
			SetError(err);
			SetErrorCode(error_code);
			SetStatus(IoBase::FAILED);
		}
		else
		{
			SetError("Task complete");
			SetStatus(IoBase::SUCCEEDED);
		}
		
		DeleteComplete();
		return DontRunAgain;
	}
	
	DiskFileDeleteSA::DiskFileDeleteSA()
		: DiskFileDelete()
		, m_job(*this)
	{
	}
	
	bool DiskFileDeleteSA::DeleteFile(
								string file_name, 
								const Callback1<const FileDeleteBase&>& requester_cb, 
								void* context)
	{
		Init(file_name, requester_cb, context);
		return m_job.Start();
	}
	
	void DiskFileDeleteSA::DeleteComplete()
	{
		m_job.Complete();
	}
		
	string DiskFileDeleteSA::Print() const
	{
		return DiskFileDelete::Print() + "Job type: SA\n";
	}
	
	DiskFileDeleteMgd::DiskFileDeleteMgd(unsigned job_id, IoJobMgrGlobal& job_mgr)
		: DiskFileDelete()
		, m_job_id(job_id)
		, m_job_mgr(job_mgr)
	{
	}
	
	string DiskFileDeleteMgd::Print() const
	{
		return DiskFileDelete::Print() + "Job type: Mgd\n";
	}

	DiskFileDeleteMgr::DiskFileDeleteMgr(MemberSet& trace_set, unsigned max_limit)
		: IoJobMgrGlobal(trace_set)
	 	, m_max_limit(max_limit)
	{
	}

	bool DiskFileDeleteMgr::DeleteFile(
								string file_name, 
								const Callback1<const FileDeleteBase&>& requester_cb, 
								void* context)
	{
		DiskFileDeleteMgd* job = static_cast<DiskFileDeleteMgd*>(AddJob(/*type(ignored)*/0));
		if ( !job ) return false;
		job->Init(file_name, requester_cb, context);
		return true;
	}

	IoBase* DiskFileDeleteMgr::CreateIo(unsigned/*type(ignored)*/, unsigned job_id, IoJobMgrGlobal& mgr)
	{
		return new DiskFileDeleteMgd(job_id, mgr);
	}

	DiskFileDeleteFifo::DiskFileDeleteFifo(MemberSet& trace_set, unsigned max_limit)
		: DiskFileDeleteMgr(trace_set, max_limit)
	{
	}

	DiskFileDeleteGeneral::DiskFileDeleteGeneral(MemberSet& trace_set, unsigned concurrent_limit, unsigned max_limit)
		: DiskFileDeleteMgr(trace_set, max_limit)
		, m_concurrent_limit(concurrent_limit)
	{
	}

}

