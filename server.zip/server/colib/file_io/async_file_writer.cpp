#include "async_file_writer.h"
#include "file_io_error.h"
#include "file_io_utils.h"
#include <event_loop/event_loop.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>

namespace colib
{
	DiskFileWriter::DiskFileWriter()
		: AsyncWriterBase()
		, m_start_act(callbackRt(this, &DiskFileWriter::StartTask), "StartTaskAct")
		, m_act(callbackRt(this, &DiskFileWriter::DoTask), "TaskAct")
		, m_target_file_name()  
		, m_fd(-1)
	 	, m_write_offset(0)	
	 	, m_bytes_to_write(0)
		, m_fail_write_limit(false) 
	{
	}

	DiskFileWriter::~DiskFileWriter()
	{
		Stop();
	}

	string DiskFileWriter::Print() const
	{
		return AsyncWriterBase::Print() + string::Format(
												"Rename to: %s\n"
												"Fd: %d\n"
												"Bytes to write: %d\n"
												"Write offset: %d\n"
												"Start task activity is %sactive\n" 
												"Task activity is %sactive\n", 
												m_target_file_name.c_str(),
												m_fd,
												m_bytes_to_write,
												m_write_offset,
												m_start_act.IsActive() ? "" : "not ",
												m_act.IsActive() ? "" : "not ");
	}
	
	void DiskFileWriter::CloseFile()
	{
		if ( m_fd > 0 ) close(m_fd);
		m_fd = -1;
	}

	void DiskFileWriter::Reset()
	{
		AsyncWriterBase::Reset();
		m_target_file_name = "";
		CloseFile();
		m_write_offset = 0;
	   	m_bytes_to_write = 0;
		m_fail_write_limit = false;
	}

	void DiskFileWriter::Init(
								string file_name, 
								AsyncWriterBase::WriteMode mode,
								const char* data,
								int length, 
								const Callback1<const AsyncWriterBase&>& requester_cb, 
								void* context,
								string target_file_name)
	{
		Reset();
		//
		// Copy data
		//
		int max_size_limit = MaxWriteLimit();
		int copy_length = ( length <= 0 ) ? 0 : ( length < max_size_limit ) ? length : max_size_limit;
		memcpy(m_data, data, copy_length);
		//
		SetFileName(file_name);
		SetMode(mode);
		SetDataLength(length);
		SetCallback(requester_cb);
		SetContext(context);
		m_target_file_name = target_file_name;
	}
	
	bool DiskFileWriter::WriteInitialize(int flag, string& err, int& error_code)
	{		
		//
		// Check size
		//
		int length = GetDataLength();		
		if ( length <= 0 ) 
		{
			err = string::Format("Fail to write: length (%d) invalid", length);
			error_code = FileIoError::WRITE_SIZE_INVALID;
			return false;
		}

		if ( length > static_cast<int>(MaxWriteLimit()) )
		{
			m_fail_write_limit = true;
			err = string::Format("bytes to write (%d) exceed max allowed write limit (%u)", length, MaxWriteLimit());
			error_code = FileIoError::RW_SIZE_EXCEEDS_LIMIT;
			return false;
		}
		//
		// Create directory if necessary
		//
		string dir_path;
		DiskFile::ParseDir(GetFileName(), dir_path, err);
		err.empty();
		//
		if ( 
			!dir_path.is_empty() && 
			!DiskFile::MakeDir(dir_path, DiskFile::DEFAULT_DIR_PERMISSION, err, error_code) 
			) 
			return false;
		//
		// Open file to write
		//	
		mode_t perm = DiskFile::DEFAULT_FILE_PERMISSION;
		if ( GetMode() == AsyncWriterBase::APPEND ) flag |= O_APPEND;
		else if ( GetMode() == AsyncWriterBase::OVERWRITE ) flag |= O_TRUNC;	
		m_fd = open(GetFileName().c_str(), flag, perm);
		if ( m_fd <= 0 )
		{	
			err = string::Format("Fail to open file: %s (%d)", strerror(errno), errno);
			error_code = errno;
			return false;
		}	
		m_bytes_to_write = GetDataLength();

		return true;
	}

	bool DiskFileWriter::WriteFinish(string& err, int& error_code)
	{	
		//
		// Update filesize
		//
		int filesize = 0;
		if ( !DiskFile::GetFileSize(GetFileName(), filesize, err, error_code) ) return false;
		SetFileSize(filesize);
		//
		// Rename 
		//
		if ( !m_target_file_name.is_empty() )
		{	
			//
			// Create directory if necessary
			//
			string dir_path;
			DiskFile::ParseDir(m_target_file_name, dir_path, err);
			if ( 
				!dir_path.is_empty() && 
				!DiskFile::MakeDir(dir_path, DiskFile::DEFAULT_DIR_PERMISSION, err, error_code) 
				)
				return false;
			//
			// Rename
			//
			if ( !DiskFile::RenameFile(GetFileName(), m_target_file_name, err, error_code) ) return false;
		}

		return true;
	}

	eCallbackRt DiskFileWriter::StartTask()
	{
		bool ret = true;
		string err;
		int error_code;
		//
		// Initialize
		//
		if ( !WriteInitialize(O_WRONLY | O_NONBLOCK | O_CREAT, err, error_code) )
		{	
			SetError(err);
			SetErrorCode(error_code);
			ret = false;
		}
		//
		// Add activity
		//
		if ( ret && !EventLoop::GetInstance().AddActivity(&m_act) )
		{	
			SetError("Fail to add task activity");
			SetErrorCode(FileIoError::ADD_ACTIVITY_FAILED);
			ret = false;
		}

		if ( !ret )
		{
			SetStatus(IoBase::FAILED);
			CloseFile();
			WriteComplete();
		}

		return DontRunAgain;
	}

	bool DiskFileWriter::Start()
	{
		bool ret = EventLoop::GetInstance().AddActivity(&m_start_act);
		if ( ret ) SetStatus(IoBase::IN_PROGRESS);
		return ret;
	}

	void DiskFileWriter::Stop()
	{
		CloseFile();
		EventLoop::GetInstance().DeleteActivity(&m_act);
	}

	bool DiskFileWriter::WriteData(int to_write, string& err, int& error_code)
	{	
		int bytes_write = 0;
		if ( !DiskFile::WriteFile(m_fd, m_data + m_write_offset, to_write, bytes_write, err, error_code) ) return false;
		m_write_offset += bytes_write;
		m_bytes_to_write -= bytes_write;
		return true;
	}

	eCallbackRt DiskFileWriter::DoTask()
	{
		const int BLOCK_SIZE = 1024;
		int to_write = std::min(BLOCK_SIZE, m_bytes_to_write);
		
		string err;
		int error_code;
		if ( !WriteData(to_write, err, error_code) )
		{
			SetError(err);
			SetErrorCode(error_code);
			SetStatus(IoBase::FAILED);
			CloseFile();
			WriteComplete();
			return DontRunAgain;
		}
		if ( m_bytes_to_write > 0 ) return RunAgain;
		//
		// Write complete
		//
		SetError("File write complete");
		SetStatus(IoBase::SUCCEEDED);
		CloseFile();
		//
		// Finish
		//
		if ( !WriteFinish(err, error_code) )
		{
			SetError(err);
			SetErrorCode(error_code);
			SetStatus(IoBase::FAILED);
		}

		WriteComplete();
		return DontRunAgain;
	}

	DiskFileWriterSA::DiskFileWriterSA()
		: DiskFileWriter()
		, m_job(*this)
	{
	}
	
	bool DiskFileWriterSA::WriteFile(
								string file_name, 
								const char* data,
								int length,
								const Callback1<const AsyncWriterBase&>& requester_cb, 
								void* context)
	{
		return WriteFile(file_name, AsyncWriterBase::OVERWRITE, data, length, requester_cb, context, "");
	}
		
	bool DiskFileWriterSA::WriteFileWithMove(
								string file_name, 
								const char* data,
								int length,
								const Callback1<const AsyncWriterBase&>& requester_cb, 
								void* context,
								string target_file_name)
	{
		return WriteFile(file_name, AsyncWriterBase::OVERWRITE, data, length, requester_cb, context, target_file_name);
	}
	
	bool DiskFileWriterSA::AppendFile(
								string file_name, 
								const char* data,
								int length,
								const Callback1<const AsyncWriterBase&>& requester_cb, 
								void* context)
	{
		return WriteFile(file_name, AsyncWriterBase::APPEND, data, length, requester_cb, context, "");
	}
		
	bool DiskFileWriterSA::AppendFileWithMove(
								string file_name, 
								const char* data,
								int length,
								const Callback1<const AsyncWriterBase&>& requester_cb, 
								void* context,
								string target_file_name)
	{
		return WriteFile(file_name, AsyncWriterBase::APPEND, data, length, requester_cb, context, target_file_name);
	}

	bool DiskFileWriterSA::WriteFile(
								string file_name, 
								AsyncWriterBase::WriteMode mode,
								const char* data,
								int length,
								const Callback1<const AsyncWriterBase&>& requester_cb, 
								void* context,
								string target_file_name)
	{
		Init(file_name, mode, data, length, requester_cb, context, target_file_name);
		return m_job.Start();
	}

	void DiskFileWriterSA::WriteComplete()
	{
		m_job.Complete();
	}
		
	string DiskFileWriterSA::Print() const
	{
		return DiskFileWriter::Print() + "Job type: SA\n";
	}
	
	DiskFileWriterMgd::DiskFileWriterMgd(unsigned job_id, IoJobMgrGlobal& job_mgr)
		: DiskFileWriter()
		, m_job_id(job_id)
		, m_job_mgr(job_mgr)
	{
	}
	
	string DiskFileWriterMgd::Print() const
	{	
		return DiskFileWriter::Print() + string::Format(
											"Job type: Mgd\n"
											"Job ID: %u\n",
											m_job_id);
	}

	DiskFileWriterMgr::DiskFileWriterMgr(MemberSet& trace_set, unsigned max_limit)
		: IoJobMgrGlobal(trace_set)
	 	, m_max_limit(max_limit)
	{
	}

	bool DiskFileWriterMgr::WriteFile(
								string file_name, 
								const char* data,
								int length,
								const Callback1<const AsyncWriterBase&>& requester_cb, 
								void* context)
	{
		return WriteFile(file_name, AsyncWriterBase::OVERWRITE, data, length, requester_cb, context, "");
	}
		
	bool DiskFileWriterMgr::WriteFileWithMove(
								string file_name, 
								const char* data,
								int length,
								const Callback1<const AsyncWriterBase&>& requester_cb, 
								void* context,
								string target_file_name)
	{
		return WriteFile(file_name, AsyncWriterBase::OVERWRITE, data, length, requester_cb, context, target_file_name);
	}
	
	bool DiskFileWriterMgr::AppendFile(
								string file_name, 
								const char* data,
								int length,
								const Callback1<const AsyncWriterBase&>& requester_cb, 
								void* context)
	{
		return WriteFile(file_name, AsyncWriterBase::APPEND, data, length, requester_cb, context, "");
	}

	bool DiskFileWriterMgr::AppendFileWithMove(
								string file_name, 
								const char* data,
								int length,
								const Callback1<const AsyncWriterBase&>& requester_cb, 
								void* context,
								string target_file_name)
	{
		return WriteFile(file_name, AsyncWriterBase::APPEND, data, length, requester_cb, context, target_file_name);
	}

	bool DiskFileWriterMgr::WriteFile(
								string file_name, 
								AsyncWriterBase::WriteMode mode,
								const char* data,
								int length, 
								const Callback1<const AsyncWriterBase&>& requester_cb, 
								void* context,
								string target_file_name)
	{
		DiskFileWriterMgd* job = static_cast<DiskFileWriterMgd*>(AddJob(/*type(ignored)*/0));
		if ( !job ) return false;
		job->Init(file_name, mode, data, length, requester_cb, context, target_file_name);
		return true;
	}

	IoBase* DiskFileWriterMgr::CreateIo(unsigned/*type(ignored)*/, unsigned job_id, IoJobMgrGlobal& mgr)
	{
		return new DiskFileWriterMgd(job_id, mgr);
	}

	DiskFileWriteFifo::DiskFileWriteFifo(MemberSet& trace_set, unsigned max_limit)
		: DiskFileWriterMgr(trace_set, max_limit)
	{
	}

	DiskFileWriteGeneral::DiskFileWriteGeneral(MemberSet& trace_set, unsigned concurrent_limit, unsigned max_limit)
		: DiskFileWriterMgr(trace_set, max_limit)
		, m_concurrent_limit(concurrent_limit)
	{
	}	

}

