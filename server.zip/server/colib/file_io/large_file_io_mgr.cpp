// large_file_io_mgr.cpp
// vi:set ts=4 sw=4 nowrap:

#include "large_file_io_mgr.h"
#include <event_loop/event_loop.h>

namespace colib
{	
	bool LargeFileIoMgr::ReadFile(
							string filename, 
							const Callback1<const AsyncReaderBase&>& requester_cb,
							void* context,
							FileIoMgr& file_io_mgr)
	{
		LargeFileIO* io = GetFileIO(filename);
		return io ? io->Read(filename, requester_cb, context, file_io_mgr) : false;
	}	

	bool LargeFileIoMgr::ReadFile(
							string filename, 
							const Callback3<char*, int, void*>& on_read_succeed, 
							const Callback2<string, void*>& on_read_failed, 
							void* context, 
							string& err, 
							FileIoMgr& file_io_mgr)
	{
		LargeFileIO* io = GetFileIO(filename);
		if ( io ) return io->Read(filename, on_read_succeed, on_read_failed, context, err, file_io_mgr);
		err = "no large file IO";
		return false;
	}
		
	bool LargeFileIoMgr::WriteFile(
							string filename, 
							char* data, int len, 
							const Callback1<const AsyncWriterBase&>& requester_cb,
							void* context, 
							FileIoMgr& file_io_mgr)
	{	
		LargeFileIO* io = GetFileIO(filename);
		return io ? io->Write(filename, data, len, requester_cb, context, file_io_mgr) : false;
	}

	bool LargeFileIoMgr::WriteFile(
							string filename, 
							char* data, int len, 
							const Callback1<void*>& on_write_succeed, 
							const Callback2<string, void*>& on_write_failed, 
							void* context, 
							string& err,
							FileIoMgr& file_io_mgr)
	{	
		LargeFileIO* io = GetFileIO(filename);
		if ( io ) return io->Write(filename, data, len, on_write_succeed, on_write_failed, context, err, file_io_mgr);		
		err = "no large file IO";
		return false;	
	}
		
	bool LargeFileIoMgr::SafeWriteFile(
							string filename, 
							char* data, int len, 
							const Callback1<const AsyncWriterBase&>& requester_cb,
							void* context, 
							FileIoMgr& file_io_mgr)
	{	
		LargeFileIO* io = GetFileIO(filename);
		return io ? io->SafeWrite(filename, data, len, requester_cb, context, file_io_mgr) : false;
	}


	bool LargeFileIoMgr::SafeWriteFile(
							string filename, 
							char* data, int len, 
							const Callback1<void*>& on_write_succeed, 
							const Callback2<string, void*>& on_write_failed, 
							void* context, 
							string& err,
							FileIoMgr& file_io_mgr)
	{	
		LargeFileIO* io = GetFileIO(filename);
		if ( io ) return io->SafeWrite(filename, data, len, on_write_succeed, on_write_failed, context, err, file_io_mgr);	
		err = "no large file IO";
		return false;			
	}

	//
	// GlobalLargeFileIoMgr
	//
	GlobalLargeFileIoMgr& GlobalLargeFileIoMgr::GetInstance()
	{
		static GlobalLargeFileIoMgr instance;
		return instance;
	}

	GlobalLargeFileIoMgr::GlobalLargeFileIoMgr()
		: LargeFileIoMgr()
		, LargeFileIoReleaser()		  
		, m_file_io_clean_act(callbackRt(this, &GlobalLargeFileIoMgr::Cleanup), "LargeFileIoMgrCleanup")
		, m_file_io_to_remove()  
		, m_queue_read_request()
		, m_queue_write_request()  
	{
	}	

	GlobalLargeFileIoMgr::~GlobalLargeFileIoMgr()
	{
		Cleanup();
	}

	eCallbackRt GlobalLargeFileIoMgr::Cleanup()
	{
		for ( unsigned i = 0; i < m_file_io_to_remove.size(); ++i )
		{
			delete m_file_io_to_remove[i];
		}
		m_file_io_to_remove.clear();
		return DontRunAgain;
	}

	LargeFileIO* GlobalLargeFileIoMgr::GetFileIO(string)
	{
		return new LargeFileIO(this);
	}

	void GlobalLargeFileIoMgr::Release(LargeFileIO* io)
	{
		if ( io ) 
		{
			m_file_io_to_remove.push_back(io);
			EventLoop::GetInstance().AddActivity(&m_file_io_clean_act);
		}
	}
	//
	// RequestBase
	//
	GlobalLargeFileIoMgr::LargeFileIORequestBase::LargeFileIORequestBase()
		: m_file_io_mgr(0)
		, m_filename()
		, m_context(0)
	{
	}		
	//
	// ReadRequest
	//
	GlobalLargeFileIoMgr::LargeFileIOReadRequest::LargeFileIOReadRequest()
		: LargeFileIORequestBase()
		, m_read_complete_cbk()
		, m_read_succeed_cbk()
		, m_read_failed_cbk()
	{
	}

	GlobalLargeFileIoMgr::LargeFileIOReadRequest::LargeFileIOReadRequest(const LargeFileIOReadRequest&)
		: LargeFileIORequestBase()
		, m_read_complete_cbk()
		, m_read_succeed_cbk()
		, m_read_failed_cbk()
	{
	}

	bool GlobalLargeFileIoMgr::QueueReadFile(
							string filename, 
							const Callback1<const AsyncReaderBase&>& requester_cb,
							void* context,
							FileIoMgr& file_io_mgr)
	{
		//
		// add request
		//
		LargeFileIOReadRequest& request = m_queue_read_request.Append()->GetData();
		request.m_file_io_mgr = &file_io_mgr;
		request.m_filename = filename;
		request.m_context = context;
		request.m_read_complete_cbk = requester_cb;
		//
		// start read if it is the first request
		//
		if ( m_queue_read_request.Size() == 1 ) StartNextQueueRead();

		return true;
	}	
	
	bool GlobalLargeFileIoMgr::QueueReadFile(
							string filename, 
							const Callback3<char*, int, void*>& on_read_succeed, 
							const Callback2<string, void*>& on_read_failed, 
							void* context, 
							string&,
							FileIoMgr& file_io_mgr)
	{	
		//
		// add request
		//
		LargeFileIOReadRequest& request = m_queue_read_request.Append()->GetData();
		request.m_file_io_mgr = &file_io_mgr;
		request.m_filename = filename;
		request.m_context = context;
		request.m_read_succeed_cbk = on_read_succeed;
		request.m_read_failed_cbk = on_read_failed;
		//
		// start read if it is the first request
		//
		if ( m_queue_read_request.Size() == 1 ) StartNextQueueRead();

		return true;
	}

	void GlobalLargeFileIoMgr::StartNextQueueRead()
	{
		// 
		// Sanity check
		//
		if ( m_queue_read_request.IsEmpty() ) return;
		// 
		// Read head
		//
		LargeFileIOReadRequest& request = m_queue_read_request.GetHead()->GetData();
		this->ReadFile(
				request.m_filename, 
				callback(this, &GlobalLargeFileIoMgr::QueueReadComplete),
				request.m_context,
				*request.m_file_io_mgr);
	}

	void GlobalLargeFileIoMgr::QueueReadComplete(const AsyncReaderBase& rdr)
	{	
		// 
		// Sanity check
		//
		if ( m_queue_read_request.IsEmpty() ) return;
		// 
		// Read complete for head
		//
		Dlist<LargeFileIOReadRequest>::Node* head = m_queue_read_request.GetHead();
		LargeFileIOReadRequest& request = head->GetData();
		//
		// Dispatch appropriate callback
		//
		if ( request.m_read_complete_cbk.IsSet() ) 
		{
			request.m_read_complete_cbk.Dispatch(rdr);
		}
		else
		{
			if ( rdr.GetStatus() == IoBase::SUCCEEDED ) 
			{
				request.m_read_succeed_cbk.Dispatch(const_cast<char*>(rdr.GetData()), rdr.GetDataLength(), rdr.GetContext());
			}
			else
			{
				request.m_read_failed_cbk.Dispatch(rdr.GetError(), rdr.GetContext());
			}
		}
		// 
		// Remove from queue
		//
		m_queue_read_request.Remove(head);
		// 
		// Serve next
		//
		StartNextQueueRead();
	}
	//
	// WriteRequest
	//
	GlobalLargeFileIoMgr::LargeFileIOWriteRequest::LargeFileIOWriteRequest()
		: GlobalLargeFileIoMgr::LargeFileIORequestBase()
		, m_data_buffer()
		, m_safe_write(false)  
		, m_write_complete_cbk()
		, m_write_succeed_cbk()
		, m_write_failed_cbk()
	{
	}
	
	GlobalLargeFileIoMgr::LargeFileIOWriteRequest::LargeFileIOWriteRequest(const LargeFileIOWriteRequest&)
		: GlobalLargeFileIoMgr::LargeFileIORequestBase()
		, m_data_buffer()
		, m_safe_write(false)  
		, m_write_complete_cbk()
		, m_write_succeed_cbk()
		, m_write_failed_cbk()
	{
	}

	bool GlobalLargeFileIoMgr::QueueWriteFile(	
							string filename, 
							char* data, int len, 
							const Callback1<const AsyncWriterBase&>& requester_cb,
							void* context, 
							FileIoMgr& file_io_mgr)
	{	
		// 
		// add request
		//
		LargeFileIOWriteRequest& request = m_queue_write_request.Append()->GetData();
		request.m_file_io_mgr = &file_io_mgr;
		request.m_filename = filename;
		request.m_context = context;
		request.m_safe_write = false;
		request.m_write_complete_cbk = requester_cb;	
		//
		// Optimization: no data copy if it is the first request
		//
		if ( m_queue_write_request.Size() == 1 ) 
		{
			this->WriteFile(
					request.m_filename,
					data, len,
					callback(this, &GlobalLargeFileIoMgr::QueueWriteComplete),
					request.m_context,
					*request.m_file_io_mgr);
		}
		else // Copy the data
		{
			request.m_data_buffer.insert(request.m_data_buffer.end(), data, data + len);
		}

		return true;
	}	
	
	bool GlobalLargeFileIoMgr::QueueWriteFile(	
							string filename, 
							char* data, int len, 	
							const Callback1<void*>& on_write_succeed, 
							const Callback2<string, void*>& on_write_failed, 
							void* context, 
							string&,
							FileIoMgr& file_io_mgr)
	{	
		// 
		// add request
		//
		LargeFileIOWriteRequest& request = m_queue_write_request.Append()->GetData();
		request.m_file_io_mgr = &file_io_mgr;
		request.m_filename = filename;
		request.m_context = context;
		request.m_safe_write = false;
		request.m_write_succeed_cbk = on_write_succeed;
		request.m_write_failed_cbk = on_write_failed;
		//
		// Optimization: no data copy if it is the first request
		//
		if ( m_queue_write_request.Size() == 1 ) 
		{
			this->WriteFile(
					request.m_filename,
					data, len,
					callback(this, &GlobalLargeFileIoMgr::QueueWriteComplete),
					request.m_context,
					*request.m_file_io_mgr);
		}
		else // Copy the data
		{
			request.m_data_buffer.insert(request.m_data_buffer.end(), data, data + len);
		}

		return true;
	}	
	
	bool GlobalLargeFileIoMgr::QueueSafeWriteFile(	
							string filename, 
							char* data, int len, 
							const Callback1<const AsyncWriterBase&>& requester_cb,
							void* context, 
							FileIoMgr& file_io_mgr)
	{	
		// 
		// add request
		//
		LargeFileIOWriteRequest& request = m_queue_write_request.Append()->GetData();
		request.m_file_io_mgr = &file_io_mgr;
		request.m_filename = filename;
		request.m_context = context;
		request.m_safe_write = true;
		request.m_write_complete_cbk = requester_cb;	
		//
		// Optimization: no data copy if it is the first request
		//
		if ( m_queue_write_request.Size() == 1 ) 
		{
			this->SafeWriteFile(
					request.m_filename,
					data, len,
					callback(this, &GlobalLargeFileIoMgr::QueueWriteComplete),
					request.m_context,
					*request.m_file_io_mgr);
		}
		else // Copy the data
		{
			request.m_data_buffer.insert(request.m_data_buffer.end(), data, data + len);
		}

		return true;
	}	
	
	bool GlobalLargeFileIoMgr::QueueSafeWriteFile(	
							string filename, 
							char* data, int len, 	
							const Callback1<void*>& on_write_succeed, 
							const Callback2<string, void*>& on_write_failed, 
							void* context, 
							string&,
							FileIoMgr& file_io_mgr)
	{	
		// 
		// add request
		//
		LargeFileIOWriteRequest& request = m_queue_write_request.Append()->GetData();
		request.m_file_io_mgr = &file_io_mgr;
		request.m_filename = filename;
		request.m_context = context;
		request.m_safe_write = true;
		request.m_write_succeed_cbk = on_write_succeed;
		request.m_write_failed_cbk = on_write_failed;
		//
		// Optimization: no data copy if it is the first request
		//
		if ( m_queue_write_request.Size() == 1 ) 
		{
			this->SafeWriteFile(
					request.m_filename,
					data, len,
					callback(this, &GlobalLargeFileIoMgr::QueueWriteComplete),
					request.m_context,
					*request.m_file_io_mgr);
		}
		else // Copy the data
		{
			request.m_data_buffer.insert(request.m_data_buffer.end(), data, data + len);
		}

		return true;
	}	

	void GlobalLargeFileIoMgr::QueueWriteComplete(const AsyncWriterBase& wtr)
	{
		//
		// Sanity check
		//
		if ( m_queue_write_request.IsEmpty() ) return;
		// 
		// Write complete for head
		//
		Dlist<LargeFileIOWriteRequest>::Node* head = m_queue_write_request.GetHead();
		LargeFileIOWriteRequest& request = head->GetData();
		//
		// Dispatch appropriate callback
		//
		if ( request.m_write_complete_cbk.IsSet() ) 
		{
			request.m_write_complete_cbk.Dispatch(wtr);
		}
		else
		{
			if ( wtr.GetStatus() == IoBase::SUCCEEDED ) 
			{
				request.m_write_succeed_cbk.Dispatch(wtr.GetContext());
			}
			else
			{
				request.m_write_failed_cbk.Dispatch(wtr.GetError(), wtr.GetContext());
			}
		}
		// 
		// Remove from queue
		//
		m_queue_write_request.Remove(head);
		// 
		// Serve next
		//
		StartNextQueueWrite();
	}

	void GlobalLargeFileIoMgr::StartNextQueueWrite()
	{
		// 
		// Sanity check
		//
		if ( m_queue_write_request.IsEmpty() ) return;
		// 
		// Write head
		//
		LargeFileIOWriteRequest& request = m_queue_write_request.GetHead()->GetData();
		if ( request.m_safe_write )
		{
			this->SafeWriteFile(
					request.m_filename,
					&request.m_data_buffer[0],
					request.m_data_buffer.size(),
					callback(this, &GlobalLargeFileIoMgr::QueueWriteComplete),
					request.m_context,
					*request.m_file_io_mgr);
		}
		else
		{	
			this->WriteFile(
					request.m_filename,
					&request.m_data_buffer[0],
					request.m_data_buffer.size(),
					callback(this, &GlobalLargeFileIoMgr::QueueWriteComplete),
					request.m_context,
					*request.m_file_io_mgr);
		}
	}

}//end namespace iDirect

