#include "file_read_base.h"

namespace colib
{
	AsyncReaderBase::AsyncReaderBase()
		: FileIoBase()
 		, m_data_length(0)
		, m_offset(0) 
		, m_requester_cb()
	{
	}

	AsyncReaderBase::AsyncReaderBase(
								string file_name, 
								int offset, 
								int length, 
								const Callback1<const AsyncReaderBase&>& requester_cb, 
								void* context)
		: FileIoBase(file_name, context)
		, m_data_length(length)
		, m_offset(offset) 
		, m_requester_cb(requester_cb)
	{
	}
	
	string AsyncReaderBase::Print() const
	{
		return FileIoBase::Print() + string::Format(
											"Offset: %d\n"
											"Data: <%p, %d>\n"	
											"Read max limit: %u\n"
											"Read fail max limit: %s\n"
											"Callback is %sset\n",
											GetOffset(),
											GetData(), GetDataLength(),
											MaxReadLimit(), 
											FailMaxReadLimit() ? "true" : "false",
											m_requester_cb.IsSet() ? "" : "not ");
	}

}

