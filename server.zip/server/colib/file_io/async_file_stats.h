#if !defined(__IDIRECT_ASYNC_FILE_STATS_H__)
#define __IDIRECT_ASYNC_FILE_STATS_H__

#include "file_stats_base.h"
#include "io_job.h"
#include <event_loop/activity_hld.h>

namespace colib
{
	class GlobalFileIoMgr;
	class DiskFileStatsMgr;
	class DiskDirList;

	class DiskFileStats : public FileStatsBase
	{
		public:
			
			/** For this class ERROR CODE RANGE [NOT YET DEFINED] **/
			
			virtual ~DiskFileStats();

			virtual string Print() const;
			
			DiskFileStats(const DiskFileStats&) = delete;
			DiskFileStats& operator=(const DiskFileStats&) = delete;

		protected:
		
			DiskFileStats();

			virtual bool Start();
			virtual void Stop();
			virtual void Complete() { DispatchCB(); }
	
			void Init(
					string file_name, 
					const Callback1<const FileStatsBase&>& requester_cb, 
					void* context);

			bool GetFileStats(string&, int& error_code);
			eCallbackRt DoTask();
			
			virtual void StatsComplete() = 0; 	

		protected:
			
			ActivityHold m_act;

		friend class DiskFileStatsMgr;
	};

	class DiskFileStatsSA : public DiskFileStats
	{
		public:

			DiskFileStatsSA();
			virtual ~DiskFileStatsSA() {};
			//
			bool StatsFile(
					string file_name, 
					const Callback1<const FileStatsBase&>& requester_cb, 
					void* context);
			//
			// Stop
			//
			void StopTask() { m_job.Stop(); }
	
			virtual string Print() const;

			DiskFileStatsSA(const DiskFileStatsSA&) = delete;
			DiskFileStatsSA& operator=(const DiskFileStatsSA&) = delete;

		protected:

			virtual void StatsComplete(); 	

		protected:

			IoJobMgrSA m_job;
		
		friend class DiskDirList;
	};	

	class DiskFileStatsMgd : public DiskFileStats
	{
		public:

			virtual ~DiskFileStatsMgd() {};

			virtual string Print() const;

		protected:

			DiskFileStatsMgd(unsigned job_id, IoJobMgrGlobal&);
		
			virtual void Stop() {}; // Not allowed to stop by itself
			virtual void StatsComplete() { m_job_mgr.JobDone(m_job_id); }

		protected:

			unsigned m_job_id;
			IoJobMgrGlobal& m_job_mgr;

		friend class DiskFileStatsMgr;
	};

	class DiskFileStatsMgr : public IoJobMgrGlobal
	{
		public:

			virtual ~DiskFileStatsMgr() {};	
			//
			bool StatsFile(
					string file_name, 
					const Callback1<const FileStatsBase&>& requester_cb, 
					void* context);

		protected:
			
			DiskFileStatsMgr(MemberSet& trace_set, unsigned max_limit);
			void SetMaxLimit(unsigned max_limit) { m_max_limit = max_limit; }

			virtual IoBase* CreateIo(unsigned/*type(ignored)*/, unsigned job_id, IoJobMgrGlobal& mgr);
			virtual unsigned MaximumJobLimit() const { return m_max_limit; }

		protected:

			unsigned m_max_limit;
	};

	class DiskFileStatsFifo : public DiskFileStatsMgr
	{
		public:

			DiskFileStatsFifo(MemberSet&, unsigned max_limit = 1);
			virtual ~DiskFileStatsFifo() {};
		
		protected:
		
			virtual unsigned ConcurrentJobLimit() const { return 1; }	
			void SetParams(unsigned max_limit) { SetMaxLimit(max_limit); }

		friend class GlobalFileIoMgr;	
	};

	class DiskFileStatsGeneral : public DiskFileStatsMgr
	{
		public:

			DiskFileStatsGeneral(MemberSet&, unsigned concurrent_limit = 1, unsigned max_limit = 1);
			virtual ~DiskFileStatsGeneral() {};
			
		protected:

			virtual unsigned ConcurrentJobLimit() const { return m_concurrent_limit; }		
			void SetParams(unsigned concurrent_limit, unsigned max_limit) 
			{ m_concurrent_limit = concurrent_limit; SetMaxLimit(max_limit); }	
		
		protected:

			unsigned m_concurrent_limit;	
		
		friend class GlobalFileIoMgr;	
	};

}

#endif
