#include "dir_list_base.h"
#include "file_stats_base.h"

namespace colib
{
	DirListBase::DirListBase()
		: DirIoBase()
		, m_requester_cb()  
	{
	}

	DirListBase::DirListBase(string dir_name, const Callback1<const DirListBase&>& requester_cb, void* context)
		: DirIoBase(dir_name, context)
		, m_requester_cb(requester_cb)  
	{
	}

	string DirListBase::Print() const
	{
		return DirIoBase::Print() + string::Format(
											"FileCount: %u\n"
											"Callback is %sset\n",
											GetFilesCount(),
											m_requester_cb.IsSet() ? "" : "not ");
	}

}
