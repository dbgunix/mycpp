#include "file_io_base.h"

namespace colib
{
	FileIoBase::FileIoBase()
		: IoBase()
		, m_file_name()
		, m_file_size(-1)
	{
	}

	FileIoBase::FileIoBase(string file_name, void* context)
		: IoBase(context)
		, m_file_name(file_name)
		, m_file_size(-1)
	{
	}

	const char* FileIoBase::GetTypeStr() const
	{
		switch ( GetType() ) 
		{
			case READ: return "READ";
			case WRITE: return "WRITE";
			case STATS: return "STATS";
			case DELETE: return "DELETE";
			case RENAME: return "RENAME";			 
			default: return "UNKNOWN";			 
		}
	}

	string FileIoBase::PrintFile() const
	{	
		return string::Format(
					"Filename: %s\n"
					"Filesize: %d\n",
					GetFileName().c_str(),
					GetFileSize());
	}

	string FileIoBase::Print() const
	{
		string type = string::Format("IoType: %s\n", GetTypeStr());
		return PrintFile() + type + IoBase::Print();
	}

}
