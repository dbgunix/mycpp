#include "async_file_rename.h"
#include "file_io_utils.h"
#include <event_loop/event_loop.h>

namespace colib
{
	DiskFileRename::DiskFileRename()
		: FileRenameBase()
		, m_act(callbackRt(this, &DiskFileRename::DoTask), "TaskAct")
	{
	}

	DiskFileRename::~DiskFileRename()
	{
		Stop();
	}

	string DiskFileRename::Print() const
	{
		return FileRenameBase::Print() + string::Format(
													"Task activity is %sactive\n", 
													m_act.IsActive() ? "" : "not ");
	}

	void DiskFileRename::Init(
							string file_name, 
							string target_name,
							const Callback1<const FileRenameBase&>& requester_cb, 
							void* context)
	{
		Reset();
		SetFileName(file_name);
		SetTargetName(target_name);
		SetCallback(requester_cb);
		SetContext(context);
	}
	
	bool DiskFileRename::Start()
	{	
		//
		// Add activity
		//
		bool ret = EventLoop::GetInstance().AddActivity(&m_act);
		if ( ret ) SetStatus(IoBase::IN_PROGRESS);
		return ret;
	}

	void DiskFileRename::Stop()
	{
		EventLoop::GetInstance().DeleteActivity(&m_act);
	}

	bool DiskFileRename::Rename(string& err, int& error_code)
	{	
	   	return DiskFile::RenameFile(GetFileName(), GetTargetName(), err, error_code);
	}
	
	eCallbackRt DiskFileRename::DoTask()
	{
		string err;
		int error_code;

		if ( !Rename(err, error_code) )
		{
			SetError(err);
			SetErrorCode(error_code);
			SetStatus(IoBase::FAILED);
		}
		else
		{
			SetError("Task complete");
			SetStatus(IoBase::SUCCEEDED);
		}
		
		RenameComplete();
		return DontRunAgain;
	}

	DiskFileRenameSA::DiskFileRenameSA()
		: DiskFileRename()
		, m_job(*this)
	{
	}
	
	bool DiskFileRenameSA::RenameFile(
								string file_name, 
								string target_name,
								const Callback1<const FileRenameBase&>& requester_cb, 
								void* context)
	{
		Init(file_name, target_name, requester_cb, context);
		return m_job.Start();
	}
	
	void DiskFileRenameSA::RenameComplete()
	{
		m_job.Complete();
	}
		
	string DiskFileRenameSA::Print() const
	{
		return DiskFileRename::Print() + "Job type: SA\n";
	}
	
	DiskFileRenameMgd::DiskFileRenameMgd(unsigned job_id, IoJobMgrGlobal& job_mgr)
		: DiskFileRename()
		, m_job_id(job_id)
		, m_job_mgr(job_mgr)
	{
	}
	
	string DiskFileRenameMgd::Print() const
	{
		return DiskFileRename::Print() + "Job type: Mgd\n";
	}

	DiskFileRenameMgr::DiskFileRenameMgr(MemberSet& trace_set, unsigned max_limit)
		: IoJobMgrGlobal(trace_set)
	 	, m_max_limit(max_limit)
	{
	}

	bool DiskFileRenameMgr::RenameFile(
								string file_name, 
								string target_name,
								const Callback1<const FileRenameBase&>& requester_cb, 
								void* context)
	{
		DiskFileRenameMgd* job = static_cast<DiskFileRenameMgd*>(AddJob(/*type(ignored)*/0));
		if ( !job ) return false;
		job->Init(file_name, target_name, requester_cb, context);
		return true;
	}

	IoBase* DiskFileRenameMgr::CreateIo(unsigned/*type(ignored)*/, unsigned job_id, IoJobMgrGlobal& mgr)
	{
		return new DiskFileRenameMgd(job_id, mgr);
	}

	DiskFileRenameFifo::DiskFileRenameFifo(MemberSet& trace_set, unsigned max_limit)
		: DiskFileRenameMgr(trace_set, max_limit)
	{
	}

	DiskFileRenameGeneral::DiskFileRenameGeneral(MemberSet& trace_set, unsigned concurrent_limit, unsigned max_limit)
		: DiskFileRenameMgr(trace_set, max_limit)
		, m_concurrent_limit(concurrent_limit)
	{
	}

}

