#if !defined(__IDIRECT_FILE_COPY_BASE_H__)
#define __IDIRECT_FILE_COPY_BASE_H__

#include "file_io_base.h"
#include <utils/callback.h>

namespace colib
{
	class FileCopyBase : public FileIoBase
	{
		public:
			
			virtual ~FileCopyBase() {};

			virtual IoType GetType() const { return COPY; }
			virtual string Print() const;

			string GetTargetName() const { return m_target_name; }

			FileCopyBase(const FileCopyBase&) = delete;
			FileCopyBase& operator=(const FileCopyBase&) = delete;

		protected:
			
			FileCopyBase();
			FileCopyBase(string file_name, string target_name, const Callback1<const FileCopyBase&>& requester_cb, void* context);

			void SetTargetName(string target_name) { m_target_name = target_name; }
			void SetCallback(const Callback1<const FileCopyBase&>& requester_cb) { m_requester_cb = requester_cb; }

			virtual void Reset();

			void DispatchCB() { m_requester_cb.Dispatch(*this); }

		protected:
		
			string m_target_name;
			Callback1<const FileCopyBase&> m_requester_cb;
	};
	
	inline void FileCopyBase::Reset()
	{
		FileIoBase::Reset();
		m_target_name.clear();
		m_requester_cb.Clear();
	}

}

#endif
