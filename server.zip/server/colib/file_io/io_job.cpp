#include "io_job.h"
#include <event_loop/event_loop.h>
#include <utils/trace/trace.h>

#include <string.h>

namespace colib
{	
	IoJobBase::IoJobBase(IoBase& io)
		: m_io(io)
	{
	}

	string IoJobBase::Print() const
	{
		return m_io.Print();
	}
	
   	IoJobMgd::IoJobMgd(IoBase& io, unsigned job_id)
		: IoJobBase(io)
	  	, m_job_id(job_id)
	{
	}
	 
	string IoJobMgd::Print() const
	{
		return IoJobBase::Print() + string::Format("JobID: %u\n", m_job_id);
	}

	IoJobMgr::IoJobMgr()
		: m_next_job_act(callbackRt(this, &IoJobMgr::NextJob), "IoJobMgr::NextJobAct")
	{
	}

	IoJobMgr::~IoJobMgr()
	{
		StopNextJobActivity();
	}

	bool IoJobMgr::StartNextJobActivity()
	{
		return EventLoop::GetInstance().AddActivity(&m_next_job_act);
	}
	
	void IoJobMgr::StopNextJobActivity()
	{
		EventLoop::GetInstance().DeleteActivity(&m_next_job_act);
	}

	IoJobMgrSA::IoJobMgrSA(IoBase& io)
		: IoJobMgr()
		, m_job(io)
	{
	}

	bool IoJobMgrSA::Start()
	{
		return StartNextJobActivity();
	}

	void IoJobMgrSA::Stop()
	{
		m_job.Stop();
		StopNextJobActivity();
	}
	
	void IoJobMgrSA::Complete()
	{
		m_job.Complete();
	}

	eCallbackRt IoJobMgrSA::StartNextJob()
	{
		m_job.Start();
		return DontRunAgain;
	}

	static ValueList::ValueHolder   InitStats()
	{
		return
		{
			Value("num_reject", 0),
			Value("num_create_io_fail", 0),
			Value("num_start_succeed", 0),
			Value("num_start_fail", 0),
			Value("num_complete", 0),
			Value("num_cleanup", 0),
			Value("job_done_active", 0),
			Value("job_done_waiting", 0),
			Value("job_done_invalid", 0)
		};
	};

	IoJobMgrGlobal::IoJobMgrGlobal(MemberSet& trace_set)
		: IoJobMgr()
		, m_next_job_id(1)
		, m_io_jobs_active()
		, m_io_jobs_waiting()
		, m_io_jobs_to_remove()
		, m_io_created()
		, m_job_cleanup_act(callbackRt(this, &IoJobMgrGlobal::JobCleanup), "IoJobMgrGlobal::JobCleanup")  
		, m_trace_set(trace_set)  
		, m_stats(InitStats())
	{
	}

	IoJobMgrGlobal::~IoJobMgrGlobal()
	{
		for ( std::map<unsigned, IoJobMgd*>::iterator it = m_io_jobs_active.begin();
				it != m_io_jobs_active.end(); ++it )
		{
			delete it->second;
		}
		m_io_jobs_active.clear();
		
		for ( std::list<IoJobMgd*>::iterator it = m_io_jobs_waiting.begin();
				it != m_io_jobs_waiting.end(); ++it )
		{
			delete *it;
		}
		m_io_jobs_waiting.clear();

		for ( std::map<unsigned, IoBase*>::iterator it = m_io_created.begin();
				it != m_io_created.end(); ++it )
		{
			DestroyIo(it->second);
		}
		m_io_created.clear();
		
		EventLoop::GetInstance().DeleteActivity(&m_job_cleanup_act);
	}

	IoBase* IoJobMgrGlobal::AddJob(unsigned type)
	{
		member_TRACE(&m_trace_set, 7, "AddJob (type = %u)\n", type);
		if ( ( m_io_jobs_active.size() + m_io_jobs_waiting.size() ) >= MaximumJobLimit() ) 
		{
			++IOJOBMGRGLOBAL_STAT(num_reject);
			member_TRACE(&m_trace_set, 7, "AddJob fail - active (%u) plus waiting (%u) exceed max limit (%u)\n",
					(unsigned)m_io_jobs_active.size(), (unsigned)m_io_jobs_waiting.size(), MaximumJobLimit());
			return 0;
		}
		//
		// Create IO
		//
		unsigned job_id = m_next_job_id++;
		IoBase* io = CreateIo(type, job_id, *this);
		if ( !io ) 
		{	
			++IOJOBMGRGLOBAL_STAT(num_create_io_fail);
			member_TRACE(&m_trace_set, 7, "AddJob fail - create IO failed\n");
			return 0;
		}
		m_io_created[job_id] = io;
		//
		// Create JobMgd
		//
		IoJobMgd* job = new IoJobMgd(*io, job_id);
		m_io_jobs_waiting.push_back(job);
		member_TRACE(&m_trace_set, 7, "Insert Job to waiting queue\n");	
		//
		StartNextJobActivity();
		member_TRACE(&m_trace_set, 7, "Start activity to create next job\n");
		//
		return io;
	}

	eCallbackRt IoJobMgrGlobal::StartNextJob()
	{
		if ( m_io_jobs_waiting.empty() ) return DontRunAgain;
		if ( m_io_jobs_active.size() >= ConcurrentJobLimit() ) return DontRunAgain;
		//
		// Iterate jobs in waiting list, whoever succeed to start moved to active
		//
		std::list<IoJobMgd*>::iterator it = m_io_jobs_waiting.begin();
		while ( it != m_io_jobs_waiting.end() )
		{
			IoJobMgd* job = *it;
			if ( !job->Start() ) 
			{
				++IOJOBMGRGLOBAL_STAT(num_start_fail);
				++it;
				continue;	// fail to start current, move to next
			}
			++IOJOBMGRGLOBAL_STAT(num_start_succeed);
			member_TRACE(&m_trace_set, 7, "Job task start\n%s\n", job->Print().c_str());
			unsigned job_id = job->GetJobID();
			m_io_jobs_active[job_id] = job;
			m_io_jobs_waiting.erase(it);
			return RunAgain;
		}
		// no one starts successfully, no need to run again
		return DontRunAgain;
	}

	void IoJobMgrGlobal::JobDone(unsigned job_id)
	{
		member_TRACE(&m_trace_set, 7, "JobDone - %u\n", job_id);
	
		IoJobMgd* job = 0;

		std::map<unsigned, IoJobMgd*>::iterator it = m_io_jobs_active.find(job_id);
		if ( it != m_io_jobs_active.end() )
		{
			job = it->second;
   			++IOJOBMGRGLOBAL_STAT(job_done_active);
		}
		else
		{	
			for ( std::list<IoJobMgd*>::iterator iter = m_io_jobs_waiting.begin(); 
					iter != m_io_jobs_waiting.end(); ++iter )
			{
				if ( (*iter)->GetJobID() == job_id )
				{
					job = *iter;
   					++IOJOBMGRGLOBAL_STAT(job_done_waiting);
					break;
				}
			}
		}

		if ( !job ) 
		{
   			++IOJOBMGRGLOBAL_STAT(job_done_invalid);
			return;
		}

		job->Complete();
		++IOJOBMGRGLOBAL_STAT(num_complete);
		//
		m_io_jobs_to_remove.push_back(job_id);
		member_TRACE(&m_trace_set, 7, "JobID (%u) insert to remove list\n", job_id);	
		//
		EventLoop::GetInstance().AddActivity(&m_job_cleanup_act);
		member_TRACE(&m_trace_set, 7, "Start activity to cleanup job\n");
	}
	
	void IoJobMgrGlobal::DelJob(unsigned job_id)
	{
		IoJobMgd* job = 0;

		if ( !job )
		{
			std::map<unsigned, IoJobMgd*>::iterator it = m_io_jobs_active.find(job_id);
			if ( it != m_io_jobs_active.end() ) job = it->second;
			m_io_jobs_active.erase(job_id);
		}
		
		if ( !job )
		{	
			for ( std::list<IoJobMgd*>::iterator it = m_io_jobs_waiting.begin(); 
					it != m_io_jobs_waiting.end(); ++it )
			{
				if ( (*it)->GetJobID() == job_id )
				{
					job = *it;
					break;
				}
			}

			if ( job ) m_io_jobs_waiting.remove(job);
		}
		
		if ( job ) delete job;

		std::map<unsigned, IoBase*>::iterator it = m_io_created.find(job_id);
		if ( it != m_io_created.end() ) DestroyIo(it->second);
		m_io_created.erase(job_id);
	}

	eCallbackRt IoJobMgrGlobal::JobCleanup()
	{
		for ( std::list<unsigned>::iterator it = m_io_jobs_to_remove.begin();
				it != m_io_jobs_to_remove.end(); ++it )
		{
			unsigned job_id = *it;
			member_TRACE(&m_trace_set, 7, "Remove JobID (%u) from active\n", job_id);
			DelJob(job_id);
		}
		IOJOBMGRGLOBAL_STAT(num_cleanup) += m_io_jobs_to_remove.size();
		m_io_jobs_to_remove.clear();
		//
		StartNextJobActivity();
		member_TRACE(&m_trace_set, 7, "Start activity to create next job\n");
		//
		return DontRunAgain;
	}

	string IoJobMgrGlobal::ConsoleHelp() const
	{
		return "stats|status [detail]";
	}

	void IoJobMgrGlobal::ConsoleCommand(Writable* con, int argc, char* argv[])
	{
		string usage = "Usage:\t" + ConsoleHelp();

		if ( argc == 0 )
		{
			con->PrintString(usage.c_str());
			return;
		}

		if ( !strcmp(argv[0], "stats") )
		{
			m_stats.ConsoleCommand(con, argc-1, argv+1);
		}
		else if ( !strcmp(argv[0], "status") )
		{
			con->Print(
					"Concurrent Limit: %u\n"
					"Maximum Limit: %u\n"
					"Next JobID: %u\n"
					"Job active: %u\n"
					"Job waiting: %u\n"
					"Job to remove: %u\n"
					"IO created: %u\n"
					"Job creation activity is %sactive\n"
					"Job cleanup activity is %sactive\n",
					ConcurrentJobLimit(),
					MaximumJobLimit(),
					m_next_job_id,
					m_io_jobs_active.size(),
					m_io_jobs_waiting.size(),
					m_io_jobs_to_remove.size(),
					m_io_created.size(),
					m_next_job_act.IsActive() ? "" : "not ",
					m_job_cleanup_act.IsActive() ? "" : "not ");

			if ( ( argc > 1 ) && !strcmp(argv[1], "detail") )
			{
				if ( !m_io_jobs_active.empty() )
				{
					con->Print("Job(s) active:\n");
					for ( std::map<unsigned, IoJobMgd*>::iterator it = m_io_jobs_active.begin();
							it != m_io_jobs_active.end(); ++it )
					{
						con->Print("%s\n", it->second->Print().c_str());
					}
				}

				if ( !m_io_jobs_waiting.empty() )
				{
					con->Print("Job(s) waiting:\n");
					for ( std::list<IoJobMgd*>::iterator it = m_io_jobs_waiting.begin();
							it != m_io_jobs_waiting.end(); ++it )
					{
						con->Print("%s\n", (*it)->Print().c_str());
					}
				}

				if ( !m_io_jobs_to_remove.empty() )
				{
					con->Print("JobID(s) to remove: ");
					for ( std::list<unsigned>::iterator it = m_io_jobs_to_remove.begin();
							it != m_io_jobs_to_remove.end(); ++it )
					{
						con->Print("%u ", *it);
					}
					con->Print("\n");
				}
			}
		}
		else con->PrintString(usage);
	}

}
