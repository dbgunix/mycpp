// file_loader.h
// vi:set ts=4 sw=4 nowrap:

#ifndef FILE_LOADER_H_ALREADY_INCLUDED
#define FILE_LOADER_H_ALREADY_INCLUDED

#include "large_file_io.h"
#include <timer/periodic_timer.h>
#include <config/value.h>
#include <console/session.h>

namespace colib
{
	//
	// FileLoaderMgr serves as watchdog to automatically load file content if modified
	//
	class FileLoaderMgr
	{
		public:
			
			enum Stats
			{
				Stat_num_load_succeed,
				Stat_num_load_skip,
				Stat_num_load_fail,
				Stat_fail_reason,
			};

			FileLoaderMgr(FileIoMgr& mgr = GlobalFileIoMgr::GetInstance());
			virtual ~FileLoaderMgr();
			
			void SetFileIOMgr(FileIoMgr& file_io_mgr) { m_file_io_mgr = &file_io_mgr; }

			bool Init(
					string& err,
					string filename, 
					const Callback2<char*, int>& cbk, // Callback when file content is loaded
					int freq_sec = 1); // How often to check file state, default to one second
	
			void ConsoleCommand(ConsoleSession* con, int argc, char* argv[]);

		private:

			void AutoLoad(unsigned, void*);
			void CheckFile(const FileStatsBase&);			
			void ReadSucceed(char*, int, void*);
			void ReadFailed(string, void*);

		private:
			
			FileIoMgr* m_file_io_mgr;
			PeriodicTimer m_auto_load_timer;
			LargeFileIO m_file_reader;
			int64_t m_file_mtime;
			bool m_file_stat_in_progress;
			string m_filename;
			Callback2<char*, int> m_on_load;
			int m_freq_sec;
			ValueList m_stats;
	};
	#define LOADER_STAT(stat) m_stats[FileLoaderMgr::Stat_##stat].AsInt()

}//end namespace iDirect

#endif

