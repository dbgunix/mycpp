#if !defined(__IDIRECT_ASYNC_FILE_DELETE_H__)
#define __IDIRECT_ASYNC_FILE_DELETE_H__

#include "file_delete_base.h"
#include "io_job.h"
#include <event_loop/activity_hld.h>

namespace colib
{
	class GlobalFileIoMgr;
	class DiskFileDeleteMgr;

	class DiskFileDelete : public FileDeleteBase
	{
		public:
			
			virtual ~DiskFileDelete();

			virtual string Print() const;
			
			DiskFileDelete(const DiskFileDelete&) = delete;
			DiskFileDelete& operator=(const DiskFileDelete&) = delete;

		protected:
		
			DiskFileDelete();

			virtual bool Start();
			virtual void Stop();
			virtual void Complete() { DispatchCB(); }

			void Init(
					string file_name, 
					const Callback1<const FileDeleteBase&>& requester_cb, 
					void* context);

			bool Delete(string&, int& error_code);
			eCallbackRt DoTask();
			
			virtual void DeleteComplete() = 0; 	

		protected:
			
			ActivityHold m_act;

		friend class DiskFileDeleteMgr;
	};

	class DiskFileDeleteSA : public DiskFileDelete
	{
		public:

			DiskFileDeleteSA();
			virtual ~DiskFileDeleteSA() {};
			//
			bool DeleteFile(
					string file_name, 
					const Callback1<const FileDeleteBase&>& requester_cb, 
					void* context);
			//
			// Stop
			//
			void StopTask() { m_job.Stop(); }
	
			virtual string Print() const;

			DiskFileDeleteSA(const DiskFileDeleteSA&) = delete;
			DiskFileDeleteSA& operator=(const DiskFileDeleteSA&) = delete;

		protected:

			virtual void DeleteComplete(); 	

		protected:

			IoJobMgrSA m_job;
	};	

	class DiskFileDeleteMgd : public DiskFileDelete
	{
		public:

			virtual ~DiskFileDeleteMgd() {};

			virtual string Print() const;

		protected:

			DiskFileDeleteMgd(unsigned job_id, IoJobMgrGlobal&);
		
			virtual void Stop() {}; // Not allowed to stop by itself
			virtual void DeleteComplete() { m_job_mgr.JobDone(m_job_id); }

		protected:

			unsigned m_job_id;
			IoJobMgrGlobal& m_job_mgr;

		friend class DiskFileDeleteMgr;
	};

	class DiskFileDeleteMgr : public IoJobMgrGlobal
	{
		public:

			virtual ~DiskFileDeleteMgr() {};	
			//
			bool DeleteFile(
					string file_name, 
					const Callback1<const FileDeleteBase&>& requester_cb, 
					void* context);

		protected:
			
			DiskFileDeleteMgr(MemberSet& trace_set, unsigned max_limit);
			void SetMaxLimit(unsigned max_limit) { m_max_limit = max_limit; }

			virtual IoBase* CreateIo(unsigned/*type(ignored)*/, unsigned job_id, IoJobMgrGlobal& mgr);
			virtual unsigned MaximumJobLimit() const { return m_max_limit; }

		protected:

			unsigned m_max_limit;
	};

	class DiskFileDeleteFifo : public DiskFileDeleteMgr
	{
		public:

			DiskFileDeleteFifo(MemberSet&, unsigned max_limit = 1);
			virtual ~DiskFileDeleteFifo() {};

		protected:
		
			virtual unsigned ConcurrentJobLimit() const { return 1; }	
			void SetParams(unsigned max_limit) { SetMaxLimit(max_limit); }

		friend class GlobalFileIoMgr;
	};

	class DiskFileDeleteGeneral : public DiskFileDeleteMgr
	{
		public:

			DiskFileDeleteGeneral(MemberSet&, unsigned concurrent_limit = 1, unsigned max_limit = 1);
			virtual ~DiskFileDeleteGeneral() {};

		protected:

			virtual unsigned ConcurrentJobLimit() const { return m_concurrent_limit; }		
			void SetParams(unsigned concurrent_limit, unsigned max_limit) 
			{ m_concurrent_limit = concurrent_limit; SetMaxLimit(max_limit); }	
		
		protected:

			unsigned m_concurrent_limit;	

		friend class GlobalFileIoMgr;
	};

}

#endif
