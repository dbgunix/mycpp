#if !defined(__IDIRECT_ASYNC_FILE_COPY_H__)
#define __IDIRECT_ASYNC_FILE_COPY_H__

#include "file_copy_base.h"
#include "io_job.h"
#include <event_loop/activity_hld.h>

namespace colib
{
	class GlobalFileIoMgr;
	class DiskFileCopyMgr;

	class DiskFileCopy : public FileCopyBase
	{
		public:

			virtual ~DiskFileCopy();

			virtual string Print() const;
			
			DiskFileCopy(const DiskFileCopy&) = delete;
			DiskFileCopy& operator=(const DiskFileCopy&) = delete;

		protected:
		
			DiskFileCopy();

			virtual bool Start();
			virtual void Stop();
			virtual void Complete() { DispatchCB(); }

			void Init(
					string file_name, 
					string target_name,
					const Callback1<const FileCopyBase&>& requester_cb, 
					void* context);

			bool Copy(string&, int& error_code);
			eCallbackRt DoTask();
			
			virtual void CopyComplete() = 0; 	

		protected:
			
			ActivityHold m_act;

		friend class DiskFileCopyMgr;
	};

	class DiskFileCopySA : public DiskFileCopy
	{
		public:

			DiskFileCopySA();
			virtual ~DiskFileCopySA() {};
			//
			bool CopyFile(
					string file_name, 
					string target_name,
					const Callback1<const FileCopyBase&>& requester_cb, 
					void* context);
			//
			// Stop
			//
			void StopTask() { m_job.Stop(); }
	
			virtual string Print() const;

			DiskFileCopySA(const DiskFileCopySA&) = delete;
			DiskFileCopySA& operator=(const DiskFileCopySA&) = delete;

		protected:

			virtual void CopyComplete(); 	

		protected:

			IoJobMgrSA m_job;
	};	

	class DiskFileCopyMgd : public DiskFileCopy
	{
		public:

			virtual ~DiskFileCopyMgd() {};

			virtual string Print() const;

		protected:

			DiskFileCopyMgd(unsigned job_id, IoJobMgrGlobal&);
		
			virtual void Stop() {}; // Not allowed to stop by itself
			virtual void CopyComplete() { m_job_mgr.JobDone(m_job_id); }

		protected:

			unsigned m_job_id;
			IoJobMgrGlobal& m_job_mgr;

		friend class DiskFileCopyMgr;
	};

	class DiskFileCopyMgr : public IoJobMgrGlobal
	{
		public:

			virtual ~DiskFileCopyMgr() {};	
			//
			bool CopyFile(
					string file_name, 
					string target_name,
					const Callback1<const FileCopyBase&>& requester_cb, 
					void* context);

		protected:
			
			DiskFileCopyMgr(MemberSet& trace_set, unsigned max_limit);
			void SetMaxLimit(unsigned max_limit) { m_max_limit = max_limit; }

			virtual IoBase* CreateIo(unsigned/*type(ignored)*/, unsigned job_id, IoJobMgrGlobal& mgr);
			virtual unsigned MaximumJobLimit() const { return m_max_limit; }

		protected:

			unsigned m_max_limit;
	};

	class DiskFileCopyFifo : public DiskFileCopyMgr
	{
		public:

			DiskFileCopyFifo(MemberSet&, unsigned max_limit = 1);
			virtual ~DiskFileCopyFifo() {};
		
		protected:
		
			virtual unsigned ConcurrentJobLimit() const { return 1; }	
			void SetParams(unsigned max_limit) { SetMaxLimit(max_limit); }

		friend class GlobalFileIoMgr;
	};

	class DiskFileCopyGeneral : public DiskFileCopyMgr
	{
		public:

			DiskFileCopyGeneral(MemberSet&, unsigned concurrent_limit = 1, unsigned max_limit = 1);
			virtual ~DiskFileCopyGeneral() {};
		
		protected:

			virtual unsigned ConcurrentJobLimit() const { return m_concurrent_limit; }		
			void SetParams(unsigned concurrent_limit, unsigned max_limit) 
			{ m_concurrent_limit = concurrent_limit; SetMaxLimit(max_limit); }	
		
		protected:

			unsigned m_concurrent_limit;	

		friend class GlobalFileIoMgr;
	};

}

#endif
