#if !defined(__IDIRECT_ASYNC_FILE_RENAME_H__)
#define __IDIRECT_ASYNC_FILE_RENAME_H__

#include "file_rename_base.h"
#include "io_job.h"
#include <event_loop/activity_hld.h>

namespace colib
{
	class GlobalFileIoMgr;
	class DiskFileRenameMgr;

	class DiskFileRename : public FileRenameBase
	{
		public:

			virtual ~DiskFileRename();

			virtual string Print() const;
			
			DiskFileRename(const DiskFileRename&) = delete;
			DiskFileRename& operator=(const DiskFileRename&) = delete;

		protected:
		
			DiskFileRename();

			virtual bool Start();
			virtual void Stop();
			virtual void Complete() { DispatchCB(); }

			void Init(
					string file_name, 
					string target_name,
					const Callback1<const FileRenameBase&>& requester_cb, 
					void* context);

			bool Rename(string&, int& error_code);
			eCallbackRt DoTask();
			
			virtual void RenameComplete() = 0; 	

		protected:
			
			ActivityHold m_act;

		friend class DiskFileRenameMgr;
	};

	class DiskFileRenameSA : public DiskFileRename
	{
		public:

			DiskFileRenameSA();
			virtual ~DiskFileRenameSA() {};
			//
			bool RenameFile(
					string file_name, 
					string target_name,
					const Callback1<const FileRenameBase&>& requester_cb, 
					void* context);
			//
			// Stop
			//
			void StopTask() { m_job.Stop(); }
	
			virtual string Print() const;

			DiskFileRenameSA(const DiskFileRenameSA&) = delete;
			DiskFileRenameSA& operator=(const DiskFileRenameSA&) = delete;

		protected:

			virtual void RenameComplete(); 	

		protected:

			IoJobMgrSA m_job;
	};	

	class DiskFileRenameMgd : public DiskFileRename
	{
		public:

			virtual ~DiskFileRenameMgd() {};

			virtual string Print() const;

		protected:

			DiskFileRenameMgd(unsigned job_id, IoJobMgrGlobal&);
		
			virtual void Stop() {}; // Not allowed to stop by itself
			virtual void RenameComplete() { m_job_mgr.JobDone(m_job_id); }

		protected:

			unsigned m_job_id;
			IoJobMgrGlobal& m_job_mgr;

		friend class DiskFileRenameMgr;
	};

	class DiskFileRenameMgr : public IoJobMgrGlobal
	{
		public:

			virtual ~DiskFileRenameMgr() {};	
			//
			bool RenameFile(
					string file_name, 
					string target_name,
					const Callback1<const FileRenameBase&>& requester_cb, 
					void* context);

		protected:
			
			DiskFileRenameMgr(MemberSet& trace_set, unsigned max_limit);
			void SetMaxLimit(unsigned max_limit) { m_max_limit = max_limit; }

			virtual IoBase* CreateIo(unsigned/*type(ignored)*/, unsigned job_id, IoJobMgrGlobal& mgr);
			virtual unsigned MaximumJobLimit() const { return m_max_limit; }

		protected:

			unsigned m_max_limit;
	};

	class DiskFileRenameFifo : public DiskFileRenameMgr
	{
		public:

			DiskFileRenameFifo(MemberSet&, unsigned max_limit = 1);
			virtual ~DiskFileRenameFifo() {};
		
		protected:
		
			virtual unsigned ConcurrentJobLimit() const { return 1; }	
			void SetParams(unsigned max_limit) { SetMaxLimit(max_limit); }

		friend class GlobalFileIoMgr;
	};

	class DiskFileRenameGeneral : public DiskFileRenameMgr
	{
		public:

			DiskFileRenameGeneral(MemberSet&, unsigned concurrent_limit = 1, unsigned max_limit = 1);
			virtual ~DiskFileRenameGeneral() {};
		
		protected:

			virtual unsigned ConcurrentJobLimit() const { return m_concurrent_limit; }		
			void SetParams(unsigned concurrent_limit, unsigned max_limit) 
			{ m_concurrent_limit = concurrent_limit; SetMaxLimit(max_limit); }	
		
		protected:

			unsigned m_concurrent_limit;	

		friend class GlobalFileIoMgr;
	};

}

#endif
