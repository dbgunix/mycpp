#if !defined(__IDIRECT_DIR_LIST_BASE_H__)
#define __IDIRECT_DIR_LIST_BASE_H__

#include "dir_io_base.h"
#include "file_stats_base.h"
#include <utils/callback.h>

#include <vector>

namespace colib
{
	class DirListBase : public DirIoBase
	{
		public:

			virtual ~DirListBase() {};

			virtual IoType GetType() const { return LIST; }
			virtual string Print() const;
			
			virtual unsigned GetFilesCount() const = 0;
			virtual FileStatsBase* GetFile(unsigned idx) = 0;
			virtual const FileStatsBase* GetFile(unsigned idx) const = 0;
		
			DirListBase(const DirListBase&) = delete;
			DirListBase& operator=(const DirListBase&) = delete;

		protected:
		
			DirListBase();
			DirListBase(string dir_name, const Callback1<const DirListBase&>& requester_cb, void* context);

			void SetCallback(const Callback1<const DirListBase&>& requester_cb) { m_requester_cb = requester_cb; }
			
			virtual void Reset();

			void DispatchCB() { m_requester_cb.Dispatch(*this); }
	
			Callback1<const DirListBase&> m_requester_cb;
	};
	
	inline void DirListBase::Reset() 
	{ 
		DirIoBase::Reset(); 
		m_requester_cb.Clear(); 
	}

}

#endif
