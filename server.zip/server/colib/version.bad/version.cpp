//version.cpp

#include <version/version.h>

namespace colib
{

#if defined( __GNUC__)
__attribute__((weak)) const char *GetApplicationName()
{
	return "XXUnnamedApplicationXX";
}
#endif

}
