#if !defined(__VERSION_APP_NAME_H__)
#define __VERSION_APP_NAME_H__

// NOTE: this file/function is deprecated and will be removed.

namespace iDirect
{

const char *GetApplicationName();

}

#endif

