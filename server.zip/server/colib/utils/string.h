#ifndef colib_string_h_included
#define colib_string_h_included

#include <stdarg.h>

namespace colib
{

class string
{
public:
	string() : m_buf(0) { }
	string(const string &of);
	string(const char *of,bool separate_buffer=true);
	string(const char *of,unsigned len);//this constructor makes a copy of 'of'
	explicit string(unsigned max);
	~string();
	//
	string& operator=(const string &to);
	string& operator+=(const char *add);
	string& operator+=(char add);
	operator const char*()const;
	const char* c_str()const;
	//
	char* get_buffer() { return internal_get_buffer(true); }
	unsigned get_length()const;

	unsigned get_maxlength()const;
	bool set_maxlength(unsigned maxlength);
	char* detach();
	bool attach(char *newbuf,unsigned bufsize);
	bool attach_cnt(char *newbuf);
	//
	void truncate(unsigned max_length);
	void truncate_tail();
	//
	static string combine(const char *a,...);
	static string catenate(const char*a,const char*b);
	bool find(const string &b) const;
	int find_first_not_of(const char* other);
   	colib::string find_first_not_of(const string &b);

	//
	bool is_empty()const;
	void empty();
	void clear();
	void reset();
	//
	static bool oper_eq(const char*a,const char*b);
	static bool oper_gt(const char*a,const char*b);
	static bool oper_lt(const char*a,const char*b);
	static bool oper_find(const char*a,const char*b);

	static int CalcFormatLimit( const char *format, va_list args );
	static string vFormat( const char *format, va_list args );

	static string Format( const char *format, ... )
#ifdef __GNUC__
	 __attribute__ ((format (printf, 1, 2)))
#endif
	;

	bool AppendFmt( const char *format, ...)
#ifdef __GNUC__
	 __attribute__ ((format (printf, 2, 3)))
#endif
	;

	bool vAppendFmt( const char *format, va_list args);

	bool separate();

	void ucase();

	// debug use only
	bool GetStatus(void*& bufPos, unsigned& capacity,
					bool& isOwned, bool& isExposed, unsigned& len,
					unsigned& getlen, int& ref) const;
private:
	char* internal_get_buffer(bool exposeData);
	class strbuf
	{
	public:
		strbuf();
		strbuf(const char *of,bool separate);
		strbuf(const char *of,unsigned len);
		strbuf(const strbuf &of);
		strbuf(unsigned max);
		~strbuf();

		unsigned quick_strlen() const;

		bool IsLengthValid() const { return (m_length && m_owns && !m_is_data_exposed);}
		void InvalidateLength() { m_length = 0; }

		char* GetData() { InvalidateLength(); return m_data;}

		// length may but not necessary be invalidated if (c == '\0') != (data[pos] == '\0')
		void SetCharAt(unsigned pos, char c) {
				if ((c == '\0') != (m_data[pos] == '\0')) {
					InvalidateLength();
				}
				m_data[pos] = c;
		}

		const char* const_get_data() const { return m_data; }
		char* TransferData() {
			char * ret = GetData();
			m_data = 0;
			return ret;
		}
		void SetData(char* to) { m_data = to; InvalidateLength(); }
		void SetDataAndLen(char* to, unsigned len) { m_data = to; m_length = len; }

		unsigned GetLength() const { return m_length; }

		// length is mutable so we can delcare SetLength() as const
		void SetLength(unsigned to) const { m_length = to; }

		int GetRefCount() const { return m_refcount; }
		void ResetRefCount() { m_refcount = 0; }
		void IncRefCount() { ++ m_refcount; }
		void DecRefCount() { -- m_refcount; }

		void SetOwner(bool is) { m_owns = is; }
		bool IsOwner() const { return m_owns; }

		bool IsDataExposed() const { return m_is_data_exposed; }
		void SetDataExposed() { m_is_data_exposed = true; }

		unsigned GetMem() const { return m_mem; }
		void SetMem(unsigned m) { m_mem = m; }

		strbuf& operator=(strbuf&) = delete;

	private:
		char *m_data;
		unsigned m_mem;
		bool m_owns;            // ownership of the memory
		bool m_is_data_exposed; // indicate if the string class owns the content of the string.
							  // set true if the data buffer can be modified by pointer outside of
							  // the managment of string class, eg., string::get_buffer() method exposes
                              // the data buffer.
		mutable unsigned m_length;
		int m_refcount;
	} *m_buf;
};

inline string::operator const char*()const
{
	return (m_buf && m_buf->const_get_data()) ? m_buf->const_get_data() : "";
}
inline const char* string::c_str() const
{
	return (m_buf && m_buf->const_get_data()) ? m_buf->const_get_data() : "";
}

inline bool string::find(const string &b) const
{
	return oper_find(*this, b);
}

inline bool string::is_empty()const
{
	return !m_buf || !m_buf->const_get_data() || !*m_buf->const_get_data();
}

inline void string::empty()
{
	clear();
}
inline string::~string()
{
	if(m_buf)
	{
		m_buf->DecRefCount();
		if(m_buf->GetRefCount() == 0)
			delete m_buf;
	}
}
inline string::string(const string &of)
	: m_buf(of.m_buf)
{
	if(m_buf)
		m_buf->IncRefCount();
}
inline string::string(const char *of,bool separate_buffer)
	: m_buf(new strbuf(of,separate_buffer))
{
}
//this constructor makes a copy of 'of'
inline string::string(const char *of,unsigned len)
	: m_buf(new strbuf(of,len))
{
}
inline string::string(unsigned max)
	: m_buf(new strbuf(max+1))
{
}

inline bool operator==(const string &a,const string &b)
{
	return string::oper_eq(a,b);
}
inline bool operator!=(const string &a,const string &b)
{
	return !string::oper_eq(a,b);
}
inline bool operator<(const string &a,const string &b)
{
	return string::oper_lt(a,b);
}
inline bool operator<=(const string &a,const string &b)
{
	return !string::oper_gt(a,b);
}
inline bool operator>(const string &a,const string &b)
{
	return string::oper_gt(a,b);
}
inline bool operator>=(const string &a,const string &b)
{
	return !string::oper_lt(a,b);
}
inline bool operator==(const string &a,const char *b)
{
	return string::oper_eq(a,b);
}
inline bool operator!=(const string &a,const char *b)
{
	return !string::oper_eq(a,b);
}
inline bool operator<(const string &a,const char *b)
{
	return string::oper_lt(a,b);
}
inline bool operator<=(const string &a,const char *b)
{
	return !string::oper_gt(a,b);
}
inline bool operator>(const string &a,const char *b)
{
	return string::oper_gt(a,b);
}
inline bool operator>=(const string &a,const char *b)
{
	return !string::oper_lt(a,b);
}
inline bool operator==(const char *a,const string &b)
{
	return string::oper_eq(a,b);
}
inline bool operator!=(const char *a,const string &b)
{
	return !string::oper_eq(a,b);
}
inline bool operator<(const char *a,const string &b)
{
	return string::oper_lt(a,b);
}
inline bool operator<=(const char *a,const string &b)
{
	return !string::oper_gt(a,b);
}
inline bool operator>(const char *a,const string &b)
{
	return string::oper_gt(a,b);
}
inline bool operator>=(const char *a,const string &b)
{
	return !string::oper_lt(a,b);
}
inline string operator+(const string &a,const string &b)
{
	return string::catenate(a,b);
}
inline string operator+(const char *a,const string &b)
{
	return string::catenate(a,b);
}
inline string operator+(const string &a,const char *b)
{
	return string::catenate(a,b);
}

}

#endif
