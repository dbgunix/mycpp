#ifndef HARDWARE_FEATURE_CAPABILITY_H
#define HARDWARE_FEATURE_CAPABILITY_H

#include<utils/dbenums.h>
#include<utils/string.h>

namespace colib
{

enum FeatureEnable
{
	NotApplicable = -1, 
	AlwaysEnabled,
	LicenseNeeded,
	Licensed
};

//feature names
enum EFeatureName
{
	FEATURE_LINK_ENCRYPTION = 1,
	FEATURE_MOBILITY,
	FEATURE_SPREAD_SPECTRUM,
	FEATURE_TRANSEC,
	FEATURE_M0D1NB_BW_RATE_LIMIT,
	FEATURE_ENCRYPTION,
	FEATURE_SCPC_RETURN,
	FEATURE_MCD_TDMA,
	FEATURE_MCD_SCPC,
	FEATURE_COTM
};

enum EOptionName
{
	FEATURE_ENABLED = 1,
	SPREADSPECTRUM_INBOUND,
	SPREADSPECTRUM_OUTBOUND,
	M0D1NBBWRATELIMIT_RATE,
	TRANSEC_LEGACY,
	TRANSEC_DVBS2,
	NUM_MCD_CHANNELS,
	MAX_COMPOSITE_SYMRATE, 
	MAX_SYMRATE_PER_CARRIER,
	MAX_VELOCITY 
};

ENUM_TBL(EFeatureName) =
{
	{FEATURE_LINK_ENCRYPTION, 		"Link Encryption"},
	{FEATURE_MOBILITY,				"Mobility"},
	{FEATURE_SPREAD_SPECTRUM,		"Spread Spectrum"},
	{FEATURE_TRANSEC,				"Transec"},
	{FEATURE_M0D1NB_BW_RATE_LIMIT,	"Bandwidth Rate Limit"},
	{FEATURE_ENCRYPTION,			"Encryption"},
	{FEATURE_SCPC_RETURN,			"SCPC return"},
	{FEATURE_MCD_SCPC,				"MCD SCPC"},
	{FEATURE_MCD_TDMA,				"MCD TDMA"},
	{FEATURE_COTM,					"COTM"}
};

FMT_ENUM_FUNCS(EFeatureName)

ENUM_TBL(EOptionName) =
{
	{FEATURE_ENABLED,				"enable"},
	{SPREADSPECTRUM_INBOUND,		"inbound"},
	{SPREADSPECTRUM_OUTBOUND,		"outbound"},
	{M0D1NBBWRATELIMIT_RATE,		"rate"},
	{TRANSEC_LEGACY,				"legacy"},
	{TRANSEC_DVBS2,					"dvbs2"},
	{NUM_MCD_CHANNELS,				"num mcd channel"},
	{MAX_COMPOSITE_SYMRATE,			"max composite symrate"},
	{MAX_SYMRATE_PER_CARRIER,		"max symrate per carrier"},
	{MAX_VELOCITY,					"max velocity"}
};

FMT_ENUM_FUNCS(EOptionName)

const colib::string FEATURE_ENABLED_TRUE =		"1";
const colib::string OPTION_UNLIMITED = "unlimited";
const int OPTION_UNLIMITED_VALUE =	-2;

const int FEATURE_M0D1NB_BW_RATE_DEFAULT =			256 * 1000;

const int FEATURE_MCD_SCPC_NUM_CHANNELS_DEFAULT =      1;
const int FEATURE_MCD_SCPC_MAX_COMPOSITE_SYMRATE_DEFAULT = 128 * 1000;
const int FEATURE_MCD_SCPC_MAX_SYMRATE_PER_CARRIER_DEFAULT =128 * 1000;

const int FEATURE_MCD_TDMA_NUM_CHANNELS_DEFAULT =      1;
const int FEATURE_MCD_TDMA_MAX_COMPOSITE_SYMRATE_DEFAULT = 128 * 1000;
const int FEATURE_MCD_TDMA_MAX_SYMRATE_PER_CARRIER_DEFAULT =128 * 1000;

const int FEATURE_COTM_MAX_VELOCITY_DEFAULT = 150; 
// return -1, if N/A
// featureName should be one of the above. for other names, NotApplicable will be returned.
int GetDeviceDefaultCapability(	const EFeatureName feature,
								const EOptionName option, 
								const ENetModemVersionType type );

}

#endif
