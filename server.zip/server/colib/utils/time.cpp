#include <utils/time.h>
#include <utils/xdr.h>
#include <stdio.h>

namespace colib
{

const char* DEFAULT_UTC_FORMAT = "%FT%T%Z";

static int64_t ConvertTimeValToMsec(const timeval& tv)
{
	// ensure 64-bit math
	return static_cast<int64_t>(tv.tv_sec)*1000 + static_cast<int64_t>(tv.tv_usec)/1000;
}

Time::Time()
	: m_tv()
{
}

Time::Time(int32_t msec)
	: m_tv()
{
	m_tv.tv_sec= msec/1000;
	m_tv.tv_usec= (msec%1000)*1000;
	Normalize();
}

Time::Time(int32_t sec, int32_t usec)
	: m_tv()
{
	m_tv.tv_sec=sec;
	m_tv.tv_usec=usec;
	Normalize();
}

Time::Time(const Time &other)
	: m_tv()
{
	m_tv.tv_sec = other.GetSeconds();
	m_tv.tv_usec = other.GetUsec();
	Normalize();
}

Time& Time::operator=(const Time &other)
{
	if (this == &other)
	{
		return *this;
	}
	m_tv.tv_sec = other.GetSeconds();
	m_tv.tv_usec = other.GetUsec();
	return *this;
}

bool Time::XdrProc(CXDR *pXDR)
{
	return pXDR->XdrLong (&m_tv.tv_sec) && pXDR->XdrLong (&m_tv.tv_usec);
}

char* Time::Format(char *buf, int sz) const
{
	snprintf(buf,sz,"%lu.%06lu", m_tv.tv_sec, m_tv.tv_usec/1000 );
	return buf;
}

Time& Time::SetToNow()
{
	gettimeofday(&m_tv, NULL);
	return *this;
}

void Time::RoundDownToMs(int32_t ms)
{
	int64_t round = ms * 1000LL;
	int64_t now = m_tv.tv_sec * 1000000LL + m_tv.tv_usec;
	if (round < 0)
	{
		round=1000LL;
	}
	now = (now / round) * round;
	m_tv.tv_sec = now / 1000000LL;
	m_tv.tv_usec = now % 1000000LL;
}

void Time::RoundUpToMs(int32_t ms)
{
	int64_t round = ms * 1000LL;
	int64_t now = m_tv.tv_sec * 1000000LL + m_tv.tv_usec + round;
	if (round < 0)
	{
		round=1000LL;
	}
	now = (now / round) * round;
	m_tv.tv_sec = now / 1000000LL;
	m_tv.tv_usec = now % 1000000LL;
}

void Time::SetToMsDelta(int32_t ms_from_now)
{
	SetToNow();
	// we use a forward rounding timout, taking advantage of long long
	RoundUpToMs(ms_from_now);
}

void Time::SetToMsFromNow(int32_t ms_from_now)
{
	SetToNow();
	int64_t us = (m_tv.tv_sec * 1000000LL) + m_tv.tv_usec + (ms_from_now * 1000LL);
	m_tv.tv_sec = us / 1000000LL;
	m_tv.tv_usec = us % 1000000LL;
}

int64_t Time::ConvertToMs() const
{
	return ConvertTimeValToMsec(m_tv);
}

void Time::Normalize()
{
	// usec overflow
	while (m_tv.tv_usec >= 1000000)
	{
		m_tv.tv_usec -= 1000000;
		++m_tv.tv_sec;
	}
	// usec underflow
	while (m_tv.tv_usec < 0)
	{
		m_tv.tv_usec += 1000000;
		--m_tv.tv_sec;
	}
}

string Time::FormatToUTC(const char* fmt)
{
	struct tm *ptm = gmtime(&m_tv.tv_sec);
	
	char buf[256];
	strftime(buf, sizeof(buf), fmt, ptm);

	return string(buf);
}

string Time::FormatToDefaultUTC()
{
	return FormatToUTC(DEFAULT_UTC_FORMAT);
}

bool Time::LoadFromUTC(const char* fmt, string utc_time)
{
	struct tm tm;
	if ( !strptime(utc_time.c_str(), fmt, &tm) ) return false;	
	m_tv.tv_sec = mktime(&tm);
	return ( m_tv.tv_sec != -1 );
}

bool Time::LoadFromDefaultUTC(string utc_time)
{
	return LoadFromUTC(DEFAULT_UTC_FORMAT, utc_time);
}

int64_t Time::GetNowSec()
{
	timeval tv;
	gettimeofday(&tv, NULL);
	return tv.tv_sec;
}

int64_t Time::GetNowMsec()
{
	timeval tv;
	gettimeofday(&tv, NULL);
	return ConvertTimeValToMsec(tv);
}

}
