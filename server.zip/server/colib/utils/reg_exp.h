//reg_exp.h
// vi:set ts=4 sw=4 nowrap:

#ifndef REG_EXP_H_ALREADY_INCLUDED
#define REG_EXP_H_ALREADY_INCLUDED

//#include <sys/types.h>
#include <regex.h>
#include<utils/callback.h>
#include<utils/string.h>


namespace colib
{

class Regex
{
public:
	class RegBuf
	{
	public:
		RegBuf();
		~RegBuf();

		string m_pattern;
		regex_t m_reg;
		bool m_ok;
		int m_ref;
	};

	bool operator<( const Regex &than )const;
	bool Matches( string to )const;
	bool Matches(const char* to) const;
	bool SetPattern( string pattern );
	bool IsOk() const;
	void Empty();
	string GetLastError()const;
	string GetPattern()const;

	refbuf<RegBuf> m_rb;
private:
	mutable string m_last_error;
};

}//end namespace colib

#endif

