#if !defined(__BUFFER_POOL_H__)
#define __BUFFER_POOL_H__

#include <stdlib.h>
#include <stdio.h>
#include <list>

namespace colib
{

template <typename T> class BufferPool
{
public:
	BufferPool(int max_bufs);
	virtual ~BufferPool();
	T* Get();
	void Return(T* buf);
	int Available() const { return m_free_list.size(); }
	bool IsEmpty() const { return m_free_list.empty(); }
	int NumAllocated() const { return m_allocated_bufs; }

protected:
	int Allocate(int amount);
	bool Grow();
	bool m_grow;
	const int m_max_bufs;
	int m_allocated_bufs;

private:
	std::list<T*> m_free_list;
};

template <typename T>
BufferPool<T>::BufferPool(int max_bufs)
	: m_grow(true)
	, m_max_bufs(max_bufs)
	, m_allocated_bufs(0)
	, m_free_list()
{
}

template <typename T>
BufferPool<T>::~BufferPool()
{
	typename std::list<T*>::iterator it(m_free_list.begin());
	for ( ; it != m_free_list.end(); ++it)
	{
		delete *it;
	}
    m_free_list.clear();
}

template <typename T>
int BufferPool<T>::Allocate(int amount)
{
	int num_to_alloc = std::min(amount, m_max_bufs - m_allocated_bufs);

	for (int ii(0); ii < num_to_alloc; ++ii)
	{
		m_free_list.push_back(new T);
	}
	m_allocated_bufs += num_to_alloc;
	return num_to_alloc;
}

template <typename T>
bool BufferPool<T>::Grow()
{
	bool ret = false;
	if (m_grow)
	{
		// TODO: better logic
		// for now, grow by 50%
		// always grow by at least 1
		ret = Allocate(std::max(m_allocated_bufs/2, 1)) > 0;
	}
	return ret;
}

template <typename T>
T* BufferPool<T>::Get()
{
	if (m_free_list.empty())
	{
		if (!Grow())
		{
			return NULL;
		}
	}
	T* ret = *m_free_list.begin();
	m_free_list.pop_front();
	ret->Reset();
	return ret;
}

template <typename T>
void BufferPool<T>::Return(T* buf)
{
	if (buf != NULL)
	{
		m_free_list.push_front(buf);
	}
}

}

#endif
