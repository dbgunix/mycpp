/* -*- tab-width:4; c-basic-offset: 4 -*- */
// uint128.h
// vi:set ts=4 sw=4 nowrap:

#include<utils/uint128.h>

#include <math.h>
#include <limits>
#include <algorithm>
#include <string.h>

namespace colib
{

const UInt128 UInt128::m_lower(0, 0);
const UInt128 UInt128::m_upper(std::numeric_limits<uint64_t>::max(),
								std::numeric_limits<uint64_t>::max());

UInt128::UInt128()
	: m_buf()
{
	m_buf.u6_addr64[0] = 0;
	m_buf.u6_addr64[1] = 0;
}

UInt128::UInt128(const UInt128& other)
	: m_buf()
{
	m_buf.u6_addr64[0] = other.m_buf.u6_addr64[0];
	m_buf.u6_addr64[1] = other.m_buf.u6_addr64[1];
}

UInt128::UInt128(u_int64_t u6_addr64_low, u_int64_t u6_addr64_high)
	: m_buf()
{
	m_buf.u6_addr64[0] = u6_addr64_low;
	m_buf.u6_addr64[1] = u6_addr64_high;
}

UInt128::UInt128(const in6_addr& in6Addr)  { // u6_addr32[4] {
	memcpy(m_buf.u6_in6_addr.s6_addr, in6Addr.s6_addr, sizeof(in6_addr));
}

UInt128& UInt128::operator = (const in6_addr& in6Addr) {
	memcpy(m_buf.u6_in6_addr.s6_addr, in6Addr.s6_addr, sizeof(in6_addr));
	return *this;
}

void UInt128::FLIP()
{
#if(NETWORK_BYTE_ORDER != MACHINE_BYTE_ORDER)
	std::swap(u6_addr64[0], u6_addr64[1]);
	FLIP(u6_addr64[0]);
	FLIP(u6_addr64[1]);
#endif
}

UInt128& UInt128::operator = (unsigned int i) {
	m_buf.u6_addr64[1] = 0;
	m_buf.u6_addr64[0] = i;
	return *this;
}

UInt128& UInt128::operator+=(unsigned int i) {
	if (m_buf.u6_addr64[0] + i < m_buf.u6_addr64[0]) {// overflow
		m_buf.u6_addr64[0] += i;
		m_buf.u6_addr64[1] += 1; // may overflow
	} else {
		m_buf.u6_addr64[0] += i; //may overflow
	}
	return *this;
}

const UInt128 UInt128::operator+(unsigned int i) const {
	return UInt128(*this)+=i;
}

UInt128& UInt128::operator-=(unsigned int i) {
	if (m_buf.u6_addr64[0] >= i) {
		m_buf.u6_addr64[0] -= i;
	}
	else {
		i --; // i must be greather than 0
		m_buf.u6_addr64[1] --;
		m_buf.u6_addr64[0] += (std::numeric_limits<uint64_t>::max() - i);
	}
	return *this;
}

UInt128& UInt128::operator -=(const UInt128& other) {
	if (m_buf.u6_addr64[0] >= other.m_buf.u6_addr64[0]) {
		m_buf.u6_addr64[0] -= other.m_buf.u6_addr64[0];
		m_buf.u6_addr64[1] -= other.m_buf.u6_addr64[1];
	} else {
		// other.m_buf.u6_addr64[0] must be greater than 0
		u_int64_t tmp = other.m_buf.u6_addr64[0] - 1;
		m_buf.u6_addr64[0] += (std::numeric_limits<uint64_t>::max() - tmp);
		m_buf.u6_addr64[1] --;
		m_buf.u6_addr64[1] -= other.m_buf.u6_addr64[1];
	}
	return *this;
}

const UInt128 UInt128::operator -(unsigned int i) const {
	return UInt128(*this)-= i;
}

const UInt128 UInt128::operator -(const UInt128& other) const {
	return UInt128(*this)-= other;
}

UInt128& UInt128::operator &=(const UInt128& other) {
	m_buf.u6_addr64[0] &= other.m_buf.u6_addr64[0];
	m_buf.u6_addr64[1] &= other.m_buf.u6_addr64[1];
	return *this;
}

const UInt128 UInt128::operator &(const UInt128& other) const {
	return UInt128(*this) &= other;
}

UInt128& UInt128::operator |=(const UInt128& other) {
	m_buf.u6_addr64[0] |= other.m_buf.u6_addr64[0];
	m_buf.u6_addr64[1] |= other.m_buf.u6_addr64[1];
	return *this;
}

const UInt128 UInt128::operator |(const UInt128& other) const {
	return UInt128(*this) |= other;
}

const UInt128 UInt128::operator ~() const {
	UInt128 tmp;
	tmp.m_buf.u6_addr64[0] = ~m_buf.u6_addr64[0];
	tmp.m_buf.u6_addr64[1] = ~m_buf.u6_addr64[1];
	return tmp;
}

bool UInt128::operator == (const UInt128& other) const {
	return (m_buf.u6_addr64[0] == other.m_buf.u6_addr64[0]
				&& m_buf.u6_addr64[1] == other.m_buf.u6_addr64[1]);

}

bool UInt128::operator <(const UInt128& other) const {
	if (m_buf.u6_addr64[1] < other.m_buf.u6_addr64[1]) {
		return true;
	} else if (m_buf.u6_addr64[1] > other.m_buf.u6_addr64[1]) {
		return false;
	} else {
		return m_buf.u6_addr64[0] < other.m_buf.u6_addr64[0];
	}
}

string UInt128::ToString(const UInt128& num) const {
	return string::Format("0X%x%x%x%x",
			num.m_buf.u6_in6_addr.s6_addr32[0],
			num.m_buf.u6_in6_addr.s6_addr32[1],
			num.m_buf.u6_in6_addr.s6_addr32[2],
			num.m_buf.u6_in6_addr.s6_addr32[3]);
}

} //namespace
