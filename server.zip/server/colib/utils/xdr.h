#if !defined(__XDR_H__)
#define __XDR_H__

#include<utils/string.h>
#include<utils/multi_enc_intf.h>

#include <stdint.h>

namespace colib
{

class CXDR
{
public:
	enum xdr_op
	{
		XDR_ENCODE = 0,
		XDR_DECODE = 1,
		XDR_UNDEF = 2
	};
	static const int MAX_XDR_STRING_LEN = 128 * 1024; /* 128K */
	static const int DEF_BUF_LEN = 512;

	virtual ~CXDR() { }

	virtual unsigned int GetLength () const { return m_next; }
	unsigned int GetRemaining () const { return m_last - m_next; }
	xdr_op GetOp() const { return m_op; }

	// wrappers only, implemented in base class
	bool XdrChar (char* pc);
	bool XdrUchar (unsigned char* puc);
	bool XdrLong(long* pl);
	bool XdrUlong(unsigned long* pul);

	template <typename T>
	bool XdrEnum (T* pe);

	// integer primitives
	virtual bool XdrUshort(unsigned short* pus) = 0;
	virtual bool XdrUint (unsigned int* piu) = 0;
	virtual bool XdrShort(short* ps) = 0;
	virtual bool XdrInt (int* pi) = 0;
	virtual bool XdrBool(bool* pb) = 0;
	virtual bool XdrInt64(int64_t* pi64) = 0;
	virtual bool XdrUint64(uint64_t* pui64) = 0;
	// floating point types
	virtual bool XdrFloat(float* fp) = 0;
	virtual bool XdrDouble(double* pd) = 0;
	// raw bytes
	virtual bool XdrOpaque(char* pc, unsigned int uiCnt) = 0;
	virtual bool XdrBytes(char* data, unsigned int bytes) = 0;
	// "compressed" integer types
	virtual bool XdrIntInOneByte(int* pi) = 0;
	virtual bool XdrUintInOneByte(unsigned int* pi) = 0;
	virtual bool XdrBoolInOneByte(bool* pi) = 0;
	virtual bool XdrUintInTwoByte(unsigned int* pi) = 0;
	// string types
	virtual bool XdrStringPadded(char **ppc, unsigned int uiMaxsize) = 0;
	virtual bool XdrStringPadded(string &str) = 0;
	virtual bool XdrStringPacked(string &str) = 0;

	virtual bool XdrSkip(unsigned int len) = 0;

protected:
	static const int BYTES_PER_XDR_UNIT = 4;

	CXDR(xdr_op op, char* pBuffer, int max_len);
	CXDR(xdr_op op);

	const xdr_op m_op;
	char* mp_Base;
	unsigned int m_next;
	unsigned int m_last;

private:
	CXDR(const CXDR &xdr);
	void operator=(const CXDR &xdr);
};

class XdrEncode : public CXDR
{
public:
	XdrEncode(char* pBuffer, int max_len)
		: CXDR(CXDR::XDR_ENCODE, pBuffer, max_len)
	{
	}
	bool XdrShort (short* ps);
	bool XdrInt(int* pi);
	bool XdrUshort (unsigned short* pus);
	bool XdrUint(unsigned int* pi);
	bool XdrInt64(int64_t* pi64);
	bool XdrUint64(uint64_t* pui64);
	bool XdrBool(bool* pb);

	bool XdrFloat (float* fp);
	bool XdrDouble (double* pd);

	bool XdrOpaque(char* pc, unsigned int uiCnt);
	bool XdrBytes(char* data, unsigned int bytes);

	bool XdrIntInOneByte (int* pi);
	bool XdrUintInOneByte (unsigned int* pi);
	bool XdrBoolInOneByte (bool* pi);
	bool XdrUintInTwoByte (unsigned int* pi);

	bool XdrStringPadded(char **ppc, unsigned int uiMaxsize);
	bool XdrStringPadded(string &str);
	bool XdrStringPacked(string &str);

	bool XdrSkip(unsigned int len) { (void)len; return true; }

protected:
	// for XdrBuffEncode only
	XdrEncode()
		: CXDR(CXDR::XDR_ENCODE)
	{
	}

private:
	static const int REALLOC_PAD = 128;
	bool PutInt(int x);
	bool PutUint(unsigned int x);
	bool PutInt64 (int64_t x);
	bool PutUint64 (uint64_t x);
	bool PutFloat (float x);
	bool PutDouble (double d);
	virtual bool PutBytes (const void* pData, unsigned int len);

	bool EncodeOpaque(const char* pc, unsigned int uiCnt);
};

class XdrBuffEncode : public XdrEncode
{
public:
	XdrBuffEncode(MultiEncodeIntf& buf)
		: m_buf(buf)
	{
	}
	unsigned int GetLength() const { return m_buf.GetLength(); }
	void PrependLength(unsigned int len) { m_buf.PrependLength(len); }

private:
	bool PutBytes (const void* pData, unsigned int len) { return m_buf.WriteXdrBytes(static_cast<const char*>(pData), len); }
	MultiEncodeIntf &m_buf;
};

class XdrDecode : public CXDR
{
public:
	XdrDecode(char* pBuffer, int max_len)
		: CXDR(CXDR::XDR_DECODE, pBuffer, max_len)
	{
	}
	bool XdrShort (short* ps);
	bool XdrInt (int* pi);
	bool XdrUshort (unsigned short* pus);
	bool XdrUint (unsigned int* pi);
	bool XdrInt64(int64_t* pi64);
	bool XdrUint64(uint64_t* pui64);
	bool XdrBool(bool* pb);

	bool XdrFloat (float* fp);
	bool XdrDouble (double* pd);

	bool XdrOpaque(char* pc, unsigned int uiCnt);
	bool XdrBytes(char* data, unsigned int bytes);

	bool XdrIntInOneByte (int* pi);
	bool XdrUintInOneByte (unsigned int* pi);
	bool XdrBoolInOneByte (bool* pi);
	bool XdrUintInTwoByte (unsigned int* pi);

	bool XdrStringPadded(char **ppc, unsigned int uiMaxsize);
	bool XdrStringPadded(string &str);
	bool XdrStringPacked(string &str);

	bool XdrSkip(unsigned int len);

private:
	bool GetInt(int *x);
	bool GetUint(unsigned int* x);
	bool GetInt64(int64_t* x);
	bool GetUint64(uint64_t* x);
	bool GetFloat(float* x);
	bool GetDouble(double* pd);
	bool GetBytes(void* pData, unsigned int len);
};

////////////////////////////////////////////////////////////////////////////////
//
//      Class Name: EncodableItem
//
//     Description: Simplifies the encoding and decoding of the member variables
//                  of a class for XDR.
//
////////////////////////////////////////////////////////////////////////////////
//
class CEncodableItem
{
public:
	CEncodableItem();
	virtual ~CEncodableItem();

	virtual bool XdrProc (CXDR* x) = 0;
	bool Encode(char* pData, unsigned int *len);
	bool Encode(MultiEncodeIntf &mei, unsigned int *len, bool prepend_len);
	bool Encode(CXDR* pXdr, unsigned int* len);
	bool Decode(char* pData, unsigned int len);
};

template <typename T>
bool CXDR::XdrEnum (T* pe)
{
	int32_t data(*pe);
	bool res = XdrInt(&data);

	if (res && m_op == XDR_DECODE)
	{
		*pe = static_cast<T>(data);
	}
	return res;
}

}

#endif
