#if !defined(__MONO_TIME_H__)
#define __MONO_TIME_H__

#include <sys/time.h>
#include <time.h>
#include <stdint.h>

namespace colib
{

class MonoTime
{
public:
	MonoTime();
	MonoTime(time_t sec, long int nsec);
	MonoTime(const MonoTime &other);
	MonoTime& operator=(const MonoTime &other);

	MonoTime& SetToNow();

	time_t GetSeconds() const {return m_ts.tv_sec; }
	long GetNsec() const { return m_ts.tv_nsec; }

	// This function will set "this" time to now + ms_from_now
	void SetToMsFromNow(uint32_t ms_from_now);
	void IncrementMs(uint32_t ms);

	// TODO: round up to next ms?
	long ConvertToMs() const { return m_ts.tv_sec*1000 + m_ts.tv_nsec/1000000; }

	static long GetNowMs();

private:
	// make sure 0 <= nsec <= 1000000000
	void Normalize();
	timespec m_ts;
};

inline MonoTime operator-(const MonoTime &a, const MonoTime &b)
{
	MonoTime ret(a.GetSeconds()-b.GetSeconds(), a.GetNsec()-b.GetNsec());
	return ret;
}

inline MonoTime operator+(const MonoTime &a, const MonoTime &b)
{
	MonoTime ret(a.GetSeconds()+b.GetSeconds(),a.GetNsec()+b.GetNsec());
	return ret;
}

inline bool operator== (const MonoTime &a, const MonoTime &b)
{
	return a.GetSeconds() == b.GetSeconds() && a.GetNsec() == b.GetNsec();
}

inline bool operator<(const MonoTime &a, const MonoTime &b)
{
	return a.GetSeconds() == b.GetSeconds() ?
			a.GetNsec() < b.GetNsec() :
			a.GetSeconds() < b.GetSeconds();
}

inline bool operator>(const MonoTime &a, const MonoTime &b)
{
	return a.GetSeconds() == b.GetSeconds() ?
			a.GetNsec() > b.GetNsec() :
			a.GetSeconds() > b.GetSeconds();
}

inline bool operator<=(const MonoTime &a, const MonoTime &b)
{
	return !(a > b);
}

inline bool operator>=(const MonoTime &a, const MonoTime &b)
{
	return !(a < b);
}

inline bool operator!=(const MonoTime &a, const MonoTime &b)
{
	return !(a == b);
}

}
#endif

