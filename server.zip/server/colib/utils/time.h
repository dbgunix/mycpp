//time.h

#ifndef __UTILS_TIME_H__
#define __UTILS_TIME_H__

#include <sys/time.h>
#include <time.h>
#include <unistd.h>
#include <stdint.h>
#include <utils/string.h>

namespace colib
{

class CXDR;

class Time
{
public:
	Time();
	Time(int32_t msec);
	Time(int32_t sec, int32_t usec);
	Time(const Time &other);
	Time& operator=(const Time &other);

	Time& SetToNow();

	int64_t GetSeconds() const {return m_tv.tv_sec; }
	int64_t GetUsec() const { return m_tv.tv_usec; }
	void SetSeconds(unsigned value) { m_tv.tv_sec=value; }
	
	//Do NOT pass args <= 0 to these
	void RoundDownToMs(int32_t ms);
	void RoundUpToMs(int32_t ms);

	//This function will set "this" time to now + (0 thru ms_from_now)
	//It is designed to produce a regular delta between timeouts regardless
	//of when the function is called (within a window of ms_from_now )
	void SetToMsDelta(int32_t ms_from_now );

	// This function will set "this" time to now + ms_from_now
	void SetToMsFromNow(int32_t ms_from_now);

	int64_t ConvertToMs() const;

	char* Format(char *buf, int sz) const;
	bool XdrProc(CXDR * xdr);

	string FormatToDefaultUTC();
	string FormatToUTC(const char* fmt);
	bool LoadFromDefaultUTC(string utc_time);
	bool LoadFromUTC(const char* fmt, string utc_time);

	static int64_t GetNowSec();
	static int64_t GetNowMsec();

private:
	// make sure 0 <= usec <= 1000000
	void Normalize();
	timeval m_tv;
};

inline Time operator-(const Time &a, const Time &b)
{
	Time ret(a.GetSeconds()-b.GetSeconds(), a.GetUsec()-b.GetUsec());
	return ret;
}

inline Time operator+(const Time &a, const Time &b)
{
	Time ret(a.GetSeconds()+b.GetSeconds(),a.GetUsec()+b.GetUsec());
	return ret;
}

inline bool operator== (const Time &a, const Time &b)
{
	return a.GetSeconds() == b.GetSeconds() && a.GetUsec() == b.GetUsec();
}

inline bool operator<(const Time &a, const Time &b)
{
	return a.GetSeconds() == b.GetSeconds() ?
			a.GetUsec() < b.GetUsec() :
			a.GetSeconds() < b.GetSeconds();
}

inline bool operator>(const Time &a, const Time &b)
{
	return a.GetSeconds() == b.GetSeconds() ?
			a.GetUsec() > b.GetUsec() :
			a.GetSeconds() > b.GetSeconds();
}

inline bool operator<=(const Time &a, const Time &b)
{
	return !(a > b);
}

inline bool operator>=(const Time &a, const Time &b)
{
	return !(a < b);
}

inline bool operator!=(const Time &a, const Time &b)
{
	return !(a == b);
}

}
#endif

