#ifndef BASE_ENCODER_INCLUDE_H
#define BASE_ENCODER_INCLUDE_H

//Base encoding specified in http://tools.ietf.org/html/rfc4648
// Also support colib base 64 encoding for legacy system. Only use it for backwards compatible purpose 
//
namespace colib {

// try to make header file simple and internal data and functions are defined in
// CPP file
class BaseEncoder {
public:
	static const bool Default_Padding = false;
	static const int  ERROR_INVALID_ALPHABET = -1;
	static const int  ERROR_INVALID_BASE_ENCODING = -2;	
	static const int  ERROR_INSUFFICIENT_BUFFER = -3;
	static const int  ERROR_INTERNAL = -4; // due to bugs
	static const int  ERROR_UNKNOWN_ERROR = -5;// only for colib base 64 encoding
public:

	// the length include padding if addPadding is true
	static int GetBase64Len(int octetLen, bool addPadding = Default_Padding);
	// the buffer size is 1 byte more for the zero character
	
	/** Calculate the base64 buffer size with space for the terminating character
  	* \param[in] octetLen length of the octets to be encoded
  	* \param[in] addPadding if padding is included in the encoding 
  	* \return the base encoding buffer size in bytes 
  	*/
	static int GetBase64BufSize(int octetLen, bool addPadding = Default_Padding) { return GetBase64Len(octetLen, addPadding) + 1; };

	// Colib Base64 has no padding
	static int GetColibBase64Len(int octetLen); 

	/** Calculate the Colib base64 buffer size with space for the terminating character
  	* \param[in] octetLen length of the octets to be encoded
  	* \param[in] addPadding if padding is included in the encoding 
  	* \return the base encoding buffer size in bytes 
  	*/
	static int GetColibBase64BufSize(int octetLen) { return GetBase64Len(octetLen) + 1; } 

	// the length include padding if addPadding is true
	static int GetBase32Len(int octetLen, bool addPadding = Default_Padding); 

	/** Calculate the base32 buffer size with space for the terminating character
  	* \param[in] octetLen length of the octets to be encoded
  	* \param[in] addPadding if padding is included in the encoding 
  	* \return the base encoding buffer size in bytes 
  	*/
	static int GetBase32BufSize(int octetLen, bool addPadding = Default_Padding) { return GetBase32Len(octetLen, addPadding) + 1; }

	// base 16 has no padding
	static int GetBase16Len(int octetLen);

	/** Calculate the base16 buffer size with space for the terminating character
  	* \param[in] octetLen length of the octets to be encoded
  	* \return the base encoding buffer size in bytes
  	*/
	static int GetBase16BufSize(int octetLen) { return GetBase16Len(octetLen) + 1; }

	// This length includes the padding and may be more than the actual length.
	// The decode methods will return the real data length without padding
	static int GetDecode64Len(int baseLen);

	// colib encoding. obsoleted only for legacy system support/upgrading
	static int GetColibDecode64Len(int baseLen);

	static int GetDecode32Len(int baseLen);
	static int GetDecode16Len(int baseLen);

	// case sensitive encoder
	static int Encode64(char * encodeBuf, int bufLen,
                 const unsigned char* octet, int octetLen, bool padded = Default_Padding);
			
	static int Decode64(unsigned char* octetBuf, int bufLen, 
				const char * encode, int encodeLen);

	// safe for url and file name
	static int Encode64UrlFileNameSafe(char * encodeBuf, int bufLen,
                 const unsigned char* octet, int octetLen, bool padded = Default_Padding);
			
	static int Decode64UrlFileNameSafe(unsigned char* octetBuf, int bufLen, 
				const char * encode, int encodeLen);

	// colib base64. Only for backwards compatiblity
	static int Encode64Colib(char * encodeBuf, int bufLen,
                 const unsigned char* octet, int octetLen);
			
	static int Decode64Colib(unsigned char* octetBuf, int bufLen, 
				const char * encode, int encodeLen);

	// case insensitive encoders
	static int Encode32(char * encodeBuf, int bufLen,
                 const unsigned char* octet, int octetLen, bool padded = Default_Padding);
			
	static int Decode32(unsigned char* octetBuf, int bufLen, 
				const char * encode, int encodeLen);

	static int Encode32ExtHex(char * encodeBuf, int bufLen,
                 const unsigned char* octet, int octetLen, bool padded = Default_Padding);
			
	static int Decode32ExtHex(unsigned char* octetBuf, int bufLen, 
				const char * encode, int encodeLen);

	static int Encode16(char * encodeBuf, int bufLen,
                 const unsigned char* octet, int octetLen);
			
	static int Decode16(unsigned char* octetBuf, int bufLen, 
				const char * encode, int encodeLen);

private:
	static int Encode(int encoder, 
					char * encodeBuf, int bufLen, 
					const unsigned char* octet, int octetLen, bool padded); 
	static int Decode(int encoder, 
					unsigned char* octetBuf, int bufLen, 
					const char * encode, int encodeLen);
};


}; //namespace

#endif // include 
