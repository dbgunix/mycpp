#ifndef DBENUMS_H
#define DBENUMS_H

///////////////////////////////////////////////////////////////
// Enumerated Types - From NMS Database Definitions
//
// NOTE: The Def*Initial #define's which follow each
// enum type are used by a code generator on the GUI/NMS
// "side" and should not be removed.
//
// NOTE: This file is shared by the NMS code, the embedded
// code, and the GUI.
///////////////////////////////////////////////////////////////

namespace colib
{

///////////////////////////////////////////////////////////////
// Structures and functions for translating following enums
///////////////////////////////////////////////////////////////
struct TEnumRec
{
    int            m_iEnum;
    const char *   m_strEnum;
};
#define EOERT {-1,""}

// Returns empty string if can't find iEnum.
const char *EnumToStr(int iEnum, const TEnumRec *tblEnumRec, const char *err_val = "");
// Returns the first enum in the table if can't find strEnum.
int StrToEnum(const char *strEnum, const TEnumRec *tblEnumRec, bool case_sensitive = false, int err_val = 0);
// Returns the number of TEnumRecs in tblEnumRec
int EnumCnt(const TEnumRec *tblEnumRec);

////////////////////////////////////////
// ENUM_TBL()
//   - takes the enumeration tag as arg
//   - expands to a const declaration of
//     TEnumRec array.
// eg.
//	ENUM_TBL(EMyType)
//  expands to:
//  const TEnumRec EMyTypeTable []
//
#define ENUM_TBL(enum_type) const TEnumRec enum_type##Table []
#define ENUM_TBL_DEF_START(enum_type) const TEnumRec enum_type##Table_Internal[] = {
#define ENUM_TBL_DEF_STOP(enum_type) , EOERT}; const TEnumRec *enum_type##Table = enum_type##Table_Internal;
#define ENUM_TBL_DECL(enum_type) const TEnumRec *enum_type##Table

////////////////////////////////////////
// ENUM_FMT_FUNCS()
//   - takes the enumeration tag as arg
//   - expands to definitions of 2 funcs,
//     which convert from str to enum an
//     vice versa.
// eg.
//     ENUM_FMT_FUNCS(EMyType)
//   expands to definitions of:
//     inline const char *FormatEMyType(EMyType val) - which converts from enum to str.
//   and
//     inline EMyType FormatEMyType(const char *val) - which converts from str to enum.
//
#define FMT_ENUM_FUNCS(enum_type)\
inline const char *Format##enum_type(enum_type val)\
{\
	return EnumToStr((int)val, enum_type##Table);\
}\
inline enum_type Format##enum_type(const char *val)\
{\
	return (enum_type)StrToEnum(val, enum_type##Table);\
}

#define FMT_ENUM_FUNCS4(enum_type, err_str, case_sensitive, err_int)\
inline const char *Format##enum_type(enum_type val)\
{\
	return EnumToStr((int)val, enum_type##Table, err_str);\
}\
inline enum_type Format##enum_type(const char *val)\
{\
	return (enum_type)StrToEnum(val, enum_type##Table, case_sensitive, err_int);\
}

///////////////////////////////////////////////////////////////
//  ENUMS
///////////////////////////////////////////////////////////////

//User access permissions
enum EAccessPermissions{
	 ChangePassword,
	 Modify
};
#define EAccessPermissionsCount 2

//For MCD linecard,
enum HubRxMode
{
	SINGLE_MODE = 0,
	MCD_SINGLE_SCPC,
	MCD_SINGLE_TDMA,
	MCD_MULTIPLE_SCPC,
	MCD_MULTIPLE_TDMA,
	MCD_MODE_TYPE_COUNT
};
#define DefHubModeInitial MCD_SINGLE_TDMA

ENUM_TBL(HubRxMode) =
{
	{SINGLE_MODE,			""},
	{MCD_SINGLE_SCPC,		"Single Channel SCPC"},
	{MCD_SINGLE_TDMA,		"Single Channel TDMA"},
	{MCD_MULTIPLE_SCPC,		"Multiple Channel SCPC"},
	{MCD_MULTIPLE_TDMA,		"Multiple Channel TDMA"},
	{MCD_MODE_TYPE_COUNT,	""},
	EOERT
};
FMT_ENUM_FUNCS(HubRxMode);

///////////////////////////////////////
// Transponder Polarization Type
enum ETransPolarType {
	TransHorizontal,
	TransVertical,
    TransCircularRight,
	TransCircularLeft
};
#define DefETransPolarTypeInitial TransHorizontal

ENUM_TBL(ETransPolarType) =
{
    {TransHorizontal,          "Horizontal"},
    {TransVertical,            "Vertical"},
    {TransCircularRight,		"Right-Hand Circular"},
	{TransCircularLeft,			"Left-Hand Circular"},
	EOERT
};

FMT_ENUM_FUNCS(ETransPolarType);

///////////////////////////////////////
// COTM Type
enum ECOTMType {
	COTMMaritime,
	COTMVehicular,
	COTMTrain,
    COTMAirplane
};
#define DefECOTMTypeInitial COTMMaritime
#define NOCOTM

ENUM_TBL(ECOTMType) =
{
    {COTMMaritime,          "Maritime"},
	{COTMVehicular,		    "Vehicular"},
    {COTMTrain,             "Railway"},
   	{COTMAirplane,		      "Avionics"},
	EOERT
};

FMT_ENUM_FUNCS(ECOTMType);

double MaxCOTMSpeed(int iEnum);
double MinCOTMSpeed(int iEnum);

//speed in miles per hour
#define DefCOTMMaxSpeed 700
#define DefLightSpeed 670616629

///////////////////////////////////////
// Transponder Polarization Type
enum ETransXPolarType {
  	TransXHorizontal,
  	TransXVertical,
  	TransXCircularRight,
  	TransXCircularLeft,
  	TransXCrossPol
};
#define DefETransXPolarTypeInitial TransXCrossPol

ENUM_TBL(ETransXPolarType) =
{
	{TransXHorizontal,          "Horizontal"},
	{TransXVertical,            "Vertical"},
	{TransXCircularRight,       "Right-Hand Circular"},
	{TransXCircularLeft,        "Left-Hand Circular"},
	{TransXCrossPol,            "Cross-pol"},
	EOERT
};

FMT_ENUM_FUNCS(ETransXPolarType);


// Transponder Footprint Type
enum ETransFootPrintType {
	TransWest,
	TransEurope,
    TransAmerica
};
#define DefETransFootPrintTypeInitial TransEurope

ENUM_TBL(ETransFootPrintType) =
{
    {TransWest,                "West"},
    {TransEurope,              "Europe"},
    {TransAmerica,             "America"},
	EOERT
};

FMT_ENUM_FUNCS(ETransFootPrintType);

// The values correspond to Slot Type enum in TCT of SI Tables
enum EUpstreamModeType
{
	TDMA = 0,
	ACQ = 1,
	SCPC = 2,
	SUPER_BURST = 3,
};
#define DefEUpstreamModeType TDMA

ENUM_TBL(EUpstreamModeType) =
{
	{TDMA,	"TDMA"},
	{ACQ,   "ACQ"},
	{SCPC,	"SCPC"},
	{SUPER_BURST, "SUPER_BURST"},
	EOERT
};
FMT_ENUM_FUNCS(EUpstreamModeType);

enum EAcqType {
	AT_TDMA_WITHOUT_ACQ, // no acq slot in one frame
	AT_TDMA_WITH_ACQ, // legacy acq slot
	AT_SUPER_BURST, // super burst, only 8 SB channels allowed in one line card
	AT_SS, // spread acq slot, supported after 4.0 release
};
#define DefEAcqType AT_TDMA_WITH_ACQ

ENUM_TBL(EAcqType) =
{
	{AT_TDMA_WITHOUT_ACQ, "TDMA_No_ACQ"},
	{AT_TDMA_WITH_ACQ,    "TDMA_ACQ"},
	{AT_SUPER_BURST,      "TDMA_Super_Burst"},
	{AT_SS,               "SS_TDMA_ACQ"},
	EOERT
};
FMT_ENUM_FUNCS(EAcqType);

enum ENetworkType{
  STAR,
  STAR_MESH
};

#define DefENetworkTypeInitial STAR

ENUM_TBL(ENetworkType) =
{
    {STAR,            "Star"},
    {STAR_MESH,       "Star Mesh"},
	EOERT
};

FMT_ENUM_FUNCS(ENetworkType);
///////////////////////////////////////
// Carrier Type
enum ECarrierType {
	CarrierInBound,
	CarrierOutBound
};
#define DefECarrierTypeInitial CarrierInBound

ENUM_TBL(ECarrierType) =
{
    {CarrierInBound,           "Inroute"},
    {CarrierOutBound,          "Outroute"},
	EOERT
};

FMT_ENUM_FUNCS(ECarrierType);

// Carrier Coding Rate Type
enum ECarrierCodingRateType {
	CarrierTpc512,
	CarrierTpc128
};
#define DefECarrierCodingRateTypeInitial CarrierTpc512

ENUM_TBL(ECarrierCodingRateType) =
{
	{CarrierTpc512,				"TPC-512"},
	{CarrierTpc128,				"TPC-128"}
};
FMT_ENUM_FUNCS(ECarrierCodingRateType);

// User-entered carrier data rate type -- this enum records
// which bit rate field the user filled in when creating the carrier:
// transmission rate, information rate, or symbol rate.
enum ECarrierBitRateType {
	TransmissionBitRate,
	InformationBitRate,
	SymbolBitRate
};
#define DefECarrierBitRateTypeInitial TransmissionBitRate

ENUM_TBL(ECarrierBitRateType) =
{
	{TransmissionBitRate,		"TransmissionBitRate"},
	{InformationBitRate,		"InformationBitRate"},
	{SymbolBitRate,				"SymbolRate"}
};

FMT_ENUM_FUNCS(ECarrierBitRateType);

// Carrier Usage type
// Specifies the type of upstream traffic accetpted by
// the carrier: Star only carrier, star-mesh carrier or
// mesh carrier
enum ECarrierUsageType {
	StarOnly,
	StarMesh,
	MeshOnly
};
#define DefECarrierUsageTypeInitial StarOnly

ENUM_TBL(ECarrierUsageType) =
{
	{StarOnly,		"StarOnly"},
	{StarMesh,		"StarMesh"},
	{MeshOnly,		"MeshOnly"}
};

FMT_ENUM_FUNCS(ECarrierUsageType);

///////////////////////////////////////
// Carrier Usage Order
// Specifies the order in which of upstream traffic is sent on
// the carrier: Star only carrier, star-then-mesh carrier,
// mesh-then-star carrier, or mesh-only carrier.
enum ECarrierUsageOrder {
	Star_Only,
	Mesh_Star,
	Star_Mesh,
	Mesh_Only
};
#define DefECarrierUsageOrderInitial Star_Only

ENUM_TBL(ECarrierUsageOrder) =
{
	{Star_Only,		"Star_only"},
	{Mesh_Star,		"Mesh_then_Star"},
	{Star_Mesh,		"Star_then_Mesh"},
	{Mesh_Only,		"Mesh_only"}
};

FMT_ENUM_FUNCS(ECarrierUsageOrder);

///////////////////////////////////////
// Stack path to route the packet through
enum EPktDataPath {
	StarData,
	MeshData
};
#define DefECarrierUsageOrderInitial Star_Only

ENUM_TBL(EPktDataPath) =
{
	{StarData,		"StarData"},
	{MeshData,		"MeshData"}
};

FMT_ENUM_FUNCS(EPktDataPath);

///////////////////////////////////////
// LNB Band Type
enum ELNBBandType {
	LNB_BAND_3_625,
	LNB_BAND_10_95,
    LNB_BAND_11_7,
    LNB_BAND_12_2
};
#define DefELNBBandTypeInitial LNB_BAND_3_625

ENUM_TBL(ELNBBandType) =
{
    {LNB_BAND_3_625,           "3.625-4.2 GHz"},
    {LNB_BAND_10_95,           "10.95-11.7 GHz"},
    {LNB_BAND_11_7,            "11.7-12.2 GHz"},
    {LNB_BAND_12_2,            "12.2-12.75 GHz"},
	EOERT
};

FMT_ENUM_FUNCS(ELNBBandType);

// LNB Stability Type
enum ELNBStabilityType {
	LNB_STABILITY_0_5,
	LNB_STABILITY_0_9,
    LNB_STABILITY_1_5
};
#define DefELNBStabilityTypeInitial LNB_STABILITY_0_5

///////////////////////////////////////
// Reflector Approval Type
enum ERefApprovalType {
	Ref_1_2,
	Ref_1_8,
    Ref_2_4
};
#define DefERefApprovalTypeInitial Ref_1_2

ENUM_TBL(ERefApprovalType) =
{
    {Ref_1_2,                  "1.2 meter"},
    {Ref_1_8,                  "1.8 meter"},
    {Ref_2_4,                  "2.4 meter"},
	EOERT
};

FMT_ENUM_FUNCS(ERefApprovalType);

// Reflector Mount Type
enum ERefMountType {
	RefMountNonPen,
	RefMountPen,
    RefMountPole
};
#define DefERefMountTypeInitial RefMountNonPen

ENUM_TBL(ERefMountType) =
{
    {RefMountNonPen,           "non-penetrating mount"},
    {RefMountPen,              "penetrating mount"},
    {RefMountPole,             "pole mount"},
	EOERT
};

FMT_ENUM_FUNCS(ERefMountType);

///////////////////////////////////////
// BUC
enum EBUCType {
	BUC2WKU,
	BUC4WKU,
	BUC4WC,
	BUC8W,
	BUC10W,
	BUC20W,
	BUC5W,
	BUC2W,
	BUC1WKU,
	BUC16WKU,
	BUC7WKU,
	BUC5WKU,
	BUC3WKU,
	BUC3WKUEXT,
};
#define DefEBUCTypeInitial BUC2WKU

ENUM_TBL(EBUCType) =
{
    {BUC2WKU,                  "2W Ku-band"},
    {BUC4WKU,                  "4W Ku-band"},
    {BUC4WC,                   "4W C-band"},
    {BUC8W,                    "8W Hi-Power Ku-band"},
    {BUC10W,                   "10W Hi-Power C-band"},
    {BUC20W,                   "20W Hi-Power C-band"},
    {BUC5W,                    "5W C-band"},
    {BUC2W,                    "2W C-band"},
    {BUC1WKU,                  "1W Ku-band"},
    {BUC16WKU,                 "16W Hi-Power Ku-band"},
	{BUC7WKU,				   "7W Ku-band"},
	{BUC5WKU,				   "5W Ku-band"},
	{BUC3WKU,				   "3W Ku-band"},
	{BUC3WKUEXT,			   "3W Ku-band ext"},
    EOERT
};

FMT_ENUM_FUNCS(EBUCType);

///////////////////////////////////////
// NetModem Type
enum ENetModemType {
	TxHub,
	RxHub,
	TxRxHub,
	Remote,
	Standby,
	TxRxHubSolo,
	Failed,
	RemoteRx,
	Peer,
	RoleCount //8330
};
#define DefENetModemTypeInitial TxHub
extern ENUM_TBL_DECL(ENetModemType);
/*ENUM_TBL(ENetModemType) =
{
	{TxHub,                    	"Transmit Line Card"},
	{RxHub,                    	"Receive Line Card"},
	{TxRxHub,                  	"Transmit and Receive Line Card"},
	{Remote,					"Remote"},
	{Standby,					"Standby"},
	{TxRxHubSolo,				"Solo Transmit and Receive Line Card"},
	{Failed,					"Failed"},
	{RemoteRx,					"Receive Remote"},
	{Peer,						"Point to Point"},
	EOERT
};
*/
FMT_ENUM_FUNCS(ENetModemType);

// Renamed to ENewNetModemType to preserve old enum
enum ENewNetModemType {
    Hub_RxTx_Solo,    // no slaves (single modem hub configuration)
    Hub_RxTx_Master,  // sends    frame sync
    Hub_Rx_Slave,     // receives frame sync
    Hub_Tx_Master,    // sends    frame sync
    Hub_Rx_Master_FS_Repeater, //
    Hub_Standby,       // waits for configuration
    Rmt,			  // Renamed this to avoid conflict with old Remote
    Remote_Rx,
    Pnt_To_Pnt
};
#define DefENewNetModemTypeInitial Hub_RxTx_Solo

ENUM_TBL(ENewNetModemType) =
{
    {Hub_RxTx_Solo, 			"Hub_RxTx_Solo"},
    {Hub_RxTx_Master,			"Hub_RxTx_Master"},
    {Hub_Rx_Slave,   			"Hub_Rx_Slave"},
    {Hub_Tx_Master,  			"Hub_Tx_Master"},
    {Hub_Rx_Master_FS_Repeater,	"Hub_Rx_Master_FS_Repeater"},
    {Hub_Standby,				"Hub_Standby"},
    {Rmt,						"Remote"},
    {Remote_Rx,					"Remote_Rx"},
    {Pnt_To_Pnt,				"Pnt_To_Pnt"},
	EOERT
};

FMT_ENUM_FUNCS(ENewNetModemType);

enum ERoleType {
	RT_Primary,
	RT_Standby
};

ENUM_TBL(ERoleType) =
{
    {RT_Primary, 			"Primary"},
    {RT_Standby,			"Standby"},
};

FMT_ENUM_FUNCS(ERoleType);

enum EHubSyncTimingType{
    Solo   = 0,
    Master = 1,
    Slave  = 2
};
#define DefEHubSyncTimingTypeInitial Solo

ENUM_TBL(EHubSyncTimingType) =
{
	{Solo,						"Solo"},
	{Master,					"Master"},
	{Slave,						"Slave"}
};

FMT_ENUM_FUNCS(EHubSyncTimingType);

// Data Port Type
enum EDataPortType {
	MdmDimPortTypeOff = 0,
    MdmDimPortType232 = 2,
    MdmDimPortType449 = 4,
    MdmDimPortTypeV35 = 14
};
#define DefEDataPortTypeInitial MdmDimPortTypeOff

ENUM_TBL(EDataPortType) =
{
	{MdmDimPortTypeOff,		"OFF"},
	{MdmDimPortType232,		"RS-232"},
	{MdmDimPortType449,		"RS-449/530"},
	{MdmDimPortTypeV35,		"V.35"},
	EOERT
};

FMT_ENUM_FUNCS(EDataPortType);

// Data Source Type
enum EDataSourceType {
	MdmScpcDataPortLan,
	MdmScpcDataPortDim1,
	MdmScpcDataPortDim2,
	MdmScpcDataPortDim3,
	MdmScpcDataPortTxCw,
	MdmScpcDataPortTxPn,
	MdmScpcDataPortTx10
};
#define DefEDataSourceTypeInitial MdmScpcDataPortLan

ENUM_TBL(EDataSourceType) =
{
	{MdmScpcDataPortLan,		"LAN"},
    {MdmScpcDataPortDim1,		"DIM, Slot 1"},
    {MdmScpcDataPortDim2,		"DIM, Slot 2"},
	{MdmScpcDataPortDim3,		"DIM, Slot 3"},
	{MdmScpcDataPortTxCw,		"Tx Test: CW"},
	{MdmScpcDataPortTxPn,		"Tx Test: PN"},
	{MdmScpcDataPortTx10,		"Tx Test: 1/0"},
	EOERT
};

FMT_ENUM_FUNCS(EDataSourceType);

// Demodulator State Type
enum EDemodulatorStateType {
            MdmRxStateOff,
            MdmRxStateAcquiring,
            MdmRxStateLocked,
            MdmRxStateUnlocked
};
#define DefEDemodulatorStateTypeInitial MdmRxStateOff

ENUM_TBL(EDemodulatorStateType) =
{
	{MdmRxStateOff,				"Off"},
	{MdmRxStateAcquiring,		"Acquiring"},
	{MdmRxStateLocked,			"Locked"},
	{MdmRxStateUnlocked,		"Unlocked"}
};

FMT_ENUM_FUNCS(EDemodulatorStateType);

// Modem Modem Type
enum EModemModeType {
            MdmModeBurst    = 0,
            MdmModeScpc     = 2,
            MdmModeDisabled = 4,
            MdmModeDvbs2    = 6
};
#define DefEModemModeTypeInitial MdmModeBurst

ENUM_TBL(EModemModeType) =
{
    {MdmModeBurst,             "TDMA"},
    {MdmModeScpc,              "SCPC"},
    {MdmModeDisabled,          "Disabled"},
    {MdmModeDvbs2,             "DVB-S2"},
	EOERT
};

FMT_ENUM_FUNCS(EModemModeType);

// Rx Clock Source Type
enum ERxClockSourceType {
            MdmRxClockSourceReceive  = 0,
            MdmRxClockSourceTerminal = 1
};
#define DefERxClockSourceTypeInitial MdmRxClockSourceReceive

ENUM_TBL(ERxClockSourceType) =
{
	{MdmRxClockSourceReceive,	"Receive Timing"},
	{MdmRxClockSourceTerminal,	"Terminal Timing"},
	EOERT
};

FMT_ENUM_FUNCS(ERxClockSourceType);

// Tx Clock Source Type
enum ETxClockSourceType {
            MdmTxClockSourceStation  = 0,
            MdmTxClockSourceTerminal = 1
};
#define DefETxClockSourceTypeInitial MdmTxClockSourceStation

ENUM_TBL(ETxClockSourceType) =
{
	{MdmTxClockSourceStation,	"Station Timing"},
	{MdmTxClockSourceTerminal, "Terminal Timing"},
	EOERT
};

FMT_ENUM_FUNCS(ETxClockSourceType);

// Modulation Type
enum EModulationType {
            MdmModulationBpsk      = 0,
            MdmModulationQpsk      = 1,
			MdmModulationPSK_8     = 2,
			MdmModulationPSK_16    = 3,
			MdmModulationDVBS2_CCM = 4,
			MdmModulationDVBS2_ACM = 5,
                	MdmModulationSSB       = 6,
			MdmModulationAdaptive = 7,
			 MdmModulationInvalid  = 8 
};
#define DefEModulationTypeInitial MdmModulationQpsk

ENUM_TBL(EModulationType) =
{
    {MdmModulationBpsk,        "BPSK"},
    {MdmModulationQpsk,        "QPSK"},
	{MdmModulationPSK_8,       "8PSK"},
	{MdmModulationPSK_16,      "16PSK"},
	{MdmModulationDVBS2_CCM,   "CCM"},
	{MdmModulationDVBS2_ACM,   "ACM"},
	{MdmModulationSSB,         "SSB"},
	{MdmModulationAdaptive,    "Adaptive"},
	{MdmModulationInvalid, 	   "Invalid"},
	EOERT
};

FMT_ENUM_FUNCS(EModulationType);

int GetBitsPerSymbol(EModulationType modulation);

//------------------------------------------------
// atdma MODCOD is different from ModCodTypes
// MODCOD is combined by Modulation & CodingRate
//------------------------------------------------
// Coding Rate Type
enum ECodingRateType
{
	MdmFEC1By3 = 1,
	MdmFEC1By2 = 2,
	MdmFEC2By3 = 3,
	MdmFEC3By4 = 4,
	MdmFEC4By5 = 5,
	MdmFEC5By6 = 6,
	MdmFEC6By7 = 7,
	MdmFEC7By8 = 8,
	MdmFECInvalid = 9
};

ENUM_TBL(ECodingRateType) =
{
	{MdmFEC1By3, "1/3"},
	{MdmFEC1By2, "1/2"},
	{MdmFEC2By3, "2/3"},
	{MdmFEC3By4, "3/4"},
	{MdmFEC4By5, "4/5"},
	{MdmFEC5By6, "5/6"},
	{MdmFEC6By7, "6/7"},
	{MdmFEC7By8, "7/8"},
	{MdmFECInvalid, "Invalid"}
};

FMT_ENUM_FUNCS(ECodingRateType);
short SetMODCOD(short iModulation, short iCodingRate);
void GetMODCOD(short iModCod, short &iModulation, short &iCodingRate);

//-------------------------------------------------
//atdam Block Size
//-------------------------------------------------
enum EFecBlockSize
{
	FecBlock100 = 0,
	FecBlock170 = 1,
	FecBlock438 = 2,
	FecBlockReserved = 3
};

ENUM_TBL(EFecBlockSize) =
{
	{FecBlock100, "100"},
	{FecBlock170, "170"},
	{FecBlock438, "438"},
	{FecBlockReserved, "Reserved"}
};

FMT_ENUM_FUNCS(EFecBlockSize);

//--------------------
// MODCOD types
//--------------------
enum EModCodTypes
{
	Mode_qpsk_1_4 = 0,
	Mode_qpsk_1_3,
	Mode_qpsk_2_5,
	Mode_qpsk_1_2,
	Mode_qpsk_3_5,
	Mode_qpsk_2_3,
	Mode_qpsk_3_4,
	Mode_qpsk_4_5,
	Mode_qpsk_5_6,
	Mode_qpsk_8_9,
	Mode_qpsk_9_10,

	Mode_8psk_3_5,
	Mode_8psk_2_3,
	Mode_8psk_3_4,
	Mode_8psk_5_6,
	Mode_8psk_8_9,
	Mode_8psk_9_10,

	Mode_16apsk_2_3,
	Mode_16apsk_3_4,
	Mode_16apsk_4_5,
	Mode_16apsk_5_6,
	Mode_16apsk_8_9,
	Mode_16apsk_9_10,

	Mode_32apsk_3_4,
	Mode_32apsk_4_5,
	Mode_32apsk_5_6,
	Mode_32apsk_8_9,
	Mode_32apsk_9_10,

	Mode_Count
};

ENUM_TBL(EModCodTypes) =
{
	{Mode_qpsk_1_4,    "QPSK-1/4"   },
	{Mode_qpsk_1_3,    "QPSK-1/3"   },
	{Mode_qpsk_2_5,    "QPSK-2/5"   },
	{Mode_qpsk_1_2,    "QPSK-1/2"   },
	{Mode_qpsk_3_5,    "QPSK-3/5"   },
	{Mode_qpsk_2_3,    "QPSK-2/3"   },
	{Mode_qpsk_3_4,    "QPSK-3/4"   },
	{Mode_qpsk_4_5,    "QPSK-4/5"   },
	{Mode_qpsk_5_6,    "QPSK-5/6"   },
	{Mode_qpsk_8_9,    "QPSK-8/9"   },
	{Mode_qpsk_9_10,   "QPSK-9/10"  },
	{Mode_8psk_3_5,    "8PSK-3/5"   },
	{Mode_8psk_2_3,    "8PSK-2/3"   },
	{Mode_8psk_3_4,    "8PSK-3/4"   },
	{Mode_8psk_5_6,    "8PSK-5/6"   },
	{Mode_8psk_8_9,    "8PSK-8/9"   },
	{Mode_8psk_9_10,   "8PSK-9/10"  },
	{Mode_16apsk_2_3,  "16APSK-2/3" },
	{Mode_16apsk_3_4,  "16APSK-3/4" },
	{Mode_16apsk_4_5,  "16APSK-4/5" },
	{Mode_16apsk_5_6,  "16APSK-5/6" },
	{Mode_16apsk_8_9,  "16APSK-8/9" },
	{Mode_16apsk_9_10, "16APSK-9/10"},
	{Mode_32apsk_3_4,  "32APSK-3/4" },
	{Mode_32apsk_4_5,  "32APSK-4/5" },
	{Mode_32apsk_5_6,  "32APSK-5/6" },
	{Mode_32apsk_8_9,  "32APSK-8/9" },
	{Mode_32apsk_9_10, "32APSK-9/10"},
	EOERT
};

FMT_ENUM_FUNCS(EModCodTypes);

// SpreadingFactor Type
enum ESpreadingFactorType {
	SF_UnspreadBpsk 	= 0,
	SF_1    = 1,
	SF_2 	= 2,
	SF_4	= 4,
	SF_8	= 8,
	SF_16	= 16,
	SF_Invalid
};
#define DefESpreadingFactorTypeInitial SF_UnspreadBpsk

ENUM_TBL(ESpreadingFactorType) =
{
	{SF_UnspreadBpsk,       "No Spreading"},
	{SF_1,     "COTM SF=1"},
    {SF_2,     "COTM SF=2"},
    {SF_4,     "COTM SF=4"},
    {SF_8,     "COTM SF=8"},
  	{SF_16,    "COTM SF=16"},
	EOERT
};

FMT_ENUM_FUNCS(ESpreadingFactorType);

// Scrambling Type
enum EScramblingType {
            MdmScramOff = 0,
            MdmScramIdr	= 1,
			MdmScramV35 = 2
};
#define DefEScramblingTypeInitial MdmScramIdr

ENUM_TBL(EScramblingType) =
{
    {MdmScramOff,              "OFF"},
    {MdmScramIdr,              "IDR"},
    {MdmScramV35,              "V35"},
	EOERT
};

FMT_ENUM_FUNCS(EScramblingType);

// Differential Coding Type
enum EDifferentialCodingType {
            MdmDiffOff = 0,
            MdmDiffOn
};
#define DefEDifferentialCodingTypeInitial MdmDiffOff

ENUM_TBL(EDifferentialCodingType) =
{
    {MdmDiffOff,               "OFF"},
    {MdmDiffOn,                "ON"},
	EOERT
};

FMT_ENUM_FUNCS(EDifferentialCodingType);

// Spectral Inversion Type
enum ESpectralInversionType {
            MdmSpecNorm = 0,
            MdmSpecInv
};
#define DefESpectralInversionTypeInitial MdmSpecNorm

ENUM_TBL(ESpectralInversionType) =
{
    {MdmSpecNorm,              "Normal"},
    {MdmSpecInv,               "Inverted"},
	EOERT
};

FMT_ENUM_FUNCS(ESpectralInversionType);

// LNB Frequency Band
enum EFreqBandType {
    MdmLowBand = 0,
    MdmHighBand,
};
#define DefEFreqBandTypeInitial MdmLowBand

ENUM_TBL(EFreqBandType) =
{
    {MdmLowBand,               "Low Band"},
    {MdmHighBand,              "High Band"},
	EOERT
};

FMT_ENUM_FUNCS(EFreqBandType);

// LNB DC Voltage
enum EDCVoltageType {
    MdmDCVoltage19 = 0,
    MdmDCVoltage14,
};
#define DefEDCVoltageTypeInitial MdmDCVoltage19

ENUM_TBL(EDCVoltageType) =
{
    {MdmDCVoltage19,              "X-Pol Mode (19V)"},
    {MdmDCVoltage14,              "Co-Pol Mode (14V)"},
	EOERT
};

FMT_ENUM_FUNCS(EDCVoltageType);

// Modulator State Type
enum EModulatorStateType {
            MdmTxStateOff = 0,
            MdmTxStateStandby,
            MdmTxStateEnabled,
            MdmTxStateBursting
};
#define DefEModulatorStateTypeInitial MdmTxStateOff

ENUM_TBL(EModulatorStateType) =
{
	{MdmTxStateOff, 			"Disabled"},
    {MdmTxStateStandby,			"Standby"},
    {MdmTxStateEnabled,			"Enabled"},
    {MdmTxStateBursting,		"Bursting"},
	EOERT
};

FMT_ENUM_FUNCS(EModulatorStateType);

// Error Correction Type
enum EErrorCorrectionType {
            MdmFecRateOff 			= 0,
            MdmFecRate3By4 			= 2,
            MdmFecRate1By2 			= 3,
            MdmFecRate1By3 			= 4,
            MdmTpc676By1024			= 5,
            MdmFecReed				= 6,
            MdmVit1By2Rs112By126	= 7,
            MdmVit1By2Rs178By194	= 8,
            MdmVit1By2Rs201By219	= 9,
            MdmVit1By2Rs205By225	= 10,
            MdmVit3By4Rs112By126	= 11,
            MdmVit3By4Rs178By194	= 12,
            MdmVit3By4Rs201By219	= 13,
            MdmVit3By4Rs205By225	= 14,
            MdmTpc3249By4096		= 15,
            MdmTcm2By3				= 16,
            MdmTcm2By3Rs201By219	= 17,
            MdmTpc2028By4096		= 18,
            MdmTpc14400By16384		= 19,
            MdmTpc546By1024			= 20,
            MdmTpc441By1024			= 21,
            MdmDVBS2Fec				= 22,
            // Due to the uncertainty in the block sizes and coding rates, used generic names
            // Note that the block size is of fixed size.
            // Block size-1 - 100 bytes
            Mdm2D16StateBSize1FEC1By3	= 23,
            Mdm2D16StateBSize1FEC1By2	= 24,
            Mdm2D16StateBSize1FEC2By3	= 25,
            Mdm2D16StateBSize1FEC3By4	= 26,
            Mdm2D16StateBSize1FEC4By5	= 27,
            Mdm2D16StateBSize1FEC5By6	= 28,
            Mdm2D16StateBSize1FEC6By7	= 29,
            Mdm2D16StateBSize1FEC7By8	= 30,

            // Block size-2 - 170 bytes
            Mdm2D16StateBSize2FEC1By3	= 31,
            Mdm2D16StateBSize2FEC1By2	= 32,
            Mdm2D16StateBSize2FEC2By3	= 33,
            Mdm2D16StateBSize2FEC3By4	= 34,
            Mdm2D16StateBSize2FEC4By5	= 35,
            Mdm2D16StateBSize2FEC5By6	= 36,
            Mdm2D16StateBSize2FEC6By7	= 37,
            Mdm2D16StateBSize2FEC7By8	= 38,

            // Block size-3 - 438 bytes
            Mdm2D16StateBSize3FEC1By3	= 39,
            Mdm2D16StateBSize3FEC1By2	= 40,
            Mdm2D16StateBSize3FEC2By3	= 41,
            Mdm2D16StateBSize3FEC3By4	= 42,
            Mdm2D16StateBSize3FEC4By5	= 43,
            Mdm2D16StateBSize3FEC5By6	= 44,
            Mdm2D16StateBSize3FEC6By7	= 45,
            Mdm2D16StateBSize3FEC7By8	= 46,

/* TODO: ask NMS team
            MdmAdaptive100	= 47,
            MdmAdaptive170	= 48,
            MdmAdaptive438	= 49,
*/
			// end
            InvalidErrorCorrection
};
#define DefEErrorCorrectionTypeInitial MdmFecRateOff
double GetCodingRate_atdma(ECodingRateType type);
int GetFecBlockSize(EErrorCorrectionType type);
int GetFecBlockSize(EFecBlockSize type);
double GetCodingRate(EErrorCorrectionType type);

ENUM_TBL(EErrorCorrectionType) =
{
    {MdmFecRateOff,            "OFF"},
    {MdmFecRate3By4,           "Viterbi Rate 3/4"},
    {MdmFecRate1By2,           "Viterbi Rate 1/2"},
    {MdmFecRate1By3,           "Viterbi Rate 1/3"},
    {MdmTpc676By1024,          "TPC-676/1024 (.66)"},
    {MdmFecReed,               "Reed"},
    {MdmVit1By2Rs112By126,     "Viterbi-1/2, RS-112/126"},
    {MdmVit1By2Rs178By194,     "Viterbi-1/2, RS-178/194"},
    {MdmVit1By2Rs201By219,     "Viterbi-1/2, RS-201/219"},
    {MdmVit1By2Rs205By225,     "Viterbi-1/2, RS-205/225"},
    {MdmVit3By4Rs112By126,     "Viterbi-3/4, RS-112/126"},
    {MdmVit3By4Rs178By194,     "Viterbi-3/4, RS-178/194"},
    {MdmVit3By4Rs201By219,     "Viterbi-3/4, RS-201/219"},
    {MdmVit3By4Rs205By225,     "Viterbi-3/4, RS-205/225"},
    {MdmTpc3249By4096,         "TPC-3249/4096 (.79)"},
    {MdmTcm2By3,               "TCM-2/3"},
    {MdmTcm2By3Rs201By219,     "TCM-2/3, RS-201/219"},
    {MdmTpc2028By4096,			"TPC-2028/4096 (.49)"},
    {MdmTpc14400By16384,		"TPC-14400/16384 (.879)"},
    {MdmTpc546By1024,			"TPC-546/1024 (.533)"},
    {MdmTpc441By1024,			"TPC-441/1024 (.431)"},
    {MdmDVBS2Fec,				"LDPC  BCH "},

    {Mdm2D16StateBSize1FEC1By3,		"2D16S-100bytes  (1/3)"},
    {Mdm2D16StateBSize1FEC1By2,		"2D16S-100bytes  (1/2)"},
    {Mdm2D16StateBSize1FEC2By3,		"2D16S-100bytes  (2/3)"},
    {Mdm2D16StateBSize1FEC3By4,		"2D16S-100bytes  (3/4)"},
    {Mdm2D16StateBSize1FEC4By5,		"2D16S-100bytes  (4/5)"},
    {Mdm2D16StateBSize1FEC5By6,		"2D16S-100bytes  (5/6)"},
    {Mdm2D16StateBSize1FEC6By7,		"2D16S-100bytes  (6/7)"},
    {Mdm2D16StateBSize1FEC7By8,		"2D16S-100bytes  (7/8)"},
    {Mdm2D16StateBSize2FEC1By3,		"2D16S-170bytes  (1/3)"},
    {Mdm2D16StateBSize2FEC1By2,		"2D16S-170bytes  (1/2)"},
    {Mdm2D16StateBSize2FEC2By3,		"2D16S-170bytes  (2/3)"},
    {Mdm2D16StateBSize2FEC3By4,		"2D16S-170bytes  (3/4)"},
    {Mdm2D16StateBSize2FEC4By5,		"2D16S-170bytes  (4/5)"},
    {Mdm2D16StateBSize2FEC5By6,		"2D16S-170bytes  (5/6)"},
    {Mdm2D16StateBSize2FEC6By7,		"2D16S-170bytes  (6/7)"},
    {Mdm2D16StateBSize2FEC7By8,		"2D16S-170bytes  (7/8)"},
    {Mdm2D16StateBSize3FEC1By3,		"2D16S-438bytes  (1/3)"},
    {Mdm2D16StateBSize3FEC1By2,		"2D16S-438bytes  (1/2)"},
    {Mdm2D16StateBSize3FEC2By3,		"2D16S-438bytes  (2/3)"},
    {Mdm2D16StateBSize3FEC3By4,		"2D16S-438bytes  (3/4)"},
    {Mdm2D16StateBSize3FEC4By5,		"2D16S-438bytes  (4/5)"},
    {Mdm2D16StateBSize3FEC5By6,		"2D16S-438bytes  (5/6)"},
    {Mdm2D16StateBSize3FEC6By7,		"2D16S-438bytes  (6/7)"},
    {Mdm2D16StateBSize3FEC7By8,		"2D16S-438bytes  (7/8)"},
/* TODO: ask NMS team
    {MdmAdaptive100,		"100 byte payload"},
    {MdmAdaptive170,		"170 byte payload"},
    {MdmAdaptive438,		"438 byte payload"},
*/

	EOERT
};

FMT_ENUM_FUNCS(EErrorCorrectionType);

//----------------------
// Time-Plan Slot Types
//----------------------
enum ETPSlotType {
		TPSlotAvailable,	// Slot is available for assignment
		TPSlotUnavailable,  // Slot is not available, and not assigned (Bad Slot)
		TPSlotReserved,		// Slot has been reserved for a specific modem
		TPSlotAcq			// Slot has been reserved as an aquisition slot
};
#define DefETPSlotTypeInitial TPSlotAvailable

ENUM_TBL(ETPSlotType) =
{
	{TPSlotAvailable,	        "Available"},
	{TPSlotUnavailable,			"Unavailable"},
	{TPSlotReserved,		    "Reserved"},
	{TPSlotAcq,					"Aquisition"},
	EOERT
};

FMT_ENUM_FUNCS(ETPSlotType);

//----------------------
// Event Level Types
//----------------------
enum EEventLevel {
    EvtLevelInfo    = 0,
    EvtLevelWarning = 1,
    EvtLevelError   = 2,
    EvtLevelFatal   = 3,
	EvtLevelNms     = 4, // always notify Nms - maybe just for testing...

	FirstEvtLevel	= 0, // For range checking
	LastEvtLevel	= 4,
	AllEvtLevels	= -1
};
#define DefEEventLevelInitial EvtLevelInfo

ENUM_TBL(EEventLevel) =
{
    {EvtLevelInfo,             "Information"},
    {EvtLevelWarning,          "Warning"},
    {EvtLevelError,            "Error"},
    {EvtLevelFatal,            "Fatal"},
	{EvtLevelNms,              "Nms"},
	{AllEvtLevels,             "All"},
	EOERT
};

FMT_ENUM_FUNCS(EEventLevel);

//----------------------
// Event Class Types
//----------------------
enum EEventClass {
    EvtClassGbl     = 0,
    EvtClassEvt     = 1,
    EvtClassCpp     = 2,
    EvtClassCps     = 3,
    EvtClassMs      = 4,
    EvtClassCu      = 5,
    EvtClassDama    = 6,
    EvtClassLL      = 7,
    EvtClassCrm     = 8,
    EvtClassCd      = 9,
    EvtClassOs      = 10,
    EvtClassMc      = 11,
    EvtClassCf      = 12,
    EvtClassUt      = 13,
    EvtClassSd      = 14,
    EvtClassCp      = 15,
    EvtClassCpm     = 16,
    EvtClassTime    = 17,
    EvtClassNcp     = 18,
    EvtClassTmt     = 19,
    EvtClassRoot    = 20,
    EvtClassMr      = 21,
    EvtClassMif     = 22,
    EvtClassMdm     = 23,
    EvtClassDl      = 24,
    EvtClassFt      = 25,
    EvtClassPvc     = 26,
    EvtClassConf    = 27,
	EvtClassNetworkRemoteDown		= 28,
	EvtClassNetworkRemoteWarning	= 29,
	EvtClassNetworkRemoteUp			= 30,
	EvtClassStats					= 31,
	EvtClassPPHeartbeat				= 32,
	EvtClassUcp		= 33,
	EvtClassAcq		= 34,
	EvtClassRouter	= 35,
	EvtClassPP		= 36,

    EvtClassClasses = 37,	// count

	FirstEvtClass	= 0,	// For range checking
	LastEvtClass	= 36,
	AllEvtClasses	= -1
};
#define DefEEventClassInitial EvtClassGbl

ENUM_TBL(EEventClass) =
{
    {EvtClassGbl,				"Gbl"},
    {EvtClassEvt,				"Evt"},
    {EvtClassCpp,				"Cpp"},
    {EvtClassCps,				"Cps"},
    {EvtClassMs,				"Ms"},
    {EvtClassCu,				"Cu"},
    {EvtClassDama,				"Dama"},
    {EvtClassLL,				"LL"},
    {EvtClassCrm,				"Crm"},
    {EvtClassCd,				"Cd"},
    {EvtClassOs,				"Os"},
    {EvtClassMc,				"Mc"},
    {EvtClassCf,				"Cf"},
    {EvtClassUt,				"Ut"},
    {EvtClassSd,				"Sd"},
    {EvtClassCp,				"Cp"},
    {EvtClassCpm,				"Cpm"},
    {EvtClassTime,				"Time"},
    {EvtClassNcp,				"Ncp"},
    {EvtClassTmt,				"Tmt"},
    {EvtClassRoot,				"Root"},
    {EvtClassMr,				"Mr"},
    {EvtClassMif,				"Mif"},
    {EvtClassMdm,				"Mdm"},
    {EvtClassDl,				"Dl"},
    {EvtClassFt,				"Ft"},
    {EvtClassPvc,				"Pvc"},
    {EvtClassConf,				"Conf"},
	{EvtClassNetworkRemoteDown,	"Down"},
	{EvtClassNetworkRemoteWarning, "Warning"},
	{EvtClassNetworkRemoteUp,	"Up"},
	{EvtClassStats,				"Stats"},
	{EvtClassPPHeartbeat,		"Heartbeat"},
	{EvtClassUcp,				"UCP"},
	{EvtClassAcq,				"ACQ"},
	{AllEvtClasses,				"All"},
	EOERT
};

FMT_ENUM_FUNCS(EEventClass);

//----------------------
// NMS User Permission
// Types
//----------------------
enum EUserPermissionType {
    UsrPermAll      = 0,

    FirstUsrPerm    = 0,
    LastUsrPerm     = 0,
    DefEUserPermissionTypeWildcard
};
#define DefEUserPermissionTypeInitial UsrPermAll

//----------------------
// ProtocolProcessor
// Options Files Types
//----------------------
enum EPPOptionsType {
    PPOptGlobal,
    PPOptNetwork,
    PPOptHub,
    PPOptRemote,

    FirstPPOptType = PPOptGlobal,
    LastPPOptType = PPOptRemote
};

ENUM_TBL(EPPOptionsType) =
{
    {PPOptGlobal,                   "Global"},
    {PPOptNetwork,                  "Network"},
    {PPOptHub,                      "Hub"},
    {PPOptRemote,                   "Remote"},
	EOERT
};

FMT_ENUM_FUNCS(EPPOptionsType);

enum EModemPlatformType
{
	E_INFINITI = 0,
	E_INFINITI_PLUS,
	E_INFINITI_PLUS_HLC,
	E_FUSION,
	E_DARWIN,
	E_INFINITI_HLC,
	E_NUEVO,
	E_G4ORCE
};

enum EModemSubPlatformType
{
	E_UNKNOWN = 0,
	E_eP100
};

ENUM_TBL(EModemPlatformType) =
{
	{E_INFINITI,			"INFINITI"},
	{E_INFINITI_PLUS,		"INFINITI_PLUS"},
	{E_INFINITI_PLUS_HLC,	"INFINITI_PLUS_HLC"},
	{E_FUSION,				"FUSION"},
	{E_DARWIN,				"DARWIN"},
	{E_INFINITI_HLC,		"INFINITI_HLC"},
	{E_NUEVO,               "NUEVO"},
	{E_G4ORCE,              "G4ORCE"},
	EOERT
};

FMT_ENUM_FUNCS(EModemPlatformType);

//--------------------
// NetModem Hardware
// Versions
//--------------------
enum ENetModemVersionType
{
	NMVerNone          =  -1,
	NMVer2             =   0,
	NMVer2Plus         =   1,
 	NMVer1100          =  18,
	NMVer3100          =  19,
	NMVer3125          =  31,
	NMVer5100          =  20,
	NMVer5150          =  23,
 	NMVer5300          =  25,
 	NMVer5350          =  26,
	NMVer7300          =  21,
 	NMVer7350          =  24,
	NMVerM1D1          =  22,
	NMVerM0D1          =  32,
	NMVerM0D1NB        =  36,
	NMVer10300         =  33,
	NMVer10315         =  34,
	NMVer10330         =  35,
	NMVerGPR           =  99,
	NMVeriConnexR      =  29,
	NMVeriConnexH      =  40,
	NMVeriConnex300    =  44,
	NMVer10100         =  42,
	NMVerM1D1iSCPC     =  37,
	NMVer3100NB        =  45,
	NMVerM1D1T         =  47,
	NMVer8350          =  49,
	NMVerM1D1TSS       =  50,
	NMVerXLC_10        = 100,
	NMVerEM1D1		   = 101,
	NMVerXLC_11		   = 102,
	NMVerE7350         = 103,
	NMVerE8350         = 104,
	NMVeriConnexE800   = 105,
	NMVerX3Remote      = 128,
	NMVerEP100         = 129,
	NMVeriConnexE850mp = 132,
	NMVerX5Remote      = 133,
	NMVerXLC_M		   = 134,
	NMVerEM0DM		   = 135,
	NMVerX4Remote      = 136,
	NMVerSCMRemote     = 138,
	NMVerICMRemote     = 139,
	NMVerX1IndoorRemote        = 140,
	NMVerX1OutdoorRemote       = 141,
	NMVerReserved              = 142,
	NMVerTesla                 = 143,
	NMVerMarconi               = 144,
	NMVerE150                  = 145,
	NMVerX7Remote              = 146,
	NMVerProtocolProcessor     = 1024,

	NMVerCount,

	FirstNMVerType = NMVer2,
	LastNMVerType  = NMVerGPR
};

ENUM_TBL(ENetModemVersionType) =
{
	{NMVer2,          "II"},
	{NMVer2Plus,      "II+"},
 	{NMVer1100,       "1000"},
	{NMVer3100,       "3100"},
	{NMVer3125,       "3125"},
	{NMVer5100,       "5100"},
	{NMVer5150,       "5150"},
 	{NMVer5300,       "5300"},
 	{NMVer5350,       "5350"},
	{NMVer7300,       "7300"},
 	{NMVer7350,       "7350"},
	{NMVerM1D1,       "M1D1"},
	{NMVerM0D1,       "M0D1"},
	{NMVerM0D1NB,     "M0D1-NB"},
	{NMVer10300,      "PrivateHub"},
	{NMVer10315,      "MiniHub15"},
	{NMVer10330,      "MiniHub30"},
	{NMVerGPR,        "GPR"},
	{NMVeriConnexR,   "iConnex-700"},
	{NMVeriConnexH,   "iConnex-100"},
	{NMVeriConnex300, "iConnex-300"},
	{NMVer10100,      "PrivateHub-S"},
	{NMVerM1D1iSCPC,  "M1D1-iSCPC"},
	{NMVer3100NB,     "3100-NB"},
	{NMVerM1D1T,      "M1D1-T"},
	{NMVer8350,       "8350"},
	{NMVerM1D1TSS,    "M1D1-TSS"},
	{NMVerXLC_10,     "XLC-10"},
	{NMVerEM1D1,	  "eM1D1"},
	{NMVerEM0DM,	  "eM0DM"},
	{NMVerXLC_11,     "XLC-11"},
	{NMVerE7350,      "e7350"},
	{NMVerE8350,      "e8350"},
	{NMVeriConnexE800,"iConnex-e800"},
	{NMVeriConnexE850mp,"iConnex-e850mp"},
	{NMVerX3Remote,      "X3"},
	{NMVerEP100,      "eP100"},
	{NMVerX5Remote,      "X5"},
	{NMVerXLC_M,      "XLC-M"},
	{NMVerEM0DM,      "eM0DM"},
	{NMVerTesla,      "Tesla"},
	{NMVerMarconi,    "Marconi"},
	{NMVerX4Remote,    "X4"},
	{NMVerSCMRemote,   "SCM"},
	{NMVerICMRemote,   "ICM"},
	{NMVerX1IndoorRemote, "X1-Indoor"},
	{NMVerX1OutdoorRemote, "X1-Outdoor"},
	{NMVerReserved,    "Reserved"},
	{NMVerTesla,       "Tesla-Tx-HLC"},
	{NMVerMarconi,     "Marconi-Rx-HLC"},
	{NMVerE150,        "E150"},
	{NMVerX7Remote,    "X7"},
	{NMVerProtocolProcessor,	"Protocol-Processor"},
	EOERT
};

FMT_ENUM_FUNCS(ENetModemVersionType);

enum EGPSInput
{
	GPSManual  = 0,
	GPSSerial  = 1,
	GPSAntenna = 2,

	GPSCount
};

enum EMobileRemoteType
   {
           Non_mobile = 0,
           Maritime  = 1,
           Vehicle = 2,
           Train = 3,
           Plane = 4,
           MobileRemoteCount
   };


enum EModemType
{
	MT_ERROR		= 0,
	MT_HUB			= 1,
	MT_REMOTE 		= 2,
	MT_PEER			= 4,
	MT_BOOT			= 8,
	MT_LOOP			= 16,
	MT_SCPC_RTN_REMOTE  	= 32,
	MT_NONE			= -1
};

ENUM_TBL(EModemType) =
{
	{MT_ERROR,		"Error Stack"},
	{MT_HUB,		"Line Card"},
	{MT_REMOTE,		"Remote"},
	{MT_PEER,		"Remote: Peer Mode"},
	{MT_BOOT,		"Boot"},
	{MT_LOOP,		"Loopback"},
	{MT_SCPC_RTN_REMOTE,	"Remote: SCPC Return Mode"},
	{MT_NONE,		"No Modem"}
};

FMT_ENUM_FUNCS(EModemType);

enum EAdcType
{
	Adc65Mhz = 0,
	Adc120Mhz = 1
};

ENUM_TBL(EAdcType) =
{
	{Adc65Mhz, "65 Mhz ADC"},
	{Adc120Mhz, "120 Mhz ADC"}
};

FMT_ENUM_FUNCS(EAdcType);

enum EDacType
{
	Dac8Bit120Mhz = 0,
	Dac10Bit120Mhz = 1
};


ENUM_TBL(EDacType) =
{
	{Dac8Bit120Mhz, "8-bit DAC @ 120 Mhz"},
	{Dac10Bit120Mhz, "10-Bit DAC @ 120 Mhz"}
};

FMT_ENUM_FUNCS(EDacType);

enum EFpgaType
{
	FpgaNone = 0,
	FpgaXC3S400 = 1,
	FpgaXC3S1000 = 2,
	FpgaReserved = 3
};

ENUM_TBL(EFpgaType) =
{
	{FpgaNone, "No FPGA"},
	{FpgaXC3S400, "XC 3S-400 FPGA"},
	{FpgaXC3S1000, "XC 3S-1000 FPGA"},
	{FpgaReserved, "Reserved for future use"}
};

FMT_ENUM_FUNCS(EFpgaType);

int GetSkipInteval(ENetModemVersionType modem);
int GetPilotLength();
}

#endif

