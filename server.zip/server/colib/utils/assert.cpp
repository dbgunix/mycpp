//
// Copyright (c) 2002 colib, Inc.  All Rights Reserved
//

#include<utils/assert.h>

namespace colib
{
	static void DoAssert(const char*, const char*, const unsigned)
	{
	}

	void (*OnAssert)(const char* message, const char* file, const unsigned line) = DoAssert;
}

