// time_utils.h
// vi:set ts=4 sw=4 nowrap:

#ifndef TIME_UTILS_H_ALREADY_INCLUDED
#define TIME_UTILS_H_ALREADY_INCLUDED

#include <time.h>
#include <sys/time.h>
#include <unistd.h>
#include <stdint.h>
#include <utils/string.h>

namespace colib
{
	//
	// Format clock (in ms) into format of
	//
	//  ##[DAY]##[HOUR]##[MINUTE]##[SECOND]##[MS]
	//
	string		FormatReadableClockMS(unsigned clock_ms);

    //
    // Format yyyy-mm-dd hh24:mi:ms[.mmmmmm]
    string      GetTimeStr();
    string      FormatTimeStr(time_t ts);
    string      GetTimeofdayStr();
    string      FormatTimeofdayStr(struct timeval& tv);

}//end namespace colib


#endif

