//filter.cpp
// vi:set ts=4 sw=4 nowrap:

#include<utils/filter.h>

namespace colib
{

bool TraceFilter::MakeFilterExpression(FilterExpLogic logic, Filter* f)
{
	switch (logic) {
		case FILTER_SIMPLE:
			if (m_filter)
				return false; // should never happen
			m_filter = f;
			break;
		case FILTER_AND:
			if (m_filter) {
				if (f)
					m_filter = new AndFilter(m_filter, f);
			} else {
				m_filter = f; 
			}
			break;
		case FILTER_OR:
			if (m_filter) {
				if (f)
					m_filter = new OrFilter(m_filter, f);
			} else {
				m_filter = f; 
			}
			break;
		case FILTER_NOT:
			if (f) {
				if (m_filter) {
					return false;
				} else {
					m_filter = new NotFilter(f);		
				}
			} else {
				if (m_filter) {
					m_filter = new NotFilter(m_filter);		
				}
			}
			break;
		default: //
			return false;
	}
	return (m_filter ? true : false);
}

bool TraceFilter::MakeFilterExpression(FilterExpLogic log, TraceFilter& other)
{
	Filter* f = other.GetFilter();
	if (MakeFilterExpression(log, f)) {
		other.TransferFilter();
		return true;
	}
	return false;
}

bool TraceFilter::operator()(const void* item) const {
	return !m_filter || !item || (*m_filter)(item); 
}

};// namespace


