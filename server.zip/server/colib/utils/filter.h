//filter.h
// vi:set ts=4 sw=4 nowrap:

#ifndef FILTER_HEADER_INCLUDED
#define FILTER_HEADER_INCLUDED
#include <stdlib.h>
#include<utils/string.h>

//Base filters

namespace colib
{

enum FilterExpLogic {
	FILTER_SIMPLE,
	FILTER_AND,
	FILTER_OR,
	FILTER_NOT
};

class Filter {
public:
	Filter() {}
	virtual bool operator()(const void*) const = 0;
	virtual string ToString() const = 0;
	virtual ~Filter() {}
};

class NoneFilter : public Filter {
public:
	virtual bool operator()(const void*) const { return false; }
	virtual string ToString() const { return "None"; }
};

class AnyFilter : public Filter {
public:
	virtual bool operator()(const void*) const { return true; };
	virtual string ToString() const { return "Any"; }
};

class UnitaryFilter : public Filter
{
public:
	UnitaryFilter(Filter* f) : m_filter(f) {}
	~UnitaryFilter() { delete m_filter; }
	void SetFilter(Filter* f) { m_filter = f; }

	UnitaryFilter(const UnitaryFilter&) = delete;
	UnitaryFilter& operator=(const UnitaryFilter&) = delete;
protected:
	Filter* m_filter;
};

class BinaryFilter : public Filter {
public:
	BinaryFilter(Filter* f1, Filter* f2) : Filter(),
		m_filter1(f1), m_filter2(f2) {}
	~BinaryFilter() {
		delete m_filter1;
		delete m_filter2;
	}
	void SetFilters(Filter* f1, Filter* f2) {
		m_filter1 = f1;
		m_filter2 = f2;
	}

	BinaryFilter(const BinaryFilter&) = delete;
	BinaryFilter& operator=(const BinaryFilter&) = delete;
protected:
	Filter* m_filter1;
	Filter* m_filter2;
};

class AndFilter : public BinaryFilter {
public:
	AndFilter(Filter* f1, Filter* f2) : BinaryFilter(f1, f2) {}
	virtual bool operator()(const void* item) const {
		return (*m_filter1)(item) && (*m_filter2)(item);
	}
	virtual string ToString() const {
		return string::Format("(AND, %s, %s)", m_filter1->ToString().c_str(),
							  m_filter2->ToString().c_str());
	}
};

class OrFilter : public BinaryFilter {
public:
	OrFilter(Filter* f1, Filter* f2) : BinaryFilter(f1, f2) {}
	virtual bool operator()(const void* item) const {
		return (*m_filter1)(item) || (*m_filter2)(item);
	}

	virtual string ToString() const {
		return string::Format("(OR, %s, %s)", m_filter1->ToString().c_str(),
							  m_filter2->ToString().c_str());
	}
};

class NotFilter : public UnitaryFilter {
public:
	NotFilter(Filter* f) : UnitaryFilter(f) {}
	virtual bool operator()(const void* item) const { return !(*m_filter)(item); }
	virtual string ToString() const {
		return string::Format("(NOT, %s)", m_filter->ToString().c_str());
	}
};

class TraceFilter {
public:
	TraceFilter(Filter* f = NULL) : m_filter(f) {}
	~TraceFilter() { delete m_filter; }
	void SetFilter(Filter* f) { m_filter = f; }
	const Filter* GetFilter() const { return m_filter; }
	Filter* GetFilter() { return m_filter; }
	Filter* TransferFilter() {
		Filter* tmp = m_filter;
		m_filter = NULL;
		return tmp;
	}
	void ResetFilter() {
		delete m_filter;
		m_filter = NULL;
	}

	string ToString() const { return (m_filter ? m_filter->ToString() : ""); }
	bool MakeFilterExpression(FilterExpLogic log, Filter* f);
	bool MakeFilterExpression(FilterExpLogic log, TraceFilter& other);
	bool operator()(const void* item) const;

	TraceFilter(const TraceFilter&) = delete;
	TraceFilter& operator=(const TraceFilter&) = delete;

private:
	Filter* m_filter;
};

}; // name space

#endif


