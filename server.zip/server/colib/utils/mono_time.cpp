#include<utils/mono_time.h>

namespace colib
{

MonoTime::MonoTime()
	: m_ts()
{
}

MonoTime::MonoTime(time_t sec, long int nsec)
	: m_ts()
{
	m_ts.tv_sec = sec;
	m_ts.tv_nsec = nsec;
	Normalize();
}

MonoTime::MonoTime(const MonoTime &other)
	: m_ts(other.m_ts)
{
	//m_tv.tv_sec = other.GetSeconds();
	//m_tv.tv_usec = other.GetUsec();
	Normalize();
}

MonoTime& MonoTime::operator=(const MonoTime &other)
{
	if (this != &other)
	{
		m_ts.tv_sec = other.GetSeconds();
		m_ts.tv_nsec = other.GetNsec();
	}
	return *this;
}

MonoTime& MonoTime::SetToNow()
{
#ifdef CLOCK_MONOTONIC_RAW // Linux 2.6.28 and libc 2.12 only
	clock_gettime(CLOCK_MONOTONIC_RAW, &m_ts);
#else
	clock_gettime(CLOCK_MONOTONIC, &m_ts);
#endif
	return *this;
}

void MonoTime::SetToMsFromNow(uint32_t ms_from_now)
{
	SetToNow();
	IncrementMs(ms_from_now);
}

void MonoTime::IncrementMs(uint32_t ms)
{
	int64_t ns = (m_ts.tv_sec * 1000000000LL) + m_ts.tv_nsec + (ms * 1000000LL);
	m_ts.tv_sec = ns / 1000000000LL;
	m_ts.tv_nsec = ns % 1000000000LL;
}

long MonoTime::GetNowMs()
{
	static MonoTime t;
	return t.SetToNow().ConvertToMs();
}

void MonoTime::Normalize()
{
	// usec overflow
	while (m_ts.tv_nsec >= 1000000000)
	{
		m_ts.tv_nsec -= 1000000000;
		++m_ts.tv_sec;
	}
	// usec underflow
	while (m_ts.tv_nsec < 0)
	{
		m_ts.tv_nsec += 1000000000;
		--m_ts.tv_sec;
	}
}

}
