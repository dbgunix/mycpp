#include<utils/license_prefix.h>

namespace colib
{
	const char* LICENSE_HEADER      = "-----BEGIN COLIB LICENSE-----";
	const char* SIGNATURE_HEADER    = "-----BEGIN COLIB LICENSE SIGNATURE-----";
	const char* SIGNATURE_VERSION   = "Version: colib 1.0";
	const char* SIGNATURE_TRAILER   = "-----END COLIB LICENSE SIGNATURE-----";
}
