// time_utils.cpp
// vi:set ts=4 sw=4 nowrap:

#include <utils/time_utils.h>

namespace colib
{
	string FormatReadableClockMS(unsigned clock)
	{
		static unsigned SECOND  =   1000;
		static unsigned MINUTE  =   60 * SECOND;
		static unsigned HOUR    =   60 * MINUTE;
		static unsigned DAY     =   24 * HOUR;

		// DAY
		int day = clock / DAY;
		clock %= DAY;
		// HOUR
		int hour = clock / HOUR;
		clock %= HOUR;
		// MINUTE
		int minute = clock / MINUTE;
		clock %= MINUTE;
		// SECOND
		int second = clock / SECOND;
		clock %= SECOND;

		string output;

		if ( day ) output.AppendFmt("%d[DAY]", day);
		if ( hour ) output.AppendFmt("%d[HOUR]", hour);
		if ( minute ) output.AppendFmt("%d[MINUTE]", minute);
		if ( second ) output.AppendFmt("%d[SECOND]", second);
		output.AppendFmt("%d[MS]", clock);
		
		return output;
	}

    string      FormatTimeofdayStr(struct timeval& tv)
    {
        time_t now = tv.tv_sec;
        tm *tnow = localtime(&now);
        colib::string output = colib::string::Format("%d-%02d-%02d %02d:%02d:%02d", 
                tnow->tm_year+1900, tnow->tm_mon+1, tnow->tm_mday, tnow->tm_hour, 
                tnow->tm_min, tnow->tm_sec);
        if(tv.tv_usec) output += colib::string::Format(".%06d", (int)tv.tv_usec);
        return output;
    }

    string     GetTimeofdayStr()
    {
        struct timeval val;
        gettimeofday(&val, 0);
        return FormatTimeofdayStr(val);
    }

    string      FormatTimeStr(time_t ts)
    {
        struct timeval val = {ts, 0};
        return FormatTimeofdayStr(val);
    }

    string      GetTimeStr()
    {
        return FormatTimeStr(time(NULL));
    }

}//end namespace colib

