#include<utils/string.h>

#include <string.h>
#include <limits.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>

#include<utils/system/memory.h>

#include<utils/system/machine.h>

namespace colib
{
//GLOBAL string class booleans
bool string::oper_eq(const char* const a,const char* const b)
{
	return strcmp(a,b)==0;
}
bool string::oper_gt(const char* const a,const char* const b)
{
	return strcmp(a,b) > 0;
}
bool string::oper_lt(const char*a,const char*b)
{
	return strcmp(a,b) < 0;
}
bool string::oper_find(const char*a,const char*b)
{
	if(strstr(a,b) != 0) return true;

	return false;
}

///////////////////////////////////CLASS STRBUF
string::strbuf::~strbuf()
{
	if(m_data && m_owns)
		xfree(m_data);
}

string::strbuf::strbuf()
	: m_data(0)
	, m_mem(0)
	, m_owns(true)
	, m_is_data_exposed(false)
	, m_length(0)
	, m_refcount(1)
{
}

string::strbuf::strbuf(const char *of,bool separate)
	: m_data(0)
	, m_mem(0)
	, m_owns(true)
	, m_is_data_exposed(false)
	, m_length(0)
	, m_refcount(1)
{
	if( !of )
	{
		// nothing to do, init params are valid for this case
	}else if( separate )
	{
		m_owns=true;
		m_is_data_exposed = false;
		m_mem=strlen(of)+1;
		m_data=(char*)xmalloc(m_mem);
		if(!m_data) {
			m_mem=0;
			m_length = 0;
		} else {
			strcpy(m_data,of);
			m_length = m_mem - 1;
		}

	}else
	{
		// warning we are casting a * to const to a normal pointer
		// while the owns flag is set to false, nothing untoward should
		// happen, but bewarned
		m_mem=0;
		m_data=(char*)of;
		m_owns=false;
		m_is_data_exposed = true;
		m_length = 0; // the lenght is not reliable
	}
}

string::strbuf::strbuf(const strbuf &of)
	: m_data(0)
	, m_mem(0)
	, m_owns(true)
	, m_is_data_exposed(false)
	, m_length(0)
	, m_refcount(1)
{
	if( of.m_data )
	{
		m_mem = of.quick_strlen()+1;
		if( (m_data = (char*)xmalloc(m_mem))!=0 )
		{
			strcpy(m_data,of.m_data);
			m_length = m_mem - 1;
		}else {
			m_mem=0;
			m_length = 0;
		}
	}
}

string::strbuf::strbuf(unsigned max)
	: m_data(0)
	, m_mem(0)
	, m_owns(true)
	, m_is_data_exposed(false)
	, m_length(0)
	, m_refcount(1)
{
	if( (m_data = (char*)xmalloc(max))!=0 )
	{
		m_mem= max;
		m_data[0]='\0';
	}
}

string::strbuf::strbuf(const char *of,unsigned len)
	: m_data(0)
	, m_mem(0)
	, m_owns(true)
	, m_is_data_exposed(false)
	, m_length(0) // Do not set length = len because strlen(of) may be less than len
	, m_refcount(1)
{
	if( of )
	{
		char *tmp = (char*)xmalloc(len+1);
		if(tmp)
		{
			strncpy(tmp,of,len);
			tmp[len] = '\0';
			m_data=tmp;
			m_mem=len+1;
		}else
		{
			m_data = 0;
			m_mem = 0;
		}
	}
}

unsigned string::strbuf::quick_strlen() const
{
	return (IsLengthValid() ? GetLength() : strlen(m_data));
}

///////////////////////////////////CLASS STRING

string& string::operator=(const string &to)
{
	strbuf *tb = to.m_buf;
	if(tb)
		tb->IncRefCount();
	if(m_buf)
	{
		m_buf->DecRefCount();
		if(m_buf->GetRefCount() == 0)
			delete m_buf;
	}
	m_buf=tb;
	return *this;
}
//
char* string::internal_get_buffer(bool exposeData)
{
	if(!separate())
		return 0;
	char* ret = m_buf->GetData();
	if (exposeData && ret) {
		m_buf->SetDataExposed();
	}
	return ret;
}
unsigned string::get_length()const
{
	if(!m_buf || !m_buf->const_get_data() )
		return 0;
	if (m_buf->IsLengthValid()) {
		return m_buf->GetLength();
	} else {
#ifdef DEBUG_STRLEN
		printf("call strlen to get length\n");
#endif
		m_buf->SetLength(strlen(m_buf->const_get_data()));
		return m_buf->GetLength();
	}
}

unsigned string::get_maxlength()const
{
	if(m_buf&&m_buf->GetMem() > 0)
		return m_buf->GetMem() - 1;
	return 0;
}

void string::clear()
{
	if(m_buf)
	{
		m_buf->DecRefCount();;
		if(m_buf->GetRefCount() == 0)
			delete m_buf;
		m_buf=0;
	}
}

void string::reset()
{
	char *str_buf = internal_get_buffer(false);
	if (str_buf)
	{
		str_buf[0] = '\0';
	}
	else
	{
		clear();
	}
}
string string::Format( const char *format, ... )
{
	va_list args;
	string ret;
	va_start(args,format);
	ret = string::vFormat(format,args);
	va_end(args);
	return ret;
}
bool string::AppendFmt( const char *format, ...)
{
	va_list args;
	bool ret;
	va_start(args,format);
	ret = vAppendFmt(format,args);
	va_end(args);
	return ret;
}

void string::truncate(unsigned max_length)
{
	if(m_buf&&separate()&&m_buf->GetMem() > max_length)
		(m_buf->GetData())[max_length]='\0';
}

char* string::detach()
{
	char *ret = 0;
	if(!m_buf)
	{
		ret = 0;
	}else if(m_buf->GetRefCount() > 1 || !m_buf->IsOwner())
	{
		if( m_buf->const_get_data() )
		{
			unsigned len = m_buf->quick_strlen()+1;
			//spawn new string
			ret = (char*)xmalloc(len);
			if( !ret )
				return 0;
			strcpy(ret,m_buf->const_get_data());
		}else
			ret = 0;
		m_buf->DecRefCount();
		if( m_buf->GetRefCount() < 1)
			delete m_buf;
		m_buf=0;
	}else
	{
		ret = m_buf->TransferData();
		delete m_buf;
		m_buf=0;
	}
	return ret;
}
bool string::attach(char *newbuf,unsigned bufsize)
{
	if( !m_buf )
	{
		m_buf = new strbuf;
	}else if( m_buf->GetRefCount() > 1 )
	{
		strbuf *newb = new strbuf;
		m_buf->DecRefCount();
		m_buf = newb;
	}else if( m_buf->const_get_data() && m_buf->IsOwner() )
	{
		xfree(m_buf->GetData());
	}
	m_buf->SetData(newbuf);
	m_buf->SetOwner(true);
	if( newbuf )
	{
		m_buf->SetMem(bufsize);
		if( bufsize>0 )
			m_buf->SetCharAt(bufsize-1, '\0');
	}else
		m_buf->SetMem(0);
	return true;
}
bool string::attach_cnt(char *newbuf)
{
	if(!m_buf)
	{
		m_buf = new strbuf;
	}else if(m_buf->GetRefCount() > 1)
	{
		strbuf *newb = new strbuf;
		m_buf->DecRefCount();
		m_buf = newb;
	}else if(m_buf->const_get_data() && m_buf->IsOwner())
	{
		xfree(m_buf->GetData());
	}
	m_buf->SetData(newbuf);
	m_buf->SetOwner(true);
	if(newbuf)
	{
		unsigned len = strlen(newbuf);
		m_buf->SetMem(len + 1);
		m_buf->SetLength(len);
	}else
		m_buf->SetMem(0);
	return true;
}
bool string::set_maxlength(unsigned maxlength)
{
	maxlength++;
	if(!m_buf)
	{
		m_buf = new strbuf(maxlength);
		return m_buf!= 0 && m_buf->const_get_data();
	}
	if(m_buf->GetRefCount() > 1)
	{
		// following code is an optimized version of separate
		strbuf *newb = new strbuf(maxlength);
		if(!newb)
			return false;
		if(!(newb->const_get_data()))
		{
			delete newb;
			return false;
		}
		if(m_buf->const_get_data())
			strncpy(newb->GetData(),m_buf->const_get_data(),maxlength-1);
		newb->SetCharAt(maxlength-1, '\0');
		m_buf->DecRefCount();
		m_buf=newb;
		return true;
	}
	if(m_buf->IsOwner() && maxlength==m_buf->GetMem())
		return true;
	char *tmp=(char*)xmalloc(maxlength);
	if(!tmp)
		return false;
	if(m_buf->const_get_data())
	{
		strncpy(tmp,m_buf->const_get_data(),maxlength-1);
		if(m_buf->IsOwner())
			xfree(m_buf->GetData());
	}
	tmp[maxlength-1]='\0';
	m_buf->SetData(tmp);
	m_buf->SetMem(maxlength);
	m_buf->SetOwner(true);
	return true;
}

bool string::separate()
{
	if(!m_buf)
	{
		m_buf = new strbuf;
		return m_buf!= 0;
	}
	if(m_buf->GetRefCount() > 1)
	{
		strbuf *newb = new strbuf(*m_buf);
		if(m_buf->const_get_data() && !newb->const_get_data() )
		{
			delete newb;
			return false;
		}
		m_buf->DecRefCount();
		m_buf=newb;
		return true;
	}
	if( !m_buf->IsOwner() )
	{
		if( m_buf->const_get_data() )
		{
			// since I am not the owner of the string, I cannot turst
			// the length field. Use strlen(...) directly
			unsigned len = strlen( m_buf->const_get_data() ) + 1;
			char *tmp=(char*)xmalloc(len);
			if(!tmp)
				return false;
			strcpy( tmp, m_buf->const_get_data() );
			m_buf->SetDataAndLen(tmp, len - 1);
			m_buf->SetMem(len);
		}
		m_buf->SetOwner(true);
	}
	return true;
}
string string::catenate(const char*a,const char*b)
{
	string r;
	r.m_buf = new strbuf;

	unsigned alen,ttllen;
	alen=ttllen= a ? strlen(a) : 0;
	ttllen+= b ? strlen(b)+1 : 1;
	if(r.set_maxlength(ttllen) )
	{
		if( a )
			strcpy(r.m_buf->GetData(),a);
		strcpy(r.m_buf->GetData() + alen, b ? b : "" );
		r.m_buf->SetLength(ttllen - 1);
	}

	return r;
}

// Naming like stl::string::find_first_not_of
// This method returns a positive number (including 0)
// when it finds the string
// The return value is negative, if it didn't find it
int string::find_first_not_of(const char* other)
{
	unsigned iLen = get_length();
	if(iLen < strlen(other)) {
		return -1;
	}

	const char* me = c_str();
	unsigned i = 0;
	while (i < iLen) {
		if(me[i] != other[i]) {
			return i;
		}
		++i;
	}

	return -2;
}
// TODO: consider remove or rename
void string::truncate_tail()
{
	unsigned iLen = get_length();

	const char* me = c_str();
	unsigned i = iLen - 1;
	while (i > 0) {
		if(me[i] == '\n' || me[i] == '\t' || me[i] == '\r') {
			truncate(i);
		}
		else
		{
			return;
		}
		--i;
	}
	return;
}
// This method returns a string starting at the first
// character which is different
colib::string string::find_first_not_of(const string &other)
{
	int iPos = find_first_not_of(other.c_str());
	if (iPos < 0) {
		return colib::string("");
	}

	colib::string strDiff(&c_str()[iPos]);
	return strDiff;
}

string& string::operator+=(const char *add)
{
	if( add )
	{
		// add non null
		unsigned nlen = strlen(add);
		if( !m_buf )
		{
			m_buf = new strbuf(nlen+1);
			if(!m_buf->const_get_data())
				return *this;
			strcpy(m_buf->GetData(), add);
		}else
		{
			unsigned clen = get_length();
			unsigned newsize = nlen + clen + 1;

			if( m_buf->GetRefCount() > 1 )
			{
				//buffer split
				strbuf *newb = new strbuf( newsize );
				if(!newb->const_get_data())
				{
					delete newb;
					return *this;
				}
				strncpy(newb->GetData(),m_buf->const_get_data(), clen);
				strncpy(newb->GetData()+clen,add,nlen);
				newb->SetCharAt(nlen+clen, '\0');
				newb->SetLength(nlen+clen);
				m_buf->DecRefCount();
				m_buf = newb;
			}else if( newsize > m_buf->GetMem() )
			{
				//primitive realloc
				// this condition should also catch buffer-non-ownership
				// (newsize is at least 1 and buf->mem will be 0)
				if(newsize < 2 * m_buf->GetMem())
					newsize = 2 * m_buf->GetMem();

				char *newm = (char*)xmalloc(newsize);
				if(!newm)
					return *this;
				strncpy(newm,m_buf->const_get_data(),clen);
				strncpy(newm+clen,add,nlen);
				newm[nlen+clen]='\0';
				if( m_buf->const_get_data() && m_buf->IsOwner() )
					xfree(m_buf->GetData());
				m_buf->SetDataAndLen(newm, clen + nlen);
				m_buf->SetOwner(true);
				m_buf->SetMem(newsize);
			}else
			{
				strncpy(m_buf->GetData()+clen,add,nlen);
						m_buf->SetCharAt(nlen+clen, '\0');
						m_buf->SetLength(nlen+clen);
			}
		}
	}
	return *this;
}
string& string::operator+=(char add)
{
	if( add )
	{
		// add non '\0'
		if( !m_buf )
		{
			m_buf = new strbuf(2);
			if(!m_buf->const_get_data())
				return *this;
			m_buf->SetCharAt(0, add);
			m_buf->SetCharAt(1, '\0');
			m_buf->SetLength(1);
		}else
		{
			unsigned clen = get_length();
			unsigned newsize = clen + 2;

			if( m_buf->GetRefCount() > 1 )
			{
				//buffer split
				strbuf *newb = new strbuf( newsize );
				if(!newb->const_get_data())
				{
					delete newb;
					return *this;
				}
				char * tmpData = newb->GetData();
				strncpy(tmpData,m_buf->const_get_data(),clen);
				tmpData[clen]=add;
				tmpData[clen+1]='\0';
				m_buf->DecRefCount();
				m_buf = newb;
				m_buf->SetLength(clen + 1);
			}else if( newsize > m_buf->GetMem() )
			{
				//primitive realloc
				// this condition should also catch buffer-non-ownership
				// (newsize is at least 1 and buf->mem will be 0)
				if(newsize < 2 * m_buf->GetMem() )
					newsize = 2 * m_buf->GetMem();

				char *newm = (char*)xmalloc(newsize);
				if(!newm)
					return *this;
				strncpy(newm,m_buf->const_get_data(),clen);
				newm[clen]=add;
				newm[clen+1]='\0';
				if( m_buf->const_get_data() && m_buf->IsOwner() )
					xfree(m_buf->GetData());
				m_buf->SetDataAndLen(newm, clen + 1);
				m_buf->SetOwner(true);
				m_buf->SetMem(newsize);
			}else
			{
				char * tmpData = m_buf->GetData();
				tmpData[clen]=add;
				tmpData[clen+1]='\0';
				m_buf->SetLength(clen+1);
			}
		}
	}
	return *this;
}
string string::combine(const char *a,...)
{
	va_list args;
	const char *str=a;
	char *into;
	unsigned ttllen=0;
	string retval;
	// count argument length, terminated by a null pointer
	va_start(args,a);
	while(str!=0)
	{
		ttllen+=strlen(str);
		str = va_arg(args,const char *);
	}
	va_end(args);
	//catenate arguments
	if(!retval.set_maxlength(ttllen+1) )
		return retval;
	into = retval.internal_get_buffer(false);
	str=a;
	va_start(args,a);
	while(str!=0)
	{
		strcpy(into,str);
		into += strlen(str);
		str = va_arg(args,const char *);
	}
	va_end(args);
	return retval;
}

//the following function is derived from glib
int string::CalcFormatLimit( const char *format, va_list args )
{
	return vsnprintf(NULL,0,format,args);
}

string string::vFormat( const char *format, va_list args )
{
	string ret;

	va_list args_copy;
	/*this may be incorrect for some platforms, see glib G_VA_COPY */
	va_copy(args_copy, args);
	int reserve = CalcFormatLimit(format,args_copy) + 1;
	va_end(args_copy);

	if(reserve > 1 )
	{
		char *buf = (char*)xmalloc(reserve);

		if(buf)
		{
			buf[0]='\0';
			int len = vsnprintf( buf, reserve, format, args );
			buf[reserve-1]='\0';
			if( !ret.attach(buf,reserve) ) {
				xfree(buf);
			} else {
				// assert len <= reserve and len >= 0
				ret.m_buf->SetLength(len);
			}
		}
	}

	return ret;
}

// This method is slow, because it calls vsnprintf.
// Nothing we can do about it at this time
bool string::vAppendFmt( const char *format, va_list args)
{
	va_list args_copy;
	/*this may be incorrect for some platforms, see glib G_VA_COPY */
	va_copy(args_copy, args);

	int reserve = CalcFormatLimit(format,args_copy) + 1;
	va_end(args_copy);

	if(reserve > 1 )
	{
		unsigned nlen = (unsigned)reserve;
		int count = 0;
		if( !m_buf )
		{
			m_buf = new strbuf(nlen);
			if(!m_buf->const_get_data())
				return false;
			char * tmpData = m_buf->GetData();
			count = vsnprintf( tmpData, reserve, format, args );
			tmpData[nlen-1]='\0';
			m_buf->SetLength(count);
		}else
		{
			int clen = get_length();
			unsigned newsize = nlen + clen;

			if( m_buf->GetRefCount() > 1 )
			{
				//buffer split
				strbuf *newb = new strbuf( newsize );
				if(!newb->const_get_data())
				{
					delete newb;
					return false;
				}
				char* tmpData = newb->GetData();
				strncpy(tmpData,m_buf->const_get_data(),clen);
				count = vsnprintf( tmpData + clen, reserve, format, args );
				tmpData[nlen+clen-1]='\0';
				newb->SetLength(clen + count);
				m_buf->DecRefCount();
				m_buf = newb;
			}else if( newsize > m_buf->GetMem() )
			{
				//primitive realloc
				// this condition should also catch buffer-non-ownership
				// (newsize is at least 1 and buf->mem will be 0)
				if(newsize < 2 * m_buf->GetMem() )
					newsize = 2 * m_buf->GetMem();

				char *newm = (char*)xmalloc(newsize);
				if(!newm)
					return false;
				strncpy(newm,m_buf->const_get_data(),clen);
				count = vsnprintf( newm+clen, reserve, format, args );
				newm[nlen+clen-1]='\0';
				if( m_buf->const_get_data() && m_buf->IsOwner())
					xfree(m_buf->GetData());
				m_buf->SetDataAndLen(newm, clen + count);
				m_buf->SetOwner(true);
				m_buf->SetMem(newsize);
			}else
			{
				char *tmpData = m_buf->GetData();
				count = vsnprintf( tmpData + clen, reserve, format, args );
				tmpData[nlen+clen-1]='\0';
				m_buf->SetLength(clen + count);
			}
		}
	}
	return true;
}

void string::ucase()
{
	char *tmpbuf = internal_get_buffer(false);
	unsigned count = 0;
	while (*tmpbuf != 0)
	{
		*tmpbuf = toupper(*tmpbuf);
		tmpbuf++;
		count ++;
	}
	m_buf->SetLength(count);
}


// debug use only
bool string::GetStatus(void*& bufPos, unsigned& capacity,
					bool& isOwned, bool& isExposed, unsigned& len,
					unsigned& getlen, int& ref) const
{
	bufPos = (void*)m_buf;

	capacity = m_buf ? m_buf->GetMem() : 0;
	isOwned = m_buf ? m_buf->IsOwner() : false;
	isExposed = m_buf ? m_buf->IsDataExposed() : false;
	getlen = get_length();
	ref = m_buf ? m_buf->GetRefCount() : 0;
	len = m_buf ? m_buf->GetLength() : 0;


	if (!m_buf) return true;

	return (!m_buf->IsLengthValid() || getlen == len);
}

}
