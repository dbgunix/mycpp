//
// Copyright 2001 colib,  All Rights Reserved.
//
// Module:
//    imemory.cpp
//
// History:
//    2001-06-19: DE	Original Version.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include<utils/imemory.h>
#include<utils/iassert.h>

//
// DEBUG section: Begin
//

#ifdef DEBUG
typedef struct sChunk      // allocation information
{
   void*       mpMemory;   // pointer to allocated memory
   unsigned    mSize;      // size of allocated memory
   const char* mpFile;     // file (allocation source)
   long        mLine;      // line (allocation source)
} Chunk;

static bool    ChunkInitialize(void);
static void    ChunkTerminate(void);
static void    ChunkReport(
                     const char*    stream);
static void*   ChunkAlloc(
                     const char*    apFile,
                     const int      aLine,
                     const unsigned aSize);
static void    ChunkFree(
                     const char*    apFile,
                     const int      aLine,
                     void*          apMemory);
#endif

//
// DEBUG section: End
//

#if defined(__GNUC__)
#include <pthread.h>
   typedef pthread_mutex_t PlatformCriticalSection;
   #define PlatformCriticalSectionInitialize(c) pthread_mutex_init(&(c),NULL)
   #define PlatformCriticalSectionEnter(c)      pthread_mutex_lock(&(c))
   #define PlatformCriticalSectionLeave(c)      pthread_mutex_unlock(&(c))
   #define PlatformCriticalSectionTerminate(c)  pthread_mutex_destroy(&(c))
#else
   typedef CRITICAL_SECTION PlatformCriticalSection;
   #define PlatformCriticalSectionInitialize(c) InitializeCriticalSection(&(c))
   #define PlatformCriticalSectionEnter(c)      EnterCriticalSection(&(c))
   #define PlatformCriticalSectionLeave(c)      LeaveCriticalSection(&(c))
   #define PlatformCriticalSectionTerminate(c)  DeleteCriticalSection(&(c))
#endif

//
// Each pool node is linked to it's siblings+++
//

typedef unsigned char Word8;
typedef unsigned long Word32;

typedef struct sPoolNode
{
   struct sPoolNode*    mpNext;        // right sibling
   struct sPoolNode**   mppPrevNext;   // left siblings ipNext
} PoolNode;

//
// Each pool is a chain of poolnodes
//

typedef struct sPool
{
   PoolNode*         mpFirst;             // latest node addition
   int               mFlags;              // flags passed to PoolAlloc
   unsigned          mSize;               // size of elements (if appl.)
   PlatformCriticalSection  mCriticalSection;   // thread safe
} Pool;

static int              gsInitialized=0;     // Module init. flag
static ALLOCHandler*	gspfALLOC=0;
static REALLOCHandler*	gspfREALLOC=0;
static FREEHandler*     gspfFREE=0;
static void*            gspOcean=0;          // Heap pointer
static unsigned         gsOceanSize=0;       // Heap size
static unsigned         gsOceanLevel=0;      // Heap fill level
static PlatformCriticalSection gsCriticalSection;  // thread safe

//
// Calculates the alignment "size" of an element/node/etc.
// The size argument will be increased if necessary to make sure it is
// evenly divisible by the size of a long.
//
// Arguments:
//    aSize       Size of an object.
//
// Returns:       Resized value of argument.
//

#ifdef DEBUG
static unsigned RoundSize(
                  const unsigned   aSize)
{
   unsigned lResult;                            // return value
   
   lResult=aSize%sizeof(Word32);                // remainder?
   if (lResult==0) lResult=aSize;               // no, size is aligned
   else lResult=aSize+(sizeof(Word32)-lResult); // yes, re-size
   
   return (lResult);                            // done
}
#endif

//
// Performs module cleanup on program termination.
//
// Returns:    N/A.
//

static void MemoryExitHandler(void)
{
#ifndef DEBUG
   MemoryTerminate(true);     // Release: Silent exit
#else
   MemoryTerminate(false);    // DEBUG: Report leaks, etc.
#endif
}

//
// Routines used for lazy initialization (ALLOC, REALLOC, FREE)
//

static void* MemoryALLOC(const unsigned aBytes)
{
	return (malloc(aBytes));
}

static void* MemoryREALLOC(void* apPointer, const unsigned aBytes)
{
	return (realloc(apPointer, aBytes));
}

static void MemoryFREE(void* apPointer)
{
	free(apPointer);
}

//
// Global new/delete (DEBUG mode only)
//

#ifdef DEBUG

#ifdef new
#undef new
#endif

void* operator new(const size_t aBytes)
{
	return (MemoryAlloc(aBytes));
}

void* operator new(const size_t aBytes, const char* apFile, const unsigned aLine)
{
	return (libMemoryAlloc(apFile, aLine, aBytes));
}

void operator delete(void* apPointer)
{
	MemoryFree(apPointer);
}

void* operator new[](const size_t aBytes)
{
	return (MemoryAlloc(aBytes));
}

void* operator new[](const size_t aBytes, const char* apFile, const unsigned aLine)
{
	return (libMemoryAlloc(apFile, aLine, aBytes));
}

void operator delete[](void* apPointer)
{
	MemoryFree(apPointer);
}
#endif

//
// Used to initialize the memory management sub-system.  This must
// be called before any other calls into this module.
//
// (See header file for arguments/return-value descriptions)
//

LIBDEFINE(bool   ,            MemoryInitialize)(
                                 FUNCFILELINE
                                 void*             apOcean,
                                 const unsigned    aSize,
                                 ALLOCHandler*		apfALLOC,
                                 REALLOCHandler*	apfREALLOC,
				 				 FREEHandler*		apfFREE)
{
   bool     lResult;       // return value

   AssertCommon(apfALLOC!=0);
   AssertCommon(apfREALLOC!=0);
   AssertCommon(apfFREE!=0);

   lResult=true;           // default
   if (gsInitialized==0)   // first time?
   {
      AssertCommon(apOcean==0 || (apOcean!=0 && aSize>0));
   
      lResult=false;       // not yet ready
   gspfALLOC=apfALLOC;
   gspfREALLOC=apfREALLOC;
   gspfFREE=apfFREE;
      gspOcean=apOcean;
      gsOceanSize=aSize;
      gsOceanLevel=0;
   
#ifdef DEBUG
      lResult=ChunkInitialize(); // init leak tracking
#endif

      PlatformCriticalSectionInitialize(gsCriticalSection);   // thread safe
         if (atexit(MemoryExitHandler)==0)   // termination
         {
            lResult=true;     // we're done
            gsInitialized=1;  // remember for later
         }
   }

   return (lResult);          // done
}

//
// Used to terminate the memory management sub-system.  Once called
// no other calls may be made into this module.  If DEBUG is defined
// then this function will report resource leaks.
//
// (See header file for arguments/return-value descriptions)
//

LIBDEFINE(void,               MemoryTerminate)(
                                 FUNCFILELINE
                                 const bool        aSilent)
{
   if (gsInitialized!=0)                  // ignore if not init.
   {
      AssertCommon(gsInitialized>0);
      
      if (!aSilent) MemoryReport(0); // report leaks
      
#ifdef DEBUG
      ChunkTerminate();                   // clean up tracking
#endif

/***** To be completed:  Problem is destructors that use the free store.
      PlatformCriticalSectionTerminate(gsCriticalSection);
      gsInitialized=0;
*****/
   }
}

//
// Writes a report of current memory usage statistics.
//
// (See header file for arguments/return-value descriptions)
//

LIBDEFINE(void,               MemoryReport)(
                                 FUNCFILELINE
                                 const char*      stream)
{
   (void)stream;

   AssertCommon(gsInitialized!=0);

#ifdef DEBUG
   ChunkReport(stream);                         // report leaks
#endif
}

//
// Used to add a low-memory condition handler.
//
// (See header file for arguments/return-value descriptions)
//

LIBDEFINE(void,               MemoryRequestInsert)(
                                 FUNCFILELINE
                                 FMemRequestHandler*  apfHandler,
                                 void*                apContext)
{
   AssertCommon(gsInitialized!=0);
   AssertCommon(apfHandler!=0);

   (void)apfHandler;
   (void)apContext;
}

//
// Used to remove a low-memory condition handler.  If 'apContext' is
// zero, then all handlers using 'apfHandler' are removed.
//
// (See header file for arguments/return-value descriptions)
//

LIBDEFINE(void,               MemoryRequestRemove)(
                                 FUNCFILELINE
                                 FMemRequestHandler*  apfHandler,
                                 void*                apContext)
{
   AssertCommon(gsInitialized!=0);
   AssertCommon(apfHandler!=0);

   (void)apfHandler;
   (void)apContext;
}

//
// Used to allocate memory for an object.
//
// (See header file for arguments/return-value descriptions)
//

LIBDEFINE(void*,              MemoryAlloc)(
                                 FUNCFILELINE
                                 const unsigned    aElementSize)
{
   void* lpMemory;         // return value

   if (!gsInitialized) (void)MemoryInitialize(0,0, MemoryALLOC, MemoryREALLOC, MemoryFREE);
   
   AssertCommon(gsInitialized!=0);
   AssertCommon(aElementSize>0);

   lpMemory=0;                   // default value
   {
#ifndef  DEBUG
      lpMemory=gspfALLOC(aElementSize); // allocate memory
#else
      lpMemory=ChunkAlloc(apFile, aLine, aElementSize);
#endif
   }
   
   return (lpMemory);         // done
}

//
// Used to free memory allocated for an object.
//
// (See header file for arguments/return-value descriptions)
//

LIBDEFINE(void,               MemoryFree)(
                                 FUNCFILELINE
                                 void*             apMemory)
{
   AssertCommon(gsInitialized!=0);

   //AssertCommon(apMemory!=0);
   if (apMemory==0) return;
   
   {
#ifndef  DEBUG
      gspfFREE(apMemory);             // free memory
#else
      ChunkFree(apFile, aLine, apMemory); // free
#endif
   }
}

//
// Used to allocate a Memory Pool.  Memory pools are used to more
// efficiently allocate space for small objects of the same size.  The
// overhead is small when compared to using MemAlloc/MemFree.  Typically
// approaching one bit per object.  Using pools can also reduce swapping
// in virtual memory since, 'like' objects tend to be co-located.
//
// (See header file for arguments/return-value descriptions)
//

LIBDEFINE(HMemPool,           MemoryPoolAlloc)(
                                 FUNCFILELINE
                                 const int         aFlags,
                                 const unsigned    aElementSize)
{
   Pool* lpPool;           // return value
   
   AssertCommon(gsInitialized!=0);
   //AssertCommon(aElementSize>=0);

   lpPool=(Pool*)MemoryAlloc(sizeof(Pool));   // new pool
   if (lpPool!=0)          // success?
   {
      lpPool->mpFirst=0;            // empty list
      lpPool->mFlags=aFlags;        // set flags
      lpPool->mSize=aElementSize;   // set size
      PlatformCriticalSectionInitialize(lpPool->mCriticalSection); // safe
   }
   
   return ((HMemPool)lpPool);    // done
}

//
// Used to release a Memory Pool.  Any memory allocated through this
// pool (and not yet released) will be freed.
//
// (See header file for arguments/return-value descriptions)
//

LIBDEFINE(void,               MemoryPoolFree)(
                                 FUNCFILELINE
                                 const HMemPool    aMemPool)
{
   Pool*       lpPool;        // pool pointer
   PoolNode*   lpNode;        // pool node pointer

   AssertCommon(gsInitialized!=0);

   lpPool=(Pool*)aMemPool;       // cast to pool pointer
   if (lpPool!=0)                // not free store?
   {
      lpNode=lpPool->mpFirst;    // start at head
      while (lpNode!=0)          // do all nodes
      {
         PoolNode*   lpTemp;     // temp pool node

         lpTemp=lpNode;          // save for freeing
         lpNode=lpNode->mpNext;  // get next node
#ifndef  DEBUG
         gspfFREE(lpTemp);      // free node
#else
         ChunkFree(apFile, aLine, lpTemp); // free
#endif
      }
      PlatformCriticalSectionTerminate(lpPool->mCriticalSection); // safe
      MemoryFree(lpPool);      // free pool
   }
}

//
// Used to allocate memory for an object.  Storage will be allocated
// from the memory pool indicated in the first argument.
//
// (See header file for arguments/return-value descriptions)
//

LIBDEFINE(void*,              MemoryPoolMemoryAlloc)(
                                 FUNCFILELINE
                                 const HMemPool    aMemPool,
                                 const unsigned    aElementSize)
{
   Pool* lpPool;           // pool pointer
   void* lpMemory;         // return value
   
   AssertCommon(gsInitialized!=0);
   AssertCommon(aMemPool!=0);
   AssertCommon(aElementSize>0);

   lpMemory=0;                   // default value
   lpPool=(Pool*)aMemPool;       // cast to pointer
   {
      PoolNode*   lpNode;        // pool node pointer
      
      AssertCommon((lpPool->mSize==0) || (lpPool->mSize==aElementSize));
      
#ifndef  DEBUG
      lpNode=(PoolNode*)gspfALLOC(   // allocate node
               sizeof(PoolNode)+aElementSize);
#else
      lpNode=(PoolNode*)ChunkAlloc(       // allocate node
               apFile, aLine, 
               sizeof(PoolNode)+aElementSize);
#endif
      if (lpNode!=0)             // success?
      {
         PoolNode*   lpFirst;    // temp
         
         PlatformCriticalSectionEnter(lpPool->mCriticalSection);
         // link up node in pool node chain
         lpFirst=lpPool->mpFirst;
         lpNode->mpNext=lpFirst; 
         lpNode->mppPrevNext=&(lpPool->mpFirst);
         if (lpFirst!=0)
         {
            lpFirst->mppPrevNext=&(lpNode->mpNext);
         }
         lpPool->mpFirst=lpNode;
         PlatformCriticalSectionLeave(lpPool->mCriticalSection);
         
         // return pointer to data area of node
         lpNode+=1;
         lpMemory=lpNode;
      }
   }
   
   return (lpMemory);         // done
}

//
// Used to free memory allocated for an object.
//
// (See header file for arguments/return-value descriptions)
//

LIBDEFINE(void,               MemoryPoolMemoryFree)(
                                 FUNCFILELINE
                                 const HMemPool    aMemPool,
                                 void*             apMemory)
{
   Pool* lpPool;           // pool pointer

   AssertCommon(gsInitialized!=0);
   AssertCommon(aMemPool!=0);
   AssertCommon(apMemory!=0);
   
   lpPool=(Pool*)aMemPool;       // cast to pool pointer
   {
      PoolNode*   lpNode;     // pool node

      lpNode=(PoolNode*)apMemory;   // cast from area
      lpNode-=1;                    // back up to pool node

      // unlink from pool node chain
      PlatformCriticalSectionEnter(lpPool->mCriticalSection);
      if (lpNode->mpNext!=0)
      {
         lpNode->mpNext->mppPrevNext=lpNode->mppPrevNext;
      }
      *(lpNode->mppPrevNext)=lpNode->mpNext;
      PlatformCriticalSectionLeave(lpPool->mCriticalSection);
#ifndef  DEBUG
      gspfFREE(lpNode);               // free node
#else
      ChunkFree(apFile, aLine, lpNode);   // free
#endif
   }
}

//
// Used to copy a block of memory (wrapper for memcpy).
//

LIBDEFINE(void,               MemoryCopy)(
                                 FUNCFILELINE
                                 void*             apDestination,
                                 const void*       apSource,
                                 const unsigned    aSize)
{
   AssertCommon(apDestination!=0);
   AssertCommon(apSource!=0);
   AssertCommon(aSize>0);
   
   (void)memcpy(apDestination, apSource, aSize); // copy block
}

//
// Used to fill a block of memory (wrapper for memset).
//

LIBDEFINE(void,               MemoryFill)(
                                 FUNCFILELINE
                                 void*             apMemory,
                                 const int         aValue,
                                 const unsigned    aSize)
{
   AssertCommon(apMemory!=0);
   AssertCommon(aSize>0);
   
   (void)memset(apMemory, aValue, aSize); // fill block
}

//
// Description:
//    This part is only inluded in the DEBUG version.  It provides
//    resource allocation tracking, and is to be used by developers
//    only.  This code is never to be included in release versions.
//

//
// DEBUG section: Begin
//

#ifdef DEBUG

#define INITIAL_BLOCKS     64       // preallocate # blocks
#define CHUNKS_PER_BLOCK   1024     // grow by # of chunks

static Chunk*  gspChunks=0;
static long*   gspFreeChunks=0;
static long    gsChunkBlocks;
static long    gsChunkTop;
static long    gsFreeChunkTop;
static Chunk   gsDeletedChunks[CHUNKS_PER_BLOCK];
static long    gsDeletedIndex;

static void ChunkBlockClear(Chunk* apChunks)
{
   Chunk*   lpChunk;
   int      lCount;
   
   lpChunk=apChunks;
   for (lCount=0; lCount<CHUNKS_PER_BLOCK; lCount++, lpChunk++)
   {
      lpChunk->mpMemory=0;
   }
}

static bool    ChunkInitialize(void)
{
   bool     lResult;
   unsigned lElements;

   Assert(gspChunks==0);

   lResult=false;
   gsChunkBlocks=0;
   lElements=INITIAL_BLOCKS*CHUNKS_PER_BLOCK;
   gspChunks=(Chunk*)gspfALLOC(lElements*sizeof(Chunk));
   if (gspChunks!=0)
   {
      gspFreeChunks=(long*)gspfALLOC(lElements*sizeof(long));
      if (gspFreeChunks!=0)
      {
         ChunkBlockClear(gspChunks);
         gsChunkBlocks=INITIAL_BLOCKS;
         ChunkBlockClear(gsDeletedChunks);
         gsDeletedIndex=0;
         gsChunkTop=0;
         gsFreeChunkTop=0;
         lResult=true;
      }
      else
      {
         gspfFREE(gspChunks);
         gspChunks=0;
      }
   }
   return (lResult);
}

static void ChunkTerminate(void)
{
/***** To be completed:  Problem is destructors that use the free store.
   if (gspChunks!=0)
   {
      if (gspFreeChunks!=0)
      {
         gspfFREE(gspFreeChunks);
         gspFreeChunks=0;
      }
      gspfFREE(gspChunks);
      gspChunks=0;
   }
*****/
}

static void ChunkReport(const char* stream)
{
   FILE* lpFILE=stdout;

   (void)stream;

   if (gspChunks!=0)
   {
      long  lTotalSize;
      long  lTotalOccurances;
      long  lOuterCount;
      
      lTotalSize=0;
      lTotalOccurances=0;
      for ( lOuterCount=0;
         lOuterCount<(CHUNKS_PER_BLOCK*gsChunkBlocks);
         lOuterCount++)
      {
         Chunk*   lpOuterChunk;
         
         lpOuterChunk=&gspChunks[lOuterCount];
         if (  (lpOuterChunk->mpMemory!=0)
            && (lpOuterChunk->mLine>0))
         {
            long  lOccurances;
            long  lInnerCount;
            
            lOccurances=1;
            for ( lInnerCount=lOuterCount+1;
               lInnerCount<(CHUNKS_PER_BLOCK*gsChunkBlocks);
               lInnerCount++)
            {
               Chunk*   lpInnerChunk;
               
               lpInnerChunk=&gspChunks[lInnerCount];
               if (  (lpInnerChunk->mpMemory != 0)
                  && (lpOuterChunk->mSize == lpInnerChunk->mSize)
                  && (lpOuterChunk->mpFile == lpInnerChunk->mpFile)
                  && (lpOuterChunk->mLine == lpInnerChunk->mLine))
               {
                  lOccurances++;
                  lpInnerChunk->mLine*=(-1);
               }
            }
            lTotalOccurances+=lOccurances;
            lTotalSize+=(long)(lOccurances*lpOuterChunk->mSize);
            fprintf(lpFILE,
               "Allocated Memory: %s[%ld]: %ld bytes, %ld occurance(s).\n",
               lpOuterChunk->mpFile, lpOuterChunk->mLine,
               (long)lpOuterChunk->mSize, lOccurances);
         }
      }
      for (lOuterCount=0; lOuterCount<(CHUNKS_PER_BLOCK*gsChunkBlocks); lOuterCount++)
      {
         Chunk*   lpOuterChunk;
         
         lpOuterChunk=&gspChunks[lOuterCount];
         if (lpOuterChunk->mLine<0) lpOuterChunk->mLine*=(-1);
      }
      if (lTotalOccurances>0)
      {
         fprintf(lpFILE,
            "\nTotal Allocated Memory: %ld bytes in %ld occurance(s) [%ld].\n",
            lTotalSize, lTotalOccurances, (long)gsOceanLevel);
      }
   }
}

static bool    ChunkBlockGrow(void)
{
   bool     lResult;
   Chunk*   lpChunks;
   long* lpFreeChunks;
   unsigned lElements;
   
   Assert(gspChunks!=0);
   
   lElements=(unsigned)(CHUNKS_PER_BLOCK*(gsChunkBlocks+1));
   lpChunks=(Chunk*)gspfREALLOC(gspChunks,(lElements*sizeof(Chunk)));
   lResult=(lpChunks!=0);
   if (lResult)
   {
      lpFreeChunks=(long*)gspfREALLOC(gspFreeChunks,(lElements*sizeof(long)));
      lResult=(lpFreeChunks!=0);
      if (lResult)
      {
         gspChunks=lpChunks;
         gspFreeChunks=lpFreeChunks;
         ChunkBlockClear(gspChunks+(CHUNKS_PER_BLOCK*gsChunkBlocks));
         gsChunkBlocks++;
      }
   }
   return (lResult);
}

static Chunk* GetFreeChunk(long* apIndex)
{
   Chunk*   lpChunk;
   long  lIndex;

   if (gsFreeChunkTop>0)
   {
      lIndex=gspFreeChunks[--gsFreeChunkTop];
   }
   else if (gsChunkTop<(CHUNKS_PER_BLOCK*gsChunkBlocks))
   {
      lIndex=gsChunkTop++;
   }
   else if (ChunkBlockGrow())
   {
      lIndex=gsChunkTop++;
   }
   else lIndex=0;
   lpChunk=&gspChunks[lIndex];
   
   *apIndex=lIndex;
   return (lpChunk);
}

const Word32   SENTINEL_ALLOC = 0xCCCCCCCCUL;
const Word32   SENTINEL_FREE  = 0xDDDDDDDDUL;
const Word8    MARKER_ALLOC   = 0xCC;
const Word8    MARKER_FREE    = 0x00;

static void* ChunkAlloc(const char* apFile, const int aLine, const unsigned aSize)
{
   Chunk*   lpChunk;
   void*    lpMemory;
   long     lIndex;
   
   lpMemory=0;
   PlatformCriticalSectionEnter(gsCriticalSection);
   if ((gsOceanSize==0) || (gsOceanSize>=(gsOceanLevel+aSize)))
   {
      lpChunk=GetFreeChunk(&lIndex);
      if (lpChunk!=0)
      {
         Word32*  lpULong;
      
         lpMemory=gspfALLOC((3*sizeof(Word32))+RoundSize(aSize));
         if (lpMemory!=0)
         {
            lpULong=(Word32*)lpMemory;
            *lpULong++=(Word32)lIndex;
            *lpULong++=SENTINEL_ALLOC;
            lpMemory=lpULong;
            lpChunk->mpMemory=lpMemory;
            lpChunk->mSize=aSize;
            lpChunk->mpFile=apFile;
            lpChunk->mLine=aLine;
         }
      }
      if (lpMemory!=0) gsOceanLevel+=aSize;
   }
   PlatformCriticalSectionLeave(gsCriticalSection);
   if (lpMemory!=0)
   {
      MemoryFill(lpMemory,MARKER_ALLOC,RoundSize(aSize)+sizeof(Word32));
   }
   
   return (lpMemory);
}

static void ChunkFree(const char* apFile, const int aLine, void* apMemory)
{
   Word32*  lpULong;
   Word8*   lpUChar;
   long     lIndex;
   Chunk*   lpChunk;
   
   lpULong=(Word32*)apMemory;
   PlatformCriticalSectionEnter(gsCriticalSection);
   lpULong--;
   if (*lpULong!=SENTINEL_ALLOC)
   {
      long  lFound;
      long  lCount;
      
      lFound=CHUNKS_PER_BLOCK;
      for (lCount=0; lCount<CHUNKS_PER_BLOCK; lCount++)
      {
         if (gsDeletedChunks[lCount].mpMemory==apMemory)
         {
            lFound=lCount;
            break;
         }
      }
      if (lFound!=CHUNKS_PER_BLOCK)
      {
         Chunk*   lpDeleted;
         lpDeleted=&gsDeletedChunks[lFound];
         fprintf(stderr,
            "edgxMemory: Memory released multiple times: %s[%d].\n",
            apFile, aLine);
         fprintf(stderr,
            "edgxMemory: Original allocation information: %s[%ld]: %ld bytes.\n",
            lpDeleted->mpFile, lpDeleted->mLine, (long)lpDeleted->mSize);
         AssertCommon(*lpULong==SENTINEL_ALLOC);
      }
      else
      {
         fprintf(stderr,
            "edgxMemory: Head-Sentinel corrupted: %s[%d].\n",
            apFile, aLine);
         AssertCommon(*lpULong==SENTINEL_ALLOC);
      }
   }
   *lpULong=SENTINEL_FREE;
   lpULong--;
   lIndex=(long)(*lpULong);
   if (lIndex>=(CHUNKS_PER_BLOCK*gsChunkBlocks))
   {
      long  lFound;
      long  lCount;
      
      lFound=CHUNKS_PER_BLOCK;
      for (lCount=0; lCount<CHUNKS_PER_BLOCK; lCount++)
      {
         if (gsDeletedChunks[lCount].mpMemory==apMemory)
         {
            lFound=lCount;
            break;
         }
      }
      if (lFound!=CHUNKS_PER_BLOCK)
      {
         Chunk*   lpDeleted;
         lpDeleted=&gsDeletedChunks[lFound];
         fprintf(stderr,
            "edgxMemory: Memory released multiple times: %s[%d].\n",
            apFile, aLine);
         fprintf(stderr,
            "edgxMemory: Original allocation information: %s[%ld]: %ld bytes.\n",
            lpDeleted->mpFile, lpDeleted->mLine, (long)lpDeleted->mSize);
         AssertCommon(lIndex<(CHUNKS_PER_BLOCK*gsChunkBlocks));
      }
      else
      {
         fprintf(stderr,
            "edgxMemory: Head-Sentinel corrupted: %s[%d].\n",
            apFile, aLine);
         AssertCommon(lIndex<(CHUNKS_PER_BLOCK*gsChunkBlocks));
      }
   }
   lpChunk=&gspChunks[lIndex];
   if (apMemory!=(lpChunk->mpMemory))
   {
      long  lFound;
      long  lCount;
      
      lFound=CHUNKS_PER_BLOCK;
      for (lCount=0; lCount<CHUNKS_PER_BLOCK; lCount++)
      {
         if (gsDeletedChunks[lCount].mpMemory==apMemory)
         {
            lFound=lCount;
            break;
         }
      }
      if (lFound!=CHUNKS_PER_BLOCK)
      {
         Chunk*   lpDeleted;
         lpDeleted=&gsDeletedChunks[lFound];
         fprintf(stderr,
            "edgxMemory: Memory released multiple times: %s[%d].\n",
            apFile, aLine);
         fprintf(stderr,
            "edgxMemory: Original allocation information: %s[%ld]: %ld bytes.\n",
            lpDeleted->mpFile, lpDeleted->mLine, (long)lpDeleted->mSize);
         AssertCommon(lpDeleted==0);
      }
      else
      {
         fprintf(stderr,
            "edgxMemory: Memory released is not marked as allocated: %s[%d].\n",
            apFile, aLine);
         AssertCommon(apMemory==(lpChunk->mpMemory));
      }
   }
   lpUChar=(Word8*)(lpULong+2);
   if (lpUChar[lpChunk->mSize]!=MARKER_ALLOC)
   {
      fprintf(stderr,
         "edgxMemory: Tail-Sentinel corrupted: %s[%d].\n",
         apFile, aLine);
      fprintf(stderr,
         "edgxMemory: Original allocation information: %s[%ld]: %ld bytes.\n",
         lpChunk->mpFile, lpChunk->mLine, (long)lpChunk->mSize);
      AssertCommon(lpUChar[lpChunk->mSize]==MARKER_ALLOC);
   }
   MemoryFill(lpUChar,MARKER_FREE,lpChunk->mSize);
   gsDeletedChunks[gsDeletedIndex++]=*lpChunk;
   if (gsDeletedIndex==CHUNKS_PER_BLOCK) gsDeletedIndex=0;
   gspFreeChunks[gsFreeChunkTop++]=lIndex;
   gsOceanLevel-=lpChunk->mSize;
   lpChunk->mpMemory=0;
   PlatformCriticalSectionLeave(gsCriticalSection);
   gspfFREE(lpULong);
}

LIBDEFINE(bool,               MemoryIsValid)(
                                 FUNCFILELINE
                                 void*             apMemory)
{
   Word32*  lpULong;
   Word8*   lpUChar;
   long     lIndex;
   Chunk*   lpChunk;
   
   if (apMemory==0)
   {
      fprintf(stderr,
         "edgxMemory: apMemory==0: %s[%d].\n",
         apFile, aLine);
      return (false);
   }
   lpULong=(Word32*)apMemory;
   PlatformCriticalSectionEnter(gsCriticalSection);
   lpULong--;
   if (*lpULong!=SENTINEL_ALLOC)
   {
      long  lFound;
      long  lCount;
      
      lFound=CHUNKS_PER_BLOCK;
      for (lCount=0; lCount<CHUNKS_PER_BLOCK; lCount++)
      {
         if (gsDeletedChunks[lCount].mpMemory==apMemory)
         {
            lFound=lCount;
            break;
         }
      }
      if (lFound!=CHUNKS_PER_BLOCK)
      {
         Chunk*   lpDeleted;
         lpDeleted=&gsDeletedChunks[lFound];
         fprintf(stderr,
            "edgxMemory: Memory released multiple times: %s[%d].\n",
            apFile, aLine);
         fprintf(stderr,
            "edgxMemory: Original allocation information: %s[%ld]: %ld bytes.\n",
            lpDeleted->mpFile, lpDeleted->mLine, (long)lpDeleted->mSize);
      }
      else
      {
         fprintf(stderr,
            "edgxMemory: Head-Sentinel corrupted: %s[%d].\n",
            apFile, aLine);
      }
      PlatformCriticalSectionLeave(gsCriticalSection);
      return (false);
   }
   lpULong--;
   lIndex=(long)(*lpULong);
   if (lIndex>=(CHUNKS_PER_BLOCK*gsChunkBlocks))
   {
      long  lFound;
      long  lCount;
      
      lFound=CHUNKS_PER_BLOCK;
      for (lCount=0; lCount<CHUNKS_PER_BLOCK; lCount++)
      {
         if (gsDeletedChunks[lCount].mpMemory==apMemory)
         {
            lFound=lCount;
            break;
         }
      }
      if (lFound!=CHUNKS_PER_BLOCK)
      {
         Chunk*   lpDeleted;
         lpDeleted=&gsDeletedChunks[lFound];
         fprintf(stderr,
            "edgxMemory: Memory released multiple times: %s[%d].\n",
            apFile, aLine);
         fprintf(stderr,
            "edgxMemory: Original allocation information: %s[%ld]: %ld bytes.\n",
            lpDeleted->mpFile, lpDeleted->mLine, (long)lpDeleted->mSize);
      }
      else
      {
         fprintf(stderr,
            "edgxMemory: Head-Sentinel corrupted: %s[%d].\n",
            apFile, aLine);
      }
      PlatformCriticalSectionLeave(gsCriticalSection);
      return (false);
   }
   lpChunk=&gspChunks[lIndex];
   if (apMemory!=(lpChunk->mpMemory))
   {
      long  lFound;
      long  lCount;
      
      lFound=CHUNKS_PER_BLOCK;
      for (lCount=0; lCount<CHUNKS_PER_BLOCK; lCount++)
      {
         if (gsDeletedChunks[lCount].mpMemory==apMemory)
         {
            lFound=lCount;
            break;
         }
      }
      if (lFound!=CHUNKS_PER_BLOCK)
      {
         Chunk*   lpDeleted;
         lpDeleted=&gsDeletedChunks[lFound];
         fprintf(stderr,
            "edgxMemory: Memory released multiple times: %s[%d].\n",
            apFile, aLine);
         fprintf(stderr,
            "edgxMemory: Original allocation information: %s[%ld]: %ld bytes.\n",
            lpDeleted->mpFile, lpDeleted->mLine, (long)lpDeleted->mSize);
      }
      else
      {
         fprintf(stderr,
            "edgxMemory: Memory released is not marked as allocated: %s[%d].\n",
            apFile, aLine);
      }
      PlatformCriticalSectionLeave(gsCriticalSection);
      return (false);
   }
   lpUChar=(Word8*)(lpULong+2);
   if (lpUChar[lpChunk->mSize]!=MARKER_ALLOC)
   {
      fprintf(stderr,
         "edgxMemory: Tail-Sentinel corrupted: %s[%d].\n",
         apFile, aLine);
      fprintf(stderr,
         "edgxMemory: Original allocation information: %s[%ld]: %ld bytes.\n",
         lpChunk->mpFile, lpChunk->mLine, (long)lpChunk->mSize);
      PlatformCriticalSectionLeave(gsCriticalSection);
      return (false);
   }
   PlatformCriticalSectionLeave(gsCriticalSection);
   return (true);
}

#endif

//
// DEBUG section: End
//
