#ifndef SYSTEM_ENVIRON_HPP
#define SYSTEM_ENVIRON_HPP

#if defined (__ARMEB__)
#define PLATFORM_LINUX
#define COMPILER_GNUC
#define HARDWARE_IXP
#elif defined (__PPC__)
#define PLATFORM_LINUX
#define COMPILER_GNUC
#define HARDWARE_PPC
#elif defined(__GNUC__)
#define PLATFORM_LINUX
#define COMPILER_GNUC
#define HARDWARE_I386
#else
#error Platform Not Supported!
#endif

#endif

