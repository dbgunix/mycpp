#ifndef SYSTEM_MEMORY_H
#define SYSTEM_MEMORY_H


// commnet out ifdef for NMEMDEBUG
// when DEBUG_FIND_MEM_LEAK is used.
//
// Use this to find memory which we allocate
// but don't free. This is for special cases
// where other memory leak tools fail
// because we are actually freeing the 
// memeory on exit
//#define DEBUG_FIND_MEM_LEAK 1

#ifndef DEBUG_FIND_MEM_LEAK
	#define NMEMDEBUG 1
#endif

#ifndef NMEMDEBUG
#define MEMFUNCPREFIX const char* file, unsigned line,
#define MEMCALLPREFIX __FILE__, __LINE__,
#else
#define MEMFUNCPREFIX
#define MEMCALLPREFIX
#endif

#ifdef __cplusplus
extern "C" {
#endif
	typedef void xcallback(const char* string, void* context);

	void xreport(xcallback* callback, unsigned clock, void* context);

#ifdef DEBUG_FIND_MEM_LEAK
	void SetBoolGo(void);
	void PrintBT(void);

	char* _xstrdup(MEMFUNCPREFIX const char *str);
	void* _xcalloc(MEMFUNCPREFIX unsigned nmemb, unsigned size);
	void* _xmalloc(MEMFUNCPREFIX unsigned size);
	void* _xrealloc(MEMFUNCPREFIX void* ptr, unsigned size);
	void _xfree(MEMFUNCPREFIX void* ptr);
#endif
#ifdef __cplusplus
} // extern "C"
#endif

#ifdef DEBUG_FIND_MEM_LEAK
#define xstrdup(str)		_xstrdup(MEMCALLPREFIX (str))
#define xcalloc(nmemb,size)	_xcalloc(MEMCALLPREFIX (nmemb), (size))
#define xmalloc(size)		_xmalloc(MEMCALLPREFIX (size))
#define xrealloc(ptr,size)	_xrealloc(MEMCALLPREFIX (ptr), (size))
#define xfree(ptr)			_xfree(MEMCALLPREFIX (ptr))
#else
#define xstrdup(str)		strdup((str))
#define xcalloc(nmemb,size)	calloc((nmemb), (size))
#define xmalloc(size)		malloc((size))
#define xrealloc(ptr,size)	realloc((ptr), (size))
#define xfree(ptr)		free((ptr))
#endif

#endif
