#ifndef SYSTEM_MACHINE_HPP
#define SYSTEM_MACHINE_HPP

#include<utils/system/endian.h>

#include <sys/types.h>
#include <limits.h>
#include <stdint.h>

namespace colib
{

#if (NETWORK_BYTE_ORDER == MACHINE_BYTE_ORDER)
template <class T>
inline T FLIP (const T value) {
        return value;
}

template <class T>
inline T FLOP (T& ref, const T value) {
	ref = value;
}

template <class T>
inline T FLIP64 (const T value) {
        return value;
}

template <class T>
inline T FLOP64 (T& ref, const T value) {
        ref = value;
}
#else
inline bool FLIP(const bool value)
{
	return value;
}

inline void FLOP(bool& ref, const bool value)
{
	ref = value;
}

inline unsigned char FLIP(const unsigned char value)
{
	return value;
}

inline void FLOP(unsigned char& ref, const unsigned char value)
{
	ref = value;
}

inline unsigned short FLIP(const unsigned short value)
{
	unsigned short result;
	((unsigned char*)&result)[0] = ((const unsigned char*)&value)[1];
	((unsigned char*)&result)[1] = ((const unsigned char*)&value)[0];
	return result;
}

inline void FLOP(unsigned short& ref, const unsigned short value)
{
	((unsigned char*)&ref)[0] = ((const unsigned char*)&value)[1];
	((unsigned char*)&ref)[1] = ((const unsigned char*)&value)[0];
}

inline unsigned int FLIP(const unsigned int value)
{
	unsigned int result;
	((unsigned char*)&result)[0] = ((const unsigned char*)&value)[3];
	((unsigned char*)&result)[1] = ((const unsigned char*)&value)[2];
	((unsigned char*)&result)[2] = ((const unsigned char*)&value)[1];
	((unsigned char*)&result)[3] = ((const unsigned char*)&value)[0];
	return result;
}

inline void FLOP(unsigned int& ref, const unsigned int value)
{
	((unsigned char*)&ref)[0] = ((const unsigned char*)&value)[3];
	((unsigned char*)&ref)[1] = ((const unsigned char*)&value)[2];
	((unsigned char*)&ref)[2] = ((const unsigned char*)&value)[1];
	((unsigned char*)&ref)[3] = ((const unsigned char*)&value)[0];
}

inline signed char FLIP(const signed char value)
{
	return value;
}

inline void FLOP(signed char& ref, const signed char value)
{
	ref = value;
}

inline signed short FLIP(const signed short value)
{
	signed short result;
	((unsigned char*)&result)[0] = ((const unsigned char*)&value)[1];
	((unsigned char*)&result)[1] = ((const unsigned char*)&value)[0];
	return result;
}

inline void FLOP(signed short& ref, const signed short value)
{
  	((unsigned char*)&ref)[0] = ((const unsigned char*)&value)[1];
  	((unsigned char*)&ref)[1] = ((const unsigned char*)&value)[0];
}

inline signed int FLIP(const signed int value)
{
	signed int result;
	((unsigned char*)&result)[0] = ((const unsigned char*)&value)[3];
	((unsigned char*)&result)[1] = ((const unsigned char*)&value)[2];
	((unsigned char*)&result)[2] = ((const unsigned char*)&value)[1];
	((unsigned char*)&result)[3] = ((const unsigned char*)&value)[0];
	return result;
}

inline void FLOP(signed int& ref, const signed int value)
{
	((unsigned char*)&ref)[0] = ((const unsigned char*)&value)[3];
	((unsigned char*)&ref)[1] = ((const unsigned char*)&value)[2];
	((unsigned char*)&ref)[2] = ((const unsigned char*)&value)[1];
	((unsigned char*)&ref)[3] = ((const unsigned char*)&value)[0];
}

inline void FLOP64(int64_t& ref, const int64_t value)
{
	((unsigned char*)&ref)[0] = ((const unsigned char*)&value)[7];
	((unsigned char*)&ref)[1] = ((const unsigned char*)&value)[6];
	((unsigned char*)&ref)[2] = ((const unsigned char*)&value)[5];
	((unsigned char*)&ref)[3] = ((const unsigned char*)&value)[4];
	((unsigned char*)&ref)[4] = ((const unsigned char*)&value)[3];
	((unsigned char*)&ref)[5] = ((const unsigned char*)&value)[2];
	((unsigned char*)&ref)[6] = ((const unsigned char*)&value)[1];
	((unsigned char*)&ref)[7] = ((const unsigned char*)&value)[0];
}

inline int64_t FLIP64(const int64_t value)
{
	int64_t result;
	FLOP64(result, value);
	return result;
}

inline void FLOP64(uint64_t& ref, const uint64_t value)
{
	((unsigned char*)&ref)[0] = ((const unsigned char*)&value)[7];
	((unsigned char*)&ref)[1] = ((const unsigned char*)&value)[6];
	((unsigned char*)&ref)[2] = ((const unsigned char*)&value)[5];
	((unsigned char*)&ref)[3] = ((const unsigned char*)&value)[4];
	((unsigned char*)&ref)[4] = ((const unsigned char*)&value)[3];
	((unsigned char*)&ref)[5] = ((const unsigned char*)&value)[2];
	((unsigned char*)&ref)[6] = ((const unsigned char*)&value)[1];
	((unsigned char*)&ref)[7] = ((const unsigned char*)&value)[0];
}

inline uint64_t FLIP64(const uint64_t value)
{
	uint64_t result;
	FLOP64(result, value);
	return result;
}

inline signed long FLIP(const signed long value)
{
#if (__WORDSIZE == 64)
	return FLIP64(value);
#else
	signed long result;
	((unsigned char*)&result)[0] = ((const unsigned char*)&value)[3];
	((unsigned char*)&result)[1] = ((const unsigned char*)&value)[2];
	((unsigned char*)&result)[2] = ((const unsigned char*)&value)[1];
	((unsigned char*)&result)[3] = ((const unsigned char*)&value)[0];
	return result;
#endif
}

inline void FLOP(signed long& ref, const signed long value)
{
#if (__WORDSIZE == 64)
	FLOP64(ref, value);
#else
	((unsigned char*)&ref)[0] = ((const unsigned char*)&value)[3];
	((unsigned char*)&ref)[1] = ((const unsigned char*)&value)[2];
	((unsigned char*)&ref)[2] = ((const unsigned char*)&value)[1];
	((unsigned char*)&ref)[3] = ((const unsigned char*)&value)[0];
#endif
}

inline unsigned long FLIP(const unsigned long value)
{
#if (__WORDSIZE == 64)
	return FLIP64(value);
#else
	unsigned long result;
	((unsigned char*)&result)[0] = ((const unsigned char*)&value)[3];
	((unsigned char*)&result)[1] = ((const unsigned char*)&value)[2];
	((unsigned char*)&result)[2] = ((const unsigned char*)&value)[1];
	((unsigned char*)&result)[3] = ((const unsigned char*)&value)[0];
	return result;
#endif
}

inline void FLOP(unsigned long& ref, const unsigned long value)
{
#if (__WORDSIZE == 64)
	FLOP64(ref, value);
#else
	((unsigned char*)&ref)[0] = ((const unsigned char*)&value)[3];
	((unsigned char*)&ref)[1] = ((const unsigned char*)&value)[2];
	((unsigned char*)&ref)[2] = ((const unsigned char*)&value)[1];
	((unsigned char*)&ref)[3] = ((const unsigned char*)&value)[0];
#endif
}

inline float FLIP(const float value)
{
	float result;
	((unsigned char*)&result)[0] = ((const unsigned char*)&value)[3];
	((unsigned char*)&result)[1] = ((const unsigned char*)&value)[2];
	((unsigned char*)&result)[2] = ((const unsigned char*)&value)[1];
	((unsigned char*)&result)[3] = ((const unsigned char*)&value)[0];
	return result;
}

inline void FLOP(float &ref, const float value)
{
	((unsigned char*)&ref)[0] = ((const unsigned char*)&value)[3];
	((unsigned char*)&ref)[1] = ((const unsigned char*)&value)[2];
	((unsigned char*)&ref)[2] = ((const unsigned char*)&value)[1];
	((unsigned char*)&ref)[3] = ((const unsigned char*)&value)[0];
}

inline double FLIP(const double value)
{
	double result;
	((unsigned char*)&result)[0] = ((const unsigned char*)&value)[7];
	((unsigned char*)&result)[1] = ((const unsigned char*)&value)[6];
	((unsigned char*)&result)[2] = ((const unsigned char*)&value)[5];
	((unsigned char*)&result)[3] = ((const unsigned char*)&value)[4];
	((unsigned char*)&result)[4] = ((const unsigned char*)&value)[3];
	((unsigned char*)&result)[5] = ((const unsigned char*)&value)[2];
	((unsigned char*)&result)[6] = ((const unsigned char*)&value)[1];
	((unsigned char*)&result)[7] = ((const unsigned char*)&value)[0];
	return result;
}

inline void FLOP(double &ref, const double value)
{
	((unsigned char*)&ref)[0] = ((const unsigned char*)&value)[7];
	((unsigned char*)&ref)[1] = ((const unsigned char*)&value)[6];
	((unsigned char*)&ref)[2] = ((const unsigned char*)&value)[5];
	((unsigned char*)&ref)[3] = ((const unsigned char*)&value)[4];
	((unsigned char*)&ref)[4] = ((const unsigned char*)&value)[3];
	((unsigned char*)&ref)[5] = ((const unsigned char*)&value)[2];
	((unsigned char*)&ref)[6] = ((const unsigned char*)&value)[1];
	((unsigned char*)&ref)[7] = ((const unsigned char*)&value)[0];
}

#endif

}

#endif
