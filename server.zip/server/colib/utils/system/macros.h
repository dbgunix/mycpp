#ifndef SYSTEM_MACROS_HPP
#define SYSTEM_MACROS_HPP

#include<utils/system/environ.h>
#include<utils/system/endian.h>
#include<utils/system/machine.h>

#include <stdint.h>

namespace colib
{

#ifdef __ARMEB__
#define HEADER_MACROS_ALIGN1
#endif


#if (NETWORK_BYTE_ORDER == MACHINE_BYTE_ORDER)
inline uint16_t X16 (uint16_t v)
{
	return v;
}
inline uint32_t X32 (uint32_t v)
{
	return v;
}
#else
inline uint16_t X16 (uint16_t v)
{
	return (((((v) >> 0) & 0xFF) << 8)|
		((((v) >> 8) & 0xFF) << 0));
}
inline uint32_t X32 (uint32_t v)
{
	return (((((v) >> 0) & 0xFF) << 24)|
		((((v) >> 8) & 0xFF) << 16)|
		((((v) >> 16) & 0xFF) << 8)|
		((((v) >> 24) & 0xFF) << 0));
}
#endif


//PTR_ADV
//
template <class T>
inline int8_t* PTR_ADV8 (void* p, T o){
	return (reinterpret_cast<int8_t*>(p)) + (o);
}

template <class T>
inline int16_t* PTR_ADV16 (void* p, T o){
	return (reinterpret_cast<int16_t*>(p)) + (o);
}

template <class T>
inline int32_t* PTR_ADV32 (void* p, T o){
	return (reinterpret_cast<int32_t*>(p)) + (o);
}

//RAW_GET
//
inline unsigned char RAW_GET8(const void* p){
	return (*(unsigned char*)(p));
}
inline uint16_t RAW_GET16(const void *p){
#if defined(HEADER_MACROS_ALIGN1)
	uint16_t result;
	((unsigned char*)&result)[0] = ((unsigned char*)p)[0];
	((unsigned char*)&result)[1] = ((unsigned char*)p)[1];
	return result;
#else
	return (*(uint16_t*)(p));
#endif

}
inline uint32_t RAW_GET32(const void *p){
#if defined(HEADER_MACROS_ALIGN1)
	uint32_t result;
	((unsigned char*)&result)[0] = ((unsigned char*)p)[0];
	((unsigned char*)&result)[1] = ((unsigned char*)p)[1];
	((unsigned char*)&result)[2] = ((unsigned char*)p)[2];
	((unsigned char*)&result)[3] = ((unsigned char*)p)[3];
	return result;
#elif defined(HEADER_MACROS_ALIGN2)
	uint32_t result;
	((unsigned short*)&result)[0] = ((unsigned short*)p)[0];
	((unsigned short*)&result)[1] = ((unsigned short*)p)[1];
	return result;
#else
	return (*(uint32_t*)(p));
#endif
}

inline void* RAW_GET_PTR(const void* p)
{
#if defined(__ARMEB__)
	return reinterpret_cast<void*>(RAW_GET32(p));
#else
	return (*(void **)(p));
#endif
}

//RAW_SET
//
inline void RAW_SET8(void* p, unsigned char v){
	*(unsigned char*)(p) = (v);
}
inline void RAW_SET16(void *p, uint16_t v) {
#if defined(HEADER_MACROS_ALIGN1)
	((unsigned char*)p)[0] = ((unsigned char*)&v)[0];
	((unsigned char*)p)[1] = ((unsigned char*)&v)[1];
#else
	*(uint16_t*)(p) = (v);
#endif
}

inline void RAW_SET32(void *p, uint32_t v) {
#if defined(HEADER_MACROS_ALIGN1)
	((unsigned char*)p)[0] = ((unsigned char*)&v)[0];
	((unsigned char*)p)[1] = ((unsigned char*)&v)[1];
	((unsigned char*)p)[2] = ((unsigned char*)&v)[2];
	((unsigned char*)p)[3] = ((unsigned char*)&v)[3];
#elif defined(HEADER_MACROS_ALIGN2)
	((unsigned short*)p)[0] = ((unsigned short*)&v)[0];
	((unsigned short*)p)[1] = ((unsigned short*)&v)[1];
#else
	*(uint32_t*)(p) = (v);
#endif
}

inline void RAW_SET_PTR(void* p, void* v)
{
#if defined(__ARMEB__)
	RAW_SET32(p, *(uint32_t*)v);
#else
	*(void**)(p) = (v);
#endif
}

//NET_GET
//
inline unsigned char NET_GET8(const void* p){
	return (*(unsigned char*)(p));
}
inline uint16_t NET_GET16(const void *p){
	return X16(RAW_GET16(p));
}

inline uint32_t NET_GET32(const void *p){
	return X32(RAW_GET32(p));
}

//NET_SET
//
inline void NET_SET8(void* p, unsigned char v){
	*(unsigned char*)(p) = (v);
}
inline void NET_SET16(void *p, uint16_t v){
	RAW_SET16(p, X16(v));
}
inline void NET_SET32(void *p, uint32_t v){
	RAW_SET32(p, X32(v));
}

}

#if defined(COMPILER_GNUC)
#define STRUCT_PACKED
#define PACKED_STRUCT __attribute__((packed))
#else
#error Platform Not Supported!
#endif

#endif
