#ifndef SYSTEM_ENDIAN_HPP
#define SYSTEM_ENDIAN_HPP

#include <endian.h>

#ifndef BIG_ENDIAN
	#define BIG_ENDIAN __BIG_ENDIAN
#endif
#ifndef LITTLE_ENDIAN
	#define LITTLE_ENDIAN __LITTLE_ENDIAN
#endif

#if (__BYTE_ORDER == BIG_ENDIAN)
	#define NETWORK_BYTE_ORDER BIG_ENDIAN
	#define MACHINE_BYTE_ORDER BIG_ENDIAN
#elif (__BYTE_ORDER == LITTLE_ENDIAN)
	#define NETWORK_BYTE_ORDER BIG_ENDIAN
	#define MACHINE_BYTE_ORDER LITTLE_ENDIAN
#else
	#error Endianness unknown
#endif

#endif
