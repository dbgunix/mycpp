#include <utils/bitmask.h>

namespace colib
{

int BitCount(uint32_t x)
{
	x -= ( x >> 1 ) & 0x55555555;
	x  = ( ( x >> 2 ) & 0x33333333 ) + ( x & 0x33333333 );
	x  = ( ( x >> 4 ) + x ) & 0x0F0F0F0F;
	x *= 0x01010101;
	return x >> 24;
}

int GetHighestBitIndex(uint32_t bitmap)
{
	bitmap |= bitmap >> 1;
	bitmap |= bitmap >> 2;
	bitmap |= bitmap >> 4;
	bitmap |= bitmap >> 8;
	bitmap |= bitmap >> 16;

	return BitCount(bitmap) - 1;
}

int GetLowestBitIndex(uint32_t bitmap)
{
	bitmap &= -(int32_t)bitmap;
	int n = BitCount(bitmap-1);
	return ( ( n & 0x1F ) - ( n >> 5 ) );
}

uint32_t Bitmap1From(int from)
{
	uint32_t bitmap = 1 << from;
	return bitmap|((~bitmap)^(bitmap-1));
}

}
