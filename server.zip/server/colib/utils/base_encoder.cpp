#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include<utils/base_encoder.h>
#include<utils/Base64.h>

namespace colib {

// do not need to expose the internal data and functions
//
static const unsigned char NEGATIVE_UCHAR = 0xFF;
static const int BITS_IN_BYTE_8 = 8;
static unsigned char MakeMask(int width)
{
	// width should be no greater than 8 (8 is OK)
	return (1 << width) - 1;
}

//block size is 3 for base 64 and 5 for base 32
static int GetEncodeLen(int &paddingAlphabetLen, int binLen, int width, int blockSize)
{
	if (width >= BITS_IN_BYTE_8) return 0; // only support encoding less than 256 Alphabet

	int encodeLen = (binLen * BITS_IN_BYTE_8 + width - 1) / width;
	paddingAlphabetLen = (blockSize - encodeLen % blockSize) % blockSize;
	return encodeLen;
}

static int GetDecodeLen(int& resudual, int encodeLen, int width, int blockSize)
{
	int octLen = (encodeLen * width) / BITS_IN_BYTE_8;
	resudual = encodeLen % blockSize; // resudual should be 0 if padding is used

	return octLen;
}

// this bisPos is the offset relative to the most significant bit

static int BaseEncodeGetNext(const unsigned char* &octet, int& bitPos, int width, const unsigned char* endOctet)
{
	int value  = 0;
	unsigned char mask = MakeMask(width);
	// check if the remaining bits are large enough for the width
	if (bitPos + width < 8) {
		value = ((*octet) >> (8 - bitPos - width));
		value &= mask;
		bitPos += width;
	} else if (bitPos + width == 8) {
		value = (*octet) & mask;
		bitPos = 0;
	 	++ octet;
	} else {
		if (octet == endOctet) {
			value = ((*octet) & MakeMask(8 - bitPos)) << (width + bitPos - 8);
			bitPos = (width + bitPos) % 8;
		} else {
 			// borrow nextOctet
			value = (((*octet) & MakeMask(8 - bitPos)) << (width + bitPos - 8)) | ((*(octet + 1)) >> (16 - width - bitPos));
			bitPos = (bitPos + width) % 8 ;
		}
		++ octet;
	}
	return value;
}

static int BaseDecodePackNext(unsigned char* & octet, int& bitPos,
							  unsigned char alphabetVal, bool lastAlphabet, int width,
							  const unsigned char* endOctet)
{

	if (alphabetVal == NEGATIVE_UCHAR) return BaseEncoder::ERROR_INVALID_ALPHABET;

	if (!bitPos) *octet = 0; // clear the output octet when first see it

	if (lastAlphabet) {
		// The last Alphabet should perfectly cover the remaining bits in the output octet.
		// Either bitPos + width == 8 or if the number of remaining bits
		// is less than width, the extra less significant bits should be all 0
		if (bitPos + width < 8 || (alphabetVal & MakeMask( width + bitPos - 8))) {
			return BaseEncoder::ERROR_INVALID_BASE_ENCODING;
		}
	}
	if (bitPos + width <= 8) {
		*octet |= (alphabetVal << (8 - bitPos - width));
		bitPos += width;
		if (bitPos == 8) {
			bitPos = 0;
			++ octet;
			return 1; // finish this octet so move to next output octet when called again
		}
	} else {
		*octet |= (alphabetVal >> (bitPos + width - 8));
		if (octet == endOctet && (alphabetVal & MakeMask(width + bitPos - 8))) {
			// need to borrow next octet but alreay at the end of the outout
			return BaseEncoder::ERROR_INSUFFICIENT_BUFFER;
		}
		if (octet != endOctet) {
			++ octet;
			*octet = 0;
			*octet |= ((alphabetVal & MakeMask(bitPos + width - 8)) << (16 - width - bitPos));
		} else {
			++ octet;
		}
		bitPos = (bitPos + width) % 8;
		return 1; // finish this octet so move to next output octet when called again

	}
	return 0; // haven't done with this output octet yet.
}


static int BaseEncode(char * encodeBuf, int bufLen,
			const unsigned char* octet, int octetLen,
			const char* alphabetTable, int alphabetTableSize, char paddingAlphabet,
			int width, int blockSize, bool padded)
{
	if (!octetLen) return 0;

	// first get padding len
	int paddingAlphabetLen = 0;

	int encLen = GetEncodeLen(paddingAlphabetLen, octetLen, width, blockSize);
	if (padded) encLen += paddingAlphabetLen;

	if (encLen >= bufLen) {
		return BaseEncoder::ERROR_INSUFFICIENT_BUFFER;
	}

	int bitOff = 0, outIdx = 0;
	const unsigned char* octetPtr = octet, *endOctetPtr = octet + octetLen - 1;

	while(octetPtr <= endOctetPtr) {
		// octetPtr may move forward by 1 after retrun of BaseEncodeGetNext
		int value = BaseEncodeGetNext(octetPtr, bitOff, width, endOctetPtr);

		if (value < 0 || value >= alphabetTableSize) return BaseEncoder::ERROR_INTERNAL; //bug if reach here
		// bad value
		if (outIdx >= bufLen) {
			return BaseEncoder::ERROR_INSUFFICIENT_BUFFER;
		}
		encodeBuf[outIdx] = alphabetTable[value];

		++ outIdx;
	}

	// add padding
	for (; outIdx < encLen; ++ outIdx) {
		encodeBuf[outIdx] = paddingAlphabet;
	}
	encodeBuf[encLen] = 0; // zero terminated C string
	return encLen;
}

typedef unsigned char (*AlphabetToOctet)(char);

static int BaseDecode(unsigned char* octetBuf, int bufLen,
		const char * encode, int encodeLen,
		AlphabetToOctet EncodeToBin,  char paddingAlphabet, int width)
{
	if  (!encodeLen) return 0;

	unsigned char *octetPtr = octetBuf, *octetPtrEnd = octetBuf + bufLen - 1;
	const char *encodePtr = encode, *encodePtrEnd = encode + encodeLen - 1;

	// skip padding
	while (encodePtrEnd > encodePtr && *encodePtrEnd == paddingAlphabet) { -- encodePtrEnd; }

	int octetIdx = 0, bitPos = 0;
	while (encodePtr <= encodePtrEnd && octetPtr <= octetPtrEnd) {
		int move = BaseDecodePackNext(octetPtr, bitPos,
							(*EncodeToBin)(*encodePtr),
							 encodePtr == encodePtrEnd,  // is it last alphabet
							 width,
							 octetPtrEnd);
		if (move < 0) return move;
		++ encodePtr;
		octetIdx += move;
	}
	//check if consumed the whole base encoding string
	if (encodePtr <= encodePtrEnd) return BaseEncoder::ERROR_INSUFFICIENT_BUFFER;
	return octetIdx;
}

/**

                      Table 1: The Base 64 Alphabet

     Value Encoding  Value Encoding  Value Encoding  Value Encoding
         0 A            17 R            34 i            51 z
         1 B            18 S            35 j            52 0
         2 C            19 T            36 k            53 1
         3 D            20 U            37 l            54 2
         4 E            21 V            38 m            55 3
         5 F            22 W            39 n            56 4
         6 G            23 X            40 o            57 5
         7 H            24 Y            41 p            58 6
         8 I            25 Z            42 q            59 7
         9 J            26 a            43 r            60 8
        10 K            27 b            44 s            61 9
        11 L            28 c            45 t            62 +
        12 M            29 d            46 u            63 /
        13 N            30 e            47 v
        14 O            31 f            48 w         (pad) =
        15 P            32 g            49 x
        16 Q            33 h            50 y
*/

//Any optimization?
static unsigned char Base64AlphabetToOctet(char alphabet)
{
	static const int POS_PLUS = ('Z' - 'A' + 1) + ('z' - 'a' + 1) + ('9' - '0' + 1);
	if (alphabet >= 'a' && alphabet <= 'z') {
		return ('Z' - 'A' + 1 + alphabet - 'a');
  	} else if (alphabet >= 'A' && alphabet <= 'Z') {
		return (alphabet - 'A');
	} else if (alphabet >= '0' && alphabet <= '9') {
		return (('z' - 'a' + 1) + ('Z' - 'A' + 1) + (alphabet - '0'));
	} else if (alphabet == '+') {
		return POS_PLUS;
	} else if (alphabet == '/') {
		return POS_PLUS + 1;
	}
	return NEGATIVE_UCHAR;
}
/*
      Table 2: The "URL and Filename safe" Base 64 Alphabet

     Value Encoding  Value Encoding  Value Encoding  Value Encoding
         0 A            17 R            34 i            51 z
         1 B            18 S            35 j            52 0
         2 C            19 T            36 k            53 1
         3 D            20 U            37 l            54 2
         4 E            21 V            38 m            55 3
         5 F            22 W            39 n            56 4
         6 G            23 X            40 o            57 5
         7 H            24 Y            41 p            58 6
         8 I            25 Z            42 q            59 7
         9 J            26 a            43 r            60 8
        10 K            27 b            44 s            61 9
        11 L            28 c            45 t            62 - (minus)
        12 M            29 d            46 u            63 _
        13 N            30 e            47 v           (underline)
        14 O            31 f            48 w
        15 P            32 g            49 x
        16 Q            33 h            50 y         (pad) =

*/

static unsigned char Base64UrlFileNameSafeAlphabetToOctet(char alphabet)
{
	unsigned char ret = Base64AlphabetToOctet(alphabet);
	if (ret == NEGATIVE_UCHAR) {
		switch(alphabet) {
			case '-': return Base64AlphabetToOctet('+');
			case '_': return Base64AlphabetToOctet('/');
			default: return NEGATIVE_UCHAR;
		}
	}
	return ret;
}
/*

                 Table 3: The Base 32 Alphabet

     Value Encoding  Value Encoding  Value Encoding  Value Encoding
         0 A             9 J            18 S            27 3
         1 B            10 K            19 T            28 4
         2 C            11 L            20 U            29 5
         3 D            12 M            21 V            30 6
         4 E            13 N            22 W            31 7
         5 F            14 O            23 X
         6 G            15 P            24 Y         (pad) =
         7 H            16 Q            25 Z
         8 I            17 R            26 2

                Table 4: The "Extended Hex" Base 32 Alphabet
*/

//any optimization
//Base 32 Alphabet use digits from 2 to 7. NOT 1 - 6!!!!
static unsigned char Base32AlphabetToOctet(char alphabet)
{
	if (alphabet >= 'a' && alphabet <= 'z') {
		return (alphabet - 'a');
  	} else if (alphabet >= 'A' && alphabet <= 'Z') {
		return (alphabet - 'A');
	} else if (alphabet >= '2' && alphabet <= '7') {
		return ('Z' - 'A' + 1 + alphabet - '2');
	}
	return NEGATIVE_UCHAR;
}

/*
         Value Encoding  Value Encoding  Value Encoding  Value Encoding
             0 0             9 9            18 I            27 R
             1 1            10 A            19 J            28 S
             2 2            11 B            20 K            29 T
             3 3            12 C            21 L            30 U
             4 4            13 D            22 M            31 V
             5 5            14 E            23 N
             6 6            15 F            24 O         (pad) =
             7 7            16 G            25 P
             8 8            17 H            26 Q
*/

//any optimization?
static unsigned char Base32ExtHexAlphabetToOctet(char alphabet)
{
	if (alphabet >= '0' && alphabet <= '9') {
		return (alphabet - '0');
  	} else if (alphabet >= 'A' && alphabet <= 'V') {
		return ('9' - '0' + 1 + alphabet - 'A');
	} else if (alphabet >= 'a' && alphabet <= 'v') {
		return ('9' - '0' + 1 + alphabet - 'a');
	}
	return NEGATIVE_UCHAR;
}

/*
                         Table 5: The Base 16 Alphabet

         Value Encoding  Value Encoding  Value Encoding  Value Encoding
             0 0             4 4             8 8            12 C
             1 1             5 5             9 9            13 D
             2 2             6 6            10 A            14 E
             3 3             7 7            11 B            15 F
*/


static unsigned char Base16AlphabetToOctet(char alphabet)
{
	if (alphabet >= '0' && alphabet <= '9') {
		return alphabet - '0';
	} else if (alphabet >= 'A' && alphabet <= 'F') {
		return 10 + alphabet - 'A';
	} else if (alphabet >= 'a' && alphabet <= 'f') {
        return 10 + alphabet - 'a';
    }
	return NEGATIVE_UCHAR;
}

//do not want expose this in header file since it is onyl locally used


enum BaseEncoderType {
	BASE_64 = 0,
	BASE_64_URL_FILENAME_SAFE,
	BASE_32,
	BASE_32_EXT_HEX,
	BASE_16,
	BASE_COUNT
};

struct EncoderProfile {
			const char*     Alphabet;
			int             AlphabetSize;
			int             BaseBitWidth;
			int             BaseBlockSize;
			char            BasePad;
			AlphabetToOctet AlphToVal;
};

static EncoderProfile baseEncoderProfile[] =
{
	// base 64
	{
		"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",
		64,
		6,
		4,
		'=',
		Base64AlphabetToOctet
	},
	// base 64 url filename safe
	{
		"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_",
		64,
		6,
		4,
		'=',
		Base64UrlFileNameSafeAlphabetToOctet
	},
	// base 32
	{
		"ABCDEFGHIJKLMNOPQRSTUVWXYZ234567",
		32,
		5,
		8,
		'=',
		Base32AlphabetToOctet
	},
	// base 32 ext hex
	{
		"0123456789ABCDEFGHIJKLMNOPQRSTUV",
		32,
		5,
		8,
		'=',
		Base32ExtHexAlphabetToOctet
	},
	// base 16
	{
		"0123456789ABCDEF",
		16,
		4,
		2,
		'\0', // no padding for base16
		Base16AlphabetToOctet
	}
};


/** Calculate the base64 encoding length
  * \param[in] octetLen length of the octets to be encoded
  * \param[in] addPadding if padding is included in the encoding
  * \return the base 64 encoding length in bytes
  */
int BaseEncoder::GetBase64Len(int octetLen, bool addPadding)
{
	int paddingAlphabetLen = 0;
	int len = GetEncodeLen(paddingAlphabetLen, octetLen,
					baseEncoderProfile[BASE_64].BaseBitWidth,
					baseEncoderProfile[BASE_64].BaseBlockSize);
	if (addPadding) {
		len += paddingAlphabetLen;
	}
	return len;
}

/** Calculate the base32 encoding length
  * \param[in] octetLen length of the octets to be encoded
  * \param[in] addPadding if padding is included in the encoding
  * \return the base 32 encoding length in bytes
  */
int BaseEncoder::GetBase32Len(int octetLen, bool addPadding)
{
	int paddingAlphabetLen = 0;

	int len = GetEncodeLen(paddingAlphabetLen, octetLen,
					baseEncoderProfile[BASE_32].BaseBitWidth,
					baseEncoderProfile[BASE_32].BaseBlockSize);

	if (addPadding) {
		len += paddingAlphabetLen;
	}
	return len;
}

/** Calculate the base16 encoding length
  * \param[in] octetLen length of the octets to be encoded
  * \return the base 16 encoding length in bytes
  */
int BaseEncoder::GetBase16Len(int octetLen)
{
	int paddingAlphabetLen = 0;
	return GetEncodeLen(paddingAlphabetLen, octetLen,
					baseEncoderProfile[BASE_16].BaseBitWidth,
					baseEncoderProfile[BASE_16].BaseBlockSize);
}

/** Calculate the base64 decoding length
  * \param[in] octetLen length of the decoded octets
  * \return the decoding length in bytes. The actual decoded octets may be smaller than this value if the encoding has paddings
  */
int BaseEncoder::GetDecode64Len(int baseLen)
{
	int resudual = 0;
	int ret = GetDecodeLen(resudual, baseLen,
					   baseEncoderProfile[BASE_64].BaseBitWidth,
					   baseEncoderProfile[BASE_64].BaseBlockSize);
	return ret;
}

/** Calculate the base32 decoding length
  * \param[in] octetLen length of the decoded octets
  * \return the decoding length in bytes. The actual decoded octets may be smaller than this value if the encoding has paddings
  */
int BaseEncoder::GetDecode32Len(int baseLen)
{
	int resudual = 0;
	int ret = GetDecodeLen(resudual, baseLen,
					   baseEncoderProfile[BASE_32].BaseBitWidth,
					   baseEncoderProfile[BASE_32].BaseBlockSize);
	return ret;
}


/** Calculate the base16 decoding length
  * \param[in] octetLen length of the decoded octets
  * \return the decoding length in bytes
  */
int BaseEncoder::GetDecode16Len(int baseLen)
{
	int resudual = 0;
	int ret = GetDecodeLen(resudual, baseLen,
					   baseEncoderProfile[BASE_16].BaseBitWidth,
					   baseEncoderProfile[BASE_16].BaseBlockSize);
	return ret;
}

int BaseEncoder::Encode(int encoder,
						char * encodeBuf, int bufLen,
						const unsigned char* octet, int octetLen, bool padded) {

	return BaseEncode(encodeBuf, bufLen, octet, octetLen,
				baseEncoderProfile[encoder].Alphabet,
				baseEncoderProfile[encoder].AlphabetSize,
				baseEncoderProfile[encoder].BasePad,
				baseEncoderProfile[encoder].BaseBitWidth,
				baseEncoderProfile[encoder].BaseBlockSize, padded);
}

int BaseEncoder::Decode(int encoder,
						unsigned char* octetBuf, int bufLen,
						const char * encode, int encodeLen)
{

	return BaseDecode(octetBuf, bufLen, encode, encodeLen,
				 baseEncoderProfile[encoder].AlphToVal,
				 baseEncoderProfile[encoder].BasePad,
				 baseEncoderProfile[encoder].BaseBitWidth);
}


/** Encode the octets to null terminated base 64 encoding
  * \param[out] encodeBuf the encoding buffer
  * \param[in] bufLen the length of the encoding buffer
  * \param[in] octers to be encoded
  * \param[in] octetLen length of the octets
  * \param[in] padded is padding required
  * \return the actual base encoding length not including the NULL character
  */
int BaseEncoder::Encode64(char * encodeBuf, int bufLen,
                 const unsigned char* octets, int octetLen, bool padded)
{
	return Encode(BASE_64, encodeBuf, bufLen, octets, octetLen, padded);
}

/** Decode the base 64 encoding
  * \param[out] octetBuf the decoding buffer
  * \param[in] bufLen the length of the decoding buffer
  * \param[in] encode base encoding to be decoded
  * \param[in] encodeLen length of the encoding or negative error code. The length may be smaller than GetDecode64Len() due to padding
  */
int BaseEncoder::Decode64(unsigned char* octetBuf, int bufLen,
				const char * encode, int encodeLen)
{
	return Decode(BASE_64,octetBuf, bufLen, encode, encodeLen);
}


/** Encode the octets to null terminated base 64 url and file name safe alphabet
  * \param[out] encodeBuf the encoding buffer
  * \param[in] bufLen the length of the encoding buffer
  * \param[in] octers to be encoded
  * \param[in] octetLen length of the octets
  * \param[in] padded is padding required
  * \return the actual base encoding length not including the NULL character or negative error code
  */
int BaseEncoder::Encode64UrlFileNameSafe(char * encodeBuf, int bufLen,
                 const unsigned char* octet, int octetLen, bool padded)
{

	return Encode(BASE_64_URL_FILENAME_SAFE, encodeBuf, bufLen, octet, octetLen, padded);
}

/** Decode the base 64 encoding with url and file name safe alphabet
  * \param[out] octetBuf the decoding buffer
  * \param[in] bufLen the length of the decoding buffer
  * \param[in] encode base encoding to be decoded
  * \param[in] encodeLen length of the encoding or negative error code. The length may be smaller than GetDecode64Len() due to padding
  */
int BaseEncoder::Decode64UrlFileNameSafe(unsigned char* octetBuf, int bufLen,
				const char * encode, int encodeLen)
{
	return Decode(BASE_64_URL_FILENAME_SAFE,octetBuf, bufLen, encode, encodeLen);
}

/** Encode the octets to null terminated base 32 encoding
  * \param[out] encodeBuf the encoding buffer
  * \param[in] bufLen the length of the encoding buffer
  * \param[in] octers to be encoded
  * \param[in] octetLen length of the octets
  * \param[in] padded is padding required
  * \return the actual base encoding length not including the NULL character or negative error code
  */
int BaseEncoder::Encode32(char * encodeBuf, int bufLen,
                 const unsigned char* octet, int octetLen, bool padded)
{
	return Encode(BASE_32, encodeBuf, bufLen, octet, octetLen, padded);
}

/** Decode the base 32 encoding
  * \param[out] octetBuf the decoding buffer
  * \param[in] bufLen the length of the decoding buffer
  * \param[in] encode base encoding to be decoded
  * \param[in] encodeLen length of the encoding or negative error code. The length may be smaller than GetDecode32Len() due to padding
  */
int BaseEncoder::Decode32(unsigned char* octetBuf, int bufLen,
				const char * encode, int encodeLen)
{
	return Decode(BASE_32,octetBuf, bufLen, encode, encodeLen);
}

/** Encode the octets to null terminated base 32 encoding with Extended Hex Alphabet
  * \param[out] encodeBuf the encoding buffer
  * \param[in] bufLen the length of the encoding buffer
  * \param[in] octers to be encoded
  * \param[in] octetLen length of the octets
  * \param[in] padded is padding required
  * \return the actual base encoding length not including the NULL character or negative error code
  */
int BaseEncoder::Encode32ExtHex(char * encodeBuf, int bufLen,
                 const unsigned char* octet, int octetLen, bool padded)
{
	return Encode(BASE_32_EXT_HEX, encodeBuf, bufLen, octet, octetLen, padded);
}

/** Decode the base 32 encoding with Extended Hex Alphabet
  * \param[out] octetBuf the decoding buffer
  * \param[in] bufLen the length of the decoding buffer
  * \param[in] encode base encoding to be decoded
  * \param[in] encodeLen length of the encoding or negative error code. The length may be smaller than GetDecode64Len() due to padding
  */
int BaseEncoder::Decode32ExtHex(unsigned char* octetBuf, int bufLen,
				const char * encode, int encodeLen)
{
	return Decode(BASE_32_EXT_HEX, octetBuf, bufLen, encode, encodeLen);
}


/** Encode the octets to null terminated base 16 encoding
  * \param[out] encodeBuf the encoding buffer
  * \param[in] bufLen the length of the encoding buffer
  * \param[in] octers to be encoded
  * \param[in] octetLen length of the octets
  * \return the actual base encoding length not including the NULL character or negativ error code
  */
int BaseEncoder::Encode16(char * encodeBuf, int bufLen,
                 const unsigned char* octet, int octetLen)
{
	return Encode(BASE_16, encodeBuf, bufLen, octet, octetLen, false);
}

/** Decode the base 16 encoding
  * \param[out] octetBuf the decoding buffer
  * \param[in] bufLen the length of the decoding buffer
  * \param[in] encode base encoding to be decoded
  * \param[in] encodeLen length of the encoding or negative error code
  */
int BaseEncoder::Decode16(unsigned char* octetBuf, int bufLen,
				const char * encode, int encodeLen)
{
	return Decode(BASE_16, octetBuf, bufLen, encode, encodeLen);
}

//colib base64 encoding for backwards compatibility
//

/** Calculate the colib base 64 encoding length
  * \param[in] octetLen length of the octets to be encoded
  * \return the colib base 64 encoding length in bytes
  */
int BaseEncoder::GetColibBase64Len(int octetLen)
{
	return static_cast<int>(Base64::GetEncode64Length(octetLen));
}

/** Calculate the colib base 64 decoding length
  * \param[in] octetLen length of the decoded octets
  * \return the decoding length in bytes
  */
int BaseEncoder::GetColibDecode64Len(int baseLen)
{
	return static_cast<int>(Base64::GetDecode64Length(baseLen));
}


/** Obsoleted. Encode the octets to null terminated colib base 64 encoding
  * \param[out] encodeBuf the encoding buffer
  * \param[in] bufLen the length of the encoding buffer
  * \param[in] octers to be encoded
  * \param[in] octetLen length of the octets
  * \return the actual base encoding length not including the NULL character or negative error code
  */
int BaseEncoder::Encode64Colib(char * encodeBuf, int bufLen,
                 const unsigned char* octet, int octetLen)
{
	if (!Base64::Encode64((unsigned char *)encodeBuf, octet, bufLen, octetLen)) {
		return ERROR_UNKNOWN_ERROR;
	}
	return  GetColibBase64Len(octetLen);
}

/** Decode the colib base 64 encoding
  * \param[out] octetBuf the decoding buffer
  * \param[in] bufLen the length of the decoding buffer
  * \param[in] encode base encoding to be decoded
  * \param[in] encodeLen length of the encoding or negative error code
  */
int BaseEncoder::Decode64Colib(unsigned char* octetBuf, int bufLen,
				const char * encode, int encodeLen)
{
	if (!Base64::Decode64(octetBuf, (const unsigned char*)encode, bufLen, encodeLen)) {
		return ERROR_UNKNOWN_ERROR;
	}
	return GetColibDecode64Len(encodeLen);
}

}//name space

