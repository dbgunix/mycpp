#ifndef SHARED_UTILS_H
#define SHARED_UTILS_H

#include<utils/string.h>
#include<utils/system/environ.h> // for PPC ifdef

#include <ctype.h>

// Returns a pointer to a malloc'ed data that is aligned to the specified boundary
void* AlignedMalloc (void** ppData, unsigned int size, int alignment);

// returns true if the str1 is the "start" of str2
bool strcasestrstart (const char* str1, const char* str2);

// formats an IP address into "dotted notation" (e.g., "149.214.9.2")
// it returns a pointer to a "static" char array, so don't free it
// NOT thread safe!!
// these IPv4 utility functions are deprecated and should not be used
// currently enabled only for PPC (remote team)
#ifdef HARDWARE_PPC
char* FormatIpAddr (unsigned long addr);
colib::string FormatIp (unsigned long addr);
char* IPv4AddressToString(char* string, const void* address);
#endif

void hex_to_bin( unsigned char *byte, const char *str);
//int hexlength_to_binarylength(int hexlength);

inline bool is_b10posnumber( const char *str )
{
	while(*str)
	{
		if( !isdigit(*str++ ) )
			return false;
	}
	return true;
}

//
// Generic Polynomial function
//
//	Typical usage:
//	static float ScpcSnrCoefficients [] =
//	{
//		35.3,		// C0
//		-2.06e-4,	// C1
//		5.65e-10,	// C2
//		-5.89e-16	// C3
//	};
//	return Poly (NUMBEROF(ScpcSnrCoefficients), ScpcSnrCoefficients, *raw);

float Poly (int degree, const float coefficients[], int x);

void add_carriage_returns( colib::string &to );
colib::string trim_whitespace( colib::string from );

inline void AddTabsToString(colib::string &to,int count)
{
	while(count-->0)
	{
		to += (char) '\t';
	}
}

extern "C" int Colib_NONCRYPTO_rand();
extern "C" int Colib_NONCRYPTO_RAND_MAX;

#endif
