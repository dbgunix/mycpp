//dump_hex.h
// vi:set ts=4 sw=4 nowrap:

#ifndef DUMPHEX_H_ALREADY_INCLUDED
#define DUMPHEX_H_ALREADY_INCLUDED

#include<utils/string.h>

namespace colib
{

class Writable;
class MemberSet;

void DumpHex( const void *data, unsigned len );
void DumpHex( Writable *to, const void *data, unsigned len );
void DumpHex( int level, Writable *to, const void *data, unsigned len );
void DumpHex( int level, MemberSet &trace_set, const void *data, unsigned len );
string DumpHex2String( const void *data, unsigned len );

}//end namespace colib

#endif

