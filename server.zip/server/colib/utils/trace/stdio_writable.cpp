//stdio_writable.cpp
// vi:set ts=4 sw=4 nowrap:

#include<utils/trace/stdio_writable.h>

namespace colib
{

int StdioWritable::Write( const void* buf, unsigned len )
{
	return fwrite(buf,1,len,m_stream);
}

}//end namespace colib

