//trace_writable.cpp
// vi:set ts=4 sw=4 nowrap:

#include<utils/trace/trace.h>
#include<utils/trace/trace_writable.h>

namespace colib
{

TraceWritable::~TraceWritable()
{
}

int TraceWritable::Write( const void* buf, unsigned len )
{
	//cant print binary junk to global trace
	(void)buf;(void)len;
	return 0;
}
int TraceWritable::Write( int level, const void* buf, unsigned len )
{
	//cant print binary junk to global trace
	(void)level;(void)buf;(void)len;
	return 0;
}
int TraceWritable::Print( const char* fmt, ... )
{
	va_list args;
	va_start (args,fmt);
	(*g_pfTRACE0)(fmt,args);
	va_end(args);
	return 0;
}
int TraceWritable::Print( int level, const char* fmt, ... )
{
	va_list args;
	va_start (args,fmt);
	(*g_pfTRACE1)(level,fmt,args);
	va_end(args);
	return 0;
}
int TraceWritable::vPrint( const char* fmt, va_list args )
{
	(*g_pfTRACE0)(fmt,args);
	return 0;
}

int TraceWritable::vPrint( int level, const char* fmt, va_list args )
{
	(*g_pfTRACE1)(level,fmt,args);
	return 0;
}
int TraceWritable::PrintString( const char* string )
{
	TRACE("%s",string);
	return 0;
}
int TraceWritable::PrintString( int level, const char* string )
{
	TRACE(level,"%s",string);
	return 0;
}

}//end namespace colib

