//syslogger.h
// vi:set ts=4 sw=4 nowrap:

#ifndef SYSLOGGER_H_ALREADY_INCLUDED
#define SYSLOGGER_H_ALREADY_INCLUDED

#include <stdarg.h>
//#include "utils/string.h"
#include<utils/trace/writable.h>
#include <string>

namespace colib
{

class Syslogger
{
public:
	void Enable( const char *appname );
	void Disable();

	~Syslogger();
private:
	Syslogger();

	static void (*s_oldTRACE0)( const char*, va_list args );
	static void (*s_oldTRACE1)( int level, const char*, va_list args );
	//static std::string s_ident;

	static void s_pfTRACE0( const char*, va_list args );
	static void s_pfTRACE1( int level, const char*, va_list args );

	static bool s_open;

public:
	static Syslogger instance;
};

class SysloggerWritable : public Writable
{
public:
	virtual int Write( const void* buf, unsigned len );
};


}//end namespace colib

#endif

