//syslogger.cpp
// vi:set ts=4 sw=4 nowrap:

#include <syslog.h>
#include<utils/trace/syslogger.h>
#include<utils/trace/trace.h>

namespace colib
{

Syslogger Syslogger::instance;
void (*Syslogger::s_oldTRACE0)( const char*, va_list args )=0;
void (*Syslogger::s_oldTRACE1)( int level, const char*, va_list args )=0;
//std::string Syslogger::s_ident;
bool Syslogger::s_open=false;

static inline int TranslateLogLevel( int tlev )
{
	(void)tlev;
	//for now we will only use LOG_NOTICE
	return LOG_NOTICE;
#if 0
	switch(tlev)
	{
		default:
		case 0:
			return LOG_ERR;
		case 1:
			return LOG_WARNING;
		case 2:
			return LOG_NOTICE;
		case 3:
			return LOG_INFO;
		case 4:
			return LOG_DEBUG;
	}
#endif
}

void Syslogger::Enable( const char *appname )
{
	Disable();

	//s_ident = appname;
	//openlog(s_ident.c_str(),0, LOG_DAEMON);
	openlog(appname, 0, LOG_DAEMON);

	s_oldTRACE0 = g_pfTRACE0;
	s_oldTRACE1 = g_pfTRACE1;
	g_pfTRACE0 = s_pfTRACE0;
	g_pfTRACE1 = s_pfTRACE1;

	s_open = true;
}
void Syslogger::Disable()
{
	if(s_open)
	{
		s_open=false;
		closelog();

		g_pfTRACE0 = s_oldTRACE0;
		g_pfTRACE1 = s_oldTRACE1;
		s_oldTRACE0 = 0;
		s_oldTRACE1 = 0;
	}
}
Syslogger::Syslogger()
{
	s_open = false;
}
Syslogger::~Syslogger()
{
	Disable();
}
int SysloggerWritable::Write( const void* buf, unsigned len )
{
	syslog(LOG_ERR|LOG_DAEMON, "%.*s", len, (const char *)buf );
	return len;
}
void Syslogger::s_pfTRACE0( const char*fmt, va_list args )
{
	va_list args2;
	va_copy(args2, args);
	vsyslog(LOG_ERR|LOG_DAEMON, fmt, args2);
	va_end(args2);
	(*s_oldTRACE0)(fmt,args);
}
void Syslogger::s_pfTRACE1( int level, const char*fmt, va_list args )
{
	if(level==0)
	{
		va_list args2;
		va_copy(args2, args);
		vsyslog(TranslateLogLevel(level)|LOG_DAEMON, fmt, args2);
		va_end(args2);
	}
	(*s_oldTRACE1)(level,fmt,args);
}

}//end namespace colib
