#include<utils/trace/writable.h>
#include<utils/trace/trace.h>
#include<utils/string.h>

#include <string.h>
#include <algorithm>

namespace colib
{

Writable::~Writable()
{
	//notify all MemberSets
	for (auto it(m_refs.begin()); it != m_refs.end(); )
	{
		/* need to be careful here. MemberSet::Dropwritable can call
		 * Writable::Drop ref, which modifies m_refs
		 * which invalidates the iterator */
		(*it++)->DropWritable(this);
	}
}

int Writable::Write(int level, const void* buf, unsigned len)
{
	(void)level;
	return Write(buf, len);
}

int Writable::Print(const char* fmt, ... )
{
	va_list args;
	va_start (args,fmt);
	int ret = vPrint(fmt,args);
	va_end(args);
	return ret;
}
int Writable::Print(int level, const char* fmt, ...)
{
	(void)level;
	va_list args;
	va_start (args,fmt);
	int ret = vPrint(fmt,args);
	va_end(args);
	return ret;
}

int Writable::vPrint(const char* fmt, va_list args)
{
	string output(string::vFormat(fmt,args));
	return Write(output.c_str(), output.get_length());
}

int Writable::vPrint(int level, const char* fmt, va_list args)
{
	(void)level;
	return vPrint(fmt,args);
}

int Writable::PrintString(const char* string)
{
	return Write(string, strlen(string));
}

int Writable::PrintString(int level, const char* string)
{
	(void)level;
	return PrintString(string);
}

void Writable::AddRef(MemberSet *from)
{
	if (std::find(m_refs.begin(), m_refs.end(), from) == m_refs.end())
	{
		m_refs.push_back(from);
	}
}

void Writable::DropRef(MemberSet *from)
{
	auto it = std::find(m_refs.begin(), m_refs.end(), from);
	if (it != m_refs.end())
	{
		m_refs.erase(it);
	}
}

TraceMember& TraceMember::operator=(const TraceMember &other)
{
	if (this != &other)
	{
		m_level = other.m_level;
		m_member = other.m_member;
	}
	return *this;
}

std::function<bool (const TraceMember&, const Writable*)> MemberSet::m_finder = MemberSet::TraceMemberFindFunc();

MemberSet::MemberSet()
	: m_members()
{
}

MemberSet::~MemberSet()
{
	Clear();
}

int MemberSet::Write(const void *buf, unsigned len)
{
	for (auto it(m_members.begin()); it != m_members.end(); ++it)
	{
		(*it).m_member->Write(buf,len);
	}
	return 0;
}

int MemberSet::Write(int level, const void *buf, unsigned len)
{
	for (auto it(m_members.begin()); it != m_members.end(); ++it)
	{
		if ((*it).m_level >= level)
		{
			(*it).m_member->Write(buf,len);
		}
	}
	return 0;
}

int MemberSet::Print(const char *fmt, ...)
{
	if (!m_members.empty())
	{
		va_list args;
		va_start (args,fmt);

		string output(string::vFormat(fmt,args));
		const char *pv = output.c_str();

		for (auto it(m_members.begin()); it != m_members.end(); ++it)
		{
			(*it).m_member->PrintString(pv);
		}
		va_end(args);
	}
	return 0;
}

int MemberSet::Print(int level, const char *fmt, ...)
{
	if (!m_members.empty())
	{
		va_list args;
		va_start (args,fmt);

		string output(string::vFormat(fmt,args));
		const char *pv = output.c_str();

		for (auto it(m_members.begin()); it != m_members.end(); ++it)
		{
			if ((*it).m_level >= level)
			{
				(*it).m_member->PrintString(pv);
			}
		}
		va_end(args);
	}
	return 0;
}

int MemberSet::vPrint(const char *fmt, va_list args)
{
	if (!m_members.empty())
	{
		string output(string::vFormat(fmt,args));
		const char *pv = output.c_str();

		for (auto it(m_members.begin()); it != m_members.end(); ++it)
		{
			(*it).m_member->PrintString(pv);
		}
	}
	return 0;
}

int MemberSet::vPrint(int level, const char *fmt, va_list args)
{
	if (!m_members.empty())
	{
		string output(string::vFormat(fmt,args));
		const char *pv = output.c_str();

		for (auto it(m_members.begin()); it != m_members.end(); ++it)
		{
			if ((*it).m_level >= level)
			{
				(*it).m_member->PrintString(pv);
			}
		}
	}
	return 0;
}

int MemberSet::PrintString(const char *str)
{
	for (auto it(m_members.begin()); it != m_members.end(); ++it)
	{
		(*it).m_member->PrintString(str);
	}
	return 0;
}

int MemberSet::PrintString(int level, const char *str)
{
	for (auto it(m_members.begin()); it != m_members.end(); ++it)
	{
		if ((*it).m_level >= level)
		{
			(*it).m_member->PrintString(str);
		}
	}
	return 0;
}

void MemberSet::Trace(const char* fmt, ... )
{
	if (!empty())
	{
		va_list args;
		va_start(args, fmt);
		vPrint(fmt, args);
		va_end(args);
	}
}

void MemberSet::Trace(int level, const char* fmt, ... )
{
	if (!empty())
	{
		va_list args;
		va_start(args, fmt);
		vPrint(level, fmt, args);
		va_end(args);
	}
}

void MemberSet::AddWritable(int level, Writable *toadd)
{
	if(toadd)
	{
		auto it(std::find_if(m_members.begin(), m_members.end(), std::bind(m_finder, std::placeholders::_1, toadd)));
		if (it != m_members.end())
		{
			(*it).m_level = level;
		}
		else
		{
			m_members.push_back(TraceMember(toadd, level));
			toadd->AddRef(this);
		}
	}
}

void MemberSet::DropWritable(Writable *todrop)
{
	if(todrop)
	{
		auto it(std::find_if(m_members.begin(), m_members.end(), std::bind(m_finder, std::placeholders::_1, todrop)));
		if (it != m_members.end())
		{
			todrop->DropRef(this);
			m_members.erase(it);
		}
	}
}

Writable* MemberSet::FindWritable(Writable* tofind)
{
	if (tofind)
	{
		auto it(std::find_if(m_members.begin(), m_members.end(), std::bind(m_finder, std::placeholders::_1, tofind)));
		if (it != m_members.end())
		{
			return (*it).m_member;
		}
	}
	return 0;
}

int MemberSet::GetLevel(Writable *writable) const
{
	if (writable)
	{
		auto it(std::find_if(m_members.begin(), m_members.end(), std::bind(m_finder, std::placeholders::_1, writable)));
		if (it != m_members.end())
		{
			return (*it).m_level;
		}
	}
	return -1;
}

void MemberSet::Clear()
{
	for (auto it(m_members.begin()); it != m_members.end(); ++it)
	{
		(*it).m_member->DropRef(this);
	}
	m_members.clear();
}

}
