//trace.cpp

#include<utils/trace/trace.h>
#include<utils/trace/writable.h>

#include <stdio.h>

#if defined(TRACE)
#undef TRACE
#endif

namespace colib
{

//these calls dispatch to the function pointers- which can be changed
void TRACE( const char *fmt, ... )
{
	va_list args;
	va_start (args,fmt);
	(*g_pfTRACE0)(fmt,args);
	va_end(args);
}
void TRACE( int level, const char *fmt, ... )
{
	va_list args;
	va_start (args,fmt);
	(*g_pfTRACE1)(level,fmt,args);
	va_end(args);
}
void stderr_TRACE( const char *fmt, ... )
{
	va_list args;
	va_start (args,fmt);
	(*g_pfstderr_TRACE0)(fmt,args);
	va_end(args);
}
void stderr_TRACE( int level, const char *fmt, ... )
{
	va_list args;
	va_start (args,fmt);
	(*g_pfstderr_TRACE1)(level,fmt,args);
	va_end(args);
}
void nms_TRACE( const char *fmt, ... )
{
	va_list args;
	va_start (args,fmt);
	(*g_pfnms_TRACE0)(fmt,args);
	va_end(args);
}
void nms_TRACE( int level, const char *fmt, ... )
{
	va_list args;
	va_start (args,fmt);
	(*g_pfnms_TRACE1)(level,fmt,args);
	va_end(args);
}
void member_TRACE(MemberSet *set, const char *fmt, ... )
{
	if ( !set || set->empty() ) return;
	va_list args;
	va_start (args,fmt);
	set->vPrint(fmt,args);
	va_end(args);
}
void member_TRACE(MemberSet *set, int level, const char *fmt, ... )
{
	if ( !set || set->empty() ) return;
	va_list args;
	va_start (args,fmt);
	set->vPrint(level,fmt,args);
	va_end(args);
}
// These stub calls can be re-implemented elsewhere.
void v_stderr_TRACE0( const char *fmt, va_list args )
{
	vfprintf(stderr,fmt,args);
	fflush(stderr);
}

void v_stderr_TRACE1( int level, const char *fmt, va_list args )
{
	//Level is ignored here
	(void)level;
	vfprintf(stderr,fmt,args);
	fflush(stderr);
}

// Change these pointers to override default TRACE calls.
void (*g_pfTRACE0)( const char*, va_list args ) = v_stderr_TRACE0;
void (*g_pfstderr_TRACE0)( const char*, va_list args ) = v_stderr_TRACE0;
void (*g_pfTRACE1)( int level, const char*, va_list args ) = v_stderr_TRACE1;
void (*g_pfstderr_TRACE1)( int level, const char*, va_list args ) = v_stderr_TRACE1;
void (*g_pfnms_TRACE0)( const char*, va_list args ) = v_stderr_TRACE0;
void (*g_pfnms_TRACE1)( int level, const char*, va_list args ) = v_stderr_TRACE1;


/*
void NMS_TRACE( NmsInfoLevel level, const char* fmt, ...)
{
	va_list args;
	va_start (args,fmt);
	vfprintf(stderr,fmt,args);
	va_end(args);
	fflush(stderr);
}
*/

}
