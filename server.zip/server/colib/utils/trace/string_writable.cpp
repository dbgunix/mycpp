#include<utils/trace/string_writable.h>

namespace colib
{

StringWritable::StringWritable()
	: m_data()
{
}

StringWritable::StringWritable(int size)
	: m_data(size)
{
}

int StringWritable::Write(const void* buf, unsigned int len)
{
	(void)len;
	m_data += reinterpret_cast<const char*>(buf);
	return m_data.get_length();
}

int StringWritable::vPrint(const char* fmt, va_list args)
{
	m_data.vAppendFmt(fmt, args);
	return m_data.get_length();
}

int StringWritable::PrintString(const char* string)
{
	m_data += string;
	return m_data.get_length();
}

}
