//trace_writable_null.cpp
// vi:set ts=4 sw=4 nowrap:

#include<utils/trace/trace.h>
#include<utils/trace/trace_writable_null.h>

namespace colib
{

TraceWritableNull::~TraceWritableNull()
{
}

int TraceWritableNull::Write( const void* buf, unsigned len )
{
	//cant print binary junk to global trace
	(void)buf;(void)len;
	return 0;
}
int TraceWritableNull::Write( int level, const void* buf, unsigned len )
{
	//cant print binary junk to global trace
	(void)level;(void)buf;(void)len;
	return 0;
}
int TraceWritableNull::Print( const char* fmt, ... )
{
	(void)fmt;
	return 0;
}
int TraceWritableNull::Print( int level, const char* fmt, ... )
{
	(void)level;(void)fmt;
	return 0;
}
int TraceWritableNull::vPrint( const char* fmt, va_list args )
{
	(void)fmt;(void)args;
	return 0;
}

int TraceWritableNull::vPrint( int level, const char* fmt, va_list args )
{
	(void)level;(void)fmt;(void)args;
	return 0;
}
int TraceWritableNull::PrintString( const char* string )
{
	(void)string;
	return 0;
}
int TraceWritableNull::PrintString( int level, const char* string )
{
	(void)level;(void)string;
	return 0;
}

}//end namespace colib

