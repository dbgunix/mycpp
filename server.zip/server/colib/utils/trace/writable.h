//writable.h

#if !defined(__WRITABLE_H__)
#define __WRITABLE_H__

#include <stdarg.h>
#include <stdlib.h>
#include <list>
#include <functional>

// TODO: const write/print functions if possible
// TODO: consider splitting into 2 files

namespace colib
{

class MemberSet;

class Writable
{
public:
	Writable() : m_refs() { }
	virtual ~Writable();

	// TODO: why void*?, use char*
	virtual int Write(const void* buf, unsigned len) = 0;
	virtual int Write(int level, const void* buf, unsigned len);
	virtual int Print(const char* fmt, ...);
	virtual int Print(int level, const char* fmt, ...);
	virtual int vPrint(const char* fmt, va_list args);
	virtual int vPrint(int level, const char* fmt, va_list args);
	virtual int PrintString(const char* string);
	virtual int PrintString(int level, const char* string);

	virtual void AddRef(MemberSet *from);
	virtual void DropRef(MemberSet *from);

private:
	std::list<MemberSet*> m_refs;
};

struct TraceMember
{
	TraceMember()
		: m_member(NULL)
		, m_level(0)
	{
	}
	TraceMember(Writable* memb)
		: m_member(memb)
		, m_level(0)
	{
	}
	TraceMember(Writable* memb, int lev)
		: m_member(memb)
		, m_level(lev)
	{
	}
	TraceMember(const TraceMember &other)
		: m_member(other.m_member)
		, m_level(other.m_level)
	{
	}
	bool operator==(const TraceMember &to) const { return m_member == to.m_member; }
	TraceMember& operator=(const TraceMember &other);

	Writable *m_member;
	int m_level;
};

class MemberSet
{
public:
	MemberSet(const MemberSet&) = delete;
	MemberSet& operator=(const MemberSet&) = delete;

	MemberSet();
	~MemberSet();
	int Write(const void* buf, unsigned len);
	int Write(int level, const void* buf, unsigned len);
	int Print(const char* fmt, ...);
	int Print(int level, const char* fmt, ...);
	int vPrint(const char* fmt, va_list args);
	int vPrint(int level, const char* fmt, va_list args);
	int PrintString(const char* string);
	int PrintString(int level, const char* string);
	void Trace(const char *fmt, ... )
#ifdef __GNUC__
	__attribute__ ((format (printf, 2, 3)))
#endif
	;
	void Trace(int level, const char *fmt, ... )
#ifdef __GNUC__
	__attribute__ ((format (printf, 3, 4)));
#endif
	;

	void AddWritable(int level, Writable *toadd);
	void DropWritable(Writable* todrop);
	Writable* FindWritable(Writable* tofind);
	int GetLevel(Writable* writable) const;

	void Clear();

	const std::list<TraceMember>& GetMembers() const { return m_members; }
	bool empty() const { return m_members.empty(); }

private:
	struct TraceMemberFindFunc
	{
		bool operator() (const TraceMember &tm, const Writable *w) const { return tm.m_member == w; }
	};
	static std::function<bool (const TraceMember&, const Writable*)> m_finder;
	std::list<TraceMember> m_members;
};

}

#endif
