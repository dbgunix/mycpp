#if !defined(__STRING_WRITABLE_H__)
#define __STRING_WRITABLE_H__

#include<utils/string.h>
#include<utils/trace/writable.h>

namespace colib
{

class StringWritable : public Writable
{
public:
	StringWritable();
	StringWritable(int size);

	virtual int Write(const void* buf, unsigned len);
	virtual int vPrint(const char* fmt, va_list args);
	virtual int PrintString(const char* string);

	void Clear() { m_data.clear(); }
	string GetString() { return m_data; }

private:
	string m_data;
};

}

#endif
