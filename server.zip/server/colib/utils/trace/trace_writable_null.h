//trace_writable_null.h
// vi:set ts=4 sw=4 nowrap:

#ifndef TRACEWRITABLENULL_H_ALREADY_INCLUDED
#define TRACEWRITABLENULL_H_ALREADY_INCLUDED

#include<utils/trace/writable.h>

namespace colib
{

class TraceWritableNull : public Writable
{
public:
	virtual ~TraceWritableNull();

	virtual int Write( const void* buf, unsigned len );
	virtual int Write( int level, const void* buf, unsigned len );
	virtual int Print( const char* fmt, ... );
	virtual int Print( int level, const char* fmt, ... );
	virtual int vPrint( const char* fmt, va_list args );
	virtual int vPrint( int level, const char* fmt, va_list args );
	virtual int PrintString( const char* string );
	virtual int PrintString( int level, const char* string );
};

}//end namespace colib

#endif

