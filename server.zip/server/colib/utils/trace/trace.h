//trace.h

#ifndef __TRACE_H__
#define __TRACE_H__

#include <stdarg.h>

//General purpose tracing

//trace levels 0 1 2 3 will always be available
//the debug messages can be seen by adjusting the
//parameter GLOBAL::DebugLevel equalto or higher
//than the desired threshhold.

#if defined(TRACE)
#undef	TRACE
#endif

namespace colib
{

class MemberSet;

void TRACE( int level, const char*, ... )
#ifdef __GNUC__
	 __attribute__ ((format (printf, 2, 3)))
#endif
;
void TRACE( const char*, ... )
#ifdef __GNUC__
	 __attribute__ ((format (printf, 1, 2)))
#endif
;

//only used for debugging things that cannot use above method
//eventloop, packet sock, etc
void stderr_TRACE( int level, const char*, ... );
void stderr_TRACE( const char*, ... );

void nms_TRACE( int level, const char*, ...);
void nms_TRACE( const char*, ...);

void member_TRACE(MemberSet *set, int level, const char *fmt, ... )
#ifdef __GNUC__
	 __attribute__ ((format (printf, 3, 4)))
#endif
;
void member_TRACE(MemberSet *set, const char *fmt, ... )
#ifdef __GNUC__
	 __attribute__ ((format (printf, 2, 3)))
#endif
;

//these pointers can be overridden to change the default TRACE functions
extern void (*g_pfTRACE0)( const char*, va_list args );
extern void (*g_pfTRACE1)( int level, const char*, va_list args );
extern void (*g_pfnms_TRACE0)( const char*, va_list args );
extern void (*g_pfnms_TRACE1)( int level, const char*, va_list args );
extern void (*g_pfstderr_TRACE0)( const char*, va_list args );
extern void (*g_pfstderr_TRACE1)( int level, const char*, va_list args );

//supplied default trace calls
void v_stderr_TRACE0( const char *fmt, va_list args );
void v_stderr_TRACE1( int level, const char *fmt, va_list args );

//custom trace levels will not be present in the
//deliverable executable. they represent developement
//only traces. Each specific code area will create
//macros for itself. below is an example

#ifdef DEBUG_CUSTOM
#define CUSTOM0_TRACE( fmt )               TRACE(fmt)
#define CUSTOM1_TRACE( fmt, p1 )           TRACE(fmt,p1)
#define CUSTOM2_TRACE( fmt, p1, p2 )       TRACE(fmt,p1,p2)
#define CUSTOM3_TRACE( fmt, p1, p2, p3 )   TRACE(fmt,p1,p2,p3)
#endif

}

#endif
