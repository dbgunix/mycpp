//stdio_writable.h
// vi:set ts=4 sw=4 nowrap:

#ifndef STDIOWRITABLE_H_ALREADY_INCLUDED
#define STDIOWRITABLE_H_ALREADY_INCLUDED

#include <stdio.h>
#include<utils/trace/writable.h>

namespace colib
{

class StdioWritable : public Writable
{
public:
	StdioWritable(FILE *stream = stderr) : m_stream(stream) { }
	virtual ~StdioWritable() {}

	virtual int Write(const void* buf, unsigned len);

	StdioWritable(const StdioWritable&) = delete;
	StdioWritable& operator=(const StdioWritable&) = delete;

private:
	FILE *m_stream;
};

}//end namespace colib

#endif

