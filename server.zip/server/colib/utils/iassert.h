#ifndef IASSERT_HPP
#define IASSERT_HPP

//
// Copyright 2001 colib,  All Rights Reserved.
//
// Module:
//    iassert.hpp
//
// Description:
//    This module provides exception handling functionality.  This
//    includes try, throw, catch, finally, as well as assertions and
//    other debugging features.
//

//
// Defines the 'Assert' macro.  If DEBUG is defined then calling
// this macro with an expression, will cause the expression to be
// evaluated.  If the result is true nothing happens, otherwise a
// message will be printed on 'stderr' explaining that the assertion
// failed, and program execution will halt.  If DEBUG is not defined
// then calls to this function will be completely removed from the
// code (no overhead).  Use this to 'state' conditions that must be
// valid.  Examples would be function argument validation, etc.
// This macro is not to be confused with error checking.  This macro
// is intended to catch mistakes made by programmers, not conditions
// that may occur at runtime.
//

#if DEBUG
#define Assert(expression)       if (expression) (void)0;      \
                                 else libDoAssert(         	   \
                                          __FILE__, __LINE__,  \
                                          #expression,         \
                                          (const char*)0,0)
#define AssertCommon(expression) if (expression) (void)0;      \
                                 else libDoAssert(             \
                                          apFile, aLine,       \
                                          #expression,         \
                                          __FILE__, __LINE__)

//
// Implements the assertion macro(s).
//

extern "C" void         libDoAssert(
                              const char*    apFile,
                              const unsigned aLine,
                              const char*    apExpression,
                              const char*    apCommonFile,
                              const unsigned aCommonLine);

#else
   #define Assert(expression)       (void)0
   #define AssertCommon(expression) (void)0
#endif

#endif
