//
// Copyright 2000 colib,  All Rights Reserved.
//
// Module:
//    iassert.cpp
//
// History:
//    2001-06-19: DE	Original Version.
//

#include <stdio.h>
#include <stdlib.h>

#include<utils/iassert.h>

#if DEBUG

//
//Implements the assertion macro(s).
//

extern "C" void      libDoAssert(
                           const char*    apFile,
                           const unsigned aLine,
                           const char*    apExpression,
                           const char*    apCommonFile,
                           const unsigned aCommonLine)
{
   if (apCommonFile!=0) // was the assertion generated inside?
   {
      fprintf(stderr,   // yes, report library/caller info.
         "Assertion Failed: %s[%d]: %s[%d]: %s\n",
         apFile, aLine, 
         apCommonFile, aCommonLine, 
         apExpression);
   }
   else
   {
      fprintf(stderr,   // no, report caller info only
         "Assertion Failed: %s[%d]: %s\n",
         apFile, aLine,
         apExpression);
   }
   abort();
}

#endif
