#include<utils/kernel/SysTime.h>

#include <sys/time.h>

namespace colib
{

unsigned SysTime::offset = 0;

unsigned SysTime::Get()
{
	struct timeval tv;
	(void)gettimeofday(&tv, 0);
	unsigned long long time = tv.tv_sec;
	time *= 1000;
	time += (tv.tv_usec / 1000);
	return (unsigned)(time % 0x100000000ull) - offset;
}

void SysTime::Set(unsigned tick)
{
	offset = Get() + tick;
}

int SysTime::AdjustSysTime(time_t tim)
{
	// keep the current tick
	unsigned curTick = Get();
	// change the system time
	struct timeval tv;
	tv.tv_sec = tim;
	tv.tv_usec = 0;

	int ret = settimeofday(&tv, NULL); // not thread safe
	if (ret != 0) {
		return ret;
	}
	unsigned newTick = Get();
	// recover the clock for times. let
	// current time - current offset = new time - new offset
	// so new offset = new time + offset - current time
	offset = (newTick + offset - curTick);
	return ret;
}

// Adjust the system clock graducally and monotonically (time is always increasing)
// by calling adjtime instead of using settimeofday. If the system clock
// differs from the specified time too much (greater than 2145 or less than -2145 seconds on x86),
// this function will fail (See "man adjtime")
// We need watch the side effect of changing time
//
int SysTime::GraduallyAdjustSysTime(time_t tim)
{
	// keep the current tick
	unsigned curTick = Get();
	// change the system time
	struct timeval delta, olddelta;
	(void)gettimeofday(&delta, NULL);

	delta.tv_sec = tim - delta.tv_sec;
	delta.tv_usec = 0;

	int ret = adjtime(&delta, &olddelta);
	if (ret != 0) {
		return ret;
	}
	unsigned newTick = Get();
	// recover the clock for times. let
	// current time - current offset = new time - new offset
	// so new offset = new time + offset - current time

	offset = (newTick + offset - curTick);
	return ret;
}

}

