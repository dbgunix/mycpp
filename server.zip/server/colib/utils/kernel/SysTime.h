#ifndef _SYSTIME_H_
#define _SYSTIME_H_

#include <time.h>

/* Set the system clock
 * Gracefully adjusts the system clock
 */

namespace colib
{

class SysTime
{
public:
	static unsigned Get();
	static void Set(unsigned tick);

	static int AdjustSysTime(time_t tim);
	static int GraduallyAdjustSysTime(time_t tim);

private:
	static unsigned offset;
};

}

#endif

