//CallbackBuffer.h

#ifndef CALLBACK_H_INCLUDED
#define CALLBACK_H_INCLUDED

namespace colib
{

enum eCallbackRt {
	RunAgain,
	DontRunAgain
};

class CallbackBuffer
{
public:
	CallbackBuffer():m_ref(0){}
	virtual ~CallbackBuffer(){}
	virtual void Dispatch()=0;

	int m_ref;
};

class CallbackBufferRt
{
public:
	CallbackBufferRt():m_ref(0){}
	virtual ~CallbackBufferRt(){}
	virtual eCallbackRt Dispatch()=0;

	int m_ref;
};

template <typename T> class CallbackBuffer1
{
public:
	CallbackBuffer1():m_ref(0){}
	virtual ~CallbackBuffer1(){}
	virtual void Dispatch(T t)=0;

	int m_ref;
};

template <typename X, typename Y > class CallbackBuffer2
{
public:
	CallbackBuffer2():m_ref(0){}
	virtual ~CallbackBuffer2(){}
	virtual void Dispatch(X x, Y y)=0;

	int m_ref;
};

template <typename X, typename Y, typename Z > class CallbackBuffer3
{
public:
	CallbackBuffer3():m_ref(0){}
	virtual ~CallbackBuffer3(){}
	virtual void Dispatch(X x, Y y, Z z)=0;

	int m_ref;
};

template <typename R> class refbuf
{
public:
	refbuf():m_r(0){}
	refbuf(R*r);
	refbuf(const refbuf &cb);
	refbuf& operator=(const refbuf &to);
	~refbuf();

	R *m_r;
};

template <typename R> inline refbuf<R>::refbuf(R *cb)
	: m_r(cb)
{
	if(m_r)
	{
		++m_r->m_ref;
	}
}
template <typename R> inline refbuf<R>::refbuf(const refbuf<R> &cb)
	: m_r(cb.m_r)
{
	if(m_r)
	{
		++m_r->m_ref;
	}
}
template <typename R> inline refbuf<R>& refbuf<R>::operator=(const refbuf<R> &to)
{
	if (this != &to)
	{
		if(to.m_r)
		{
			++to.m_r->m_ref;
		}
		if(m_r)
		{
			--m_r->m_ref;
			if(m_r->m_ref<1)
				delete m_r;
		}
		m_r=to.m_r;
	}
	return *this;
}
template <typename R> inline refbuf<R>::~refbuf()
{
	if(m_r)
	{
		--m_r->m_ref;
		if(m_r->m_ref<1)
			delete m_r;
	}
}

template <typename X, typename Y, typename Z> class Callback3
{
public:
	Callback3():m_rb(){}
	Callback3(CallbackBuffer3<X,Y,Z>*cb):m_rb(cb){}

	void Dispatch(X x, Y y, Z z){if(m_rb.m_r)m_rb.m_r->Dispatch(x,y,z);}

	void Clear(){ m_rb.m_r=0; }

	bool IsSet() const { return ( m_rb.m_r != 0 ); }

	refbuf< CallbackBuffer3<X,Y,Z> > m_rb;
};

template <typename X, typename Y> class Callback2
{
public:
	Callback2():m_rb(){}
	Callback2(CallbackBuffer2<X,Y>*cb):m_rb(cb){}

	void Dispatch(X x, Y y){if(m_rb.m_r)m_rb.m_r->Dispatch(x,y);}

	void Clear(){ m_rb.m_r=0; }

	bool IsSet() const { return ( m_rb.m_r != 0 ); }

	refbuf< CallbackBuffer2<X,Y> > m_rb;
};

template <typename T> class Callback1
{
public:
	Callback1():m_rb(){}
	Callback1(CallbackBuffer1<T>*cb):m_rb(cb){}

	void Dispatch(T t){if(m_rb.m_r)m_rb.m_r->Dispatch(t);}

	void Clear(){ m_rb.m_r=0; }

	bool IsSet() const { return ( m_rb.m_r != 0 ); }

	refbuf< CallbackBuffer1<T> > m_rb;
};

class Callback
{
public:
	Callback():m_rb(){}
	Callback(CallbackBuffer*cb):m_rb(cb){}

	void Dispatch(){if(m_rb.m_r)m_rb.m_r->Dispatch();}

	void Clear(){ m_rb.m_r=0; }

	bool IsSet() const { return ( m_rb.m_r != 0 ); }

	refbuf< CallbackBuffer > m_rb;
};

class CallbackRt
{
public:
//	CallbackRt(){};
	CallbackRt(CallbackBufferRt*cb):m_rb(cb){}

	eCallbackRt Dispatch(){if(m_rb.m_r) return m_rb.m_r->Dispatch();
		else return DontRunAgain;}

	void Clear(){ m_rb.m_r=0; }

	bool IsSet() const { return ( m_rb.m_r != 0 ); }

	refbuf< CallbackBufferRt > m_rb;
};
typedef CallbackRt* CallbackRtPtr;


class GlobalCallback : public CallbackBuffer
{
public:
	GlobalCallback(void (*f)()):m_f(f){}

	virtual void Dispatch(){m_f();}

	void (*m_f)();
};

class GlobalCtxCallback : public CallbackBuffer
{
public:
	GlobalCtxCallback(void (*f)(void*),void *ctx):m_f(f),m_ctx(ctx){}

	virtual void Dispatch(){m_f(m_ctx);}

	void (*m_f)(void*);
	void *m_ctx;

	GlobalCtxCallback(const GlobalCtxCallback&) = delete;
	GlobalCallback& operator=(const GlobalCtxCallback&) = delete;
};

template <class T> class MemberCallback : public CallbackBuffer
{
public:
	MemberCallback(T*t,void (T::*f)()):m_obj(t),m_f(f){}

	virtual void Dispatch(){(m_obj->*m_f)();}

	T *m_obj;
	void (T::*m_f)();
};

template <class T> class MemberCallbackRt : public CallbackBufferRt
{
public:
	MemberCallbackRt(T*t,eCallbackRt (T::*f)()):m_obj(t),m_f(f){}

	virtual eCallbackRt Dispatch(){eCallbackRt ret = ((m_obj->*m_f)());
		return ret;}

	T *m_obj;
	eCallbackRt (T::*m_f)();
};

template <typename T> class GlobalCallback1 : public CallbackBuffer1<T>
{
public:
	GlobalCallback1(void (*f)(T)):m_f(f){}

	virtual void Dispatch(T t){m_f(t);}

	void (*m_f)(T);
};

template <typename T> class GlobalCtxCallback1 : public CallbackBuffer1<T>
{
public:
	GlobalCtxCallback1(void (*f)(void*,T),void *ctx):m_f(f),m_ctx(ctx){}

	virtual void Dispatch(T t){m_f(m_ctx,t);}

	void (*m_f)(void*,T);
	void *m_ctx;
};

template <typename CLS,typename T> class MemberCallback1 : public CallbackBuffer1<T>
{
public:
	MemberCallback1(CLS*cls,void (CLS::*f)(T)):m_obj(cls),m_f(f){}

	virtual void Dispatch(T t){(m_obj->*m_f)(t);}

	CLS *m_obj;
	void (CLS::*m_f)(T);
};

template <typename X, typename Y> class GlobalCallback2 : public CallbackBuffer2<X,Y>
{
public:
	GlobalCallback2(void (*f)(X,Y)):m_f(f){}

	virtual void Dispatch(X x,Y y){m_f(x,y);}

	void (*m_f)(X,Y);
};

template <typename X, typename Y> class GlobalCtxCallback2 : public CallbackBuffer2<X,Y>
{
public:
	GlobalCtxCallback2(void (*f)(void*,X,Y),void *ctx):m_f(f),m_ctx(ctx){}

	virtual void Dispatch(X x,Y y){m_f(m_ctx,x,y);}

	void (*m_f)(void*,X,Y);
	void *m_ctx;
};

template <typename CLS,typename X, typename Y> class MemberCallback2 : public CallbackBuffer2<X,Y>
{
public:
	MemberCallback2(CLS*cls,void (CLS::*f)(X,Y)):m_obj(cls),m_f(f){}

	virtual void Dispatch(X x, Y y){(m_obj->*m_f)(x,y);}

	CLS *m_obj;
	void (CLS::*m_f)(X,Y);
};

template <typename X, typename Y, typename Z> class GlobalCallback3 : public CallbackBuffer3<X,Y,Z>
{
public:
	GlobalCallback3(void (*f)(X,Y,Z)):m_f(f){}

	virtual void Dispatch(X x,Y y,Z z){m_f(x,y,z);}

	void (*m_f)(X,Y,Z);
};

template <typename X, typename Y, typename Z> class GlobalCtxCallback3 : public CallbackBuffer3<X,Y,Z>
{
public:
	GlobalCtxCallback3(void (*f)(void*,X,Y,Z),void *ctx):m_f(f),m_ctx(ctx){}

	virtual void Dispatch(X x,Y y,Z z){m_f(m_ctx,x,y,z);}

	void (*m_f)(void*,X,Y,Z);
	void *m_ctx;
};

template <typename CLS,typename X, typename Y, typename Z> class MemberCallback3 : public CallbackBuffer3<X,Y,Z>
{
public:
	MemberCallback3(CLS*cls,void (CLS::*f)(X,Y,Z)):m_obj(cls),m_f(f){}

	virtual void Dispatch(X x, Y y, Z z){(m_obj->*m_f)(x,y,z);}

	CLS *m_obj;
	void (CLS::*m_f)(X,Y,Z);
};

template <typename T, typename U> class CallbackBuffer1_bind2: public CallbackBuffer1<U>
{
public:
	CallbackBuffer1_bind2(const T&bindval):m_bv(bindval){m_ref=0;}
	CallbackBuffer1_bind2(CallbackBuffer2<T,U>*cb,const T&bindval):m_rb(cb),m_bv(bindval){m_ref=0;}
	~CallbackBuffer1_bind2(){}
	void Dispatch(U u){if(m_rb.m_r)m_rb.m_r->Dispatch(m_bv,u);}

	int m_ref;
	refbuf< CallbackBuffer2<T,U> > m_rb;
	T m_bv;
};

template <typename T> class CallbackBuffer0_bind1: public CallbackBuffer
{
public:
	CallbackBuffer0_bind1(const T&bindval):m_bv(bindval){m_ref=0;}
	CallbackBuffer0_bind1(CallbackBuffer1<T>*cb,const T&bindval):m_rb(cb),m_bv(bindval){m_ref=0;}
	~CallbackBuffer0_bind1(){}
	void Dispatch(){if(m_rb.m_r)m_rb.m_r->Dispatch(m_bv);}

	int m_ref;
	refbuf< CallbackBuffer1<T> > m_rb;
	T m_bv;
};

template <typename T> inline Callback bind_callback(  T t, Callback1<T> cb1 )
{
	return Callback( new CallbackBuffer0_bind1<T>(cb1.m_rb.m_r,t) );
}

template <typename T, typename U> inline Callback1<U> bind_callback(  T t, Callback2<T,U> cb2 )
{
	return Callback1<U>( new CallbackBuffer1_bind2<T,U>(cb2.m_rb.m_r,t) );
}

template <typename T> inline Callback callback(T*t,void (T::*f)())
{
	return Callback(new MemberCallback<T>(t,f));
}

template <typename T> inline CallbackRt callbackRt(T*t,eCallbackRt (T::*f)())
{
	return CallbackRt(new MemberCallbackRt<T>(t,f));
}

inline Callback callback(void (*f)(void *),void *ctx)
{
	return Callback(new GlobalCtxCallback(f,ctx));
}

inline Callback callback(void (*f)() )
{
	return Callback(new GlobalCallback(f));
}

template <class CLS, typename T> inline Callback1<T> callback(CLS*t,void (CLS::*f)(T))
{
	return Callback1<T>(new MemberCallback1<CLS,T>(t,f));
}

template <typename T> inline Callback1<T> callback(void (*f)(void *,T),void *ctx)
{
	return Callback1<T>(new GlobalCtxCallback1<T>(f,ctx));
}

template <typename T> inline Callback1<T> callback(void (*f)(T) )
{
	return Callback1<T>(new GlobalCallback1<T>(f));
}

template <class CLS, typename X, typename Y> inline Callback2<X,Y> callback(CLS*t,void (CLS::*f)(X,Y))
{
	return Callback2<X,Y>(new MemberCallback2<CLS,X,Y>(t,f));
}

template <typename X, typename Y> inline Callback2<X,Y> callback(void (*f)(void *,X,Y),void *ctx)
{
	return Callback2<X,Y>(new GlobalCtxCallback2<X,Y>(f,ctx));
}

template <typename X, typename Y> inline Callback2<X,Y> callback(void (*f)(X,Y) )
{
	return Callback2<X,Y>(new GlobalCallback2<X,Y>(f));
}

template <class CLS, typename X, typename Y, typename Z> inline Callback3<X,Y,Z> callback(CLS*t,void (CLS::*f)(X,Y,Z))
{
	return Callback3<X,Y,Z>(new MemberCallback3<CLS,X,Y,Z>(t,f));
}

template <typename X, typename Y, typename Z> inline Callback3<X,Y,Z> callback(void (*f)(void *,X,Y,Z),void *ctx)
{
	return Callback3<X,Y,Z>(new GlobalCtxCallback3<X,Y,Z>(f,ctx));
}

template <typename X, typename Y, typename Z> inline Callback3<X,Y,Z> callback(void (*f)(X,Y,Z) )
{
	return Callback3<X,Y,Z>(new GlobalCallback3<X,Y,Z>(f));
}

#define INSTANTIATE_CALLBACK(TYPE) \
	template inline Callback callback<TYPE>(TYPE*t,void (TYPE::*f)());	\
	template class MemberCallback<TYPE>;

#define INSTANTIATE_CALLBACK1(TYPE) \
	template inline Callback1<TYPE> callback<TYPE>(void (*f)(void *,TYPE),void *ctx);	\
	template inline Callback1<TYPE> callback<TYPE>(void (*f)(TYPE) );	\
	template class Callback1<TYPE>; \
	template class refbuf< CallbackBuffer1<TYPE> >; \
	template class CallbackBuffer1<TYPE>;

#define INSTANTIATE_CALLBACK1MEMB(CLS,TYPE) \
	template inline Callback1<TYPE> callback<CLS,TYPE>(CLS*t,void (CLS::*f)(TYPE));	\
	template class MemberCallback1<CLS,TYPE>;

}

#endif
