//callback.cpp

#include<utils/callback.h>

namespace colib
{

#ifdef __GNUC__
#else
template class refbuf< CallbackBuffer >; 
#endif

}
