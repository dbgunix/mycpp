#ifndef LICENSE_PREFIX_H
#define LICENSE_PREFIX_H   
namespace colib{

	extern const char*  LICENSE_HEADER;
	extern const char*  SIGNATURE_HEADER;
	extern const char*  SIGNATURE_VERSION;
	extern const char*  SIGNATURE_TRAILER;

};
#endif /* LICENSE_PREFIX_H */
