/* -*- tab-width:4; c-basic-offset: 4 -*- */
// uint128.h
// vi:set ts=4 sw=4 nowrap:

#ifndef UINT128_H
#define UINT128_H

#include <netinet/in.h>
#include<utils/string.h>

namespace colib
{

class  UInt128
{
public:
	union {
		uint64_t u6_addr64[2];
		in6_addr u6_in6_addr;
	} m_buf;
public:
	UInt128();
	UInt128(const UInt128& other);
	UInt128(const in6_addr& in6Addr);
	UInt128(u_int64_t u6_addr64_low, u_int64_t u6_addr64_high);
	UInt128(unsigned long ui32) : m_buf() { m_buf.u6_addr64[0] = ui32; m_buf.u6_addr64[1] = 0; }
	virtual ~UInt128(){};
public:

	void FLIP();
	UInt128& operator = (const in6_addr& in6Addr);
	UInt128& operator = (unsigned int i);
	UInt128& operator+=(unsigned int i);
	UInt128& operator-=(unsigned int i);
	UInt128& operator-=(const UInt128& other);
	UInt128& operator&=(const UInt128& other);
	UInt128& operator|=(const UInt128& other);

	const UInt128 operator+(unsigned int i) const;
	const UInt128 operator-(unsigned int i) const;
	const UInt128 operator-(const UInt128& other) const;
	const UInt128 operator&(const UInt128& other) const;
	const UInt128 operator|(const UInt128& other) const;
	const UInt128 operator~() const;

	bool operator <(const UInt128& other) const;
	bool operator == (const UInt128& other) const;
	bool operator <=(const UInt128& other) const {
		return operator<(other) || operator==(other);
	}
	bool operator >(const UInt128& other) const {
		return !(operator<=(other));
	}
	bool operator >=(const UInt128& other) const {
		return !(operator<(other));
	}

	static const UInt128& GetLower() { return m_lower; }
	static const UInt128& GetUpper() { return m_upper; }
	static const UInt128& GetDefaultLower() { return m_lower; }
	static const UInt128& GetDefaultUpper() { return m_upper; }
	virtual string ToString(const UInt128& num) const;
	virtual string ToString() const { return ToString(*this); }

private:
	static const UInt128 m_lower;
	static const UInt128 m_upper;
};

}// namespace

#endif
