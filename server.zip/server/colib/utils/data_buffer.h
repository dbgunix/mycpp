#if !defined(__DATA_BUFFER_H__)
#define __DATA_BUFFER_H__

#include <stdint.h>
#include <string.h>

namespace colib
{

template<uint32_t N>
class DataBuffer
{
public:
	DataBuffer(int32_t initial_offset);
	virtual ~DataBuffer() { }

	char* GetData() { return m_data + m_offset; }
	const char* GetData() const { return m_data + m_offset; }
	uint32_t GetLength() const { return m_length; }
	bool SetLength(unsigned length);
	uint32_t MaxLength() const { return N - m_offset; }
	bool Empty() const { return GetLength() <= 0; }
	int32_t BytesAvailable() const { return MaxLength() - GetLength(); }

	char* InsertHeader(unsigned bytes);
	char* RemoveHeader(unsigned bytes);
	char* AddTrailer(unsigned bytes);
	char* RemoveTrailer(unsigned bytes);
	bool AppendData(const char* data, int length);

protected:
	void ResetData(uint32_t offset);

	char m_data[N];
	uint32_t m_length;
	uint32_t m_offset;
};

template<uint32_t N>
DataBuffer<N>::DataBuffer(int32_t initial_offset)
	: m_data()
	, m_length(0)
	, m_offset(initial_offset)
{
	const uint32_t MAX_DATA_BUFFER_SIZE = 65536;
	static_assert(N < MAX_DATA_BUFFER_SIZE, "DataBuffer too large");
}

template<uint32_t N>
bool DataBuffer<N>::SetLength(unsigned length)
{
	if (length > MaxLength())
	{
		return false;
	}
	m_length = length;
	return true;
}

template<uint32_t N>
void DataBuffer<N>::ResetData(uint32_t offset)
{
	m_length = 0;
	m_offset = offset;
}

template<uint32_t N>
char* DataBuffer<N>::InsertHeader(unsigned bytes)
{
	char* result = 0;
	if (m_offset >= bytes)
	{
		m_offset -= bytes;
		m_length += bytes;
		result = m_data + m_offset;
	}
	return result;
}

template<uint32_t N>
char* DataBuffer<N>::RemoveHeader(unsigned bytes)
{
	char* result = 0;
	if (m_length >= bytes)
	{
		result = m_data + m_offset;
		m_offset += bytes;
		m_length -= bytes;
	}
	return result;
}

template<uint32_t N>
char* DataBuffer<N>::AddTrailer(unsigned bytes)
{
	char* result = 0;
	if (m_offset+m_length+bytes <= N)
	{
		result = m_data + m_offset + m_length;
		m_length += bytes;
	}
	return result;
}

template<uint32_t N>
char* DataBuffer<N>::RemoveTrailer(unsigned bytes)
{
	char* result = 0;
	if (m_length >= bytes)
	{
		m_length -= bytes;
		result = m_data + m_offset + m_length;
	}
	return result;
}

template<uint32_t N>
bool DataBuffer<N>::AppendData(const char* data, int length)
{
	char* buf = AddTrailer(length);
	if (buf)
	{
		memcpy(buf, data, length);
		return true;
	}
	return false;
}

}

#endif
