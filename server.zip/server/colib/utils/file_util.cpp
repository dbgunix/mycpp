//shell.cpp
// vi:set ts=4 sw=4 nowrap:

#include<utils/file_util.h>

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>

#include<utils/system/environ.h>

namespace colib
{

int GetFileSize(string path, string &err)
{
	struct stat file_stat;
	if(-1 == stat(path.c_str(), &file_stat))
	{
		err = string::Format("Unable to stat file %s: %s", path.c_str(), strerror(errno));
		return -1;
	}

	return file_stat.st_size;
}

bool LoadTextFile(string path, string &into, string &err)
{
	FILE *toread = fopen(path.c_str(),"r");
	if( !toread )
	{
		err = string::Format("Failed to open \"%s\": %s", path.c_str(), strerror(errno));
		return false;
	}
	int file_size = GetFileSize(path.c_str(), err);
	if (file_size <= 0)
	{
		fclose(toread);
		return false;
	}
	into.empty();
	into.set_maxlength(file_size+1);
	
	char inbuf[500];
	size_t rdcount;
	while( 0 < (rdcount=fread(inbuf,1,500,toread)) )
	{
		into += string(inbuf, static_cast<unsigned int>(rdcount));
	}
	bool ret;
	if (ferror(toread))
	{
		ret = false;
		err = string::Format("Failed to read \"%s\": %s", path.c_str(), strerror(errno));
	}
	else
	{
		ret = true;
	}

	fclose(toread);

	return ret;
}

bool SaveTextFile( string path, string from, string &err )
{
	FILE *towrite = fopen(path.c_str(),"w");
	if( !towrite )
	{
		err = string::Format("Failed to open \"%s\": %s", path.c_str(), strerror(errno) );
		return false;
	}

	fputs(from.c_str(), towrite);
	
	bool ret;
	if( ferror(towrite) )
	{
		ret =false;
		err = string::Format("Failed to write \"%s\": %s", path.c_str(), strerror(errno) );
	}
	else
	{
		ret = true;
	}

	fclose(towrite);

	return ret;
}

void RemoveFile(colib::string& file_name, colib::string &err)
{

	if (remove(file_name)) {
		err = string::Format("Failed to remove file \"%s\": %s", file_name.c_str(), strerror(errno));
	}
}

bool SetFileMode( string path, mode_t mode, string &err )
{
	int t_result=chmod(path.c_str(), mode);

	if(t_result==0)
	{
		return true;
	}
	else
	{
		err = string::Format("Failed to chmod \"%s\": %s", path.c_str(), strerror(errno) );
		return false;
	}
		
}

bool IsDirectory( string path, string &err )
{
	struct stat stat_buf;

	if( 0!= stat(path.c_str(),&stat_buf) )
	{
		err = string::Format("Failed to stat \"%s\": %s", path.c_str(), strerror(errno) );
		return false;
	}

	if( !S_ISDIR(stat_buf.st_mode) )
	{
		err = string::Format("\"%s\" is not a directory", path.c_str() );
		return false;
	}
	return true;
}

bool IsRegularFile( string path, string &err )
{
	struct stat stat_buf;

	if( 0!= stat(path.c_str(),&stat_buf) )
	{
		err = string::Format("Failed to stat \"%s\": %s", path.c_str(), strerror(errno) );
		return false;
	}

	if( !S_ISREG(stat_buf.st_mode) )
	{
		err = string::Format("\"%s\" is not a normal file", path.c_str() );
		return false;
	}
	return true;
}

}//end namespace colib

