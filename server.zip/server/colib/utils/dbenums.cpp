#include<utils/dbenums.h>

#include <string.h>

namespace colib
{

const TEnumRec EndOfERTable = EOERT;

bool operator==(const TEnumRec &x, const TEnumRec &y)
{
	return x.m_iEnum == y.m_iEnum && (strcmp(x.m_strEnum, y.m_strEnum)==0);
}

bool operator!=(const TEnumRec &x, const TEnumRec &y)
{
	return !(x == y);
}

const char *EnumToStr(int iEnum, const TEnumRec *tblEnumRec, const char *err_val)
{
	for (const TEnumRec *rec = tblEnumRec; *rec != EndOfERTable; rec++)
	{
		if (iEnum == rec->m_iEnum)
		{
			return rec->m_strEnum;
		}
	}
	return err_val;
}

int StrToEnum(const char *strEnum, const TEnumRec *tblEnumRec, bool case_sensitive, int err_val)
{
	int (*f) (const char *, const char *) = case_sensitive ?
		strcmp :
		strcasecmp;

	for (const TEnumRec *rec = tblEnumRec; *rec != EndOfERTable; rec++)
	{
		if (f(strEnum, rec->m_strEnum)==0)
		{
			return rec->m_iEnum;
		}
	}
	//	return tblEnumRec->m_iEnum;
	return err_val;
}

int EnumCnt(const TEnumRec *tblEnumRec)
{
	int cnt = 0;
	for (const TEnumRec *rec = tblEnumRec; *rec != EndOfERTable; rec++)
		cnt++;
	return cnt;
}

ENUM_TBL_DEF_START(ENetModemType)
	{TxHub,                    	"Transmit Line Card"},
	{TxHub,                    	"Tx"},
	{TxHub,                    	"TxOnly"},
	{RxHub,                    	"Receive Line Card"},
	{RxHub,                    	"Rx"},
	{RxHub,                    	"RxOnly"},
	{TxRxHub,                  	"Transmit and Receive Line Card"},
	{TxRxHub,                  	"TxRx"},
	{TxRxHub,                  	"TxRxMaster"},
	{Remote,					"Remote"},
	{Standby,					"Standby"},
	{TxRxHubSolo,				"Solo Transmit and Receive Line Card"},
	{TxRxHubSolo,				"Solo"},
	{TxRxHubSolo,				"PrivateHub"},
	{Failed,					"Failed"},
	{RemoteRx,					"Receive Remote"},
	{RemoteRx,					"RxOnlyRemote"},
	{Peer,						"Point to Point"},
	{Peer,						"iSCPC"},
	{Peer,						"P2P"}
ENUM_TBL_DEF_STOP(ENetModemType)

double MaxCOTMSpeed(int iEnum)
{
	double max = 150;
	switch(iEnum)
	{
		case COTMMaritime:
			max = 30;
			break;
		case COTMVehicular:
			max = 150;
			break;
		case COTMTrain:
			max = 150;
			break;
		case COTMAirplane:
			max = DefCOTMMaxSpeed;
			break;
	}

	return max;
}
double MinCOTMSpeed(int iEnum)
{
	double min = 0;
	switch(iEnum)
	{
		case COTMMaritime:
			min = 0;
			break;
		case COTMVehicular:
			min = 0;
			break;
		case COTMTrain:
			min = 0;
			break;
		case COTMAirplane:
			min = 0;
			break;
	}

	return min;
}

short SetMODCOD(short iModulation, short iCodingRate)
{
	return iCodingRate | (iModulation << 7);
}

void GetMODCOD(short iModCod, short &iModulation, short &iCodingRate)
{
	iCodingRate = 255 & iModCod; // ((1<<16)-1) == 65535
	iModulation = (~255 & iModCod) >> 7;
}

int GetBitsPerSymbol(EModulationType modulation)
{
	switch(modulation)
	{
		case MdmModulationBpsk:
			return 1;
		case MdmModulationQpsk:
			return 2;
		case MdmModulationPSK_8:
			return 3;
		case MdmModulationPSK_16:
			return 4;
		case MdmModulationSSB:
		case MdmModulationAdaptive:
		case MdmModulationDVBS2_CCM:
		case MdmModulationDVBS2_ACM:
		case MdmModulationInvalid:
			//TRACE("");
			return 1;
	}
	//TRACE("");
	return 1;
};

int GetFecBlockSize(EFecBlockSize type)
{
	switch(type)
	{
		case FecBlock100:
			return 100;
		case FecBlock170:
			return 170;
		case FecBlock438:
			return 438;
		case FecBlockReserved:
			return 1;
	}
	return 1;
}

int GetFecBlockSize(EErrorCorrectionType type)
{
	switch(type)
	{
		case MdmFecRateOff:
		case MdmFecRate3By4:
		case MdmFecRate1By2:
		case MdmFecRate1By3:
		case MdmTpc676By1024:
		case MdmFecReed:
		case MdmVit1By2Rs112By126:
		case MdmVit1By2Rs178By194:
		case MdmVit1By2Rs201By219:
		case MdmVit1By2Rs205By225:
		case MdmVit3By4Rs112By126:
		case MdmVit3By4Rs178By194:
		case MdmVit3By4Rs201By219:
		case MdmVit3By4Rs205By225:
		case MdmTpc3249By4096:
		case MdmTcm2By3:
		case MdmTcm2By3Rs201By219:
		case MdmTpc2028By4096:
		case MdmTpc14400By16384:
		case MdmTpc546By1024:
		case MdmTpc441By1024:
		case MdmDVBS2Fec:
			//TODO: TRACE
			return 1;

			// Block size-1 - 100 bytes
		case Mdm2D16StateBSize1FEC1By3:
		case Mdm2D16StateBSize1FEC1By2:
		case Mdm2D16StateBSize1FEC2By3:
		case Mdm2D16StateBSize1FEC3By4:
		case Mdm2D16StateBSize1FEC4By5:
		case Mdm2D16StateBSize1FEC5By6:
		case Mdm2D16StateBSize1FEC6By7:
		case Mdm2D16StateBSize1FEC7By8:
			return 100;

			// Block size-2 - 170 bytes
		case Mdm2D16StateBSize2FEC1By3:
		case Mdm2D16StateBSize2FEC1By2:
		case Mdm2D16StateBSize2FEC2By3:
		case Mdm2D16StateBSize2FEC3By4:
		case Mdm2D16StateBSize2FEC4By5:
		case Mdm2D16StateBSize2FEC5By6:
		case Mdm2D16StateBSize2FEC6By7:
		case Mdm2D16StateBSize2FEC7By8:
			return 170;

			// Block size-3 - 438 bytes
		case Mdm2D16StateBSize3FEC1By3:
		case Mdm2D16StateBSize3FEC1By2:
		case Mdm2D16StateBSize3FEC2By3:
		case Mdm2D16StateBSize3FEC3By4:
		case Mdm2D16StateBSize3FEC4By5:
		case Mdm2D16StateBSize3FEC5By6:
		case Mdm2D16StateBSize3FEC6By7:
		case Mdm2D16StateBSize3FEC7By8:
			return 438;

			// end
		case InvalidErrorCorrection:
			//TRACE("");
			return 1;
	}
	//TRACE("");
	return 1;
}

double GetCodingRate_atdma(ECodingRateType type)
{
	switch (type)
	{
		case MdmFECInvalid:
			return 1.0;

		case MdmFEC1By3:
			return 1.0 / 3.0;

		case MdmFEC1By2:
			return 1.0 / 2.0;

		case MdmFEC2By3:
			return 2.0 / 3.0;

		case MdmFEC3By4:
			return 3.0 / 4.0;

		case MdmFEC4By5:
			return 4.0 / 5.0;

		case MdmFEC5By6:
			return 5.0 / 6.0;

		case MdmFEC6By7:
			return 6.0 / 7.0;

		case MdmFEC7By8:
			return 7.0 / 8.0;
	}
	return 1.0;
}

double GetCodingRate(EErrorCorrectionType type)
{
	switch(type)
	{
		case MdmFecRateOff:
		case MdmFecRate3By4:
		case MdmFecRate1By2:
		case MdmFecRate1By3:
		case MdmTpc676By1024:
		case MdmFecReed:
		case MdmVit1By2Rs112By126:
		case MdmVit1By2Rs178By194:
		case MdmVit1By2Rs201By219:
		case MdmVit1By2Rs205By225:
		case MdmVit3By4Rs112By126:
		case MdmVit3By4Rs178By194:
		case MdmVit3By4Rs201By219:
		case MdmVit3By4Rs205By225:
		case MdmTpc3249By4096:
		case MdmTcm2By3:
		case MdmTcm2By3Rs201By219:
		case MdmTpc2028By4096:
		case MdmTpc14400By16384:
		case MdmTpc546By1024:
		case MdmTpc441By1024:
		case MdmDVBS2Fec:
			//TODO: TRACE
			return 1.0;

		case Mdm2D16StateBSize1FEC1By3:
		case Mdm2D16StateBSize2FEC1By3:
		case Mdm2D16StateBSize3FEC1By3:
			return 1.0/3.0;
		case Mdm2D16StateBSize1FEC1By2:
		case Mdm2D16StateBSize2FEC1By2:
		case Mdm2D16StateBSize3FEC1By2:
			return 1.0/2.0;
		case Mdm2D16StateBSize1FEC2By3:
		case Mdm2D16StateBSize2FEC2By3:
		case Mdm2D16StateBSize3FEC2By3:
			return 2.0/3.0;
		case Mdm2D16StateBSize1FEC3By4:
		case Mdm2D16StateBSize2FEC3By4:
		case Mdm2D16StateBSize3FEC3By4:
			return 3.0/4.0;
		case Mdm2D16StateBSize1FEC4By5:
		case Mdm2D16StateBSize2FEC4By5:
		case Mdm2D16StateBSize3FEC4By5:
			return 4.0/5.0;
		case Mdm2D16StateBSize1FEC5By6:
		case Mdm2D16StateBSize2FEC5By6:
		case Mdm2D16StateBSize3FEC5By6:
			return 5.0/6.0;
		case Mdm2D16StateBSize1FEC6By7:
		case Mdm2D16StateBSize2FEC6By7:
		case Mdm2D16StateBSize3FEC6By7:
			return 6.0/7.0;
		case Mdm2D16StateBSize1FEC7By8:
		case Mdm2D16StateBSize2FEC7By8:
		case Mdm2D16StateBSize3FEC7By8:
			return 7.0/8.0;
			// end
		case InvalidErrorCorrection:
			//TRACE("");
			return 1.0;
	}
	//TRACE("");
	return 1.0;
}

int GetSkipInteval(ENetModemVersionType modem)
{
	switch (modem)
	{
		default:
			return 250;
	}
}

int GetPilotLength()
{
	return 0;
}
}
