#if !defined(__BITMASK_UTILS_H__)
#define __BITMASK_UTILS_H__

#include <stdint.h>
#include <type_traits>

namespace colib
{	
//
// Function to count how many bits are 1 in a 32-bit bitmap
// E.g. 00110010 => 3
//
int BitCount(uint32_t bitmap);

//
// Given a 32-bit bitmap, find the index of the highest '1'
// E.g. 00110010 => 5
//
int GetHighestBitIndex(uint32_t bitmap);
	
//
// Given a 32-bit bitmap, find the index of the lowest '1'
// E.g. 00110010 => 1
//
int GetLowestBitIndex(uint32_t bitmap);

//
// Generate bitmap with '1' for all index greater than 'from'
// E.g. from = 3 => 11111111 11111111 11111111 11111000
//
uint32_t Bitmap1From(int from);

template<typename T>
inline T ExtractBitsFromMask(T bitmask, uint8_t msb_start, uint8_t num_bits)
{
	static_assert(std::is_integral<T>::value, "bitmask must be integral type");
	return (bitmask >> (msb_start - num_bits + 1))&((1<<num_bits) - 1);
}

template<typename T>
inline T SetBitInMask(T bitmask, uint8_t position)
{
	static_assert(std::is_integral<T>::value, "bitmask must be integral type");
	return bitmask | (1 << position);
}

template<typename T>
inline T ClearBitInMask(T bitmask, uint8_t position)
{
	static_assert(std::is_integral<T>::value, "bitmask must be integral type");
	return bitmask & (~(1 << position));
}

template<typename T>
inline T SetBitInMask(T bitmask, uint8_t position, bool set)
{
	static_assert(std::is_integral<T>::value, "bitmask must be integral type");
	return set ? SetBitInMask(bitmask, position) : ClearBitInMask(bitmask, position);
}

template<typename T, typename U>
inline T SetValueInMask(T bitmask, uint8_t msb, uint8_t num_bits, U value)
{
	static_assert(std::is_integral<T>::value, "bitmask must be integral type");
	static_assert(std::is_integral<U>::value, "value must be integral type");
	uint8_t shift_amt = msb-num_bits+1;
	// clear the old
	T clear_val = (1<<num_bits)-1;
	bitmask &= (~(clear_val<<shift_amt));
	// write the new
	bitmask |= ((value&clear_val)<<shift_amt);
	return bitmask;
}

}

#endif
