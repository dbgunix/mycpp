#include<utils/xdr.h>

#include<utils/system/memory.h>
#include<utils/system/machine.h>

#include <string.h>
#include <stdlib.h>

namespace colib
{

CXDR::CXDR(xdr_op op, char* pBuffer, int max_len)
	: m_op(op)
	, mp_Base(pBuffer)
	, m_next(0)
	, m_last(max_len)
{
}

CXDR::CXDR(xdr_op op)
	: m_op(op)
	, mp_Base(NULL)
	, m_next(0)
	, m_last(0)
{
}

bool CXDR::XdrChar(char* pc)
{
	int i = (*pc);

	if (!XdrInt(&i))
	{
		return false;
	}

	*pc = i;
	return true;
}

bool CXDR::XdrUchar (unsigned char* puc)
{
	unsigned int ui = (*puc);

	if (!XdrUint(&ui))
	{
		return false;
	}
	*puc = ui;
	return true;
}

bool CXDR::XdrLong(long *lp)
{
#if (__WORDSIZE == 64)
	return XdrInt64(lp);
#else
	return XdrInt(reinterpret_cast<int*>(lp));
#endif
}

bool CXDR::XdrUlong(unsigned long *pul)
{
#if (__WORDSIZE == 64)
	return XdrUint64(pul);
#else
	return XdrUint(reinterpret_cast<unsigned int*>(pul));
#endif
}

bool XdrEncode::XdrInt(int *pi)
{
	return PutInt(*pi);
}

bool XdrDecode::XdrInt(int* pi)
{
	return GetInt(pi);
}

bool XdrEncode::XdrUint(unsigned int *pi)
{
	return PutUint(*pi);
}

bool XdrDecode::XdrUint(unsigned int* pi)
{
	return GetUint(pi);
}

bool XdrEncode::XdrShort(short* sp)
{
	int i = (int) *sp;
	return PutInt(i);
}

bool XdrDecode::XdrShort(short* sp)
{
	int i = 0;
	if (!GetInt(&i))
	{
		return false;
	}
	*sp = (short)i;
	return true;
}

bool XdrEncode::XdrUshort (unsigned short* pus)
{
	unsigned int ui = (unsigned int) *pus;
	return PutUint(ui);
}

bool XdrDecode::XdrUshort (unsigned short* pus)
{
	unsigned int ui = 0;
	if (!GetUint(&ui))
	{
		return false;
	}
	*pus = (unsigned int)ui;
	return true;
}

bool XdrEncode::XdrInt64 (int64_t* pi64)
{
	return PutInt64 (*pi64);
}

bool XdrDecode::XdrInt64 (int64_t* pi64)
{
	return GetInt64 (pi64);
}

bool XdrEncode::XdrUint64 (uint64_t* pui64)
{
	return PutUint64 (*pui64);
}

bool XdrDecode::XdrUint64 (uint64_t* pui64)
{
	return GetUint64 (pui64);
}

bool XdrEncode::XdrBool (bool* pb)
{
	int i = (int)*pb;
	return PutInt(i);
}

bool XdrDecode::XdrBool (bool* pb)
{
	int i = 0;
	if (!GetInt(&i))
	{
		return false;
	}
	*pb = i == 0 ? false : true;
	return true;
}

bool XdrEncode::XdrFloat (float* pf)
{
	return PutFloat (*pf);
}

bool XdrDecode::XdrFloat (float* pf)
{
	return GetFloat (pf);
}

bool XdrEncode::XdrDouble (double* pd)
{
	return PutDouble (*pd);
}

bool XdrDecode::XdrDouble (double* pd)
{
	return GetDouble (pd);
}

// CXDR opaque data
// Allows the specification of a fixed size sequence of opaque bytes.
// pc points to the opaque object and uiCnt gives the byte length.
bool XdrEncode::XdrOpaque(char* pc, unsigned int uiCnt)
{
	return EncodeOpaque(pc, uiCnt);
}

bool XdrEncode::EncodeOpaque(const char* pc, unsigned int uiCnt)
{
	static unsigned char crud[BYTES_PER_XDR_UNIT];

	// if no data we are done
	if (uiCnt == 0)
	{
		return true;
	}
	// write the data
	if (!PutBytes(pc, uiCnt))
	{
		return false;
	}

	// calculate padding - round byte count to full xdr units
	unsigned int uiRndup = uiCnt % BYTES_PER_XDR_UNIT;
	if (uiRndup > 0)
	{
		uiRndup = BYTES_PER_XDR_UNIT - uiRndup;
	}
	if (uiRndup == 0)
	{
		return true;
	}
	// write the padding
	return PutBytes (crud, uiRndup);
}

bool XdrDecode::XdrOpaque(char* pc, unsigned int uiCnt)
{
	static unsigned char crud[BYTES_PER_XDR_UNIT];

	// if no data we are done
	if (uiCnt == 0)
	{
		return true;
	}

	// round byte count to full xdr units
	unsigned int uiRndup = uiCnt % BYTES_PER_XDR_UNIT;

	if (uiRndup > 0)
	{
		uiRndup = BYTES_PER_XDR_UNIT - uiRndup;
	}

	if (!GetBytes(pc, uiCnt))
	{
		return false;
	}

	if (uiRndup == 0)
	{
		return true;
	}
	return GetBytes(crud, uiRndup);
}

bool XdrEncode::XdrBytes(char* data, unsigned int bytes)
{
	if (bytes == 0)
	{
		return true;
	}

	return PutBytes(data,bytes);
}

bool XdrDecode::XdrBytes(char* data, unsigned int bytes)
{
	return GetBytes(data,bytes);
}

bool XdrEncode::XdrIntInOneByte (int* pi)
{
	char temp = (char)*pi;
	return PutBytes(&temp,1);
}

bool XdrDecode::XdrIntInOneByte (int* pi)
{
	char temp = 0;
	if( !GetBytes(&temp,1) )
	{
		return false;
	}
	*pi = (int)temp;
	return true;
}

bool XdrEncode::XdrUintInOneByte (unsigned int* pi)
{
	unsigned char temp = (unsigned char)*pi;
	return PutBytes(&temp,1);
}

bool XdrDecode::XdrUintInOneByte (unsigned int* pi)
{
	unsigned char temp = 0;
	if (!GetBytes(&temp,1))
	{
		return false;
	}
	*pi = (unsigned int)temp;
	return true;
}

bool XdrEncode::XdrBoolInOneByte( bool * pi)
{
	unsigned char temp = (unsigned char)*pi;
	return PutBytes(&temp,1);
}

bool XdrDecode::XdrBoolInOneByte( bool * pi)
{
	unsigned char temp = 0;
	if( !GetBytes(&temp,1) )
	{
		return false;
	}
	*pi = temp == 0 ? false : true;
	return true;
}

bool XdrEncode::XdrUintInTwoByte (unsigned int* pi)
{
	unsigned short temp = (unsigned short)*pi;
	temp = FLIP(temp);
	return PutBytes(&temp,2);
}

bool XdrDecode::XdrUintInTwoByte (unsigned int* pi)
{
	unsigned short temp = 0;
	if (!GetBytes(&temp,2))
	{
		return false;
	}
	temp = FLIP(temp);
	*pi = (unsigned int)temp;
	return true;
}

bool XdrEncode::XdrStringPadded(char **ppc, unsigned int uiMaxsize)
{
	char *ps = *ppc;  // sp is the actual string pointer
	unsigned int uiSize = strlen(ps);

	// first deal with the length since xdr strings are counted-strings
	if (!XdrUint(&uiSize) || uiSize > uiMaxsize)
	{
		return false;
	}
	return (XdrOpaque(ps, uiSize));
}

bool XdrDecode::XdrStringPadded(char **ppc, unsigned int uiMaxsize)
{
	char *ps = *ppc;  // sp is the actual string pointer
	unsigned int uiSize = strlen(ps);

	// first deal with the length since xdr strings are counted-strings
	if (!XdrUint(&uiSize) || uiSize > uiMaxsize)
	{
		return false;
	}

	unsigned int uiNodeSize = uiSize + 1;
	if(uiNodeSize == 0)
	{
		return true;
	}

	if(ps == 0)
	{
		*ppc = ps = (char *)xmalloc(uiNodeSize);
	}

	if(ps == 0)
	{
		return false;
	}

	ps[uiSize] = 0;
	return (XdrOpaque(ps, uiSize));
}

bool XdrEncode::XdrStringPacked(string &str)
{
	unsigned int size = str.get_length();

	if (!XdrUint(&size))
	{
		return false;
	}
	if (0 == size)
	{
		return true;
	}
	return PutBytes(str.c_str(), size);
}

bool XdrDecode::XdrStringPacked(string &str)
{
	unsigned int size = 0;

	if (!XdrUint(&size))
	{
		return false;
	}
	//sanity check:
	if(size > ( m_last - m_next) )
	{
		//This string cannot possible really be this long-
		//must be a corrupted XDR message
		return false;
	}

	if (!str.set_maxlength(size+1))
	{
		return false;
	}

	char *buf = str.get_buffer();
	buf[size] = 0;
	return (XdrBytes(buf, size));
}

bool XdrEncode::XdrStringPadded(string &str)
{
	unsigned int size = str.get_length();

	if (!XdrUint(&size))
	{
		return false;
	}
	return EncodeOpaque(str.c_str(), size);
}

bool XdrDecode::XdrStringPadded(string &str)
{
	unsigned int size = 0;

	if (!XdrUint(&size))
	{
		return false;
	}
	//sanity check:
	if(size > ( m_last - m_next) )
	{
		//This string cannot possible really be this long-
		//must be a corrupted XDR message
		return false;
	}

	if (!str.set_maxlength(size+1))
	{
		return false;
	}

	char *buf = str.get_buffer();
	buf[size] = 0;
	return (XdrOpaque(buf, size));
}

bool XdrDecode::XdrSkip(unsigned int len)
{
	// Is there enough room in the buffer?
	if ((m_last - m_next) < len)
	{
		return false;
	}
	// update the index
	m_next += len;
	return true;
}

bool XdrEncode::PutInt(int x)
{
	x = FLIP(x);
	return PutBytes(&x, sizeof(int));
}

bool XdrDecode::GetInt(int *x)
{
	if (!GetBytes(x, sizeof(int)))
	{
		return false;
	}
	*x = FLIP(*x);
	return true;
}

bool XdrEncode::PutUint(unsigned int x)
{
	x = FLIP(x);
	return PutBytes(&x, sizeof(unsigned int));
}

bool XdrDecode::GetUint(unsigned int *x)
{
	if (!GetBytes(x, sizeof(unsigned int)))
	{
		return false;
	}
	*x = FLIP(*x);
	return true;
}

bool XdrEncode::PutInt64 (int64_t x)
{
	x = FLIP64(x);
	return PutBytes (&x, sizeof(int64_t));
}

bool XdrDecode::GetInt64 (int64_t* pi64)
{
	if( !GetBytes (pi64, sizeof(int64_t)) )
	{
		return( false );
	}
	*pi64 = FLIP64( *pi64 );
	return( true );
}

bool XdrEncode::PutUint64 (uint64_t x)
{
	x = FLIP64(x);
	return PutBytes (&x, sizeof(uint64_t));
}

bool XdrDecode::GetUint64 (uint64_t* pui64)
{
	if( !GetBytes (pui64, sizeof(uint64_t)) )
	{
		return false;
	}

	*pui64 = FLIP64( *pui64 );
	return( true );
}

bool XdrEncode::PutFloat (float x)
{
	x = FLIP( x );
	return PutBytes (&x, sizeof(float));
}

bool XdrDecode::GetFloat (float* pf)
{
	if( !GetBytes (pf, sizeof(float)) )
	{
		return false;
	}

	*pf = FLIP( *pf );
	return( true );
}

bool XdrEncode::PutDouble (double d)
{
	d = FLIP (d);
	return PutBytes (&d, sizeof(double));
}

bool XdrDecode::GetDouble (double* pd)
{
//	unsigned long* pul_1 = (unsigned long *)pd;
//	unsigned long* pul_2 = pul_1 + 1;

//	if( !GetBytes (pd, sizeof(double)) )
//	return( false );

//	*pul_1 = FLIP (*pul_1);
//	*pul_2 = FLIP (*pul_2);

//	return( true );

	if( !GetBytes (pd, sizeof(double)) )
	{
		return( false );
	}

	*pd = FLIP( *pd );

	return( true );
}

bool XdrEncode::PutBytes(const void* pData, unsigned int len)
{
	// Is there enough room in the buffer?
	if (( m_last - m_next) < len)
	{
		return false;
	}

	// Copy the data
	memcpy (&mp_Base[m_next], pData, len);

	// update the index
	m_next += len;

	return true;
}

bool XdrDecode::GetBytes (void* pData, unsigned int len)
{
	// Is there enough room in the buffer?
	if (( m_last - m_next) < len)
	{
		return false;
	}

	// Copy the data
	memcpy (pData, &mp_Base[m_next], len);

	// update the index
	m_next += len;

	return true;
}

////////////////////////////////////////////////////////////////////////////////
//
//      Class Name: EncodableItem
//
////////////////////////////////////////////////////////////////////////////////
//
CEncodableItem::~CEncodableItem()
{
}

CEncodableItem::CEncodableItem()
{
}

bool CEncodableItem::Encode(char* pData, unsigned int* len)
{
	XdrEncode xdr(pData, *len);
	return Encode (&xdr, len);
}

bool CEncodableItem::Encode(MultiEncodeIntf &mei, unsigned int *len, bool prepend_len)
{
	XdrBuffEncode xdr(mei);
	bool success = true;
	if (prepend_len)
	{
		// Reserve space for length.
		success = xdr.XdrUint (len);
	}

	if (success)
	{
		// Encode itm.
		success = Encode(&xdr, len);
	}

	if (success && prepend_len)
	{
		// Prepend buf length (does not include size of the length itself)
		xdr.PrependLength(*len - sizeof(unsigned int));
	}
	return success;
}

bool CEncodableItem::Encode(CXDR* pXdr, unsigned int* len)
{
	if (pXdr != 0)
	{
		if (!XdrProc (pXdr))
		{
			return false;
		}
		*len = pXdr->GetLength();
		return true;
	}
	*len = 0;
	return false;
}

bool CEncodableItem::Decode (char* pData, unsigned int len)
{
	XdrDecode xdr(pData, len);
	return XdrProc(&xdr);
}

}
