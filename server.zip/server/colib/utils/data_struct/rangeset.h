//rangeset.h

#ifndef rangeset_h_already_included
#define rangeset_h_already_included

#include<utils/data_struct/dlist.h>
#include<utils/trace/trace.h>

namespace colib
{

//TYPE must support
// assignment, copy, <  <= >  >= == addition/subtraction with integer 1 increment decrement

template < typename TYPE > class range_t
{
public:
	range_t(){m_start=m_stop=0;}
	range_t(TYPE start, TYPE stop){ m_start=start; m_stop=stop; }		

	bool adjoins( TYPE value )const;
	bool adjoins( const range_t<TYPE> &to )const;
	
	range_t<TYPE>& combine( const range_t<TYPE> &with );
	range_t<TYPE>& normalize();
	
	TYPE m_start;
	TYPE m_stop;
};

// Could we use sorted STL here?
// Would be faster...
template < typename TYPE > class rangeset_t
{
public:
	typedef typename Dlist< range_t<TYPE> >::Node *iterator;

	bool contains( TYPE value ) const;
	bool contains( const range_t<TYPE> &r ) const;
	bool contains( const rangeset_t<TYPE> &r ) const;
	bool add( TYPE value );
	bool add( range_t<TYPE> r );
	bool add( rangeset_t<TYPE> &r );
	bool remove( TYPE value );
	bool remove( range_t<TYPE> r );
	bool remove( const rangeset_t<TYPE> &r );
	TYPE get_next_hole( TYPE start_value ) const;

	//returns the first TYPE in this set >= start_value
	bool get_next_in_set( TYPE start_value, TYPE &next ) const;
	
	void reset();
	void collapse();
	bool empty() const; //returns true if rangeset is empty

	iterator get_first_range() const;
	iterator get_next_range( iterator from )const;
	range_t<TYPE>& get_range( iterator from )const;

	Dlist< range_t<TYPE> >& get_set()  {return m_set;}

private:
	Dlist< range_t<TYPE> > m_set;
};

typedef rangeset_t<int> rangeset;
typedef range_t<int>    range_int;


inline void rangesetIntPrintDEBUG(rangeset_t<int> mySet) 
{
   TRACE("enter rangesetIntPrint\n");
   rangeset_t<int>::iterator iter;
	for( iter=mySet.get_set().GetHead(); iter ; iter=mySet.get_set().GetNext(iter) )
	{
	   TRACE("range_start %i\n", iter->m_data.m_start);
	   TRACE("range_stop %i\n",  iter->m_data.m_stop);
	}
}

template < typename TYPE > inline bool range_t<TYPE>::adjoins( TYPE value )const
{
	return m_start <= value+1 && m_stop+1 >= value;
}

template < typename TYPE > inline bool range_t<TYPE>::adjoins( const range_t<TYPE> &to )const
{
	return m_start <= to.m_stop+1 && m_stop+1 >= to.m_start;
}

template < typename TYPE > inline range_t<TYPE>& range_t<TYPE>::combine( const range_t<TYPE> &with )
{
	if( m_start > with.m_start )
		m_start = with.m_start;
	if( m_stop < with.m_stop )
		m_stop = with.m_stop;

	return *this;
}
template < typename TYPE > inline range_t<TYPE>& range_t<TYPE>::normalize()
{
	if(m_stop<m_start)
	{
		TYPE temp=m_start;
		m_start = m_stop;
		m_stop=temp;
	}
	
	return *this;
}

template < typename TYPE > inline void rangeset_t<TYPE>::reset()
{
	m_set.Clear();
}
template < typename TYPE > inline typename rangeset_t<TYPE>::iterator rangeset_t<TYPE>::get_first_range()const
{
	return m_set.GetHead();
}
template < typename TYPE > inline typename rangeset_t<TYPE>::iterator rangeset_t<TYPE>::get_next_range( iterator from )const
{
	return m_set.GetNext(from);
}
template < typename TYPE > inline range_t<TYPE>& rangeset_t<TYPE>::get_range( iterator from )const
{
	return from->m_data;
}

template < typename TYPE > bool rangeset_t<TYPE>::empty() const
{
	return m_set.IsEmpty();
}

template < typename TYPE > void rangeset_t<TYPE>::collapse()
{
	iterator check,next;
	for(check=m_set.GetHead(); check; check=next )
	{
		while( (next = m_set.GetNext(check)) != 0)
		{
			if( check->m_data.adjoins(next->m_data) )
			{
				check->m_data.combine(next->m_data);
				m_set.Remove(next);
			}
			else
				break;
		}
	}
}

template < typename TYPE > inline bool rangeset_t<TYPE>::contains( TYPE value ) const
{
   	iterator iter;
	for( iter=m_set.GetHead(); iter ; iter=m_set.GetNext(iter) )
	{
		if( value < iter->m_data.m_start )
			return false;
		if( value <= iter->m_data.m_stop )
			return true;
	}
	return false;
}

template < typename TYPE > bool rangeset_t<TYPE>::contains( const range_t<TYPE> &r ) const
{
	for (iterator i = m_set.GetHead(); i; i = m_set.GetNext(i))
	{
		if (r.m_start >= i->m_data.m_start )
		{
			if( r.m_stop <= i->m_data.m_stop)
				return true;
		}
		else
			//no chance of matching now
			break;
	}

	return false;
}
template < typename TYPE > bool rangeset_t<TYPE>::contains( const rangeset_t<TYPE> &r ) const
{
	iterator riter = r.m_set.GetHead();
	if(!riter)
		return true;

	for( iterator i = m_set.GetHead(); i; )
	{
		if( riter->m_data.m_start >= i->m_data.m_start)
		{
			if( riter->m_data.m_stop <= i->m_data.m_stop )
			{
				riter = r.m_set.GetNext(riter);
				if(!riter)
					return true;
				continue;
			}
		}
		else
			//no chance of matching now
			break;
		i = m_set.GetNext(i);
	}

	return false;
}

template < typename TYPE > bool rangeset_t<TYPE>::add( TYPE value )
{
	iterator iter;
	for( iter=m_set.GetHead(); iter ; iter=m_set.GetNext(iter) )
	{
		if( value < iter->m_data.m_start )
		{
			if( value+1 >= iter->m_data.m_start )
			{
				//adjoins start of this range_t<TYPE>
				iter->m_data.m_start = value;
				return true;
			}
			else
				//before this range_t<TYPE>
				break;
		}
		
		if( value <= iter->m_data.m_stop+1 )
		{
			if( value > iter->m_data.m_stop )
			{
				//adjoins stop of this range_t<TYPE>
				iter->m_data.m_stop = value;
				//check for next range_t<TYPE> collapse
				iterator next = m_set.GetNext(iter);
				if( next && 
					iter->m_data.m_stop+1 >= next->m_data.m_start )
				{
					//subsequent range_t<TYPE> adjoinment
					iter->m_data.m_stop = next->m_data.m_stop;
					m_set.Remove(next);
				}
			}
			return true;
		}
		//after this range_t<TYPE>
	}


	//not contained or adjoined by any extant range_t<TYPE>
	if(iter) {
		   return m_set.InsertBefore( range_t<TYPE>(value,value), iter ) != 0;
	}
	else {
		   return m_set.Append( range_t<TYPE>(value,value) ) != 0;
	}
}

template < typename TYPE > bool rangeset_t<TYPE>::add( range_t<TYPE> r )
{
	r.normalize();

	iterator iter;
	for( iter=m_set.GetHead(); iter ; iter=m_set.GetNext(iter) )
	{
		if( iter->m_data.m_stop+1 >= r.m_start )
		{
			if( iter->m_data.m_start <= r.m_stop+1 )
			{
				//adjoins this range_t<TYPE>
				iter->m_data.combine(r);
				collapse();
				return true;
			}
			else
				//before this range_t<TYPE>
				break;
		}
		//after this range_t<TYPE>
	}
	//not contained or adjoined by any extant range_t<TYPE>
	if(iter)
		return m_set.InsertBefore( r, iter ) != 0;
	else
		return m_set.Append( r ) != 0;
}

template < typename TYPE > bool rangeset_t<TYPE>::add (rangeset_t<TYPE> &r)
{
	for (iterator i = r.m_set.GetHead(); i; i = r.m_set.GetNext(i))
	{
		if (!add(i->m_data))
			return false;
	}
	return true;
}

template < typename TYPE > TYPE rangeset_t<TYPE>::get_next_hole( TYPE start_value ) const
{
	iterator iter;
	for( iter=m_set.GetHead(); iter ; iter=m_set.GetNext(iter) )
	{
		if( start_value < iter->m_data.m_start )
			return start_value;
		if( start_value <= iter->m_data.m_stop )
			start_value = iter->m_data.m_stop + 1;
	}
	return start_value;
}
template < typename TYPE > bool rangeset_t<TYPE>::get_next_in_set( TYPE start_value, TYPE &next ) const
{
	iterator iter;
	for( iter=m_set.GetHead(); iter ; iter=m_set.GetNext(iter) )
	{
		if( start_value < iter->m_data.m_start )
		{
			next = iter->m_data.m_start;
			return true;
		}
		if( start_value <= iter->m_data.m_stop )
		{
			next = start_value;
			return true;
		}
	}
	return false;
}

template < typename TYPE > bool rangeset_t<TYPE>::remove( TYPE value )
{
	iterator iter;
	for( iter=m_set.GetHead(); iter ; iter=m_set.GetNext(iter) )
	{
		if( value < iter->m_data.m_start )
			//value is not in any range_t<TYPE>
			return true;
		if( value <= iter->m_data.m_stop )
		{
			//we must shrink the current range_t<TYPE>- or break it in two
			if(value == iter->m_data.m_start )
			{
				++iter->m_data.m_start;
				if(iter->m_data.m_start > iter->m_data.m_stop)
					m_set.Remove(iter);
			}
			else if( value == iter->m_data.m_stop )
				--iter->m_data.m_stop;
			else
			{
				if( !m_set.InsertAfter( range_t<TYPE>( value+1, iter->m_data.m_stop ), iter ) )
						return false;
				iter->m_data.m_stop = value-1;
			}
			return true;
		}
	}
	//value is past the end of the rangeset_t
	return true;
}

template < typename TYPE > bool rangeset_t<TYPE>::remove( range_t<TYPE> r )
{
	iterator iter,next;
	for( iter=m_set.GetHead(); iter ; iter=next )
	{
		next=m_set.GetNext(iter);
		if( r.m_stop < iter->m_data.m_start )
			//this is past "r"
			return true;
		if( r.m_start <= iter->m_data.m_stop )
		{
			//we must shrink the current range_t<TYPE>- or break it in two
			if(r.m_start > iter->m_data.m_start )
			{
				if( r.m_stop < iter->m_data.m_stop )
				{
					//r is contained in this range, split it in two
					if( !m_set.InsertAfter( range_t<TYPE>( r.m_stop+1, iter->m_data.m_stop ), iter ) )
							return false;
				}
				//the beginning of r is in this range, Recede m_stop
				iter->m_data.m_stop = r.m_start-1;
			}
			else if( r.m_stop < iter->m_data.m_stop )
			{
				//the end of r is in this range. Move Start ahead
				iter->m_data.m_start = r.m_stop+1;
			}
			else
			{
				//this range completely encompassed
				m_set.Remove(iter);
			}
		}
	}
	//value is past the end of the rangeset_t
	return true;
}

template < typename TYPE > bool rangeset_t<TYPE>::remove( const rangeset_t<TYPE> &r )
{
	iterator riter = r.m_set.GetHead();
	if(!riter)
		return true;

	iterator iter,next;
	for( iter=m_set.GetHead(); iter ;  )
	{
		next=m_set.GetNext(iter);

		if( riter->m_data.m_stop < iter->m_data.m_start )
		{
			//this is past "r"
			riter = r.m_set.GetNext(riter);
			if (!riter) {
				return true;
			}
			// don't do iter=next; at the end of the loop
			continue;
		}
		
		if( riter->m_data.m_start <= iter->m_data.m_stop )
		{
			//we must shrink the current range_t<TYPE>- or break it in two
			if(riter->m_data.m_start > iter->m_data.m_start )
			{
				if( riter->m_data.m_stop < iter->m_data.m_stop )
				{
					//r is contained in this range, split it in two
					if( !(next=m_set.InsertAfter( range_t<TYPE>( riter->m_data.m_stop+1, iter->m_data.m_stop ), iter )) )
							return false;
				}
				//the beginning of r is in this range, Recede m_stop
				iter->m_data.m_stop = riter->m_data.m_start-1;
			}
			else if( riter->m_data.m_stop < iter->m_data.m_stop )
			{
				//the end of r is in this range. Move Start ahead
				iter->m_data.m_start = riter->m_data.m_stop+1;
				// but don't do iter=next; as it is possible to remove again from this range
			    // just get the next RHS range, if one, for efficiency purposes
				riter = r.m_set.GetNext(riter);
				if (!riter) {
					return true;
				}
				// jump over iter=next;
				continue;
			}
			else
			{
				//this range completely encompassed
				m_set.Remove(iter);
			}
		}

		iter=next;
	}
	//value is past the end of the rangeset_t
	return true;
}

}

#endif
