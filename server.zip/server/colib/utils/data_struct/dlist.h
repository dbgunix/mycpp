//dlist.h

#ifndef __DLIST_H__
#define __DLIST_H__

#include<utils/assert.h>
#include <stdlib.h>

//#define _DEBUG_DLIST_
#ifdef _DEBUG_DLIST_
#define DLIST_ASSERT(exp)	if (exp) (void)0; else colib::OnAssert(#exp, __FILE__, __LINE__)
#else
#define DLIST_ASSERT(exp)	(void)0
#endif

namespace colib
{

template<typename T> class Dlist
{
public:
	typedef bool (*search_func)(void *ctx,const T &cmp);
	typedef int (*sort_func) (const T &x, const T &y);

	class Node
	{
	public:
		Node()
			: m_next(NULL)
			, m_prev(NULL)
			, m_data()
			, m_parent(NULL)
		{
		}
		~Node();
		void MoveTo(Dlist &from,Dlist &to);
		void MoveTo(Dlist *to);
		void MoveToPrepend(Dlist *to);
		void SelfExtract();

		T& GetData(){return m_data;}
		const T& GetData()const{return m_data;}

		Node *m_next,*m_prev;
		T m_data;

		Dlist *m_parent;

		Node(const Node&) = delete;
		Node& operator=(const Node&) = delete;
	};

	Dlist();
	Dlist( const Dlist<T> &of );
	virtual ~Dlist();
	Dlist<T>& operator=(const Dlist<T> &to);

	T Get    ( ); // use this if T is an object
	T GetPtr ( ); // use this if T is a pointer

	Node* Append (const T& item);
	Node* Prepend(const T& item);
	bool Remove (const T& item);
	Node* Insert( const T& item, sort_func f );
	Node* InsertAfter( const T& item, Node *after );
	Node* InsertBefore( const T& item, Node *before );

	Node* Append();
	Node* Prepend();
	Node* InsertAfter( Node *after );
	Node* InsertBefore( Node *before );

	void Append (Node* node);
	void Prepend(Node* node);
	Node* Extract (Node* node);
	void Remove (Node *node);
	void Insert( Node *node, sort_func f);
	void InsertAfter( Node *node, Node *after );
	void InsertBefore( Node *node, Node *before );

	void Append ( Dlist<T> &from );
	void Prepend ( Dlist<T> &from );
	Node* FindOrAdd( const T& item );

	bool IsEmpty () const;
	int Size () const;
	void Clear ();
	void Randomize ();

	Node* GetHead()const;
	Node* GetTail()const;
	Node* GetNext( Node *node )const;
	Node* GetPrev( Node *node )const;
	Node* Find   (const T& item);
	Node* Search (search_func srch, void *ctx);

	void Rotate(Node* node = 0);

	T& GetData(Node *node ) const;

	const Node* GetNext( const Node *node )const;
	const Node* GetPrev( const Node *node )const;

protected:
	Node *m_pTail;
	int m_iSize;
};

template<typename T> inline Dlist<T>::Node::~Node()
{
	SelfExtract();
}

template<typename T> inline void Dlist<T>::Node::MoveTo(Dlist<T> &from, Dlist<T> &to)
{
	to.Append(from.Extract(this));
}

template<typename T> inline void Dlist<T>::Node::MoveTo(Dlist<T> *to)
{
	DLIST_ASSERT(0 != to );
	if ( !m_parent ) to->Append(this);
	else if( m_parent != to ) to->Append(m_parent->Extract(this));
}

template<typename T> inline void Dlist<T>::Node::MoveToPrepend(Dlist<T> *to)
{
	DLIST_ASSERT(0 != to );
	if ( !m_parent ) to->Prepend(this);
	else if( m_parent != to ) to->Prepend(m_parent->Extract(this));
}

template<typename T> inline void Dlist<T>::Node::SelfExtract()
{
	if ( m_parent ) m_parent->Extract(this);
}

template<typename T> inline Dlist<T>::Dlist()
	: m_pTail(0)
	, m_iSize(0)
{
}

template<typename T> inline Dlist<T>::Dlist( const Dlist<T> &of )
	: m_pTail(0)
	, m_iSize(0)
{
	Node *node;
	for( node=of.GetHead(); node!=0 ; node = of.GetNext(node) )
	{
		if( !Append( node->m_data ) )
			break;
	}
}

template<typename T> inline Dlist<T>::~Dlist()
{
	Clear ();
}

template<typename T> inline typename Dlist<T>::Node* Dlist<T>::GetHead()const
{
	if( m_pTail )
	{
		DLIST_ASSERT(m_pTail->m_parent == this);
		DLIST_ASSERT(m_pTail->m_prev != 0);
		DLIST_ASSERT(m_pTail->m_next != 0);
		return m_pTail->m_next;
	}
	else
	{
		return 0;
	}
}
template<typename T> inline typename Dlist<T>::Node* Dlist<T>::GetTail() const
{
#ifdef _DEBUG_DLIST_
    if (m_pTail != 0)
	{
		DLIST_ASSERT(m_pTail->m_parent == this);
		DLIST_ASSERT(m_pTail->m_prev != 0);
		DLIST_ASSERT(m_pTail->m_next != 0);
	}
#endif
	return m_pTail;
}
template<typename T> inline T& Dlist<T>::GetData(Node *node ) const
{
	return node->m_data;
}
template<typename T> inline typename Dlist<T>::Node* Dlist<T>::GetNext( Node *node ) const
{
	DLIST_ASSERT(node != 0);
	DLIST_ASSERT(node->m_parent == this);
	DLIST_ASSERT(node->m_prev != 0);
	DLIST_ASSERT(node->m_next != 0);
	if( node == m_pTail )
		return 0;
	return node->m_next;
}
template<typename T> inline typename Dlist<T>::Node* Dlist<T>::GetPrev( Node *node ) const
{
	DLIST_ASSERT(node != 0);
	DLIST_ASSERT(node->m_parent == this);
	DLIST_ASSERT(node->m_prev != 0);
	DLIST_ASSERT(node->m_next != 0);
	node = node->m_prev;
	DLIST_ASSERT(node->m_prev != 0);
	DLIST_ASSERT(node->m_next != 0);
	if( node == m_pTail )
		return 0;
	return node;
}

template<typename T> inline const typename Dlist<T>::Node* Dlist<T>::GetNext( const Node *node ) const
{
	DLIST_ASSERT(node != 0);
	DLIST_ASSERT(node->m_parent == this);
	DLIST_ASSERT(node->m_prev != 0);
	DLIST_ASSERT(node->m_next != 0);
	if( node == m_pTail )
		return 0;
	return node->m_next;
}
template<typename T> inline const typename Dlist<T>::Node* Dlist<T>::GetPrev( const Node *node ) const
{
	DLIST_ASSERT(node != 0);
	DLIST_ASSERT(node->m_parent == this);
	DLIST_ASSERT(node->m_prev != 0);
	DLIST_ASSERT(node->m_next != 0);
	node = node->m_prev;
	DLIST_ASSERT(node->m_prev != 0);
	DLIST_ASSERT(node->m_next != 0);
	if( node == m_pTail )
		return 0;
	return node;
}

template<typename T> inline bool Dlist<T>::IsEmpty() const
{
	return (m_pTail == 0);
}

template<typename T> inline int Dlist<T>::Size() const
{
	return m_iSize;
}

// Enqueue to the head of the list
template<typename T> inline typename Dlist<T>::Node* Dlist<T>::Prepend(const T& item)
{
	Node *node = new Node;
	if(!node)
		return 0;
	node->m_data = item;
	Prepend(node);

	return node;
}

// Enqueue to the tail of the list
template<typename T> inline typename Dlist<T>::Node* Dlist<T>::Append(const T& item)
{
	Node * node = new Node;
	if(!node)
		return 0;
	node->m_data = item;
	Append(node);

	return node;
}
template<typename T> inline typename Dlist<T>::Node* Dlist<T>::Append()
{
	Node * node = new Node;
	if(!node)
		return 0;
	Append(node);

	return node;
}
template<typename T> inline typename Dlist<T>::Node* Dlist<T>::Prepend()
{
	Node *node = new Node;
	if(!node)
		return 0;
	Prepend(node);

	return node;
}

template<typename T> inline void Dlist<T>::Prepend( Node *node )
{
	DLIST_ASSERT(node != 0);
//	DLIST_ASSERT(node->m_parent == 0);
//	DLIST_ASSERT(node->m_prev == 0);
//	DLIST_ASSERT(node->m_next == 0);
	if ( !m_pTail )
	{
		m_pTail = node;						 // Tail points to the new node
		m_pTail->m_next = m_pTail;		 // next points to itself
		m_pTail->m_prev = m_pTail;		 // next points to itself
	}
	else
	{
		DLIST_ASSERT(m_pTail->m_prev != 0);
		DLIST_ASSERT(m_pTail->m_next != 0);
		node->m_next = m_pTail->m_next;				// node points to head
		node->m_prev = m_pTail;
		m_pTail->m_next->m_prev = node;
		m_pTail->m_next = node;					// tail points to node
	}

	node->m_parent = this;

	DLIST_ASSERT(node->m_prev->m_next == node);
	DLIST_ASSERT(node->m_next->m_prev == node);
	m_iSize++;
}
template<typename T> inline void Dlist<T>::Append( Node *node )
{
	DLIST_ASSERT(node != 0);
	DLIST_ASSERT(node->m_parent == 0);
//	DLIST_ASSERT(node->m_prev == 0);
//	DLIST_ASSERT(node->m_next == 0);
	Prepend( node );
	m_pTail = node;
}


template<typename T> inline T Dlist<T>::Get()
{
	T item;
	if (!m_pTail)
		return item;

	DLIST_ASSERT(m_pTail->m_parent == this);
	DLIST_ASSERT(m_pTail->m_prev != 0);
	DLIST_ASSERT(m_pTail->m_next != 0);

	Node* head = m_pTail->m_next;

	item = head->m_data;

	delete head;
	return item;
}

template<typename T> inline T Dlist<T>::GetPtr ( )
{
	if ( ! m_pTail )
		return NULL;

	DLIST_ASSERT(m_pTail->m_parent == this);
	DLIST_ASSERT(m_pTail->m_prev != 0);
	DLIST_ASSERT(m_pTail->m_next != 0);

	Node* head = m_pTail->m_next;

	T pItem = head->m_data;

	delete head;
	return pItem;
}

template<typename T> inline bool Dlist<T>::Remove(const T& item)
{
	for( Node* iter = GetHead(); iter != 0; iter=GetNext(iter) )
	{
		// Did we stumble across the item?
		if( item == iter->m_data )
		{
	//		delete Extract(iter);
			delete iter;

			return true;
		}
	}

	return false;
}
template<typename T> inline typename Dlist<T>::Node* Dlist<T>::Insert(const T& item, sort_func f)
{
	for( Node* iter = GetHead(); iter != 0; iter=GetNext(iter) )
	{
		// Insert item before the first member who is
		// "greater-than" or "equal-to" item.
		if( f(iter->m_data, item) >= 0 )
			return InsertBefore(item, iter);
	}
	return Append(item);
}
template<typename T> inline void Dlist<T>::Insert(Node* node, sort_func f)
{
	for( Node* iter = GetHead(); iter != 0; iter=GetNext(iter) )
	{
		// Insert item before the first member who is
		// "greater-than" or "equal-to" item.
		if( f(iter->m_data, node->m_data) >= 0 )
		{
			InsertBefore(node, iter);
			return;
		}
	}
	Append(node);
}

template<typename T> inline typename Dlist<T>::Node* Dlist<T>::Find(const T& item)
{
	for( Node *iter = GetHead(); iter != 0; iter=GetNext(iter) )
	{
		// Did we stumble across the item?
		if (item == iter->m_data )
			return iter;
	}
	return 0;
}

template<typename T> inline typename Dlist<T>::Node* Dlist<T>::FindOrAdd( const T& item )
{
	Node *ret = Find(item);

	if(!ret)
	{
		ret = new Node;

		if(ret)
		{
			ret->m_data = item;
			Append(ret);
		}
	}

	return ret;
}

template<typename T> inline typename Dlist<T>::Node* Dlist<T>::Search(search_func srch, void *ctx)
{
	for( Node *iter = GetHead(); iter != 0; iter=GetNext(iter) )
	{
		// Did we stumble across the item?
		if( (*srch)(ctx,iter->m_data) )
			return iter;
	}
	return 0;
}

template<typename T> inline typename Dlist<T>::Node* Dlist<T>::Extract( Node* node )
{
	DLIST_ASSERT(node != 0);
	DLIST_ASSERT(node->m_parent == this);
	DLIST_ASSERT(node->m_prev != 0);
	DLIST_ASSERT(node->m_next != 0);
	DLIST_ASSERT(m_iSize > 0);
	// Are we removing the only item?
	if (m_iSize == 1)
		m_pTail = 0;
	else
	{
		DLIST_ASSERT(m_pTail != 0);
		DLIST_ASSERT(m_pTail->m_parent == this);
		DLIST_ASSERT(m_pTail->m_prev != 0);
		DLIST_ASSERT(m_pTail->m_next != 0);
		node->m_prev->m_next = node->m_next;
		node->m_next->m_prev = node->m_prev;

		DLIST_ASSERT(node->m_prev != node);
		DLIST_ASSERT(node->m_next != node);
		// Are we removing the tail?
		if( node == m_pTail )
			m_pTail = node->m_prev;
	}
	--m_iSize;


	node->m_parent=0;
	node->m_next = node->m_prev = 0;


	return node;
}

template<typename T> inline void Dlist<T>::Remove(Node *node)
{
	// distructor of node will automatically extract from the list
	delete node;
}

template<typename T> inline void Dlist<T>::Clear()
{
	for( Node *iter = GetHead(); iter != 0;  )
	{
		Node *next = GetNext(iter);
		delete iter;
		iter = next;
	}
	m_pTail = 0;
	m_iSize = 0;
}

// This function is not for security
template<typename T> inline void Dlist<T>::Randomize()
{
	if ( m_iSize == 0 || m_pTail == 0 ) return;

	unsigned M = ((unsigned)rand())%m_iSize;

	Node* node = GetHead();

	while (M--) node = node->m_next;

	if (node!=GetHead()) Prepend(Extract(node));
}

template<typename T> inline void Dlist<T>::Append( Dlist<T> &from )
{
	//Move all nodes from "from" to "this"
	while ( Node* node = from.GetHead() )
	{
		Append(from.Extract(node));
	}
}

template<typename T> inline void Dlist<T>::Prepend( Dlist<T> &from )
{
	//Prepend all nodes from "from" to "this"
	while ( Node* node = from.GetTail() )
	{
		Prepend(from.Extract(node));
	}
}
template<typename T> inline typename Dlist<T>::Node* Dlist<T>::InsertAfter( const T& item, Node *after )
{
	Node * node = new Node;
	if(!node)
		return 0;
	node->m_data = item;
	InsertAfter(node,after);

	return node;
}

template<typename T> inline typename Dlist<T>::Node* Dlist<T>::InsertBefore( const T& item, Node *before )
{
	Node * node = new Node;
	if(!node)
		return 0;
	node->m_data = item;
	InsertBefore(node,before);

	return node;
}

template<typename T> inline typename Dlist<T>::Node* Dlist<T>::InsertAfter(Node *after )
{
	Node * node = new Node;
	if(!node)
		return 0;
	InsertAfter(node,after);

	return node;
}

template<typename T> inline typename Dlist<T>::Node* Dlist<T>::InsertBefore(Node *before )
{
	Node * node = new Node;
	if(!node)
		return 0;
	InsertBefore(node,before);

	return node;
}


template<typename T> inline void Dlist<T>::InsertAfter( Node *node, Node *after )
{
	DLIST_ASSERT(m_pTail != 0);
	DLIST_ASSERT(m_pTail->m_parent == this);
	DLIST_ASSERT(m_pTail->m_prev != 0);
	DLIST_ASSERT(m_pTail->m_next != 0);
	DLIST_ASSERT(node != 0);
	DLIST_ASSERT(node->m_parent == 0);
//	DLIST_ASSERT(node->m_prev == 0);
//	DLIST_ASSERT(node->m_next == 0);
	DLIST_ASSERT(after != 0);
	DLIST_ASSERT(after->m_parent == this);
	DLIST_ASSERT(after->m_prev != 0);
	DLIST_ASSERT(after->m_next != 0);
	node->m_next = after->m_next;
	node->m_prev = after;
	after->m_next->m_prev = node;
	after->m_next = node;

	node->m_parent = this;

	if( after == m_pTail )
	{
		m_pTail = node;
	}
	DLIST_ASSERT(node->m_prev->m_next == node);
	DLIST_ASSERT(node->m_next->m_prev == node);
	m_iSize++;
}

template<typename T> inline void Dlist<T>::InsertBefore( Node *node, Node *before )
{
	DLIST_ASSERT(m_pTail != 0);
	DLIST_ASSERT(m_pTail->m_parent == this);
	DLIST_ASSERT(m_pTail->m_prev != 0);
	DLIST_ASSERT(m_pTail->m_next != 0);
	DLIST_ASSERT(node != 0);
	DLIST_ASSERT(node->m_parent == 0);
//	DLIST_ASSERT(node->m_prev == 0);
//	DLIST_ASSERT(node->m_next == 0);
	DLIST_ASSERT(before != 0);
	DLIST_ASSERT(before->m_parent == this);
	DLIST_ASSERT(before->m_prev != 0);
	DLIST_ASSERT(before->m_next != 0);
	node->m_prev = before->m_prev;
	node->m_next = before;
	before->m_prev->m_next = node;
	before->m_prev = node;

	node->m_parent = this;

	DLIST_ASSERT(node->m_prev->m_next == node);
	DLIST_ASSERT(node->m_next->m_prev == node);
	m_iSize++;
}

//rotate list
template<typename T> inline void Dlist<T>::Rotate(Node* node)
{
	if( m_pTail )
	{
		if ( node )
			m_pTail = node->m_prev;
		else
			m_pTail = m_pTail->m_next;
	}
}

template<typename T> inline Dlist<T>& Dlist<T>::operator=(const Dlist<T> &to)
{
	Clear();

	for( Node* node=to.GetHead(); node!=0 ; node = to.GetNext(node) )
	{
		Append(node->m_data);
	}

	return *this;
}

}

#endif
