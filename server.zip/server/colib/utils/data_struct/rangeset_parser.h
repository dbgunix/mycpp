//rangeset_parser.h

#ifndef rangeset_parser_already_included
#define rangeset_parser_already_included

#include<utils/data_struct/rangeset.h>
#include<utils/string.h>

namespace colib
{

//Functor
class ParseInt
{
public:
	bool operator()( int &ir, const char **pstr );
};

//Functor
class FormatInt
{
public:
	colib::string operator()( const int &ir );
};


template <typename TYPE, class PARSE>
bool parse_rangeset( rangeset_t<TYPE> &into, const char *str, PARSE parse );

template <typename TYPE, class FORMAT>
colib::string format_rangeset( const rangeset_t<TYPE> &from, FORMAT format);


//implementations:

inline bool rangeset_parser_isspace( char c )
{
	return c == ' ' || c == '\n' ||
		c == '\t' || c == '\r';
}


template <typename TYPE, class PARSE>
bool parse_rangeset( rangeset_t<TYPE> &into, const char *str, PARSE parse )
{
	const char *p=str;
	
	TYPE temp1,temp2;

	if(!str)
		return false;

	into.reset();
	
	while(*p)
	{
		while( rangeset_parser_isspace(*p) )
			++p;

		if( !parse(temp1,&p) )
			//failed to parse here
			return false;

		//got first value!
		while( rangeset_parser_isspace(*p) )
			++p;

		if(*p == '-')
		{
			++p;

			while( rangeset_parser_isspace(*p) )
				++p;

			//pair entry
			if( !parse(temp2,&p) )
				//failed to parse
				return false;

			//got second value!
			while( rangeset_parser_isspace(*p) )
				++p;
			
			if( !into.add( range_t<TYPE>(temp1,temp2)) )
				return false;

			if(*p == ',')
			{
				++p;
			}

			continue;
		}
		
		//a valid int was followed by non '-'
		//add a single point entry for what weve got and go on
		if(!into.add(temp1) )
			return false;
		
		if(*p == ',')
		{
			++p;
		}
	}

	return *p=='\0';
}

template <typename TYPE, class FORMAT>
colib::string format_rangeset( const rangeset_t<TYPE> &from, FORMAT format )
{
	colib::string ret;

	const char *fmt = "";
	
	typename rangeset_t<TYPE>::iterator iter = from.get_first_range();

	for(; iter; iter = from.get_next_range(iter) )
	{
		const range_t<TYPE> &r = from.get_range(iter);
		if( r.m_start == r.m_stop )
		{
			ret+=
				colib::string::combine(
				fmt,
				(const char *)format(r.m_start),
				0
				);
		}
		else
		{
			ret+= 
				colib::string::combine(
				fmt,
				(const char *)format(r.m_start),
				"-",
				(const char *)format(r.m_stop),
				0
				);
		}

		fmt = ",";
	}

	return ret;
}

}

#endif

