//rangeset_xdr.h

#ifndef rangeset_xdr_h_already_included
#define rangeset_xdr_h_already_included

#include<utils/data_struct/dlist_xdr.h>

namespace colib
{

template < typename TYPE > bool XdrPrimitiveRange( CXDR * xdr, range_t<TYPE> *t, bool (CXDR::*mfunc)(TYPE*) )
{
	if( !(xdr->*mfunc)(&t->m_start) ||
		!(xdr->*mfunc)(&t->m_stop)
		)
		return false;
	return true;
}

template < typename TYPE > bool XdrPrimitiveRangeset( CXDR * xdr, rangeset_t<TYPE> &t, bool (CXDR::*mfunc)(TYPE*) )
{
	Dlist< range_t<TYPE> > &plist = t.get_set();

	int length;
	typename Dlist< range_t<TYPE> >::Node *iter=0;
	
	if( xdr->GetOp() == CXDR::XDR_ENCODE )
	{
		length = plist.Size();
		iter = plist.GetHead();
	}
	else
	{
		plist.Clear();
	}

	if(!xdr->XdrInt(&length))
		return false;

	for(int at=0; at<length; ++at)
	{
		if( xdr->GetOp() == CXDR::XDR_DECODE )
			iter=plist.Append();

		if( !iter || ! XdrPrimitiveRange(xdr,&iter->m_data,mfunc) )
			return false;
		
		if( xdr->GetOp() == CXDR::XDR_ENCODE )
			iter = plist.GetNext(iter);
	}

	return true;
}

}

#endif

