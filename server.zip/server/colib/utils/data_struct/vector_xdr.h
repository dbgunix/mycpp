//array_xdr.h
// vi:set ts=4 sw=4 nowrap:

#ifndef VECTOR_XDR_H_ALREADY_INCLUDED
#define VECTOR_XDR_H_ALREADY_INCLUDED

#include <vector>
#include<utils/xdr.h>

namespace colib
{

template < typename t > bool XdrVectorType( CXDR *xdr, std::vector<t> &pvector )
{
	unsigned int length;

	if( xdr->GetOp() == CXDR::XDR_ENCODE )
	{
		length = pvector.size();
	}

	if(!xdr->XdrUint(&length))
		return false;

	if( xdr->GetOp() == CXDR::XDR_DECODE )
	{
		pvector.resize(length); 
	}

	for(unsigned int at=0; at<length; ++at)
	{
		if( !pvector[at].XdrProc(xdr) )
			return false;
	}

	return true;
}

template < typename t > bool XdrVectorPrim( CXDR *xdr, std::vector<t> &pvector, bool (CXDR::*mfunc)(t*)  )
{
	unsigned int length;

	if( xdr->GetOp() == CXDR::XDR_ENCODE )
	{
		length = pvector.size();
	}

	if(!xdr->XdrUint(&length))
		return false;

	if( xdr->GetOp() == CXDR::XDR_DECODE )
	{
		if( length > xdr->GetRemaining() )
			return false;

		//clear any current contents:
		pvector.resize(0);
 
		//reserve memory
		pvector.resize(length); 
	}

	for(unsigned int at=0; at<length; ++at)
	{
		if( !(xdr->*mfunc)(& pvector[at] ) )
			return false;
	}

	return true;
}

template < typename t > bool XdrVectorBlock( CXDR *xdr, std::vector<t> &pvector )
{
	unsigned int length;

	if( xdr->GetOp() == CXDR::XDR_ENCODE )
	{
		length = pvector.size();
	}

	if(!xdr->XdrUint(&length))
		return false;

	unsigned int blocksize = length * sizeof(t);

	if( xdr->GetOp() == CXDR::XDR_DECODE )
	{
		if( blocksize > xdr->GetRemaining() )
			return false;

		//clear any current contents:
		pvector.resize(0); 
		//reserve memory
		pvector.resize(length); 
	}

	char *bytes = (char*) (void*) pvector.data();
	if( !xdr->XdrBytes(bytes, blocksize ) )
	{
		return false;
	}

	return true;
}

}//end namespace colib

#endif

