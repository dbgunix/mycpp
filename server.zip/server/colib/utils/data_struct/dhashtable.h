//dhashtable.h
#ifndef		DHASHTABLE_INCLUDED
#define		DHASHTABLE_INCLUDED

#include<utils/data_struct/dlist.h>

namespace colib
{

typedef unsigned long HashKey;

HashKey c_void_hash(const void *,unsigned len);
HashKey c_str_hash(const char *);

template <typename T> inline HashKey HashFunc( const T &t )
{
	return c_void_hash(&t,sizeof(T));
}

template < > inline HashKey HashFunc< const char* >( const char * const &t )
{
	return c_str_hash(t);
}


template <typename T, unsigned hash_size, HashKey (*hash_fun)(const T& )=HashFunc<T> >
class DHashTable
{
public:
	DHashTable();
	virtual ~DHashTable();

	typename Dlist<T>::Node* Insert(const T& item);
	typename Dlist<T>::Node* Insert(typename Dlist<T>::Node* node);
	typename Dlist<T>::Node* Find(const T &item);
	bool Remove(const T& item);

	Dlist<T>& GetBinList(HashKey key);
	HashKey GetHashSize(){ return hash_size; }

	void Clear ();
	int GetSize() { return m_size; }
	Dlist<T>* GetTable();

protected:
	int m_size;
	Dlist<T> m_table[hash_size];
};

template <typename T, unsigned hash_size, HashKey (*hash_fun)(const T& ) >
 inline DHashTable<T,hash_size,hash_fun>::DHashTable()
{
	m_size = 0;
}

template <typename T, unsigned hash_size, HashKey (*hash_fun)(const T& ) >
 inline DHashTable<T,hash_size,hash_fun>::~DHashTable()
{
}

template <typename T, unsigned hash_size, HashKey (*hash_fun)(const T& ) >
 inline typename Dlist<T>::Node* DHashTable<T,hash_size,hash_fun>::Insert(const T& item)
{
	typename Dlist<T>::Node* ret = m_table[ (*hash_fun)(item) % hash_size ].Append(item);
	if(ret)
		++m_size;

	return ret;
}

template <typename T, unsigned hash_size, HashKey (*hash_fun)(const T& ) >
 inline typename Dlist<T>::Node* DHashTable<T,hash_size,hash_fun>::Insert(typename Dlist<T>::Node* node)
{
   	m_table[ (*hash_fun)(node->GetData()) % hash_size ].Append(node);
	++m_size;
	return node;
}

template <typename T, unsigned hash_size, HashKey (*hash_fun)(const T& ) >
 inline bool DHashTable<T,hash_size,hash_fun>::Remove( const T& item)
{
	bool result;

	if ((result = m_table[ (*hash_fun)(item) % hash_size ].Remove(item)) == true)
	{
		m_size --;
	}

	return (result);
}

template <typename T, unsigned hash_size, HashKey (*hash_fun)(const T& ) >
 inline typename Dlist<T>::Node* DHashTable<T,hash_size,hash_fun>::Find( const T& item)
{
	return m_table[ (*hash_fun)(item) % hash_size ].Find(item);
}

template <typename T, unsigned hash_size, HashKey (*hash_fun)(const T& ) >
 inline Dlist<T>& DHashTable<T,hash_size,hash_fun>::GetBinList( HashKey key )
{
	return m_table[key];
}

template <typename T, unsigned hash_size, HashKey (*hash_fun)(const T& ) >
 inline Dlist<T>* DHashTable<T,hash_size,hash_fun>::GetTable( )
{
	return m_table;
}
template <typename T, unsigned hash_size, HashKey (*hash_fun)(const T& ) >
 inline void DHashTable<T,hash_size,hash_fun>::Clear( )
{
	if(m_size>0)
	{
		for (unsigned i = 0; i < hash_size; i++)
		{
			m_table[i].Clear();
		}
		m_size=0;
	}
}

}

#endif
