// ringbuf.cpp
// vi:set ts=4 sw=4 nowrap:

#include<utils/data_struct/ringbuf.h>
//#include "machine.h"

#include <string.h>
#include <arpa/inet.h>

namespace colib
{

static int BitCount (unsigned x)
{
	x -= ( x >> 1 ) & 0x55555555;
	x  = ( ( x >> 2 ) & 0x33333333 ) + ( x & 0x33333333 );
	x  = ( ( x >> 4 ) + x ) & 0x0F0F0F0F;
	x *= 0x01010101;
	return x >> 24;
}

void ringbuf::init_ringbuf_control(unsigned int pool_size_in_bytes /*must be even power of two*/ )
{
	m_pool_size = pool_size_in_bytes>>2;
	if( BitCount(pool_size_in_bytes) != 1 )
	{
	//	throw;
	}
	m_pool_size_modulo_mask = m_pool_size - 1;
	m_read_next_index = m_write_next_index = 0;
	m_read_next_index_reset_ctr = 0;
	m_read_dropped_bytes = 0;
}

static void word_write_put( unsigned int * dest, unsigned int *src, unsigned int write_len )
{
	while( write_len --  )
	{
		unsigned int temp = *src++;
		*dest++ = htonl(temp);
	}
}

unsigned int ringbuf::next_read_length()const
{
	unsigned max_can_read = read_words_ready();

	if( max_can_read < 1 )
		return 0;

	unsigned next_read_len_bytes = m_pool[m_read_next_index];

	return next_read_len_bytes;
}

int ringbuf::read( char *data, unsigned int read_len )
{
	//the most that can be read
	unsigned max_can_read = read_words_ready();

	if( max_can_read < 1 )
		return 0;

	unsigned next_read_len_bytes = m_pool[m_read_next_index];
	
	bool reset_read_index = ((next_read_len_bytes+4+3)>>2 > max_can_read);
	if ( !reset_read_index ) reset_read_index = ( read_len < next_read_len_bytes );
	
	if ( reset_read_index )
	{ 	
		m_read_dropped_bytes += next_read_len_bytes;
		m_read_next_index = m_write_next_index;
		m_read_next_index_reset_ctr++;
		return -1;
	}
	
	//update control variable
	unsigned read_next_index = m_read_next_index;
	read_next_index = (read_next_index + 1) & m_pool_size_modulo_mask;

	read_len = next_read_len_bytes;

	int ret = static_cast<int>(read_len);

	unsigned remainder = read_len & 0x3;
	read_len >>= 2;

	if( read_len + read_next_index > m_pool_size )
	{
		//pass one:
		unsigned first_read_len =  m_pool_size-read_next_index;
		//memcpy( data, m_pool+read_next_index, first_read_len );
		word_write_put( (unsigned int *)data, m_pool+read_next_index, first_read_len);
		read_next_index = 0;
		read_len -= first_read_len;
		data+= first_read_len<<2;
	}

	//pass two, or only pass:
	//  write to m_write_next_index
	//memcpy(data, m_pool+read_next_index, read_len);
	word_write_put((unsigned int *)data, m_pool+read_next_index, read_len);
	read_next_index = ( read_next_index + read_len ) & m_pool_size_modulo_mask;
	data += read_len << 2;

	//write the remainder in the current pointer, if needed
	if( remainder )
	{
		unsigned int last_word_read = m_pool[read_next_index];
		read_next_index = (read_next_index + 1) & m_pool_size_modulo_mask;
	
		unsigned int right_shift = (4-remainder)*8;
		last_word_read = ( last_word_read >> right_shift );
	
		while( remainder > 0 )
		{
			remainder -- ;
			*data++ = (char)  ( (last_word_read >> (8*remainder)) & 0xFF );
		}
	}

	m_read_next_index = read_next_index;

	return ret;
}


int ringbuf::write(const char *data, unsigned int write_len)
{
	if ( !write_len ) return 0;

	//the most that can be written
	unsigned max_can_write = write_words_avail();

	//after storing as words, the leftover bytes will be stored as a partial word
	int remainder = write_len & 0x03;

	//we need enough bytes for the length and the data: 
	//  4 bytes extra for the length, 
	//  3 bytes to round up the remainder
	if( ((write_len+4+3) >> 2)  > max_can_write )
	{
		//dont allow partial writes at all
		return 0;
	}

	//store number of bytes to be written (in bytes!):
	m_pool[m_write_next_index] = write_len;

	unsigned int write_next_index = m_write_next_index;

	//increment write pointer
	write_next_index = (write_next_index + 1) & m_pool_size_modulo_mask;

	//store return value
	int ret = static_cast<int>(write_len);

	//divide down into units of words (rounded down, not including remainder)
	write_len>>=2;

	//if we need to wrap around end of buffer:
	if( write_len + write_next_index > m_pool_size )
	{
		//pass one:
		//  write from m_pool[m_write_next_index] to m_pool[m_pool_size-1]
		unsigned first_write_len =  m_pool_size-write_next_index;

		word_write_put(m_pool + write_next_index, (unsigned int*)data, first_write_len );

		write_next_index = 0;
		data+= first_write_len << 2;
		write_len -= first_write_len;
	}

	//pass two, or only pass:
	//  write to m_write_next_index
	//memcpy(m_pool+m_write_next_index, data, write_len);
	word_write_put(m_pool + write_next_index, (unsigned int*)data, write_len );
	write_next_index = (write_next_index+write_len) & m_pool_size_modulo_mask;
	data += write_len << 2;


	//write the remainder in the current pointer, if needed
	if( remainder )
	{
		unsigned int last_word_write = 0;
		unsigned int left_shift = (4-remainder)*8;

		while( remainder > 0 )
		{
			remainder -- ;
			last_word_write = (last_word_write<<8) | *data++ ;
		}
	
		m_pool[write_next_index] = (last_word_write << left_shift);
		write_next_index = (write_next_index + 1) & m_pool_size_modulo_mask;
	}

	m_write_next_index = write_next_index;

	return ret;
}
	
}//end namespace
