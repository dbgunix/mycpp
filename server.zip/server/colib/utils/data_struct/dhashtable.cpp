//dhashtable.cpp

#include<utils/data_struct/dhashtable.h>

namespace colib
{

static const HashKey shift = 4;
static const HashKey high_shift = sizeof(long) * 8 - shift;

HashKey c_void_hash(const void *val,unsigned len)
{
	HashKey ret = 0;
	if(val)
	{
		for( unsigned at=0; at<len; at++)
		{
			HashKey carry = ret >> high_shift;
			ret <<= shift;
			ret ^= ((unsigned char*)val)[at] ^ carry;
		}
	}
	return ret;
}

HashKey c_str_hash(const char *str)
{
	HashKey ret = 0;
	if(str)
	{
		while( *str )
		{
			HashKey carry = ret >> high_shift;
			ret <<= shift;
			ret ^= (unsigned char)(*str++) ^ carry;
		}
	}
	return ret;
}

}
