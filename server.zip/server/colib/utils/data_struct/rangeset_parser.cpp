//rangeset_parser.cpp
//
#include <stdlib.h>
#include<utils/data_struct/rangeset_parser.h>

namespace colib
{

//for rangeset_t<int>
bool ParseInt::operator()( int &ir, const char **pstr )
{
	if(!pstr || !*pstr)
		return false;
	
	const char *str = *pstr;
	
	long temp = strtol( str, (char **)pstr , 10);

	ir = (int)temp;

	return *pstr != str;
}
colib::string FormatInt::operator()( const int &ir )
{
	return colib::string::Format("%d",ir);
}

#ifndef __GNUC__

template bool parse_rangeset( rangeset_t<int> &into, const char *str, ParseInt parse );
template colib::string format_rangeset( const rangeset_t<int> &from, FormatInt fmt );

#endif

}
