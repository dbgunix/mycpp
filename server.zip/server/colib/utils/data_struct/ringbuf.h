// ringbuf.h
// vi:set ts=4 sw=4 nowrap:


#ifndef ringbuf_h_aotcgpf348p7089ucgaoed
#define ringbuf_h_aotcgpf348p7089ucgaoed

namespace colib
{

const unsigned FALCON_WRITE_MEM_BEGIN	= 0x563F0000;
const unsigned FALCON_WRITE_MEM_LENGTH	= 0x1000; 
const unsigned RAVEN_WRITE_MEM_BEGIN	= FALCON_WRITE_MEM_BEGIN + FALCON_WRITE_MEM_LENGTH + 0x100;
const unsigned RAVEN_WRITE_MEM_LENGTH	= 0x8000;

/////////////////////////////////////////
// class ringbuf
//
// Assumptions: 
// 	1) both memories are atomic on 32bit word operations: no mutexing needed
// 	2) byte operations dont work, so all reads/writes must be 32bit words
//
// Limitations
//  0) Pool must be an even power of two in bytes
// 	1) writes wont be truncated, either all written or none
// 	2) length will be stored with each write in a starting word

class ringbuf
{
public:
	void init_ringbuf_control( unsigned int pool_size_in_bytes /*must be even power of two*/ );

	int write( const char *data, unsigned int write_len );
	int read( char *data, unsigned int read_len );

	unsigned int next_read_length()const;

	unsigned int write_words_avail()const; //returns units in words
	unsigned int read_words_ready()const; //returns units in words

	unsigned int m_pool_size; // must be a power of 2, units of uint32
	unsigned int m_pool_size_modulo_mask; // used for modular arithmetic
	unsigned int m_read_next_index; //units of uint32
	unsigned int m_write_next_index; //units of uint32

	unsigned int m_read_next_index_reset_ctr; //error handling
	unsigned int m_read_dropped_bytes; //error handling
	
	unsigned int m_pool[0];
	//if m_read_next_index == m_write_next_index, then we are empty
	//if (m_write_next_index + 1)%m_pool_size == m_read_next_index, then we are full
};
//__attribute__((packed));

inline unsigned int ringbuf::write_words_avail() const
{
	//get number of open words, multiply by 4
	return ((m_read_next_index - m_write_next_index - 1) + m_pool_size) & m_pool_size_modulo_mask;
}

inline unsigned int ringbuf::read_words_ready() const
{
	//get number of written words, multiply by 4
	return ((m_write_next_index - m_read_next_index) + m_pool_size) & m_pool_size_modulo_mask;
}


}//end namespace

#endif





