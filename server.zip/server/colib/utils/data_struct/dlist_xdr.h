//dlist_xdr.h

#ifndef DLIST_XDR_H_INCLUDED
#define DLIST_XDR_H_INCLUDED

#include<utils/data_struct/dlist.h>
#include<utils/xdr.h>

namespace colib
{

template < typename t > bool XdrDlistType( CXDR *xdr, Dlist<t> &plist )
{
	int length;
	typename Dlist<t>::Node *iter=0;

	if( xdr->GetOp() == CXDR::XDR_ENCODE )
	{
		length = plist.Size();
		iter = plist.GetHead();
	}
	else
	{
		plist.Clear();
	}

	if(!xdr->XdrInt(&length))
		return false;

	for(int at=0; at<length; ++at)
	{
		if( xdr->GetOp() == CXDR::XDR_DECODE )
			iter=plist.Append();

		if( !iter || !iter->m_data.XdrProc(xdr) )
			return false;
		
		if( xdr->GetOp() == CXDR::XDR_ENCODE )
			iter = plist.GetNext(iter);
	}

	return true;
}

template < typename t > bool XdrDlistPrim( CXDR *xdr, Dlist<t> &plist, bool (CXDR::*mfunc)(t*)  )
{
	int length;
	typename Dlist<t>::Node *iter=0;
	
	if( xdr->GetOp() == CXDR::XDR_ENCODE )
	{
		length = plist.Size();
		iter = plist.GetHead();
	}
	else
	{
		plist.Clear();
	}

	if(!xdr->XdrInt(&length))
		return false;

	for(int at=0; at<length; ++at)
	{
		if( xdr->GetOp() == CXDR::XDR_DECODE )
			iter=plist.Append();

		if( !iter || !(xdr->*mfunc)(&iter->m_data) )
			return false;
		
		if( xdr->GetOp() == CXDR::XDR_ENCODE )
			iter = plist.GetNext(iter);
	}

	return true;
}

}

#endif 
