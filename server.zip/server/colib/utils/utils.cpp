//utils.cpp

#include<utils/utils.h>

#include<utils/system/memory.h>

#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#ifdef HARDWARE_PPC
#include <stdio.h>
#endif

// Returns a pointer to a malloc'ed data that is aligned to the specified boundary
// *WARNING* alignment must be an even power of 2, and greater than 0, else
// function is undefined.
void* AlignedMalloc (void** ppData, unsigned int size, int alignment)
{
	// The worst case is that we're off by one byte.
	// Then we need to crank the pointer by N - 1 bytes
	unsigned long adjustment = alignment - 1;

	// Malloc the data (filling in the caller's variable!)
	*ppData = xmalloc(size + adjustment);

	unsigned long addr = (unsigned long) *ppData;

	addr = (addr + adjustment) & ~adjustment;

	return (void*) addr;
}

// returns true if the str1 is the "start" of str2
bool strcasestrstart (const char* str1, const char* str2)
{
	while (*str1)
	{
		if (tolower (*str1++) != tolower (*str2++))
			return false;
	}

	return true;
}


// these IPv4 utility functions are deprecated and should not be used
// currently enabled only for PPC (remote team)
#ifdef HARDWARE_PPC
char* FormatIpAddr (unsigned long addr)
{
	static char string[16];
	return IPv4AddressToString(string, &addr);
}

colib::string FormatIp (unsigned long addr)
{
	char string[16];
	return colib::string(IPv4AddressToString(string, &addr));
}

char* IPv4AddressToString(char* string, const void* address)
{
	sprintf(string, "%u.%u.%u.%u",
	((unsigned char*)address)[0],
		((unsigned char*)address)[1],
		((unsigned char*)address)[2],
		((unsigned char*)address)[3]);
	return string;
}
#endif

//---------------------------------------------------------
float Poly (int degree, const float coefficients[], int x)
{
	float y = 0;

	while (1)
	{
		y += coefficients[--degree];
		if (degree == 0)
			break;
		y *= x;
	}

	return y;
}

void add_carriage_returns( colib::string &to )
{
	colib::string ret;
	if( !ret.set_maxlength(to.get_length()) )
		return;

	const char *p = to.c_str();

	while(*p)
	{
		if(*p == '\n')
		{
			ret += '\r';
		}
		ret += *p++;
	}

	to = ret;
}
colib::string trim_whitespace( colib::string from )
{
	//trim leading whitespace
	const char *start,*stop;

	start = from.c_str();
	if(!start)
		return colib::string();
	while( *start && isspace(*start) )
		++start;
	stop=start;
	while( *stop )
		++stop;
	while(stop>start)
	{
		if( !isspace(stop[-1]) )
		{
			break;
		}
		--stop;
	}
	return colib::string(start,(unsigned int)(stop-start));
}

extern "C"
{

int Colib_NONCRYPTO_rand()
{
	return rand();
}
int Colib_NONCRYPTO_RAND_MAX=RAND_MAX;

}

static unsigned char convert[256]=
{
	//0-31
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,

	//32-63
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,1,2,3,4,5,6,7,8,9,0,0,0,0,0,0,

	//64-95
	0,0xa,0xb,0xc,0xd,0xe,0xf,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,

	//96-127
	0,0xa,0xb,0xc,0xd,0xe,0xf,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,

	//128-
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,

	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,

	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,

	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,

};

void hex_to_bin( unsigned char *byte, const char *str)
{
	//while( str[0] && str[1] )
	while( str[0])
	{
		if(str[1])
			*byte = (convert[(unsigned int)str[0]] << 4) | (convert[ (unsigned int)str[1] ] );
		else
		*byte = (convert[0]) | (convert[(unsigned int)str[0]]); // << 4) | (convert[0]);
		++byte;
		str+=2;
	}
}

/*int hexlength_to_binarylength(int hexlength)
{
	if(hexlength == 1)
		return hexlength;
	else
		return hexlength/2;
}*/
