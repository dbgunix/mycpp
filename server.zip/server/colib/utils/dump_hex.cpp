//dump_hex.cpp
// vi:set ts=4 sw=4 nowrap:

#include<utils/dump_hex.h>
#include<utils/trace/trace_writable.h>

namespace colib
{

static string BuildString(const unsigned char *bytes, unsigned len)
{
	// allocate based on "len"
	string buf(len*5);
	static const unsigned STEP = 16;

	unsigned base = 0;
	while( base < len)
	{
		buf.AppendFmt(  "%04X: ", base);
		for( unsigned index = 0; index < STEP; ++index)
		{
			if( (base + index) >= len)
			{
				buf += "   ";
				if( (index + 1) == STEP)
					continue;
				if( ((base + index + 1) % 4) == 0)
				{
					buf += "  ";
				}
			}
			else
			{
				buf.AppendFmt(  "%02X ", bytes[base+index]);
				if( (index + 1) == STEP)
					continue;
				if( ((base + index + 1) % 4) == 0)
				{
					if( (base + index + 1) >= len)
						buf += "  ";
					else
						buf += "- ";
				}
			}
		}
		buf += "[";
		for( unsigned index = 0; index < STEP; ++index)
		{
			if( (base + index) < len)
			{
				unsigned char c = bytes[base + index];
				if( (32 <= c) && (c <= 127))
					buf.AppendFmt("%c", c);
				else
					buf += ".";
			}
			else
				break;
		}
		buf += "]\n";
		base += STEP;
	}
	return buf;
}

void DumpHex( const void *data, unsigned len )
{
	TraceWritable t;
	DumpHex(&t,data,len);
}

void DumpHex( Writable *to, const void *data, unsigned len )
{
	DumpHex(0,to,data,len);
}

void DumpHex( int level, Writable *to, const void *data, unsigned len )
{
	to->PrintString( level, BuildString(static_cast<const unsigned char*>(data), len).c_str() );
}

void DumpHex( int level, MemberSet &trace_set, const void *data, unsigned len)
{
	trace_set.PrintString(level, BuildString(static_cast<const unsigned char*>(data), len).c_str());
}

string DumpHex2String( const void *data, unsigned len )
{
	return BuildString(static_cast<const unsigned char*>(data), len);
}

}//end namespace colib
