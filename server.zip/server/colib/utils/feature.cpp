#include<utils/feature.h>

namespace colib
{

struct TEnumFeature
{
    ENetModemVersionType		type;
    FeatureEnable			crypt;
    FeatureEnable			mobility;
    FeatureEnable			transec_legacy;
    FeatureEnable			transec_dvbs2;
    FeatureEnable			ss_inbound;
    FeatureEnable			ss_outbound;
    FeatureEnable			scpc_retrun;
};

const TEnumFeature featureTable[] =
{	
//type			link_crypt     mobility       transec_legacy,	transec_dvbs2,	ss_inbound,	ss_outbound,   scpc_return_rmt
//{NMVer2,		NotApplicable, NotApplicable, NotApplicable,	NotApplicable,	NotApplicable,	NotApplicable, NotApplicable},
//{NMVer2Plus,		AlwaysEnabled, NotApplicable, NotApplicable,	NotApplicable,	NotApplicable,	NotApplicable, NotApplicable},
//{NMVer1100,		NotApplicable, NotApplicable, NotApplicable,	NotApplicable,	NotApplicable,	NotApplicable, NotApplicable},

{NMVer3100,		NotApplicable, AlwaysEnabled, NotApplicable,	NotApplicable,	NotApplicable,	NotApplicable, NotApplicable},
{NMVer3125,		AlwaysEnabled, AlwaysEnabled, NotApplicable,	NotApplicable,	NotApplicable,	NotApplicable, NotApplicable},
{NMVer5100,		NotApplicable, AlwaysEnabled, NotApplicable,	NotApplicable,	NotApplicable,	NotApplicable, NotApplicable},
{NMVer5150,		AlwaysEnabled, AlwaysEnabled, NotApplicable,	NotApplicable,	NotApplicable,	NotApplicable, NotApplicable},
{NMVer5300,		NotApplicable, AlwaysEnabled, NotApplicable,	NotApplicable,	NotApplicable,	NotApplicable, NotApplicable},
{NMVer5350,		AlwaysEnabled, AlwaysEnabled, NotApplicable,	NotApplicable,	NotApplicable,	NotApplicable, NotApplicable},
{NMVer7300,		NotApplicable, AlwaysEnabled, NotApplicable,	NotApplicable,	NotApplicable,	NotApplicable, NotApplicable},
{NMVeriConnexR,		AlwaysEnabled, AlwaysEnabled, AlwaysEnabled,	NotApplicable,	NotApplicable,	NotApplicable, NotApplicable},
{NMVeriConnexH,		NotApplicable, NotApplicable, AlwaysEnabled,	NotApplicable,	NotApplicable,	NotApplicable, NotApplicable},
{NMVeriConnex300,	NotApplicable, AlwaysEnabled, NotApplicable,	NotApplicable,	NotApplicable,	NotApplicable, NotApplicable},

//Linecards
{NMVerM1D1T,		AlwaysEnabled, NotApplicable, AlwaysEnabled,	NotApplicable,	NotApplicable,	NotApplicable, NotApplicable},
{NMVerM1D1TSS,		AlwaysEnabled, NotApplicable, AlwaysEnabled,	NotApplicable,	AlwaysEnabled,	AlwaysEnabled, NotApplicable},

{NMVerM1D1,		NotApplicable, NotApplicable, NotApplicable,	NotApplicable,	NotApplicable,	NotApplicable, NotApplicable},
{NMVerXLC_10,		NotApplicable, NotApplicable, NotApplicable,	NotApplicable,	NotApplicable,	NotApplicable, NotApplicable},
{NMVerM0D1,		NotApplicable, NotApplicable, NotApplicable,	NotApplicable,	NotApplicable,	NotApplicable, NotApplicable},
{NMVerM0D1NB,		NotApplicable, NotApplicable, NotApplicable,	NotApplicable,	NotApplicable,	NotApplicable, NotApplicable},
{NMVerXLC_11,		NotApplicable, NotApplicable, NotApplicable,	NotApplicable,	LicenseNeeded,	LicenseNeeded, NotApplicable},
{NMVerXLC_M,		NotApplicable, NotApplicable, NotApplicable,	NotApplicable,	NotApplicable,	NotApplicable, NotApplicable},
{NMVerEM0DM,		NotApplicable, NotApplicable, AlwaysEnabled,	NotApplicable,	AlwaysEnabled,	NotApplicable, NotApplicable},
{NMVerEM1D1,		NotApplicable, NotApplicable, AlwaysEnabled,	LicenseNeeded,	AlwaysEnabled,	AlwaysEnabled, NotApplicable},
{NMVer10300,		NotApplicable, NotApplicable, NotApplicable,	NotApplicable,	NotApplicable,	NotApplicable, NotApplicable},
{NMVer10315,		NotApplicable, NotApplicable, NotApplicable,	NotApplicable,	NotApplicable,	NotApplicable, NotApplicable},
{NMVer10330,		NotApplicable, NotApplicable, NotApplicable,	NotApplicable,	NotApplicable,	NotApplicable, NotApplicable},
{NMVer10100,		NotApplicable, NotApplicable, NotApplicable,	NotApplicable,	NotApplicable,	NotApplicable, NotApplicable},
{NMVerM1D1iSCPC,	NotApplicable, NotApplicable, NotApplicable,	NotApplicable,	NotApplicable,	NotApplicable, NotApplicable},

{NMVer3100NB,		NotApplicable, NotApplicable, NotApplicable,	NotApplicable,	NotApplicable,	NotApplicable, NotApplicable},
{NMVer7350,		AlwaysEnabled, AlwaysEnabled, AlwaysEnabled,	NotApplicable,	NotApplicable,	NotApplicable, NotApplicable},
{NMVer8350,		AlwaysEnabled, AlwaysEnabled, AlwaysEnabled,	NotApplicable,	AlwaysEnabled,	AlwaysEnabled, NotApplicable},

{NMVeriConnexE800,	AlwaysEnabled, AlwaysEnabled, AlwaysEnabled,	AlwaysEnabled,	AlwaysEnabled,	AlwaysEnabled, AlwaysEnabled},
{NMVeriConnexE850mp,AlwaysEnabled, AlwaysEnabled, AlwaysEnabled,	AlwaysEnabled,	AlwaysEnabled,	AlwaysEnabled, AlwaysEnabled},
{NMVerE8350,		AlwaysEnabled, AlwaysEnabled, AlwaysEnabled,	AlwaysEnabled,	AlwaysEnabled,	AlwaysEnabled, AlwaysEnabled},

{NMVerGPR,		NotApplicable, NotApplicable, NotApplicable,	NotApplicable,	NotApplicable,	NotApplicable, NotApplicable},

//This is the Darwin X3 modem.
{NMVerX3Remote,		LicenseNeeded, NotApplicable, NotApplicable,	NotApplicable,	NotApplicable,	NotApplicable, LicenseNeeded},// X3
{NMVerEP100,		LicenseNeeded, AlwaysEnabled, NotApplicable,	NotApplicable,	LicenseNeeded,	NotApplicable, NotApplicable},
{NMVerX5Remote,		LicenseNeeded, AlwaysEnabled, NotApplicable,	NotApplicable,	LicenseNeeded,	NotApplicable, LicenseNeeded},// X5

{NMVerProtocolProcessor,NotApplicable,	NotApplicable,	NotApplicable,	NotApplicable,	NotApplicable,	NotApplicable, NotApplicable}
};	

int GetDeviceDefaultCapability(	const EFeatureName feature,
								const EOptionName option,
								const ENetModemVersionType type )
{
	switch(feature)
	{
		case FEATURE_M0D1NB_BW_RATE_LIMIT:
			return (type == NMVerM0D1NB && option == M0D1NBBWRATELIMIT_RATE) ?
				FEATURE_M0D1NB_BW_RATE_DEFAULT : NotApplicable;
		case FEATURE_ENCRYPTION:
			return (type == NMVerProtocolProcessor && option == FEATURE_ENABLED) ?
				LicenseNeeded : NotApplicable;
		case FEATURE_MCD_SCPC:
			switch(option)
			{
				case(NUM_MCD_CHANNELS):
					return ( ((type == NMVerXLC_M) || (type == NMVerEM0DM)) && (option== NUM_MCD_CHANNELS) ) ?
						FEATURE_MCD_SCPC_NUM_CHANNELS_DEFAULT:NotApplicable;
				case(MAX_COMPOSITE_SYMRATE):
					return ( ((type == NMVerXLC_M) || (type == NMVerEM0DM))&& (option== MAX_COMPOSITE_SYMRATE) ) ?
						FEATURE_MCD_SCPC_MAX_COMPOSITE_SYMRATE_DEFAULT:NotApplicable;
				case(MAX_SYMRATE_PER_CARRIER):
					return ( ((type == NMVerXLC_M) || (type == NMVerEM0DM))&& (option== MAX_SYMRATE_PER_CARRIER) ) ?
						FEATURE_MCD_SCPC_MAX_SYMRATE_PER_CARRIER_DEFAULT:NotApplicable;
				default:
					break;
			}
		case FEATURE_MCD_TDMA:
			switch(option)
			{
				case(NUM_MCD_CHANNELS):
					return ( ((type == NMVerXLC_M) || (type == NMVerEM0DM)) && (option== NUM_MCD_CHANNELS) ) ?
						FEATURE_MCD_TDMA_NUM_CHANNELS_DEFAULT:NotApplicable;
				case(MAX_COMPOSITE_SYMRATE):
					return ( ((type == NMVerXLC_M) || (type == NMVerEM0DM))&& (option== MAX_COMPOSITE_SYMRATE) ) ?
						FEATURE_MCD_TDMA_MAX_COMPOSITE_SYMRATE_DEFAULT:NotApplicable;
				case(MAX_SYMRATE_PER_CARRIER):
					return ( ((type == NMVerXLC_M) || (type == NMVerEM0DM))&& (option== MAX_SYMRATE_PER_CARRIER) ) ?
						FEATURE_MCD_TDMA_MAX_SYMRATE_PER_CARRIER_DEFAULT:NotApplicable;
				default:
					return NotApplicable;
			}
		case FEATURE_COTM:
			return ( (type==NMVeriConnexE800) || (type==NMVerE8350) || (type==NMVerEP100) || (type== NMVeriConnexE850mp) )? 
				FEATURE_COTM_MAX_VELOCITY_DEFAULT:NotApplicable;
		default:
			break;
	}

	int tbl_len = sizeof( featureTable ) / sizeof( TEnumFeature );
	int index;
	for(index = 0; index < tbl_len; index++)
	{
		if( featureTable[index].type == type )
		{
			break;
		}
	}
	if( index == tbl_len ) return NotApplicable;

	switch(feature)
	{
	case FEATURE_LINK_ENCRYPTION:
	{
		return (option == FEATURE_ENABLED) ? featureTable[index].crypt : NotApplicable;
	}
	case FEATURE_MOBILITY:
	{
		return (option == FEATURE_ENABLED) ? featureTable[index].mobility: NotApplicable;
	}
	case FEATURE_TRANSEC:
	{
		switch( option )
		{
		case TRANSEC_LEGACY:
			return featureTable[index].transec_legacy;
		case TRANSEC_DVBS2:
			return featureTable[index].transec_dvbs2;
		default:
			return NotApplicable;
		}
	}
	case FEATURE_SPREAD_SPECTRUM:
	{
		switch( option )
		{
		case SPREADSPECTRUM_INBOUND:
			return featureTable[index].ss_inbound;
		case SPREADSPECTRUM_OUTBOUND:
			return featureTable[index].ss_outbound;
		default:
			return NotApplicable;
		}
	}
	case FEATURE_SCPC_RETURN:
		return (option == FEATURE_ENABLED)? featureTable[index].scpc_retrun: NotApplicable;
	default:
		return NotApplicable;
	}
}

}
