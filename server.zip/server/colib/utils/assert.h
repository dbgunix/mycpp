#ifndef ASSERT_HPP
#define ASSERT_HPP

//
// Copyright (c) 2002 colib, Inc.  All Rights Reserved
//

#ifdef ASSERT
#error ASSERT <== Macro already defined!
#endif

namespace colib
{
	/**	Called when an assertion fails.

		@param message	String representation of the failed assertion.
		@param file		Source file containing the assertion.
		@param line		Source line of the assertion.

		@return Nothing.
	 */
	extern void (*OnAssert)(const char* message, const char* file, const unsigned line);
}

/**	Asserts that an expression evaluates to true.
	If DEBUG is defined then the expression is evaluated.
	If the result is false, then a call is made to 'colib::OnAssert' to take further action.

	@param exp	Expression to be evaluated.

	@see colib::OnAssert
 */

#ifdef COLIB_DEBUG
#define ASSERT(exp)	if (exp) (void)0; else colib::OnAssert(#exp, __FILE__, __LINE__)
#else
#define ASSERT(exp)	(void)0
#endif

//#define DEBUG_WITH_VALGRIND_HELPER
#ifdef DEBUG_WITH_VALGRIND_HELPER
	#define VALGRIND_MSSG(xyxyxyxy000001) {\
		unsigned int lenxyxyxyxy000001 = xyxyxyxy000001->GetLength();\
		char * pchar000001 = (char*)xyxyxyxy000001->GetData(); \
		for(unsigned int at=0;at<lenxyxyxyxy000001;++at) \
		{ if(*pchar000001) \
				TRACE(99,"."); \
			else \
				TRACE(100,","); \
			++pchar000001; } }
#else
	#define VALGRIND_MSSG(xyxyxyxy000001)
#endif

#endif
