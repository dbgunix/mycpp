// vi:set ts=4 sw=4 nowrap:

#if !defined(__FILE_UTIL_H__)
#define __FILE_UTIL_H__

#include <sys/types.h>
#include<utils/string.h>

namespace colib
{

int GetFileSize(string path, string &err);
bool LoadTextFile(string path, string &into, string &err);
bool SaveTextFile(string path, string from, string &err);
bool SetFileMode(string path, mode_t mode, string &err);

void RemoveFile(colib::string& file_name, colib::string& err);	

bool IsRegularFile(string path, string &err);
bool IsDirectory(string path, string &err);

}

#endif

