#if !defined(__MULTI_ENC_INTF_H__)
#define __MULTI_ENC_INTF_H__

namespace colib
{

class MultiEncodeIntf
{
public:
	virtual ~MultiEncodeIntf() { }
	virtual bool WriteXdrBytes(const char *data, int len) = 0;
	virtual unsigned int GetLength() const = 0;
	virtual void PrependLength(unsigned int len) = 0;
};

}

#endif
