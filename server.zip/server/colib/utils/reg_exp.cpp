//reg_exp.cpp
// vi:set ts=4 sw=4 nowrap:

#include<utils/reg_exp.h>

#include <memory.h>
#include <string.h>

namespace colib
{

Regex::RegBuf::RegBuf()
	: m_pattern()
	, m_reg()
	, m_ok(false)
	, m_ref(0)
{
	memset(&m_reg,0,sizeof(m_reg));
}

Regex::RegBuf::~RegBuf()
{
	regfree(&m_reg);
}

bool Regex::Matches( string to )const
{
	return Matches(to.c_str());
}

bool Regex::Matches(const char* to) const
{
	if(!m_rb.m_r)
		m_last_error = "No pattern Set";
	else if(!m_rb.m_r->m_ok)
		m_last_error = "Pattern Invalid";
	int res = -1;
	if ( m_rb.m_r )
		res = regexec( &m_rb.m_r->m_reg, to, 0, 0, 0);

	return res==0;
}

bool Regex::IsOk() const
{
	if(m_rb.m_r)
		return m_rb.m_r->m_ok;
	return false;
}
void Regex::Empty()
{
	m_rb = 0;
}

bool Regex::SetPattern( string pattern )
{
	RegBuf *pnew = new RegBuf;
	if(!pnew)
	{
		m_last_error = "Out of memory";
		return false;
	}
	m_rb = pnew;
	m_rb.m_r->m_pattern = pattern;

	int res = regcomp( &m_rb.m_r->m_reg, pattern.c_str(), 0);
	if(res==0)
	{
		m_rb.m_r->m_ok=true;
		return true;
	}
	else
	{
		m_last_error.empty();
		size_t size = regerror(res, &m_rb.m_r->m_reg, 0, 0);
		m_last_error.set_maxlength(size+1);
		char *p = m_last_error.get_buffer();
		if(p)
		{
			regerror(res, &m_rb.m_r->m_reg, p, size);
		}
		return false;
	}
}

string Regex::GetLastError() const
{
	return m_last_error;
}

string Regex::GetPattern() const
{
	if(m_rb.m_r)
		return m_rb.m_r->m_pattern;
	return string("");
}

bool Regex::operator<( const Regex &than )const
{
	if(!m_rb.m_r)
	{
		return than.m_rb.m_r !=0;
	}
	if(!than.m_rb.m_r)
	{
		return false;
	}
	return m_rb.m_r->m_pattern < than.m_rb.m_r->m_pattern;
}

}//end namespace colib
