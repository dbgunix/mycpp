#ifndef IMEMORY_HPP
#define IMEMORY_HPP

//
// Copyright 2001 colib,  All Rights Reserved.
//
// Module:
//    imemory.hpp
//
// Description:
//    This module provides memory management capabilities.
//    It also provides resource debugging features that relate
//    specifically to memory management.
//

//
// Used to avoid mangling of function names in libraries.
//

#ifndef LIBEXPORT

#ifdef __cplusplus
#define LIBEXPORT(type,name)   extern "C" type lib##name
#define LIBDEFINE(type,name)   extern "C" type lib##name

#ifdef DEBUG
void* operator new(const size_t aBytes);
void* operator new(const size_t aBytes, const char* apFile, const unsigned aLine);
void operator delete(void* apPointer);
void* operator new[](const size_t aBytes);
void* operator new[](const size_t aBytes, const char* apFile, const unsigned aLine);
void operator delete[](void* apPointer);

//#define new NEW_DEBUG
//#define NEW_DEBUG ::new(__FILE__,__LINE__)
#define new ::new(__FILE__,__LINE__)
#endif

#else
#define LIBEXPORT(type,name)  type lib##name
#define LIBDEFINE(type,name)  type lib##name
#endif

#endif

//
// Used to handle debug/release differences in function argument lists.
// Debug versions will include two extra arguments: The file and line
// that originated a call to a library function.  This information can
// then be reported by the Assert macro(s).
//

#ifndef FUNCFILELINE

#ifndef DEBUG
#define FUNCFILELINE
#define CALLFILELINE
#define FUNCFILELINEVOID
#define CALLFILELINEVOID
#else
#define FUNCFILELINE       const char* apFile, const int aLine,
#define CALLFILELINE       __FILE__, __LINE__,
#define FUNCFILELINEVOID   const char* apFile, const int aLine
#define CALLFILELINEVOID   __FILE__, __LINE__
#endif

#endif

//
// These macros are what should actually be called in a program.
// They hide build specific details.  (Alpha vs. Beta vs. Release)
//

#define MemoryInitialize(apOcean, aSize, apfALLOC,apfREALLOC,apfFREE)\
         lib##MemoryInitialize(                                    \
               CALLFILELINE apOcean, aSize, apfALLOC,apfREALLOC,apfFREE)
      
#define MemoryTerminate(aSilent)                                     \
         lib##MemoryTerminate(                                     \
               CALLFILELINE aSilent)
      
#define MemoryReport(stream)                                         \
         lib##MemoryReport(                                        \
               CALLFILELINE stream)
      
#define MemoryRequestInsert(apfMemRequestHandler, apContext)         \
         lib##MemoryRequestInsert(                                 \
               CALLFILELINE apfMemRequestHandler, apContext)
      
#define MemoryRequestRemove(apfMemRequestHandler)                    \
         lib##MemoryRequestRemove(                                 \
               CALLFILELINE apfMemRequestHandler)
      
#define MemoryAlloc(aElementSize)                          			 \
         lib##MemoryAlloc(                                         \
               CALLFILELINE aElementSize)
      
#define MemoryFree(apMemory)                               			 \
         lib##MemoryFree(                                          \
               CALLFILELINE apMemory)
      
#if DEBUG
#define MemoryIsValid(apMemory)                                      \
         lib##MemoryIsValid(                                       \
               CALLFILELINE apMemory)
#endif

#define MemoryPoolAlloc(aFlags, aElementSize)                        \
         lib##MemoryPoolAlloc(                                     \
               CALLFILELINE aFlags, aElementSize)
      
#define MemoryPoolFree(aMemPool)                                     \
         lib##MemoryPoolFree(                                      \
               CALLFILELINE aMemPool)
      
#define MemoryPoolMemoryAlloc(aMemPool, aElementSize)                \
         lib##MemoryPoolMemoryAlloc(                               \
               CALLFILELINE aMemPool, aElementSize)
      
#define MemoryPoolMemoryFree(aMemPool, apMemory)                     \
         lib##MemoryPoolMemoryFree(                                \
               CALLFILELINE aMemPool, apMemory)
      
#define MemoryCopy(apDestination, apSource, aSize)                   \
         lib##MemoryCopy(                                          \
               CALLFILELINE apDestination, apSource, aSize)
      
#define MemoryFill(apMemory, aValue, aSize)                          \
         lib##MemoryFill(                                          \
               CALLFILELINE apMemory, aValue, aSize)

//
// Used by the memory management sub-system.  This allows someone
// to register a function (multiple allowed) to be called under low-
// memory conditions.  When called this function/handler should
// attempt to release memory for use by the free store.  Examples
// could include large data structures whose main purpose is to hold
// cached information for faster retrieval.  If such information is
// re-creatable (i.e. reload from disk, etc.), then such structures
// are good candidates for this kind of functionality.  When called
// they could attempt to release for example 10% of their objects.
//
// Arguments:
//    apContext   This is passed to the xxxInsert function and
//                then passed through to the actual handler.
//
// Returns:       TRUE if memory was released, FALSE otherwise.
//

typedef bool FMemRequestHandler(
								void*       apContext);

//
// Signatures for malloc/free functions
//

typedef void* ALLOCHandler(const unsigned aBytes);
typedef void* REALLOCHandler(void* aPointer, const unsigned aBytes);
typedef void  FREEHandler(void* aPointer);

//
// Used to initialize the memory management sub-system.  This must
// be called before any other calls into this module.
//
// Arguments:
//    apOcean     Pointer to heap.  If zero, use malloc/free.
//    aSize       Size of heap (malloc/free max. memory to use).
//
// Returns:       TRUE if the sub-system is ready,
//                FALSE otherwise.
//

LIBEXPORT(bool,			MemoryInitialize)(
								FUNCFILELINE
								void*             apOcean,
								const unsigned    aSize,
								ALLOCHandler*		apfALLOC,
								REALLOCHandler*	apfREALLOC,
								FREEHandler*		apfFREE);


//
// Used to terminate the memory management sub-system.  Once called
// no other calls may be made into this module.  If DEBUG is defined
// then this function will report resource leaks.
//
// Arguments:
//    aSilent     Reserved.  Pass FALSE.
//
// Returns:       N/A.
//

LIBEXPORT(void,			MemoryTerminate)(
								FUNCFILELINE
								const bool     aSilent);

//
// Writes a report of current memory usage statistics.
//
// Arguments:
//    stream      File to write to (0 = stdout).
//
// Returns:       N/A.
//

LIBEXPORT(void,			MemoryReport)(
								FUNCFILELINE
								const char*       stream);

//
// Used to add a low-memory condition handler.  (explanation above)
//
// Arguments:
//    apfHandler  Pointer to handler (function).
//    apContext   Value to be passed when invoking handler.
//
// Returns:       N/A.
//

LIBEXPORT(void,			MemoryRequestInsert)(
                                 FUNCFILELINE
                                 FMemRequestHandler*  apfHandler,
                                 void*                apContext);

//
// Used to remove a low-memory condition handler.  If 'apContext' is
// zero, then all handlers using 'apfHandler' are removed.
//
// Arguments:
//    apfHandler  Pointer to handler (function).
//    apContext   Value to be passed when invoking handler.
//
// Returns:       N/A.
//

LIBEXPORT(void,			MemoryRequestRemove)(
								FUNCFILELINE
								FMemRequestHandler*  apfHandler,
								void*                apContext);

//
// Handle to a memory pool.  A zero may sometimes be substituted, to
// indicate that the normal free store is to be used.
//

//
// Used to allocate memory for an object.
//
// Arguments:
//    aElementSize   Size of object to be allocated.
//
// Returns:          Pointer to newly allocated object or zero if
//                   the request could not be satisfied.
//

LIBEXPORT(void*,		MemoryAlloc)(
								FUNCFILELINE
								const unsigned    aElementSize);

//
// Used to free memory allocated for an object.
//
// Arguments:
//    apMemory       Pointer to the previously allocated object.
//
// Returns:          N/A.
//

LIBEXPORT(void,			MemoryFree)(
								FUNCFILELINE
								void*             apMemory);

#if DEBUG
//
// Used to validare memory allocated for an object.
//
// Arguments:
//    aMemPool       Handle to memory Pool.  Exceptions:
//                      0 (zero) The free store was used.
//    apMemory       Pointer to be validated.
//
// Returns:          True is the pointer is allocated, false otherwise.
//

LIBEXPORT(bool,			MemoryIsValid)(
								FUNCFILELINE
								void*             apMemory);
#endif

typedef void* HMemPool;

//
// Used to allocate a Memory Pool.  Memory pools are used to more
// efficiently allocate space for small objects of the same size.  The
// overhead is small when compared to using MemAlloc/MemFree.  Typically
// approaching one bit per object.  Using pools can also reduce swapping
// in virtual memory since, 'like' objects tend to be co-located.
//
// Arguments:
//    aFlags         A bit mask used to indicate the kind objects
//                   stored in the pool, and the way a pool is
//                   expected to be used.  The following values can
//                   be bitwise OR'd together:
//                      POOL_SIZE_FIX  Object sizes will be either
//                      -xor-          fixed (default) or variable.
//                      POOL_SIZE_VAR  If fixed the size must be
//                                     specified in 'aElementSize'.
//                      POOL_ALLOC_FREE   Objects can be released on the
//                      -xor-             fly (default), or only when the
//                      POOL_ALLOC_ONLY   pool itself is freed.
//    aElementSize   Size of objects to be stored in this pool.
//                      =0 (zero)   Objects in pool will be of
//                                  variable size.
//                      >0          Objects in pool will be of
//                                  fixed size (# specified).
//
// Returns:          Handle to the new/shared memory pool.
//

typedef enum eMemoryPoolFlags
{
   MemoryPoolFlagFixedSize    =0,
   MemoryPoolFlagVariableSize =1,
   MemoryPoolFlagAllocFree    =0,
   MemoryPoolFlagAllocOnly    =2
} MemoryPoolFlags;

LIBEXPORT(HMemPool,		MemoryPoolAlloc)(
								FUNCFILELINE
								const int         aFlags,
								const unsigned    aElementSize);

//
// Used to release a Memory Pool.  Any memory allocated through this
// pool (and not yet released) will be freed.
//
// Arguments:
//    aMemPool    Handle to Pool.
//
// Returns:       N/A.
//

LIBEXPORT(void,			MemoryPoolFree)(
								FUNCFILELINE
								const HMemPool    aMemPool);

//
// Used to allocate memory for an object.  Storage will be allocated
// from the memory pool indicated in the first argument.
//
// Arguments:
//    aMemPool       Handle to memory Pool.  Exceptions:
//                      0 (zero) The free store will be used.
//    aElementSize   Size of object to be allocated.
//
// Returns:          Pointer to newly allocated object or zero if
//                   the request could not be satisfied.
//

LIBEXPORT(void*,		MemoryPoolMemoryAlloc)(
								FUNCFILELINE
								const HMemPool    aMemPool,
								const unsigned    aElementSize);

//
// Used to free memory allocated for an object.
//
// Arguments:
//    aMemPool       Handle to memory Pool.  Exceptions:
//                      0 (zero) The free store was used.
//    apMemory       Pointer to the previously allocated object.
//
// Returns:          N/A.
//

LIBEXPORT(void,			MemoryPoolMemoryFree)(
								FUNCFILELINE
								const HMemPool    aMemPool,
								void*             apMemory);

//
// Used to copy a block of memory (wrapper for memcpy).
//

LIBEXPORT(void,			MemoryCopy)(
								FUNCFILELINE
								void*             apDestination,
								const void*       apSource,
								const unsigned    aSize);

//
// Used to fill a block of memory (wrapper for memset).
//

LIBEXPORT(void,			MemoryFill)(
								FUNCFILELINE
								void*             apMemory,
								const int         aValue,
								const unsigned    aSize);

#endif
