#include<timer/oneshot_timer.h>
#include<timer/timekeeper.h>

namespace colib
{

/** OneShotTimer ctor
 * \param[in] name Name of the timer
 */
OneShotTimer::OneShotTimer(string name)
	: TimerBase(name)
{
}

/** OneShotTimer ctor
 * \param[in] name Name of the timer
 * \param[in] cb Expiration callback
 */
OneShotTimer::OneShotTimer(string name, const Callback2<unsigned int, void*>& cb)
	: TimerBase(name, cb)
{
}

/** Start the timer
 * \param[in] timeout_msec Duration of the timer in milliseconds
 */
void OneShotTimer::Start(unsigned int timeout_msec)
{
	MonoTime exp;
	exp.SetToMsFromNow(timeout_msec);
	TimerBase::Start(exp);
}

/** Trigger timer expiration
 * \param[in] exp Monotonic time of the expiration
 */
void OneShotTimer::Expired(const MonoTime &exp)
{
	m_is_active = false;
	m_on_expire.Dispatch(exp.ConvertToMs(), m_ctx);
}

/** Determine the next timeout of the long timer
 * \param[in] timeout_sec Remaining timeout of long timer (in seconds)
 * \return Duration of next timeout
 */
static inline unsigned int GetNextMs(unsigned int timeout_sec)
{
	// timeout in one hour or remaining time, whichever is less
	static const unsigned int MSEC_PER_HOUR = 3600 * 1000;
	return std::min(MSEC_PER_HOUR, timeout_sec * 1000);
}

/** LongOneShotTimer ctor
 * \param[in] name Name of the timer
 */
LongOneShotTimer::LongOneShotTimer(string name)
	: TimerBase(name)
	, m_actual_expiration()
{
}

/** Start the timer
 * \param[in] timeout_sec Duration of the timer in seconds
 */
void LongOneShotTimer::Start(unsigned int timeout_sec)
{
	// determine the real timeout
	m_actual_expiration.SetToNow();
	m_actual_expiration = m_actual_expiration + MonoTime(timeout_sec, 0);
	// set the short term temporary timeout
	MonoTime next_exp;
	next_exp.SetToMsFromNow(GetNextMs(timeout_sec));
	TimerBase::Start(next_exp);
}

/** Trigger timer expiration
 * \param[in] exp Monotonic time of the expiration
 */
void LongOneShotTimer::Expired(const MonoTime& exp)
{
	// flag as inactive initially.
	// active flag will be set if timer is restarted
	m_is_active = false;
	// check if the real timeout has passed
	if (exp >= m_actual_expiration)
	{
		m_on_expire.Dispatch(exp.ConvertToMs(), m_ctx);
	}
	else
	{
		// real timeout has not happened yet, restart timer
		MonoTime next_exp;
		next_exp.SetToMsFromNow((m_actual_expiration - exp).GetSeconds());
		TimerBase::Start(next_exp);
	}
}

}
