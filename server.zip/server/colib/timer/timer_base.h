#if !defined(__TIMER_BASE_H__)
#define __TIMER_BASE_H__

#include<timer/timer_mgr_intf.h>
#include<timer/timer_tk_intf.h>
#include<utils/string.h>
#include<utils/callback.h>
#include<utils/mono_time.h>

namespace colib
{

class TimerBase : public TimerTkIntf
{
public:
	virtual ~TimerBase();

	bool IsActive() const { return m_is_active; }
	MonoTime GetRemainingTime(const MonoTime &from) const { return from >= m_expiration ? MonoTime(0, 0) : m_expiration - from; }

	void SetExpireCb(const Callback2<unsigned, void*> &cb) { m_on_expire = cb; }
	void SetContext(void *context) { m_ctx = context; }
	string GetName() const { return m_name; }

	void Stop();

	TimerBase(const TimerBase&) = delete;
	TimerBase& operator=(const TimerBase&) = delete;

protected:
	TimerBase(string name);
	TimerBase(string name, const Callback2<unsigned, void*> &cb);

	void Start(const MonoTime &expiration);

	string m_name;
	MonoTime m_expiration;
	TimerMgrIntf &m_parent;
	bool m_is_active;

	void *m_ctx;
	Callback2<unsigned, void*> m_on_expire;

private:
	// functions used exclusively by timekeeper (via interface class)
	const MonoTime& GetExpiration() const { return m_expiration; }
	bool HasExpired(const MonoTime &now) const { return now >= m_expiration; }
};

}

#endif
