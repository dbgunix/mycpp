#if !defined(__TIMEKEEPER_INTF_H__)
#define __TIMEKEEPER_INTF_H__

#include<utils/mono_time.h>

namespace colib
{

class EventLoop;
class Writable;

class TimeKeeperIntf
{
public:
	virtual ~TimeKeeperIntf() { }

private:
	friend class EventLoop;
	virtual MonoTime GetNextTimeout() const = 0;
	virtual void DispatchTimers() = 0;
	virtual bool Empty() const = 0;
	virtual int Size() const = 0;
	virtual void ResetCount() = 0;
	virtual void DumpStatus(Writable *to) = 0;
};

}

#endif
