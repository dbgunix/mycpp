#if !defined(__TIMEKEEPER_H__)
#define __TIMEKEEPER_H__

#include<utils/mono_time.h>
#include<timer/timer_mgr_intf.h>
#include<timer/timekeeper_intf.h>

#include <map>

namespace colib
{

class Writable;
class TimerTkIntf;

class TimeKeeper : public TimerMgrIntf, public TimeKeeperIntf
{
public:
	static TimerMgrIntf& GetTimerMgrInstance();
	static TimeKeeperIntf& GetTimeKeeperInstance();
	virtual ~TimeKeeper() { }

private:
	TimeKeeper();

	/// singleton instance
	static TimeKeeper& GetInstance();
	// timekeeper functions (for eloop/others)
	MonoTime GetNextTimeout() const;
	void DispatchTimers();
	bool Empty() const { return m_timer_queue.empty(); }
	int Size() const { return m_timer_queue.size(); }
	void ResetCount() { m_expire_count = 0; }
	void DumpStatus(Writable *to);
	// timer mgr functions (for timers)
	void AddTimer(TimerTkIntf *timer);
	void RemoveTimer(TimerTkIntf*timer);

	/// count of number of timer expirations
	int m_expire_count;
	/// container of active timers, sorted by remaining time
	std::multimap<MonoTime, TimerTkIntf*> m_timer_queue;
};

}

#endif
