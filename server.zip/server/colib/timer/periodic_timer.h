#if !defined(__PERIODIC_TIMER_H__)
#define __PERIODIC_TIMER_H__

#include<timer/timer_base.h>

namespace colib
{

class PeriodicTimer: public TimerBase
{
public:
	PeriodicTimer(string name);
	PeriodicTimer(string name, const Callback2<unsigned int, void*>& cb);
	void StartStaggered(unsigned int first_timeout, unsigned int period_msec);
	void Start(unsigned int period_msec);

	PeriodicTimer(const PeriodicTimer&) = delete;
	PeriodicTimer& operator=(const PeriodicTimer&) = delete;

private:
	// used exclusively by timekeeper (via interface class)
	void Expired(const MonoTime &exp);

	/// period of the timer (in msec)
	unsigned int m_period;
};

}

#endif
