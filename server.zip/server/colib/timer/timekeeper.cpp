#include<timer/timekeeper.h>
#include<timer/timer_base.h>
#include<utils/trace/writable.h>
#include<timer/timer_tk_intf.h>

#include <limits.h>

namespace colib
{

/** Get instance interface used for timer management
 * \return Timer management interface to instance
 */
TimerMgrIntf& TimeKeeper::GetTimerMgrInstance()
{
	return GetInstance();
}

/** Get instance interface used for event loop timekeeper
 * \return Timekeeper interface to instance
 */
TimeKeeperIntf& TimeKeeper::GetTimeKeeperInstance()
{
	return GetInstance();
}

TimeKeeper& TimeKeeper::GetInstance()
{
	static TimeKeeper instance;
	return instance;
}

/** Timekeeper ctor
 */
TimeKeeper::TimeKeeper()
	: m_expire_count(0)
	, m_timer_queue()
{
}

/** Add a timer to the container of active timers
 * \param[in] timer Timer to add
 */
void TimeKeeper::AddTimer(TimerTkIntf *timer)
{
	m_timer_queue.insert(std::pair<MonoTime, TimerTkIntf*>(timer->GetExpiration(), timer));
}

/** Remove a timer to the container of active timers
 * \param[in] timer Timer to remove
 */
void TimeKeeper::RemoveTimer(TimerTkIntf *timer)
{
	// there could be multiple timers with the same expiration
	// find all with the target expiration, then search linearly
	auto ii(m_timer_queue.equal_range(timer->GetExpiration()));
	auto it(ii.first);
	auto it2(ii.second);

	for (; it != it2; ++it)
	{
		if (it->second == timer)
		{
			m_timer_queue.erase(it);
			return;
		}
	}
}

/** Trigger expiration in all timers which have expired
 */
void TimeKeeper::DispatchTimers()
{
	MonoTime now;
	now.SetToNow();
	while (!m_timer_queue.empty() && m_timer_queue.begin()->second->HasExpired(now))
	{
		TimerTkIntf *tmr = m_timer_queue.begin()->second;
		// remove from queue
		m_timer_queue.erase(m_timer_queue.begin());
		// trigger expiration
		tmr->Expired(now);
		++m_expire_count;
		// TODO: update clock here?
	}
}

/** Get the time remaining until the next timer expiration (shortest timeout)
 * \return remaining time until next expiration (monotonic)
 */
MonoTime TimeKeeper::GetNextTimeout() const
{
	MonoTime now;
	now.SetToNow();
	return !m_timer_queue.empty() ? m_timer_queue.begin()->second->GetRemainingTime(now) : MonoTime(UINT_MAX, 0);
}

/** Print status
 * \param[in] to Writable to use for output
 */
void TimeKeeper::DumpStatus(Writable *to)
{
	if (!to)
	{
		return;
	}

	to->Print("%d Timers Expired\n", m_expire_count);
	MonoTime now;
	now.SetToNow();
	to->Print("%d Active Timer(s)\n", m_timer_queue.size());
	for (auto it(m_timer_queue.cbegin()); it != m_timer_queue.cend(); ++it)
	{
		to->Print("%s -> %d\n", it->second->GetName().c_str(), it->second->GetRemainingTime(now).ConvertToMs());
	}
}

}
