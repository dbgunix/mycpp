#if !defined(__TIMER_TK_INTF_H__)
#define __TIMER_TK_INTF_H__

#include<utils/mono_time.h>
#include<utils/string.h>

namespace colib
{

class TimeKeeper;

class TimerTkIntf
{
public:
	virtual ~TimerTkIntf() { }

private:
	friend class TimeKeeper;

	virtual MonoTime GetRemainingTime(const MonoTime &from) const = 0;
	virtual const MonoTime& GetExpiration() const = 0;
	virtual bool HasExpired(const MonoTime &now) const = 0;
	virtual void Expired(const MonoTime &exp) = 0;
	virtual string GetName() const = 0;
};

}

#endif
