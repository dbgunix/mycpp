#if !defined(__TIMER_MGR_INTF_H__)
#define __TIMER_MGR_INTF_H__

namespace colib
{

class TimerTkIntf;

class TimerMgrIntf
{
public:
	virtual ~TimerMgrIntf() { }

private:
	friend class TimerBase;
	virtual void AddTimer(TimerTkIntf *timer) = 0;
	virtual void RemoveTimer(TimerTkIntf *timer) = 0;
};

}

#endif
