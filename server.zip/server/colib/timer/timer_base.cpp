#include<timer/timer_base.h>
#include<timer/timekeeper.h>

#include <stdlib.h>

namespace colib
{

TimerBase::TimerBase(string name)
	: m_name(name)
	, m_expiration()
	, m_parent(TimeKeeper::GetTimerMgrInstance())
	, m_is_active(false)
	, m_ctx(NULL)
	, m_on_expire()
{
}

TimerBase::TimerBase(string name, const Callback2<unsigned, void*> &cb)
	: m_name(name)
	, m_expiration()
	, m_parent(TimeKeeper::GetTimerMgrInstance())
	, m_is_active(false)
	, m_ctx(NULL)
	, m_on_expire(cb)
{
}

TimerBase::~TimerBase()
{
	Stop();
}

void TimerBase::Start(const MonoTime &expiration)
{
	if (m_is_active)
	{
		m_parent.RemoveTimer(this);
	}
	m_expiration = expiration;
	m_parent.AddTimer(this);
	m_is_active = true;
}

void TimerBase::Stop()
{
	if (m_is_active)
	{
		m_parent.RemoveTimer(this);
		m_is_active = false;
	}
}

}
