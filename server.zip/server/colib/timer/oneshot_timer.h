#if !defined(__ONESHOT_TIMER_H__)
#define __ONESHOT_TIMER_H__

#include<timer/timer_base.h>

namespace colib
{

class OneShotTimer : public TimerBase
{
public:
	OneShotTimer(string name);
	OneShotTimer(string name, const Callback2<unsigned int, void*>& cb);
	void Start(unsigned int timeout_msec);

private:
	// used exclusively by timekeeper (via interface class)
	void Expired(const MonoTime &exp);

	void operator=(const OneShotTimer&);
	OneShotTimer(const OneShotTimer&);
};

class LongOneShotTimer : public TimerBase
{
public:
	LongOneShotTimer(string name);
	void Start(unsigned int timeout_sec);

private:
	// used exclusively by timekeeper (via interface class)
	void Expired(const MonoTime &exp);
	/// final expiration of the timer
	MonoTime m_actual_expiration;

	void operator=(const LongOneShotTimer&);
	LongOneShotTimer(const LongOneShotTimer&);
};

}

#endif
