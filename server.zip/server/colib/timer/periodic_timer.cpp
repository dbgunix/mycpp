#include<timer/periodic_timer.h>
#include<timer/timekeeper.h>

#include <stdlib.h>

namespace colib
{

/** Helper function to randomize first periodic timer timeout
 * \param[in] timeout_msec Duration of first timeout (in milliseconds)
 * \return Randomized duration of first timeout (in milliseconds)
 */
static inline unsigned int Stagger(unsigned timeout_msec)
{
	// for now, 50% variance
	return rand()%(timeout_msec/2);
}

/** PeriodicTimer ctor
 * \param[in] name Name of the timer
 */
PeriodicTimer::PeriodicTimer(string name)
	: TimerBase(name)
	, m_period(0)
{
}

/** PeriodicTimer ctor
 * \param[in] name Name of the timer
 * \param[in] cb Expiration callback
 */
PeriodicTimer::PeriodicTimer(string name, const Callback2<unsigned int, void*>& cb)
	: TimerBase(name, cb)
	, m_period(0)
{
}

/** Start a periodic timer with an initial timeout which differs from the period
 * \param[in] first_timeout Duration of first timer expiration in milliseconds
 * \param[in] period_msec Period of the timer in milliseconds
 */
void PeriodicTimer::StartStaggered(unsigned int first_timeout, unsigned int period_msec)
{
	m_period = period_msec;
	MonoTime exp;
	exp.SetToMsFromNow(first_timeout);
	TimerBase::Start(exp);
}

/** Start the timer
 * \param[in] period_msec Period of the timer in milliseconds
 */
void PeriodicTimer::Start(unsigned int period_msec)
{
	m_period = period_msec;
	MonoTime exp;
	// randomize first timeout
	exp.SetToMsFromNow(Stagger(period_msec));
	TimerBase::Start(exp);
}

/** Trigger timer expiration
 * \param[in] exp Monotonic time of the expiration
 */
void PeriodicTimer::Expired(const MonoTime &exp)
{
	m_on_expire.Dispatch(exp.ConvertToMs(), m_ctx);
	// the dispatch function may have deactivated the timer
	if (m_is_active)
	{
		/* restart timer and set next timeout based
		 * on expected expiration */
		MonoTime new_exp(m_expiration);
		new_exp.IncrementMs(m_period);
		TimerBase::Start(new_exp);
	}
}

}
