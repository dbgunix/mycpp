// vi:set ts=4 sw=4 nowrap:

#ifndef JSONCPP_VERSION_H
#define JSONCPP_VERSION_H

#include <utils/assert.h>
#include <utils/callback.h>

#include <jsoncpp/value.h>
#include <jsoncpp/reader.h>
#include <jsoncpp/writer.h>
#include <jsoncpp/zeroizer.h>

namespace colib
{

#define JSONCPP_VERSION 500

}; // namespace

#endif //LIFE_MONITOR_H

