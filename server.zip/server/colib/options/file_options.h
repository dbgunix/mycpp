// file_options.h
// vi:set ts=4 sw=4 nowrap:

#ifndef __FILE_OPTIONS_H
#define __FILE_OPTIONS_H

#include<options/options.h>

namespace colib
{

class FileOptions : public Options
{
	public:
	FileOptions ();
	FileOptions (const char* filename, bool strip_end_comments = true);

	bool LoadFile(const char *filename, bool strip_end_comments = true);
	bool SaveFile(const char *filename) const;
	bool SaveFile(const char *filename,const char *text);

	bool SaveFile();

	private:
	char	m_filename[1024];
};

}

#endif
