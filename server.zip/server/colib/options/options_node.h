// vi:set ts=4 sw=4 nowrap:

#ifndef OPTIONS_NODE_H
#define OPTIONS_NODE_H

#include <utils/string.h>
#include <utils/filter.h>
#include <options/life_monitor.h>

#include <options/json_version.h>

#include <type_traits>

namespace colib
{

typedef Json::Value JValue;
typedef Json::Value::const_iterator JCIterator;

typedef std::vector<colib::string> StringVector;

class OptionsNode;

class OptionsNodeIterator {
public:
	OptionsNodeIterator() {}
	OptionsNodeIterator(const OptionsNodeIterator& other): m_citerator(other.m_citerator) {}
	OptionsNodeIterator operator++() { ++ m_citerator; return m_citerator; }
	bool operator ==(const OptionsNodeIterator& other) const {
		return m_citerator == other.m_citerator;
	}
	bool operator !=(const OptionsNodeIterator& other) const {
		return m_citerator != other.m_citerator;
	}
	// Return the member name of the referenced Value. "" if it is not an objectValue.
	const char* Key() const { return m_citerator.memberName(); }
	// Return the index of the referenced Value. (unsigned)-1 if it is not an arrayValue.
	unsigned Index() const { return m_citerator.index(); }
	OptionsNode operator*() const;
private:
	OptionsNodeIterator(const JCIterator& iter) : m_citerator(iter) {}
	JCIterator GetJCIterator() { return m_citerator; }
	JCIterator m_citerator;
	friend class OptionsNode;
};

template<typename MyType>
class SetDefault {
public:
	inline static MyType AsDefault() { return static_cast<MyType>(0);}
};

template<>
class SetDefault<colib::string> {
public:
	inline static colib::string AsDefault() { return "";}
};


class OptionsNode {
public:
	typedef Json::ValueType ValueType;

	static const char* DIFF_ADD;
	static const char* DIFF_REMOVE;
private:

	// core and encapsulated data structure of the class
	const JValue* m_value; // read only

	// The deep copied to place. When deep copy occurs,
	// the m_value will point to the address of the valueCopy
	JValue        m_valueCopy;

	// caller should make sure m_value != NULL
	const JValue& GetJValue() const { return *m_value; }

	//private constructor
	OptionsNode(const JValue* val); // fast but shallow copy
	OptionsNode(const JValue& val); // slow deep copy


public:
	// public constructors

	OptionsNode(const OptionsNode& other); // shallow copy
	OptionsNode():m_value(&m_valueCopy), m_valueCopy(JValue::null) { }

	// destrcutor
	// using virtual in case the child object is deleted with base pointer
	virtual ~OptionsNode() {}; // no memory allocated

	// public apis

	// return a deep copied OptionsNode
	bool Clone(OptionsNode& to) const;

	bool operator ==(const OptionsNode& other) const;
	bool operator !=(const OptionsNode& other) const;

	//shallow copy
	OptionsNode& operator =(const OptionsNode& other);


	unsigned int GetChildrenCount() const;

	// an options node is self contained if it owns the JValue
	bool IsSelfContained() const { return m_value == &m_valueCopy; }

	// IsEmpty() may be used to check is the OptionsNode is usable.
	// For example, some object or array element is not present in the options
	bool IsEmpty() const { return IsNull() || m_value->empty(); }

	ValueType  Type() const { return IsNull()? Json::nullValue : GetJValue().type(); }

	bool IsNull() const { return !m_value; };

	// object related

	bool IsObject() const { return (!IsNull() && m_value->isObject()); }
	unsigned ObjectSize() const { return (IsObject() ? GetJValue().size() : 0); }
	bool HasObject(const char* name) const  { return IsObject() && GetJValue().isMember(name); }

	//array related
	bool IsArray() const { return !IsNull() && m_value->isArray(); }
	unsigned ArraySize() const { return (IsArray() ? GetJValue().size() : 0); }
	bool HasArray(unsigned int arrayIndex) const  { return IsArray() && !(GetJValue())[arrayIndex].isNull(); }

	// Check if a node is alreay at the leaf of the tree.
	bool IsLeafNode() const { return !IsNull() && IsLeafNode(GetJValue()); }

	OptionsNode GetChildNode(unsigned arrayIndex) const;
	OptionsNode GetChildNode(const char* name) const;

	//linear search. Not efficient because not take advantage of the sorted internal
	//However it provides very generic search
	bool GetChildObjects(OptionsNode& out, const Filter& filter) const { return GetChildObjects(out, begin(), filter); }
	//TODO: To make this usefuly, need to modify JsonCpp to provide find function. Do it when necessary
	bool GetChildObjects(OptionsNode& out, OptionsNodeIterator startPos, const Filter& filter) const;

	// If the path is empty, return the root; otherwise
	// return the child object reached by the list of object name
	// Using this method to access large number of grandchildren is not recommended
	// due to the path traverse overhead. A better alternative is first get the child
	// node and then operate on the child nod directly
	OptionsNode GetChildNode(const std::vector<const char*>& path) const;

	colib::string GetComment() const;
	//TODO: optimization between conversion of std::string to colib::string
	colib::string ToStyledString() const { return IsEmpty() ? "" : m_value->toStyledString().c_str(); }
	void ToStyledString(colib::string& toStr, const char* memberName, const StringVector& subMembers) const;
	colib::string FastToString() const;

	// Use the key
	template <typename IdType, typename T>
	bool GetValue(const IdType& id, T &value, T default_value = SetDefault<T>::AsDefault()) const;

	template <typename IdType, typename T1, typename T2>
	bool GetValue(const IdType& id, T1 &value, T2 default_value = SetDefault<T2>::AsDefault()) const;

	template <typename IdType, typename T1, typename T2>
	bool GetValueCast(const IdType& id, T1 &value, T2 default_value = SetDefault<T2>::AsDefault()) const;

	template <typename T>
	bool GetLeafValue(T& val) const;

	template <typename ValType>
	OptionsNode GetNodeWithKeyValue(const char* key, ValType value) const;

	colib::string GetAsString(const char* name) const;
	colib::string GetAsString(unsigned index) const;

	// iterators wrapper
	// Only applicable to array or object type options.
	//
	OptionsNodeIterator begin() const { return m_value->begin(); }
	OptionsNodeIterator end() const { return m_value->end(); }

	//TODO: Need to modifiy JsonCpp to provide find
	//OptionsNodeIterator FindObject(const char* name) const { return FindObject(begin(), name); };
	//OptionsNodeIterator FindObject(OptionsNodeIterator startPos, const char* name) const;

	// The callback takes two parameters: the first one (const char*) is the object name
	// The second one is the child node of the calling OptionsNode
	void IterateObjects(colib::Callback2<const char*, const OptionsNode&>& callback) const;
	void IterateObjectsAndStop(colib::Callback3<bool&, const char*, const OptionsNode&>& callback) const;

	// The callback takes two parameters: the first one (unsigned) is the array index
	// The second one is the child node of the calling OptionsNode
	void IterateArray(colib::Callback2<unsigned, const OptionsNode&>& callback) const;
	void IterateArrayAndStop(colib::Callback3<bool&, unsigned, const OptionsNode&>& callback) const;

	// compute the difference to the other OptionsNode
	// The difference is stored as an OptionsNode objects with key symbols (+++/---) indicatng the change: add, deleting
	// TODO: improve the difference of array specially for leaves if necessary
	OptionsNode Difference(const OptionsNode& other) const;

	// create an options nodes only contains the objects in the member vector
	// The calling OptionsNode should be object type
	bool CreateTrimedTree(OptionsNode& out, const char* rootName, const StringVector& subMembers) const;


	const char* GetStatus() const { return m_status.c_str(); }

protected:

	// debug code related to object dependency

	void SetStatus(const char* status) const { m_status = status; }
	void ResetStatus() const { m_status.empty(); }

private:

	OptionsNode ShallowCopiable() const;
	void CopyFromJValue(const JValue& from);
	void SwapFromJValue(JValue& from);

	static bool IsLeafNode(const Json::Value& val) { return !val.isNull() && !val.isArray() && !val.isObject(); }


	static JValue Difference(const JValue& compare1, const JValue& compare2);

	template<typename IdType>
	OptionsNode GetChildNodeTemp(const IdType& myId) const;


	template <typename myType, typename IdType>
	bool GetLeafValueTemp(myType& myValue, const IdType& id, const myType& defaultVal, bool flag) const;


	template <typename myType>
	bool GetLeafValue(myType& myValue, unsigned id, const myType& defaultVal) const;

	template <typename myType>
	bool GetLeafValue(myType& myValue, const char* name, const myType& defaultVal) const;

	colib::string GetAsString(const JValue& jVal) const;

	// helper members and methods

	mutable colib::string m_status;

	template<typename myType>
	bool SetFromStr(myType& toVal, const JValue& jVal, const char* fmtStr) const;

	// real number type, prefer double type
	bool AsVal(double& dVal, const JValue& jVal) const;
	bool AsVal(float& dVal, const JValue& jVal) const;

	// integer type
	bool AsVal(int& iVal, const JValue& jVal) const;
	bool AsVal(unsigned int& uiVal, const JValue& jVal) const;

	// boolean
	bool AsVal(bool & bVal, const JValue& jVal) const;

	// colib string
	bool AsVal(colib::string& strVal, const JValue& jVal) const;

#if JSONCPP_VERSION > 500
	bool ASVal(int64_t& i64Val, const JValue& jVal ) const;
	bool ASVal(uint64_t& u64Val, const JValue& jVal ) const;
#endif

	friend class OptionsNodeIterator;
	friend class OptionsNodeEdit;
	friend class Options;
};


inline colib::string OptionsNode::GetComment() const
{
	return IsNull() ? "" : m_value->getComment(Json::commentAfterOnSameLine).c_str();
}

template<typename IdType>
OptionsNode  OptionsNode::GetChildNodeTemp(const IdType& myId) const
{
	const JValue& jval = (GetJValue())[myId];
	if (jval.isNull()) {
		return OptionsNode(NULL);
	} else {
		return OptionsNode(&jval);
	}
}

template<typename myType>
bool OptionsNode::SetFromStr(myType& toVal, const JValue& jVal, const char* fmtStr) const
{
	if (jVal.isString()) {
		if(jVal.asCString()) {
			if (sscanf(jVal.asCString(), fmtStr, &toVal) == 1) {
				return true;
			} else {
				SetStatus("invalid input string");
			}
		} else {
			SetStatus("Cannot get the string value");
		}
	} else {
		SetStatus("OptionsNode is not string type");
	}
	return false;
}

template <typename myType>
bool OptionsNode::GetLeafValue(myType& myVal, unsigned id, const myType& defaultVal) const
{
	return GetLeafValueTemp(myVal, id, defaultVal, IsArray());
}

template <typename myType>
bool OptionsNode::GetLeafValue(myType& myVal, const char* name, const myType& defaultVal) const
{
	return GetLeafValueTemp(myVal, name, defaultVal, IsObject());
}

template <typename myType, typename IdType>
bool OptionsNode::GetLeafValueTemp(myType& myVal, const IdType& id, const myType& defaultVal, bool flag) const
{
	myVal = defaultVal;

	if (flag) {
		const JValue& jVal = (GetJValue())[id];
		if (!jVal.isNull()) {
			return AsVal(myVal, jVal);
		} else {
			SetStatus("cannot find the node element");
		}
	} else {
		SetStatus("Incorrect Node type for Object or Array operations");
	}
	return false;
}

/* This will be called the value and default are the same standard supported type T */
template <typename IdType, typename T>
inline bool		OptionsNode::GetValue(const IdType& id, T &value, T default_value) const
{
	return GetLeafValue(value, id, default_value);
}

/* This will be called if value and default are the different types
   T1 is standard supported type, T2 may or may not be the supported type */
template <typename IdType, typename T1, typename T2>
inline bool		OptionsNode::GetValue(const IdType& id, T1 &value, T2 default_value) const
{
	T1 temp = default_value;
	return GetValue(id, value, temp);
}

/* This will be called if value and default are the different type
   T2 is standard supported type, T1 most likely is not supported type */
template<typename IdType, typename T1, typename T2>
inline bool		OptionsNode::GetValueCast(const IdType& id, T1 &value, T2 default_value) const
{
	T2 tmp = 0;
	if ( !GetValue(id, tmp, default_value) ) return false;
	value = static_cast<T1>(tmp);
	return true;
}

template <typename T>
bool OptionsNode::GetLeafValue(T& val) const
{
	if (IsLeafNode()) {
		return AsVal(val, GetJValue());
	} else {
		return false;
	}
}

template <typename ValType>
OptionsNode OptionsNode::GetNodeWithKeyValue(const char* key, ValType val) const
{
	static_assert(std::is_arithmetic<ValType>::value || std::is_same<ValType, colib::string>::value,
			"OptionsValue must be arithmetic type or colib::string");
	for (auto it(begin()); it != end(); ++it)
	{
		ValType cur_val;
		if ((*it).GetValue(key, cur_val) && cur_val == val)
		{
			return (*it);
		}
	}
	// not found, return empty node
	return OptionsNode();
}


}; // namespace

#endif //OPTIONS_NODE_H

