//options.cpp
// vi:set ts=4 sw=4 nowrap:

#include<options/options.h>
#include<utils/trace/trace.h>
#include<utils/system/environ.h>
#include<utils/license_prefix.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <vector>

namespace colib
{


Options::Options() : m_rootNode(NULL, &m_modified), m_modified(true)
{
}

Options::Options(const Options& that)
{
	CopyFrom(that);
}

Options::Options(const OptionsNodeEdit& edit):m_rootNode(edit.GetJValue(), &m_modified), m_modified(true)
{
}

Options::Options(const OptionsNode& node):m_rootNode(node.GetJValue(), &m_modified), m_modified(true)
{
}

Options::~Options()
{
	Clear();
}


bool            Options::GetLicense(colib::string &license) const
{

	if ( m_license.is_empty() )	return false;
	// Return copy
	colib::string tmpString(m_license.c_str(), m_license.get_length());
	license = tmpString;
	return true;
}


void			Options::SetLicense(const colib::string &license)
{
	m_license = license;
	m_modified = true;
}

bool			Options::operator==(const Options& that) const
{
	return (m_rootNode.GetJValue() == that.m_rootNode.GetJValue() && m_license == that.m_license);
}

bool			Options::operator!=(const Options& that) const
{
	return !(*this == that);
}

Options&		Options::operator=(const Options& other)
{
	if (this != &other)
	{
		CopyFrom(other);
	}
	return *this;
}

void			Options::CopyFrom(const Options& other)
{
	// Clean up
	Clear();

	m_rootNode.Copy(other.m_rootNode);

	// Succeed, optimization for future DumpToStr()
	m_license = other.m_license;
	m_modified = other.m_modified;
	if (!m_modified) m_cached = other.m_cached;
}

bool			Options::Merge(const Options& other, int depth)
{
	m_rootNode.Merge(other.m_rootNode, depth);
	return true;
}

const char*		Options::GetStatus() const
{
	if (m_status.is_empty()) return NULL;
	return m_status.c_str();
}


int				Options::SetStatus(const char *status) const
{
	m_status = status;
	return m_status.get_length();
}

void            Options::ClearContent()
{
	m_rootNode.Clear();
	m_cached.clear();
	OnModified();
}

void			Options::Clear()
{
	ClearContent();
	ClearStatus();
}

bool			Options::Load(const char* contents, bool strip_end_comments)
{
	bool ret = LoadBase(contents, strip_end_comments);

	if (ret) {
		m_cached = contents;
		OnModified();
	}
	return ret;
}

bool			Options::LoadBase(const char* contents, bool strip_end_comments)
{
	if (!contents) {
		SetStatus("no contents to parse");
		return false;
	}

	Clear();

	// find license

	//Take linear time. Possible optimization is search from the end of the string
	//TODO move license out side of option file
	const char* endOpt = strstr(contents, colib::LICENSE_HEADER);

	if (endOpt > contents) {
		if (!m_jreader.parse(contents, endOpt - 1, m_rootNode.GetJValue(), !strip_end_comments)) {
			SetStatus(m_jreader.getFormatedErrorMessages().c_str());
			return false;
		}
		m_license = endOpt;
	} else {
		if (!m_jreader.parse(contents, m_rootNode.GetJValue(), !strip_end_comments)) {
			SetStatus(m_jreader.getFormatedErrorMessages().c_str());
			return false;
		}
	}
	return true;
}

void			Options::zero()
{
	m_rootNode.Zero();
	Clear();
	OnModified();
}

colib::string	Options::DumpToStr() const
{
	if(m_modified)
	{
		m_cached = m_rootNode.FastToString();
		//TODO move license out side of options
		if (!m_license.is_empty() ) m_cached.AppendFmt("%s\n", m_license.c_str());

		m_modified = false;
	}
	return m_cached;
}

colib::string	Options::AsStrNoFormat() const
{
	Json::FastWriter fw;
	return m_cached = fw.write(m_rootNode.GetJValue()).c_str();
}

////////////////////////////////////
/// helper functions for Localize
////////////////////////////////////

class LocalizeFilter : public FilterAndTranslator
{
public:

	LocalizeFilter(int id) : m_id(id) {}
	// don't like void pointer
	bool operator()(const void* item) const ;
	virtual string ToString() const { return colib::string::Format("LocalizeFilter: ID = %d", m_id);};
	colib::string Translate(const char* src) const;

protected:

	int m_id;
};

static inline const char*		get_beam_ids(const char *name)
{
   	return static_cast<const char*>(strstr(name,":"));
}

static inline bool		is_in(int beam, const char *beam_ids)
{
	const char *ptr = beam_ids;
 	while ( ( ptr = get_beam_ids(ptr) ) != 0 )
 		if ( beam == atoi(++ptr) ) return true;
 	return false;
}

bool LocalizeFilter::operator()(const void* item) const {
	const char* name = static_cast<const char*>(item);
	if (!name) return false;
	const char* chIds = get_beam_ids(name);
	if (chIds) {
		return is_in(m_id, chIds);
	}
	return false;
}

colib::string LocalizeFilter::Translate(const char* src) const
{
	const char* ptr = get_beam_ids (src);
	if (ptr > src) return colib::string(src, static_cast<unsigned>(ptr - src));
	return colib::string("");
}

///when used with a consolidated options file, returns the beam-specific version of the group

class BeamNameIdFilter : public Filter
{
public:
	BeamNameIdFilter(const char* name, int id) :
				m_targetName(name), m_id(id), m_nameLen(strlen(name)) {}

	bool operator()(const void* item) const;
	colib::string ToString() const;
private:
	const char* m_targetName;
	int m_id;

	size_t m_nameLen;
};

colib::string BeamNameIdFilter::ToString() const
{
	return colib::string::Format("BeamNameIdFilter: Name = %s, ID = %d", m_targetName, m_id);
}

bool BeamNameIdFilter::operator()(const void* item) const
{
	const char* name = static_cast<const char*>(item);
	if (!name || strncasecmp(name, m_targetName, m_nameLen)) return false;
	const char* chIds = get_beam_ids(name);
	return (!m_id || (chIds && is_in(m_id, chIds)));
}

bool Options::GetChildInBeam(OptionsNode &out, const OptionsNode& node, const char *name, const int beam )
{
	if (!node.IsObject()) return false;

	return node.GetChildObjects(out, BeamNameIdFilter(name, beam));
}

/// Localize converts a consolidated Options object into a normal Options object for a
/// specific beam. A consolidated object may have group names with appended beam ID fields
/// (e.g., foogroup:1, or foogroup:3:4)
/// Localize removes all groups that are not for this beam. It also removes global groups
/// if there is a corresponding group with the target beam ID. Finally, it removes all
/// beam ID fields
void Options::Localize(OptionsNodeEdit& node, int beam)
{
	LocalizeFilter collectAndTrans(beam);
	node.TrimObjects(collectAndTrans);
}

} // namespace
