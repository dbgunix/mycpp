// vi:set ts=4 sw=4 nowrap:

#ifndef LIFE_MONITOR_H
#define LIFE_MONITOR_H

#include<utils/assert.h>
#include<utils/callback.h>

namespace colib
{

class LifeMonitor {

public:
	LifeMonitor() : m_refStatus(new Status(this)) {}
	~LifeMonitor() { if (this == m_refStatus.m_r->LifeRoot()) m_refStatus.m_r->SetLifeRoot(NULL); }

	bool IsAlive() const { return m_refStatus.m_r->LifeRoot(); }
	void SetLifeRoot(const LifeMonitor* newRoot) { m_refStatus.m_r->SetLifeRoot(newRoot);}

private:
	class Status {
		public:
			Status(const LifeMonitor* lifeRoot) : m_ref(0), m_life_root(lifeRoot){};

			const LifeMonitor* LifeRoot() const { return m_life_root; }
			void SetLifeRoot(const LifeMonitor* newRoot) { m_life_root = newRoot; }
			int m_ref;
		private:
			const LifeMonitor* m_life_root;
	};

	refbuf<Status> m_refStatus;	
};

}; // namespace

#endif //LIFE_MONITOR_H

