// vi:set ts=4 sw=4 nowrap:


#include<utils/string.h>
#include<utils/trace/trace.h>
#include<options/options_node.h>
#include <string.h> 

namespace colib
{

OptionsNode OptionsNodeIterator::operator*() const { return OptionsNode(&(*m_citerator)); }


const char* OptionsNode::DIFF_ADD = "+++";
const char* OptionsNode::DIFF_REMOVE = "---";

OptionsNode::OptionsNode(const JValue *val) : m_value(val) 
{
	if (!m_value) {
		m_valueCopy = JValue::null; 
		m_value = &m_valueCopy;
	}
}

OptionsNode::OptionsNode(const JValue& val) : m_value(&m_valueCopy), m_valueCopy(val) {}

OptionsNode::OptionsNode(const OptionsNode& other) 
			: m_value(other.m_value), m_valueCopy(JValue::null) 
{
	if (other.IsSelfContained()) {
		m_valueCopy = other.m_valueCopy;
		m_value = &m_valueCopy;
	}
}

bool OptionsNode::Clone(OptionsNode& to) const
{
	if (IsNull()) return false;
	to.CopyFromJValue(*m_value);
	return true;
}

void OptionsNode::CopyFromJValue(const JValue& from)
{
	m_valueCopy = from;
	m_value = &m_valueCopy;
}

void OptionsNode::SwapFromJValue(JValue& from)
{
	m_valueCopy.swap(from);
	m_value = &m_valueCopy;
}

OptionsNode OptionsNode::ShallowCopiable() const 
{
	return OptionsNode(m_value);
}

OptionsNode	OptionsNode::GetChildNode(const std::vector<const char*>& path) const
{
	if (IsEmpty()) {
		SetStatus("OptionsNode is empty"); 
		return OptionsNode(NULL);
	}
	const JValue *node = m_value;
	std::vector<const char*>::const_iterator pathCItr = path.begin();

	for ( ; pathCItr != path.end(); ++ pathCItr) {
		const JValue *tmp = &(*node)[*pathCItr];
		if (tmp->isNull()){
			SetStatus("empty OptionsNode down the path"); 
			return OptionsNode(NULL);
		} else {
			node = tmp;
		}
	}
	return OptionsNode(node);
}

OptionsNode OptionsNode::GetChildNode(unsigned arrayIndex) const
{
	if (IsArray()) return GetChildNodeTemp(arrayIndex);
	SetStatus("Invalid node type: OptionsNode must be array type"); 
	return OptionsNode(NULL);
}

OptionsNode OptionsNode::GetChildNode(const char* name) const
{
	if (IsObject()) return GetChildNodeTemp(name);
	SetStatus("Invalid node type: OptionsNode must be object type");
	return OptionsNode(NULL);
}

//TODO use swap instead of copy
bool OptionsNode::GetChildObjects(OptionsNode& out, OptionsNodeIterator startPos, const Filter& filter) const
{
	if (!IsObject()) { 
		SetStatus("Invalid node type: OptionsNode must be object type"); 
		return false; 
	}

	JValue jvalOut(Type());

	JCIterator jcitr = startPos.GetJCIterator();
	for ( ; jcitr != GetJValue().end(); ++ jcitr) {
		if ((filter)(jcitr.memberName())) {
			jvalOut[jcitr.memberName()] = *jcitr;
		}
	}
	if (jvalOut.size() != 0) {
		out.SwapFromJValue(jvalOut);
		return true;;
	}
	return false;
}

//need optimization
colib::string OptionsNode::GetAsString(const char* name) const
{
	if (IsObject()) {
		return GetAsString(GetJValue()[name]);
	}
	return "";
}

colib::string OptionsNode::GetAsString(unsigned index) const
{
	if (IsArray()) {
		return GetAsString(GetJValue()[index]);
	}
	return "";
}

//TODO Need optimization
colib::string OptionsNode::GetAsString(const JValue& jVal) const
{
	switch (jVal.type()) {
   	case Json::nullValue:
      	return "";
   	case Json::stringValue:
      return jVal.asString().c_str();
   	case Json::booleanValue:
      return jVal.asBool() ? "true" : "false";
   	case Json::intValue:
		return colib::string::Format("%ld", (long)jVal.asInt());
   	case Json::uintValue:
		return colib::string::Format("%lu", (unsigned long)jVal.asUInt());
   	case Json::realValue:
		return colib::string::Format("%lf", jVal.asDouble());
   	case Json::arrayValue:
   	case Json::objectValue:
		return "";
   	default:
		return "";
   	}
   	return ""; // unreachable
}


void OptionsNode::IterateObjects(Callback2<const char*, const OptionsNode&>& callback) const
{
	if (!IsObject()) return;

	OptionsNodeIterator citer = begin();
	for ( ; citer != end(); ++citer)
	{
		callback.Dispatch(citer.Key(), *citer);
	}
}

void OptionsNode::IterateObjectsAndStop(Callback3<bool&, const char*, const OptionsNode&>& callback) const
{

	if (!IsObject()) return;

	bool stop = false;
	OptionsNodeIterator citer = begin();
	for ( ;citer != end(); ++citer)
	{
		callback.Dispatch(stop, citer.Key(), *citer);
		if ( stop ) break;
	}
}


void OptionsNode::IterateArray(Callback2<unsigned, const OptionsNode&>& callback) const
{
	if (!IsArray()) return;

	OptionsNodeIterator citer = begin();
	for ( ; citer != end(); ++citer)
	{
		callback.Dispatch(citer.Index(), *citer);
	}
}

void OptionsNode::IterateArrayAndStop(Callback3<bool&, unsigned, const OptionsNode&>& callback) const
{

	if (!IsArray()) return;

	bool stop = false;
	OptionsNodeIterator citer = begin();
	for ( ;citer != end(); ++citer)
	{
		callback.Dispatch(stop, citer.Index(), *citer);
		if ( stop ) break;
	}
}

bool OptionsNode::CreateTrimedTree(OptionsNode&out, const char* rootName, 
									    const StringVector& subMembers) const
{
	if (!IsObject()) return false;

	JValue tmpNode;

	StringVector::const_iterator itr = subMembers.begin();
	for( ; itr != subMembers.end(); ++ itr) {
		const JValue& jval = (GetJValue())[itr->c_str()];
		if (!jval.isNull())	{
			tmpNode[*itr] = jval;	
		}
	} 
	JValue tmpRoot(GetJValue().type());
	tmpRoot[rootName].swap(tmpNode);
	out.SwapFromJValue(tmpRoot);
	return true;
}


void OptionsNode::ToStyledString(colib::string& toStr, 
								 const char* memberName, 
								 const StringVector& subMembers) const 
{

	OptionsNode trimed;
	if (CreateTrimedTree(trimed, memberName, subMembers) && !trimed.IsEmpty()) {
		toStr.AppendFmt("\n%s\n", trimed.ToStyledString().c_str());
	}
}

colib::string OptionsNode::FastToString() const
{
	Json::FastWriter fastWriter;
	return IsEmpty() ? "" : fastWriter.write(GetJValue()).c_str();		
}

unsigned int OptionsNode::GetChildrenCount() const {
	return IsNull() ? 0 : GetJValue().size();
}


static JValue Collect(const JValue &val, JCIterator &begin, const char *diffType)
{
	JValue tmp(val.type());
	JCIterator citr = begin;
	
	for( ; citr != val.end(); ++ citr) {

		if (val.type() == Json::arrayValue) {
			tmp.append((*citr));
		} else if (val.type() == Json::objectValue)  {
			tmp[citr.memberName()] = (*citr);
		}
	}
	//printf("2222%s\n", tmp.toStyledString().c_str());
	JValue output(Json::objectValue);
	if (!tmp.empty()) {
		output[diffType].swap(tmp);
	}
	return output;
}


static JValue Collect(const JValue &val, JCIterator &begin, JCIterator &iter2, const char *diffType)
{
	JValue tmp(val.type());

	while (begin != val.end() && begin.key() < iter2.key()) {
		if (val.type() == Json::arrayValue) {
			tmp.append((*begin));
		} else if (val.type() == Json::objectValue)  {
			tmp[begin.memberName()] = (*begin);
		}
		++ begin;
	}
	JValue output(Json::objectValue);
	if (!tmp.empty()) {
		output[diffType].swap(tmp);
	}

	return output;
}


static JValue AddMember(const char* name, const JValue& valSrc, 
						Json::ValueType parentType) {
	JValue tmp (parentType);
	switch (parentType) {
	case Json::objectValue:
		tmp[name] = valSrc;
		break;
	case Json::arrayValue:
		tmp = valSrc;
		break;
	default:
		break;
	}
	return tmp;
}

OptionsNode OptionsNode::Difference(const OptionsNode& other) const
{
	if (other.IsNull() && IsNull()) return OptionsNode(NULL);
	if (other.IsNull()) return OptionsNode(*this);
	if (IsNull()) return OptionsNode(other.GetJValue());

	JValue valDiff(Difference(GetJValue(), other.GetJValue()));
	
	return OptionsNode(valDiff);
}

JValue OptionsNode::Difference(const JValue& oldVal, const JValue& newVal) {
	
	JValue tmp(Json::arrayValue);

	// directly compare incompatible type and leaf nodes
	if (!oldVal.isConvertibleTo(newVal.type())) {
		if (!oldVal.isNull()) {
			JValue diff;
			diff[DIFF_REMOVE] = oldVal;
			tmp.append(diff);
		}
		if (!newVal.isNull()) {
			JValue diff;
			diff[DIFF_ADD] = newVal;
			(tmp.append(diff));
		}
		return tmp;
	} else {
		JCIterator citrOldVal = oldVal.begin(), citrNewVal = newVal.begin();
		while (true) {
			if (citrOldVal == oldVal.end() && citrNewVal == newVal.end()) {
				break;
			} else if (citrOldVal == oldVal.end()) {
				JValue subDiff(Collect(newVal, citrNewVal, DIFF_ADD));
				tmp.append(subDiff);
				break;	
			} else if (citrNewVal == newVal.end()) {
				JValue subDiff(Collect(oldVal, citrOldVal, DIFF_REMOVE));
				tmp.append(subDiff);
				break;
			} else {
				if (citrOldVal.key() == citrNewVal.key()) {
					if (*citrOldVal != *citrNewVal) {
						if ((*citrOldVal).isArray() || (*citrOldVal).isObject()) {
							JValue subDiff = Difference((*citrOldVal), (*citrNewVal));
							JValue subObj(Json::objectValue);
							if (oldVal.isObject()) {
								subObj[citrOldVal.memberName()].swap(subDiff);
							} else {
								subObj[colib::string::Format("Array %u",citrOldVal.index())].swap(subDiff);
							}
							tmp.append(subObj);
						} else {
							// old leaf node replaced by new
							JValue modified,tmpNode;
							modified[DIFF_ADD].swap((tmpNode = AddMember(citrOldVal.memberName(), *citrOldVal, oldVal.type())));	
							modified[DIFF_REMOVE].swap((tmpNode = AddMember(citrNewVal.memberName(), *citrNewVal, oldVal.type())));	

							tmp.append(modified);
						}
					}
					// move both iterators
					++ citrOldVal;
					++ citrNewVal;			
				} else if (citrOldVal.key() < citrNewVal.key()) {
					// removed from old value
					tmp.append(Collect(oldVal, citrOldVal, citrNewVal, DIFF_REMOVE));
				} else { // citrOldVal->first > citrNewVal->first
					// added to new
					tmp.append(Collect(newVal, citrNewVal, citrOldVal, DIFF_ADD));
				}
			} 
		}	
	}

	return tmp;
}


bool OptionsNode::operator==(const OptionsNode& other) const 
{ 
	if (GetChildrenCount() != other.GetChildrenCount()) return false;

	if (m_value == other.m_value) return true;
	if (!m_value || ! other.m_value) return false;
	
	return GetJValue() == (other.GetJValue()); 
}

bool OptionsNode::operator!=(const OptionsNode& other) const { return (!(*this == other)); }


OptionsNode& OptionsNode::operator=(const OptionsNode& other) 
{
	//shallow copy
	if (this != &other) { // no self copy
		if (other.IsSelfContained()) {
			m_valueCopy = other.m_valueCopy;
			m_value = &m_valueCopy;
		} else {
			m_value = other.m_value; // read only
			m_valueCopy = JValue::null;
		}
		m_status = other.m_status;
	}
	return *this;
} 

// real number type, prefer double type
bool OptionsNode::AsVal(double& dVal, const JValue& jVal) const
{ 	
	if (jVal.isNumeric()) {
		dVal = jVal.asDouble(); 
		return true;
	} else {
		return SetFromStr(dVal, jVal, "%lf");
	}
}
 
bool OptionsNode::AsVal(float& fVal, const JValue& jVal) const
{ 
	if (jVal.isNumeric()) {
		fVal = jVal.asDouble(); 
		return true;
	} else {
		return SetFromStr(fVal, jVal, "%f");
	}
} 

// integer type
bool OptionsNode::AsVal(int& iVal, const JValue& jVal) const
{  
	if (jVal.isNumeric()) {
		iVal = jVal.asInt(); 
		return true;
	} 
	return SetFromStr(iVal, jVal, "%i");
} 

bool OptionsNode::AsVal(unsigned int& uiVal, const JValue& jVal) const
{
	if (jVal.isNumeric()) {
		uiVal = jVal.asUInt(); 
		return true;
	} 
	return SetFromStr(uiVal, jVal, "%u");
}

// colib string
bool OptionsNode::AsVal(colib::string& strVal, const JValue& jVal) const
{
	strVal = GetAsString(jVal);
	return true;
}

#if JSONCPP_VERSION > 500
bool OptionsNode::ASVal(int64_t& i64Val, const JValue& jVal) const
{
	if (jVal.isNumeric()) {
		i64Val = jVal.asInt64(); 
		return true;
	} 
	return SetFromStr(i64Val, jVal, "%li");
}

bool OptionsNode::ASVal(uint64_t& u64Val, const JValue& jVal) const
{
	if (jVal.isNumeric()) {
		u64Val = jVal.asUInt64(); 
		return true;
	}
	return SetFromStr(u64Val, jVal, "%lu");
}
#endif

// boolean
bool OptionsNode::AsVal(bool & bVal, const JValue& jVal) const
{ 
	bVal = jVal.asBool(); 
	return true;
} 

}; // namespace


