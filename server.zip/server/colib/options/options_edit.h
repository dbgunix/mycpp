// vi:set ts=4 sw=4 nowrap:

#ifndef OPTIONS_EDIT_H
#define OPTIONS_EDIT_H

#include<utils/string.h>
#include<utils/filter.h>
#include<utils/assert.h>
#include<utils/callback.h>

#include<options/options_node.h>

#include <string.h> 

namespace colib
{

class OptionsNode;
class OptionsNodeEdit;

class FilterAndTranslator : public Filter {
public:
	virtual colib::string Translate(const char* name) const = 0;
};

class OptionsNodeEdit : public OptionsNode {

private:

	JValue* m_modifiableValue;
	bool*   m_modified; // pointer to the options member. 
			    // OptionsEdit is usually owned by Options class. 
			    // Any modification of the options will invalidate 
			    // the cached options of the owner

	// Caller should make sure m_modifiableValue != NULL
	JValue& GetJValue() { return (*m_modifiableValue); }
	const JValue& GetJValue() const { return OptionsNode::GetJValue(); }
	
	OptionsNodeEdit(JValue* jval, bool* modified); //shallow copy
	OptionsNodeEdit(const JValue& jval, bool *modified); // deep copy
	//From non-editable to editable requires deep copy
	OptionsNodeEdit(const OptionsNode& optionsNode, bool *modified); // deep copy
	
public:

	OptionsNodeEdit(); 
	//editable to editable. no deep copy. 
	OptionsNodeEdit(const OptionsNodeEdit& other); //shallow copy

	OptionsNodeEdit& operator=(const OptionsNodeEdit& other); //shallow copy
	~OptionsNodeEdit() { m_modifiableValue = NULL; }

	bool IsNull() const { return !m_modifiableValue; }
	bool IsEmpty() const{ return !m_modifiableValue || m_modifiableValue->isNull(); }

	OptionsNodeEdit	GetChildNodeEdit(const std::vector<const char*>& path);
	OptionsNodeEdit	GetChildNodeEdit(const char* name, bool create_if_not_exist);
	OptionsNodeEdit	GetChildNodeEdit(unsigned index, bool create_if_not_exist);

	bool SetComment(const char* comment);

	// Add object with the "memberName" and the value is deeply copied from "value"
	bool AddObject(const char* memberName, const OptionsNode& value, bool force); 
	bool RemoveObject(const char* memberName);
	bool ModifyObject(const char* memberName, const OptionsNode& value);
	bool RenameObject(const char* newName, const char* oldName, bool addIfNoObj);

	OptionsNode TrimObjects(const FilterAndTranslator& collectAndRename); 

	//Array has less operations as objects
	bool AppendToArray(const OptionsNode& value); 
	bool ModifyArray(unsigned arrayIndex, const OptionsNode& newValue); 
	bool TruncateArray(unsigned toSize);


	bool MoveObjectTo(OptionsNodeEdit& to, const char* toObjName, const char* fromObjName, bool force);

	//myType should be simple data type such as string, int, double.
	//Use Object and Array Apis for complex data type
	template<typename myType>
	bool PutValue(const char* name, const myType& myVal, const char* comment = NULL); 
	
	//Only append to array instead of directly operate on a certain index 
	template<typename myType>
	bool PutArrayValue(const myType& myVal, const char* comment = NULL); 
	
	//FIPS requiremet
	void Zero();

	void Clear();

	// merge 
	bool Merge(const OptionsNode& src, int maxMergeDepth);

	// deep copy
	OptionsNodeEdit Copy(const OptionsNodeEdit& other); 
private:

	bool AddObject(const char* memberName, const JValue& newVal, bool force); 

	// JsonCpp = operator does not copy the comment so we need to add the extra step to copy comemnts
	static void CopyJValueAndComment(JValue& to, const JValue& from);
	static void CopyJValueComment(JValue& to, const JValue& from);
	static void SwapJValueAndCopyComment(JValue& to, JValue& from);

	static colib::string StrToComment(const char* comment) { return colib::string::Format("//%s", comment ? comment : ""); } 

	static void Merge(JValue& dst, const JValue& src, int maxMergeDepth, int currentDepth, bool& modified);

	OptionsNodeEdit ShallowCopiable();

	void OnModified() { if (m_modified) *m_modified = true; }
	friend class Options;
	friend class OptionsNode;
};


template<typename myType>
bool OptionsNodeEdit::PutValue(const char* name, const myType& myVal, const char* comment) {

	if (!IsObject()) {
		SetStatus("Invalid operation: OptionsNodeEdit is not object type");
		return false;
	}
	const JValue& jVal = (GetJValue())[name];
	if (jVal.isNull() || (!jVal.isArray() && !jVal.isObject())) {
		if (comment) {
			((GetJValue())[name] = myVal).setComment(StrToComment(comment), Json::commentAfterOnSameLine);
		} else {
			(GetJValue())[name] = myVal;
		}
		OnModified();
		return true;
	} else {
		SetStatus("Invalid operation: the child node is not leaf node");
	}
	return false;
}

template<typename myType>
bool OptionsNodeEdit::PutArrayValue(const myType& myVal, const char* comment) {
		
		if (!IsArray()) {
			SetStatus("Invalid operation: OptionsNodeEdit is not array");
			return false;
		}
		if (comment) {
			(GetJValue().append(myVal)).setComment(StrToComment(comment), Json::commentAfterOnSameLine);
		} else {
			GetJValue().append(myVal);
		}
		OnModified();
		return true;
}

}; // namespace

#endif //OPTIONS_NODE_H

