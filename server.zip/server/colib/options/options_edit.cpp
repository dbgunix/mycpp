// vi:set ts=4 sw=4 nowrap:


#include<utils/string.h>
#include<options/options_edit.h>
#include <string.h> 

namespace colib
{

OptionsNodeEdit::OptionsNodeEdit(JValue* jVal, bool* modified)
		                            : OptionsNode(jVal), // shallow copy
                                      m_modifiableValue(jVal), 
                                      m_modified(modified) 
{
	if (!m_modifiableValue) {
		m_value = &m_valueCopy;
		m_modifiableValue = &m_valueCopy;
	}
}
	
OptionsNodeEdit::OptionsNodeEdit(const JValue& jVal, bool*modified)
					: OptionsNode(jVal), // a deep copy
					m_modifiableValue(&m_valueCopy), 
					m_modified(modified) 
{
}


OptionsNodeEdit::OptionsNodeEdit(const OptionsNode& optionsNode, bool *modified)
					: OptionsNode(optionsNode.GetJValue()), // deep copy
					m_modifiableValue(&m_valueCopy), 
					m_modified(modified)
{
} 

OptionsNodeEdit::OptionsNodeEdit(const OptionsNodeEdit& other)
	                 : OptionsNode(other), // shallow copy
                     m_modifiableValue(other.m_modifiableValue), 
                     m_modified(other.m_modified) 
{
	if (other.IsSelfContained()) {
		m_modifiableValue = &m_valueCopy;
	}
} 



OptionsNodeEdit::OptionsNodeEdit() : OptionsNode(NULL), 
									 m_modifiableValue(&m_valueCopy), 
							         m_modified(NULL)
{
}

OptionsNodeEdit& OptionsNodeEdit::operator=(const OptionsNodeEdit& other)
{
	if (this != &other) { // no self copy
		*(static_cast<OptionsNode*>(this)) = static_cast<const OptionsNode&>(other);
		if (other.IsSelfContained()) {
			m_modifiableValue = &m_valueCopy;
		} else {
			m_modifiableValue = other.m_modifiableValue;
		}
	}	
	return *this;
}

OptionsNodeEdit	OptionsNodeEdit::GetChildNodeEdit(const std::vector<const char*>& path)
{
	if (IsEmpty()) return OptionsNodeEdit(NULL, m_modified);

	JValue *node = m_modifiableValue;
	std::vector<const char*>::const_iterator pathCItr = path.begin();

	for ( ; pathCItr != path.end(); ++ pathCItr) {
		if (node->isMember(*pathCItr)){
			node = &(*node)[*pathCItr];
		} else {
			return OptionsNodeEdit(NULL, m_modified);
		}
	}
	return OptionsNodeEdit(node, m_modified);
}

OptionsNodeEdit	OptionsNodeEdit::GetChildNodeEdit(const char* name, bool create_if_not_exist)
{
	if ((create_if_not_exist && IsObject()) || HasObject(name)) {
		return OptionsNodeEdit(&(GetJValue())[name], m_modified);
	} else {
		return OptionsNodeEdit(NULL, m_modified);
	}
}

OptionsNodeEdit	OptionsNodeEdit::GetChildNodeEdit(unsigned index, bool create_if_not_exist)
{
	if (HasArray(index)) {
		return OptionsNodeEdit(&(GetJValue())[index], m_modified);
	} else if (create_if_not_exist && IsArray() && (index == 0 || HasArray(index - 1))) {
		return OptionsNodeEdit(&(GetJValue())[index], m_modified);
	} else {
		return OptionsNodeEdit(NULL, m_modified);
	}
}

bool OptionsNodeEdit::SetComment(const char* comment)
{
	if (IsNull() || !comment) {
		SetStatus("Null OptionsNodeEdit or invalid comment");
		return false;
	}
	GetJValue().setComment(StrToComment(comment).c_str(), Json::commentAfterOnSameLine);
	return true;
}

void OptionsNodeEdit::CopyJValueComment(JValue& to, const JValue& from)
{
	if (from.hasComment(Json::commentAfterOnSameLine)) {
		to.setComment(from.getComment(Json::commentAfterOnSameLine), 
						Json::commentAfterOnSameLine);
	}
}

void OptionsNodeEdit::CopyJValueAndComment(JValue& to, const JValue& from)
{
	to = from;
	CopyJValueComment(to, from);
}


void OptionsNodeEdit::SwapJValueAndCopyComment(JValue& to, JValue& from)
{
	std::string comment; // prefer colib string but does not want to convert

	if (from.hasComment(Json::commentAfterOnSameLine)) {
		comment = from.getComment(Json::commentAfterOnSameLine);
	}
	to.swap(from);
	if (!comment.empty()) {
		to.setComment(comment, Json::commentAfterOnSameLine);
	}
}

OptionsNodeEdit OptionsNodeEdit::Copy(const OptionsNodeEdit& other) 
{
	CopyJValueAndComment(m_valueCopy, other.GetJValue());
	m_value = &m_valueCopy;
	m_modifiableValue = &m_valueCopy;
	return *this;
} 

OptionsNodeEdit OptionsNodeEdit::ShallowCopiable() 
{
	return OptionsNodeEdit(m_modifiableValue, m_modified);
}

bool OptionsNodeEdit::AddObject(const char* objName, const OptionsNode& newVal, bool force) 
{ 
	if (!IsObject()) {
		SetStatus("Invalid operation: cannot add object to non-object OptionsNodeEdit");	
		return false;
	}
	return AddObject(objName, newVal.GetJValue(), force);
}

bool OptionsNodeEdit::AddObject(const char* objName, const JValue& newVal, bool force)
{
	if (newVal.isNull() || &GetJValue() == &newVal) {
		SetStatus("Invalid operation: add empty object or itself");
		return false;
	}
	if (force || !GetJValue().isMember(objName)) {
		CopyJValueAndComment(GetJValue()[objName], newVal);
		OnModified();
		return true;
	} else {
		SetStatus("Invalid operation: object with the same name exists");
	}
	return false;
}

bool OptionsNodeEdit::ModifyObject(const char* objName, const OptionsNode& value)
{
	if (!IsObject()) {
		SetStatus("Invalid operation: cannot modify non-object OptionsNodesEdit");
		return false;
	}
	if (value.HasObject(objName)) {
		return AddObject(objName, value, true);
	} else {
		SetStatus("Invalid operation: object of the name does not exist");
	}	
	return false;
}

bool OptionsNodeEdit::AppendToArray(const OptionsNode& value)
{
	if (!IsArray() || this == &value) {
		SetStatus("Invalid operation: cannot append to non-array OptionsNodeEdit or append itself");
		return false;
	}
	CopyJValueAndComment((GetJValue())[GetJValue().size()], value.GetJValue());
	OnModified();
	return true;
}

bool OptionsNodeEdit::ModifyArray(unsigned arrayIndex, const OptionsNode& newValue) 
{
	if (!HasArray(arrayIndex)) {
		SetStatus("Invalid operation: array index does not exist");
		return false;
	}
	CopyJValueAndComment((GetJValue())[arrayIndex], newValue.GetJValue());
	OnModified();
	return true;
}


bool OptionsNodeEdit::TruncateArray(unsigned toSize)
{
	if (toSize < ArraySize()) {
		GetJValue().resize(toSize);
		return true;
	} else {
		SetStatus("Invalid operation: the array is already smaller than the truncated size");
	}
	return false;
}

bool OptionsNodeEdit::RemoveObject(const char* objName) 
{ 
	if (HasObject(objName)) {
		JValue removed = GetJValue().removeMember(objName);
		// zero the member recursively
		if (!removed.isNull()) {
			OnModified();
			return true;
		}
	} else {
		SetStatus("Invalid operation: object does not exist");
	}
	return false;
}

bool OptionsNodeEdit::RenameObject(const char* newName, const char* oldName, bool addIfNoObj) 
{ 
	if (HasObject(oldName) || addIfNoObj) {
			CopyJValueAndComment((GetJValue())[newName], m_modifiableValue->removeMember(oldName));
			OnModified();
			return true;
	} else {
		SetStatus("Invalid operation: object does not exist");
	}	
	return false;
}

bool OptionsNodeEdit::MoveObjectTo(OptionsNodeEdit& to, 
								  const char* toObjName, 
								  const char* fromObjName,
								  bool force) 
{
	if ( &to == this) {
		SetStatus("Invalid operation: move object from self to self");
		return false;
	}
	if (!HasObject(fromObjName)) {
		SetStatus("Invalid operation: object does not exist");
		return false;
	}
	if (to.AddObject(toObjName, OptionsNodeEdit(GetJValue()[fromObjName], to.m_modified), force)) {
		RemoveObject(fromObjName);
		return true;
	}
	return false;
}		


bool OptionsNodeEdit::Merge(const OptionsNode& src, int maxMergeDepth)
{
	bool modified = false;
	if (!IsNull() && !src.IsNull()) {
		Merge(GetJValue(), src.GetJValue(), maxMergeDepth, 0, modified);
		OnModified();
	} else {
		SetStatus("Invalid operation: merge on Null OptionsNode(s)");
	}
	return modified;
}

//XXX TODO Optimization using mergeing sort idea

void OptionsNodeEdit::Merge(JValue& dest, const JValue& src, 
					   int maxMergeDepth, int currentDepth,
					   bool &modified) {
	

	if (src.isNull()) return;

	if (src.isObject() && dest.isObject()) {

		Json::Value::const_iterator citr = src.begin();
		for(; citr != src.end(); ++ citr) {

			if ((*citr).isNull()) continue; // skip null node

			// find or create new 
			JValue& value = dest[citr.memberName()];
			// merge child recursively
			if (currentDepth >= maxMergeDepth) {
				CopyJValueAndComment(value, *citr);
			} else {
				++ currentDepth;
				Merge(value, *citr, maxMergeDepth, currentDepth, modified); 
				-- currentDepth;
			}
		} 
	} else {
		CopyJValueAndComment(dest, src); // overwrite 
	}
}


// need to modify jsoncpp to provide zero utilities. 
// try to modify the third party libraries as less as possilbe 
void OptionsNodeEdit::Zero() {
	if (m_modifiableValue) {
		Json::zeroValue(GetJValue());
		OnModified();
	}
}


OptionsNode OptionsNodeEdit::TrimObjects(const FilterAndTranslator& collectAndRename) 
{

	bool modified = false;
	if (!IsObject()) return OptionsNode(NULL);

	JValue jvalTmp(GetJValue().type());

	JCIterator jcitr = static_cast<const JValue&>(GetJValue()).begin();
	for ( ; jcitr != GetJValue().end(); ++ jcitr) {
		if ((collectAndRename)(jcitr.memberName())) {

			colib::string transName = collectAndRename.Translate(jcitr.memberName());
		
			if (!transName.is_empty()) {
				CopyJValueAndComment(jvalTmp[transName],  *jcitr);
				modified = true;
			}
		}
	}
	if (modified) {
		SwapJValueAndCopyComment(GetJValue(), jvalTmp);
		OnModified();
	}	
	return OptionsNode(&GetJValue());
}


void OptionsNodeEdit::Clear() 
{ 
	if (!IsEmpty()) {
		OnModified();
		GetJValue() = JValue::null;
	}
}

}; // namespace


