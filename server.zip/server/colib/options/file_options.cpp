// file_options.cpp
// vi:set ts=4 sw=4 nowrap:

#include<options/file_options.h>
#include<utils/system/memory.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

namespace colib
{

FileOptions::FileOptions()
{
	m_filename[0] = '\0';
}

FileOptions::FileOptions (const char* filename, bool strip_end_comments)
{
	LoadFile(filename, strip_end_comments);
}

bool FileOptions::LoadFile(const char* filename, bool strip_end_comments)
{
	if ( !filename ) 
	{
		SetStatus("Invalid parameters");
		return false;
	}

	bool success = false;

	ClearStatus();

	int flags = 0;

	int fd = open (filename, flags);
	if (fd != -1)
	{
		struct stat stat;
		if (fstat (fd, &stat) == -1)
			SetStatus("Unable to stat");
		else
		{
			char* buffer = (char*) xmalloc (stat.st_size + 1);
			if (!buffer)
				SetStatus("Unable to malloc");
			else
			{
				if (read (fd, buffer, stat.st_size) != stat.st_size)
					SetStatus("Unable to read from file");
				else
				{
					buffer [(int) stat.st_size] = 0; // NULL terminate the string
					success = Load (buffer, strip_end_comments);
				}
				
				xfree (buffer);
			}
		}

		close (fd);
	}
	else
	{
		SetStatus("Unable to open file.");
	}

	strcpy(m_filename, filename);

	return success;
}

bool FileOptions::SaveFile(const char *filename) const
{
	bool success = false;

	if(GetStatus())
		return false;

	int fd = open (filename, O_CREAT|O_RDWR|O_TRUNC, S_IREAD|S_IWRITE);
	if (fd != -1)
	{
		colib::string buffer = DumpToFormattedStr();
		if (buffer)
		{
			ssize_t ret = write(fd, buffer.c_str(), buffer.get_length());
			if (ret > 0)
			{
				success = (static_cast<unsigned int>(ret) == buffer.get_length());
			}

			if (!success)
				SetStatus("Unable to write to file");

		}
		close (fd);
	}
	else
		SetStatus("Unable to open");

	return success;
}

bool FileOptions::SaveFile(const char *filename,const char* text)
{
	bool success = false;

	int fd = open (filename, O_CREAT|O_RDWR|O_TRUNC, S_IREAD|S_IWRITE);
	if (fd != -1)
	{
		if (text)
		{
			size_t text_length = strlen(text);

			ssize_t ret = write(fd, text, text_length);
			if (ret > 0)
			{
				success = (static_cast<unsigned int>(ret) == text_length);
			}

			if (!success)
				SetStatus("Unable to write to file");

		}
		close (fd);
	}
	else
		SetStatus("Unable to open");

	return success;
}

bool	FileOptions::SaveFile()
{
	if ( strlen(m_filename) ) return SaveFile(m_filename);
	return false;
}

}

