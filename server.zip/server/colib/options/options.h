// vi:set ts=4 sw=4 nowrap:

#ifndef __OPTIONS_H__
#define __OPTIONS_H__

#include<options/options_edit.h>

namespace colib
{

class Options
{
	public: //TODO members that should be moved to other place
		 bool                        GetLicense(colib::string &license) const; 
		 void		             SetLicense(const colib::string &license);

	public:
								Options();
								Options(const Options& that);
				
								Options(const OptionsNodeEdit& edit); // make a deep copy of JValue of edit
								Options(const OptionsNode& node); //make a deep copy of JValue
		virtual 					~Options();		
		
		Options&					operator=(const Options& that);
		bool						operator==(const Options& that) const;
		bool						operator!=(const Options& that) const;
	
		
		// merge options but not the license
		bool						Merge(const Options& other, int depth = 1);

		// We would never want to expose the real data structure used
		int							NodeCount() const { return m_rootNode.GetChildrenCount(); }	

		// The copy constructor of OptionsNode will be called so the retruned class is not
		// able to safely downcast to OptionsNodeEdit. This is the desired behavior to prevent the client code 
		// from modifying the Options
		OptionsNode					GetRootOptionsNode() const { return m_rootNode.OptionsNode::ShallowCopiable(); }

		OptionsNodeEdit				GetRootOptionsNodeEdit() { return m_rootNode.ShallowCopiable(); }

		//path operation
		OptionsNode					GetOptionsNode(const std::vector<const char*>& path) const { return m_rootNode.GetChildNode(path);}
		OptionsNodeEdit				GetOptionsNodeEdit(const std::vector<const char*>& path) { return m_rootNode.GetChildNodeEdit(path); }

		//iterator
		OptionsNodeIterator         begin() const { return GetRootOptionsNode().begin(); }
		OptionsNodeIterator         end() const { return GetRootOptionsNode().end(); }
		

		template<typename IdType>
		OptionsNodeEdit				GetOptionsNodeEdit(const IdType& id, bool creat_if_not_exist) { return m_rootNode.GetChildNodeEdit(id, creat_if_not_exist); }


		template<typename IdType>
		OptionsNode					GetOptionsNode(const IdType& id) const { return m_rootNode.GetChildNode(id); }

		OptionsNode                 Difference(const Options& other) const { return GetRootOptionsNode().Difference(other.GetRootOptionsNode()); }

		bool						IsEmpty() const { return m_rootNode.IsEmpty(); }; 
		bool						IsModified() const { return m_modified; }
		const char*					GetStatus() const; // returns 0 if no errors
		colib::string				GetStatusStr() const { return m_status; }
		void						ClearStatus() const { m_status.clear(); }


		bool						Load(const char* contents, bool strip_end_comments = true);
		void						zero();
		void						Clear();
		void						ClearContent();
		//
		// Output function
		//unformatted option string	
		colib::string				DumpToStr() const;
		// used for human
		colib::string             DumpToFormattedStr() const { return m_rootNode.ToStyledString().c_str(); };
		colib::string				AsStrNoFormat() const; // not formatted
		

		//TODO Special function for beam. Should not be here or need change to more generic name
		
		static bool 			    GetChildInBeam(OptionsNode &out, const OptionsNode& node, const char *name, const int beam );
		static void					Localize(OptionsNodeEdit& node, int Beam);

	protected:
	
		int							SetStatus(const char *status) const;
		
	private:


		void 						CopyFrom(const Options& other);
		bool						LoadBase(const char* contents, bool strip_end_comments = true);

		void                        OnModified() const { m_modified = true; } //m_modified is muted

		Json::Reader           		m_jreader;

		OptionsNodeEdit             m_rootNode;

		colib::string             m_license;
		mutable colib::string		m_cached;
		mutable bool				m_modified;
		mutable colib::string		m_status;
};


}; //colib namespace

#endif // __OPTIONS_H__

