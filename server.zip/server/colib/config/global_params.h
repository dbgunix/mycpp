#if !defined(__GLOBAL_PARAMS_H__)
#define __GLOBAL_PARAMS_H__

#include<config/value.h>

#include <vector>

namespace colib
{

class Options;
class Writable;

class GlobalParams
{
public:
	enum Category
	{
		GP_GENERAL,
		GP_PP,
		GP_SECURITY,
		GP_FIPS
	};

	enum GeneralParams
	{
		Param_debug_level
	};

	// TODO: most or all of these are PP specific and should be moved
	enum PpParams
	{
		Param_initial_mssg_bufs,
		Param_max_mssg_bufs,
		Param_pp_id,
		Param_app_id,
		Param_blade_id,
		Param_pp_distributor_flush_timeout
	};

	enum SecurityParams
	{
		Param_password,
		Param_admin_password,
		Param_os_password
	};

	enum FipsParams
	{
		Param_on
	};

	static GlobalParams& GetInstance();

	ValueList& GetValueList(Category cat) { return m_global_params[cat]; }
	bool LoadFromOptions(const Options& opt);
	void Reset();

	void ConsoleCommand(Writable *to, int argc, char* argv[]);

private:
	GlobalParams();
	std::vector<ValueList> m_global_params;
};

#define GLOBALPARAM(cat, param) colib::GlobalParams::GetInstance().GetValueList(colib::GlobalParams::GP_##cat)[colib::GlobalParams::Param_##param].AsInt()
#define GLOBALSTRPARAM(cat, param) colib::GlobalParams::GetInstance().GetValueList(colib::GlobalParams::GP_##cat)[colib::GlobalParams::Param_##param].AsString()

}

#endif
