#if !defined(__VALUE_MAP_H__)
#define __VALUE_MAP_H__

#include<utils/string.h>
#include<utils/system/environ.h>

#include <string.h>
#include <vector>
#include <functional>

// NOTE: use macro until we find a typedef which works
// See http://gcc.gnu.org/bugzilla/show_bug.cgi?id=44703
// Fixed in 4.5.1
#define VALUEINITLIST std::initializer_list<colib::Value>

namespace colib
{

class Options;
class OptionsNode;
class OptionsNodeEdit;
class Writable;

class Value
{
public:
	enum Type
	{
		INT,
		DOUBLE,
		STRING,
		UINT
	};

	//Value(const char *name) : m_type(INT), m_int(0), m_name(name) {}
	Value(int i, bool readonly = false);
	//Value(const char *name, unsigned i);
	explicit Value(const char *name, double d, bool readonly = false);
	explicit Value(double d, bool readonly = false);
	explicit Value(const char *name, const char *str, bool readonly = false);
	explicit Value (const char *str, bool readonly = false);
	//explicit Value(Type t, const char *str_val, bool readonly = false);
	Value(const char *name, int i, bool readonly = false);

	~Value();

	Value(const Value &of);
	Value& operator=(const Value &to);

	bool operator==(const Value &to) const;
	bool operator!=(const Value &to) const { return !(*this==to); }
	bool CompareToStrVal(const char *str_val) const;

	void SetFromString(const char *val);
	void StoreToOptions(OptionsNodeEdit& opt) const;

	void zero();
	void Reset();

	int& AsInt() { return m_int; }
	int AsInt() const { return m_int; }
	double& AsDouble() { return m_double; }
	double AsDouble() const { return m_double; }
	const char* AsString() const { return m_str; }

	const char* GetName() const { return m_name; }
	bool IsReadOnly() const { return m_readonly; }
	bool IsDefault() const;

	void Print(Writable *to) const;

private:
	/// Data type
	Type m_type;
	/// Indicates whether Value can be changed from the console
	bool m_readonly;
	/// Name
	const char *m_name;
	/// current value
	union
	{
		int m_int;
		unsigned m_uint;
		double m_double;
		const char *m_str;
	};
	/// default value
	union
	{
		int m_default_int;
		unsigned m_default_uint;
		double m_default_double;
		const char *m_default_str;
	};
};

class ValueList
{
public:
	typedef std::vector<Value> ValueHolder;

	ValueList() : m_values() { }
	ValueList(VALUEINITLIST init) : m_values(init) { }
	ValueList(ValueHolder&& init) : m_values(init) { }
	ValueList(const ValueList& other);
	ValueList& operator=(const ValueList& other);

	//bool AddValue(const Value& val);
	bool AddValues(std::initializer_list<Value> val);

	Value& GetValue(unsigned int index) { return m_values[index]; } // no bounds checking
	const Value& GetValue(unsigned int index) const { return m_values[index]; } // no bounds checking
	const Value* GetValueByName(const char* name) const;
	Value& operator[] (unsigned int index) { return m_values[index]; } // no bounds checking
	const Value& operator[] (unsigned int index) const { return m_values[index]; } // no bounds checking

	int& GetIntValue(unsigned int index) { return m_values[index].AsInt(); }
	double& GetDoubleValue(unsigned int index) { return m_values[index].AsDouble(); }
	const char* GetStringValue(unsigned int index) const { return m_values[index].AsString(); }
	const char* GetName(unsigned int index) const { return m_values[index].GetName(); }

	int Count() const { return m_values.size(); }
	void Reset();
	void Clone(const ValueList &other);

	bool IsKeyChanged(unsigned int index, const OptionsNode& grp) const;
	bool LoadFromOptions(const OptionsNode& grp);
	bool LoadFromOptions(const Options *opt, const char *grp_name);
	void StoreToOptions(OptionsNodeEdit& opt_edit) const;

	void Print(Writable *to) const;
	void ConsoleCommand(Writable *to, int argc, char *argv[]);

private:
	struct ValueFinder
	{
		bool operator() (const Value &v, const char *name) const { return strcmp(v.GetName(), name) == 0; }
	};
	ValueHolder::iterator FindTargetValue(const char* name);
	ValueHolder::const_iterator FindConstTargetValue(const char* name) const;

	void ConsolePrint(Writable *to, int argc, char *argv[]) const;
	void ConsoleReset(Writable *to, int argc, char *argv[]);
	void ConsoleSet(Writable *to, int argc, char *argv[]);

	/// Container of Values
	ValueHolder m_values;
	/// Functor for finding Values
	static std::function<bool (const Value&, const char*)> m_finder;
};

}

#endif
