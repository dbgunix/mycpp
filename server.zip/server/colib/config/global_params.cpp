#include <config/global_params.h>
#include <options/options.h>
#include <utils/trace/writable.h>

namespace colib
{

static ValueList::ValueHolder InitGeneralParams()
{
	return
	{
		Value("debug_level", 3)
	};
}

static ValueList::ValueHolder InitPpParams()
{
	return
	{
		Value("initial_mssg_bufs", 30000),
		Value("max_mssg_bufs", 300000),
		Value("pp_id", 0),
		Value("app_id", 0),
		Value("blade_id", 0),
		Value("pp_distributor_flush_timeout", 0)
	};
}

static ValueList::ValueHolder InitSecurityParams()
{
	return
	{
		Value("password", "admin"),
		Value("admin_password", "admin"),
		Value("os_password", "admin")
	};
}

static ValueList::ValueHolder InitFipsParams()
{
	return
	{
		Value("on", 0, true)
	};
}

GlobalParams& GlobalParams::GetInstance()
{
	static GlobalParams instance;
	return instance;
}

GlobalParams::GlobalParams()
	: m_global_params({ InitGeneralParams(), InitPpParams(), InitSecurityParams(), InitFipsParams() })
{
}

bool GlobalParams::LoadFromOptions(const Options& opt)
{
	bool success = m_global_params[GP_GENERAL].LoadFromOptions(opt.GetOptionsNode("GLOBAL"))
			&& m_global_params[GP_PP].LoadFromOptions(opt.GetOptionsNode("GLOBAL"))
			&& m_global_params[GP_SECURITY].LoadFromOptions(opt.GetOptionsNode("SECURITY"))
			&& m_global_params[GP_FIPS].LoadFromOptions(opt.GetOptionsNode("FIPS"));
	return success;
}

void GlobalParams::Reset()
{
	// reset all categories
	for (auto it(m_global_params.begin()); it != m_global_params.end(); ++it)
	{
		(*it).Reset();
	}
}

void GlobalParams::ConsoleCommand(Writable *to, int argc, char *argv[])
{
	const char* usage = "Usage:\tGLOBAL|PP|SECURITY|FIPS\n";

	if (argc < 1)
	{
		to->PrintString(usage);
	}
	else if (!strcmp(argv[0], "GLOBAL"))
	{
		GetValueList(GP_GENERAL).ConsoleCommand(to, argc-1, argv+1);
	}
	else if (!strcmp(argv[0], "PP"))
	{
		GetValueList(GP_PP).ConsoleCommand(to, argc-1, argv+1);
	}
	else if (!strcmp(argv[0], "SECURITY"))
	{
		GetValueList(GP_SECURITY).ConsoleCommand(to, argc-1, argv+1);
	}
	else if (!strcmp(argv[0], "FIPS"))
	{
		GetValueList(GP_FIPS).ConsoleCommand(to, argc-1, argv+1);
	}
	else
	{
		to->PrintString(usage);
	}
}

}
