#if !defined(__CONFIG_FIPS_MODE_H__)
#define __CONFIG_FIPS_MODE_H__

#include<config/global_params.h>

namespace colib
{

bool InFipsMode();

}

#endif
