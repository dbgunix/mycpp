#include<config/value.h>
#include<utils/system/memory.h>
#include<utils/trace/writable.h>
#include<options/options.h>

#include <stdlib.h>
#include <string.h>
#include <algorithm>

namespace colib
{

/** Named Value ctor (int)
 * \param[in] name Name of the Value
 * \param[in] i Integer value
 * \param[in] readonly Readonly flag (default false)
 */
Value::Value(const char *name, int i, bool readonly)
	: m_type(INT)
	, m_readonly(readonly)
	, m_name(name)
	, m_int(i)
	, m_default_int(i)
{
}

/** Unnamed Value ctor (int)
 * \param[in] i Integer value
 * \param[in] readonly Readonly flag (default false)
 */
Value::Value(int i, bool readonly)
	: m_type(INT)
	, m_readonly(readonly)
	, m_name("")
	, m_int(i)
	, m_default_int(i)
{
}

/** Named Value ctor (double)
 * \param[in] name Name of the Value
 * \param[in] d Double value
 * \param[in] readonly Readonly flag (default false)
 */
Value::Value(const char *name, double d, bool readonly)
	: m_type(DOUBLE)
	, m_readonly(readonly)
	, m_name(name)
	, m_double(d)
	, m_default_double(d)
{
}

/** Unnamed Value ctor (double)
 * \param[in] d Double value
 * \param[in] readonly Readonly flag (default false)
 */
Value::Value(double d, bool readonly)
	: m_type(DOUBLE)
	, m_readonly(readonly)
	, m_name("")
	, m_double(d)
	, m_default_double(d)
{
}

/** Named Value ctor (string)
 * \param[in] name Name of the Value
 * \param[in] str String value
 * \param[in] readonly Readonly flag (default false)
 * \note Copies string \a str
 */
Value::Value(const char *name, const char *str, bool readonly)
	: m_type(STRING)
	, m_readonly(readonly)
	, m_name(name)
	, m_str(str ? xstrdup(str) : NULL)
	, m_default_str(str ? xstrdup(str) : NULL)
{
}

/** Unnamed Value ctor (string)
 * \param[in] str String value
 * \param[in] readonly Readonly flag (default false)
 * \note Copies string \a str
 */
Value::Value(const char *str, bool readonly)
	: m_type(STRING)
	, m_readonly(readonly)
	, m_name("")
	, m_str(str ? xstrdup(str) : NULL)
	, m_default_str(str ? xstrdup(str) : NULL)
{
}

/** Value copy ctor
 * \param[in] of Value to copy
 */
Value::Value(const Value &of)
	: m_type(of.m_type)
	, m_readonly(of.m_readonly)
	, m_name(of.m_name)
{
	switch (m_type)
	{
		case STRING:
			m_str = of.m_str ? xstrdup(of.m_str) : NULL;
			m_default_str = of.m_default_str ? xstrdup(of.m_default_str) : NULL;
			break;
		case UINT:
			m_uint = of.m_uint;
			m_default_uint = of.m_default_uint;
			break;
		case DOUBLE:
			m_double = of.m_double;
			m_default_double = of.m_default_double;
			break;
		case INT:
		default:
			m_int = of.m_int;
			m_default_int = of.m_default_int;
			break;
	}
}

/*
 * NOTE: left in case needed later
Value::Value(Type t, const char* str_val, bool readonly)
	: m_type(t)
	, m_readonly(readonly)
	, m_name("")
{
	switch (m_type)
	{
		case STRING:
			m_str = str_val ? xstrdup(str_val) : NULL;
			break;
		case DOUBLE:
			m_double = str_val ? atof(str_val) : 0.0;
			break;
		case UINT:
			m_uint = str_val ? strtoul(str_val, (char **)NULL,  0) : 0;
			break;
		default:
			m_type = INT;
			//fall thru
		case INT:
			m_int = str_val ? strtol(str_val, (char **)NULL,  0) : 0;
			break;
	}
}
*/

/// Value dtor
Value::~Value()
{
	if(m_type==STRING)
	{
		if (m_str)
		{
			xfree((void*)m_str);
		}
		if (m_default_str)
		{
			xfree((void*)m_default_str);
		}
	}
}

/** Value assignment operator
 * \param[in] to Value to copy
 */
Value& Value::operator=(const Value &to)
{
	if(&to != this)
	{
		if(m_type==STRING)
		{
			if(m_str)
			{
				xfree((void*)m_str);
				m_str=0;
			}
		}

		m_type = to.m_type;
		//m_name = to.m_name;

		switch (m_type)
		{
			case STRING:
				m_str = to.m_str ? xstrdup(to.m_str) : 0 ;
				break;
			case UINT:
				m_uint = to.m_uint;
				break;
			case DOUBLE:
				m_double = to.m_double;
				break;
			case INT:
			default:
				m_int = to.m_int;
				break;
		}
	}
	return *this;
}

/** Value equality operator
 * \param[in] to Value to check equality with
 * \return True if Values are equal (type and value), false if not
 */
bool Value::operator==(const Value &to) const
{
	if (m_type != to.m_type)
	{
		return false;
	}

	switch (m_type)
	{
		case STRING:
			if (m_str == NULL)
			{
				return to.m_str == NULL;
			}
			if (to.m_str == NULL)
			{
				return false;
			}
			return !strcmp(m_str,to.m_str);
		case UINT:
			return m_uint == to.m_uint;
		case DOUBLE:
			return m_double == to.m_double;
		default:
		case INT:
			return m_int == to.m_int;
	}
}

/** Compare Value to string representation of value
 * \param[in] str_val String or string representation of value
 * \return True if Value is equal, false if not
 * \note Similiar to operator==, but can save a temporary
 */
bool Value::CompareToStrVal(const char* str_val) const
{
	switch (m_type)
	{
		case STRING:
			if (m_str == NULL)
			{
				return str_val == NULL;
			}
			if (str_val == NULL)
			{
				return false;
			}
			return strcmp(m_str, str_val) == 0;
		case UINT:
			return m_uint == (str_val ? strtoul(str_val, (char **)NULL,  0) : 0);
		case DOUBLE:
			return m_double == (str_val ? atof(str_val) : 0.0);
		default:
		case INT:
			return m_int == (str_val ? strtol(str_val, (char **)NULL,  0) : 0);
	}
}

/** Set Value from a string
 * \param[in] val String or string representation of value
 */
void Value::SetFromString(const char *val)
{
	switch( m_type )
	{
		case STRING:
			if(m_str)
			{
				xfree((void*)m_str);
				m_str=0;
			}
			if(val)
			{
				m_str = xstrdup(val);
			}
			break;
		case DOUBLE:
			m_double = val ? atof(val) : 0.0;
			break;
		case UINT:
			m_uint = val ? strtoul(val, (char **)NULL,  0) : 0;
			break;
		default:
			m_type = INT;
			//fall thru
		case INT:
			m_int = val ? strtol(val, (char **)NULL,  0) : 0;
			break;
	}
}

void Value::StoreToOptions(OptionsNodeEdit& opt_edit) const
{
	switch (m_type)
	{
		case Value::STRING:
			opt_edit.PutValue(m_name, m_str);
			break;
		case Value::DOUBLE:
			opt_edit.PutValue(m_name, m_double);
			break;
		case Value::INT:
		default:
			opt_edit.PutValue(m_name, m_int);
			break;
	}
}

/// Zeroize the Value
void Value::zero()
{
	switch(m_type)
	{
		case STRING:
			if(m_str)
			{
				memset((void*)m_str, 0, strlen(m_str));
				xfree((void*)m_str);
				m_str = 0;
			}
			break;
		case DOUBLE:
			m_double = 0.0;
			break;
		case UINT:
			m_uint = 0;
			break;
		default:
			m_type = INT;
		case INT:
			m_int = 0;
			break;
	}
}

/// Reset Value to default
void Value::Reset()
{
	switch (m_type)
	{
		case STRING:
			if (m_str)
			{
				xfree((void*)m_str);
				m_str=0;
			}
			m_str = m_default_str ? xstrdup(m_default_str) : NULL;
			//m_str = m_default_str;
			break;
		case DOUBLE:
			m_double = m_default_double;
			break;
		case UINT:
			m_uint = m_default_uint;
			break;
		default:
			m_type = INT;
		case INT:
			m_int = m_default_int;
			break;
	}
}

/** Check if the Value is equal to its default
 * \return True if the current value is the same as the default, false if not
 */
bool Value::IsDefault() const
{
	switch (m_type)
	{
		case STRING:
			return strcmp(m_str, m_default_str) == 0;
		case DOUBLE:
			return m_double == m_default_double;
		case UINT:
			return m_uint == m_default_uint;
		default:
		case INT:
			return m_int == m_default_int;
	}
}

/** Print Value
 * \param[in] to Writable to use for output
 */
void Value::Print(Writable *to) const
{
	switch (m_type)
	{
		case INT:
			to->Print("%s = %d\n", m_name, m_int);
			break;
		case UINT:
			to->Print("%s = %u\n", m_name, m_uint );
			break;
		case STRING:
			to->Print("%s = \"%s\"\n", m_name, m_str);
			break;
		case DOUBLE :
			to->Print("%s = %f\n", m_name, m_double);
			break;
		default :
			to->Print( "%s = Unknown Type (%d)\n", m_name, m_type);
			break;
	}
}

std::function<bool (const Value&, const char*)> ValueList::m_finder = ValueList::ValueFinder();

/** ValueList copy ctor
 * \param[in] other ValueList to copy from
 * \warning Does a deep copy of the Values of \a other
 */
ValueList::ValueList(const ValueList& other)
	: m_values(other.m_values)
{
}

/** ValueList assignment operator (copy)
 * \param[in] other ValueList to copy from
 * \warning Does a deep copy of the Values of \a other
 */
ValueList& ValueList::operator=(const ValueList& other)
{
	if (this != &other)
	{
		m_values = other.m_values;
	}
	return *this;
}

bool ValueList::AddValues(std::initializer_list<Value> val)
{
	for (auto it(val.begin()); it != val.end(); ++it)
	{
		m_values.push_back(*it);
	}
	return true;
}

/** Find a Value using its name
 * \param[in] name Value name to search for
 * \return Pointer to Value if found, NULL if not
 */
const Value* ValueList::GetValueByName(const char* name) const
{
	for (auto it(m_values.begin()); it != m_values.end(); ++it)
	{
		if (0 == strcmp((*it).GetName(), name))
		{
			return &(*it);
		}
	}
	return NULL;
}

/// Reset all Values in container to their defaults
void ValueList::Reset()
{
	for (auto it(m_values.begin()); it != m_values.end(); ++it)
	{
		(*it).Reset();
	}
}

/** Copy Values of another ValueList
 * Any Values which are present in this list but not in
 * the other will be reset to their default
 * \param[in] other ValueList to use as input
 */
void ValueList::Clone(const ValueList& other)
{
	for (auto it(m_values.begin()); it != m_values.end(); ++it)
	{
		const Value *other_val = other.GetValueByName((*it).GetName());
		if (other_val != NULL)
		{
			(*it) = *other_val;
		}
		else
		{
			(*it).Reset();
		}
	}
}

/** Determine if a given key is different from the value in the provided
 * options group, or from its default value if no group is provided
 * \param[in] index Index of the Value in the ValueList
 * \param[in] grp Options group to check against
 * \return True if Value is different from value in \a grp (if grp valid and key found).
 * True if Value is different from default value (if grp invalid or key not found).
 * False otherwise.
 */
bool ValueList::IsKeyChanged(unsigned int index, const OptionsNode& grp) const
{
	if (index >= m_values.size())
	{
		return false;
	}
	if (!grp.IsNull())
	{
		string k = grp.GetAsString(GetName(index));
		if (!k.is_empty())
		{
			return !m_values[index].CompareToStrVal(k);
		}
	}
	// grp or key invalid, compare against default
	return !m_values[index].IsDefault();
}

/** Load the ValueList from key/value pairs from an Options Group
 * Any values which are not in the Options Group will be reset to their default
 * \param[in] grp Options group to use
 * \return True if the load succeeded, false if not
 */
bool ValueList::LoadFromOptions(const OptionsNode& grp)
{
	if (grp.IsNull())
	{
		// no valid options group, reset to default
		for (unsigned int ii(0); ii < m_values.size(); ++ii)
		{
			m_values[ii].Reset();
		}
		return false;
	}

	for (unsigned int ii(0); ii < m_values.size(); ++ii)
	{
		const char* key = m_values[ii].GetName();
		string sval = grp.GetAsString(key);
		if (!sval.is_empty())
		{
			// value in options file, use it
			// TODO replace value with Json::Value
			m_values[ii].SetFromString(sval);
		}
		else
		{
			// value not in options file, load default
			m_values[ii].Reset();
		}
	}
	return true;
}

/** Load the ValueList from key/value pairs from an Options Group
 * Any values which are not in the Options Group will be reset to their default
 * \param[in] opt Options object to use
 * \param[in] grp_name Name of the group to load from
 * \return True if the load succeeded, false if not
 */
bool ValueList::LoadFromOptions(const Options *opt, const char *grp_name)
{
	if (!opt || !grp_name)
	{
		return false;
	}
	OptionsNode grp = opt->GetOptionsNode(grp_name);
	return LoadFromOptions(grp);
}

/** Store the ValueList to key/value pairs in an Options Group
 * New values will be added to the Options Group
 * \param[out] opt_edit Options object to use for storage
 */
void ValueList::StoreToOptions(OptionsNodeEdit& opt_edit) const
{
	for (auto it(m_values.cbegin()); it != m_values.cend(); ++it)
	{
		(*it).StoreToOptions(opt_edit);
	}
}

/** Find a Value in the ValueList by name
 * \param[in] name Name of the Value to look for
 * \return iterator to the Value if found
 */
ValueList::ValueHolder::iterator ValueList::FindTargetValue(const char* name)
{
	return std::find_if(m_values.begin(), m_values.end(), std::bind(m_finder, std::placeholders::_1, name));
}

/** Find a Value in the ValueList by name
 * \param[in] name Name of the Value to look for
 * \return const_iterator to the Value if found
 */
ValueList::ValueHolder::const_iterator ValueList::FindConstTargetValue(const char* name) const
{
	return std::find_if(m_values.cbegin(), m_values.cend(), std::bind(m_finder, std::placeholders::_1, name));
}

/** Handle a console command to print a single Value
 * or all Values to a Writable
 * \param[in] to Writable to use for output
 * \param[in] argc Number of arguments
 * \param[in] argv Array of arguments
 */
void ValueList::ConsolePrint(Writable *to, int argc, char *argv[]) const
{
	if (0 == argc)
	{
		// no target specified, print all
		if (m_values.empty())
		{
			to->Print("No values\n");
		}
		else
		{
			Print(to);
		}
	}
	else
	{
		auto it(FindConstTargetValue(argv[0]));
		if (it == m_values.end())
		{
			to->Print("Cannot find value \"%s\"\n", argv[0]);
		}
		else
		{
			(*it).Print(to);
		}
	}
}

/** Handle a console command to reset a single Value
 * or all Values to their default
 * \param[in] to Writable to use for output
 * \param[in] argc Number of arguments
 * \param[in] argv Array of arguments
 */
void ValueList::ConsoleReset(Writable *to, int argc, char *argv[])
{
	if (0 == argc)
	{
		// no target specified, reset all
		for (auto it(m_values.begin()); it != m_values.end(); ++it)
		{
			if (!(*it).IsReadOnly())
			{
				(*it).Reset();
			}
		}
		ConsolePrint(to, 0, NULL);
	}
	else
	{
		auto it(FindTargetValue(argv[0]));
		if (it == m_values.end())
		{
			to->Print("Cannot find value \"%s\"\n", argv[0]);
		}
		else if ((*it).IsReadOnly())
		{
			to->Print("Cannot modify value \"%s\"\n", argv[0]);
		}
		else
		{
			(*it).Reset();
			(*it).Print(to);
		}
	}
}

/** Handle a console command to set a single Value
 * or all Values
 * \param[in] to Writable to use for output
 * \param[in] argc Number of arguments
 * \param[in] argv Array of arguments
 */
void ValueList::ConsoleSet(Writable *to, int argc, char *argv[])
{
	if (argc < 2)
	{
		to->Print("Argument missing, check usage\n");
		return;
	}
	auto it(FindTargetValue(argv[0]));
	if (it == m_values.end())
	{
		to->Print("Cannot find value \"%s\"\n", argv[0]);
	}
	else if ((*it).IsReadOnly())
	{
		to->Print("Cannot modify value \"%s\"\n", argv[0]);
	}
	else
	{
		(*it).SetFromString(argv[1]);
		(*it).Print(to);
	}
}

/** Print all Values to a Writable
 * \param[in] to Writable to use for output
 */
void ValueList::Print(Writable *to) const
{
	for (auto it(m_values.cbegin()); it != m_values.cend(); ++it)
	{
		(*it).Print(to);
	}
}

/** Process a value list console command
 * \param[in] to Writable to use for output
 * \param[in] argc Number of arguments
 * \param[in] argv Array of arguments
 */
void ValueList::ConsoleCommand(Writable *to, int argc, char *argv[])
{
	static const char *usage = "Usage: show {key} | reset {key} | set [key] [value]\n";

	if (argc < 0)
	{
		to->PrintString(usage);
	}
	else if (0 == argc)
	{
		ConsolePrint(to, 0, NULL);
	}
	else if (!strcmp(argv[0], "show"))
	{
		ConsolePrint(to, argc-1, argv+1);
	}
	else if (!strcmp(argv[0], "reset"))
	{
		ConsoleReset(to, argc-1, argv+1);
	}
	else if (!strcmp(argv[0], "set"))
	{
		ConsoleSet(to, argc-1, argv+1);
	}
	else
	{
		to->PrintString(usage);
	}
}

}
