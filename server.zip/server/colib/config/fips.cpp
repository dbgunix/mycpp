#include<config/fips.h>

namespace colib
{

bool InFipsMode()
{
	return GLOBALPARAM(FIPS, on) == 1;
}


}
