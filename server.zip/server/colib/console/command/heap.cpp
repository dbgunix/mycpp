#if 0

#include "heap.h"
#include <utils/system/memory.h>
#include <utils/kernel/SysTime.h>
#include <utils/trace/trace.h>
#include <utils/trace/writable.h>
#include <utils/trace/syslogger.h>

#include <string.h>

namespace colib
{

static void xreport_callback(const char* strLog, void* context)
{
	Writable* console = reinterpret_cast<Writable*>(context);

	console->PrintString(strLog);
}

void CommandHeap(void* context, Writable* console, int argc, char* argv[])
{
	//reviewed by Chao Liu, this function has no CSP implications
#ifdef DEBUG_FIND_MEM_LEAK
	static const char* USAGE = "Usage: heap report [{full|mark|bt|start}]\n";
#else
	static const char* USAGE = "Usage: heap report [{full|mark}]\n";
#endif

	(void)context;

	if(argc == 1)
	{
		console->PrintString(USAGE);
		return;
	}

	if(strcmp(argv[1], "report") == 0)
	{


		static unsigned clock = 0;
		if (argc == 3)
		{
		 	if (strcmp(argv[2], "mark") == 0) {clock = iDirect::SysTime::Get();}
		 	else if (strcmp(argv[2], "full") == 0) {xreport(xreport_callback, 0, console);}

#ifdef DEBUG_FIND_MEM_LEAK
			else if (strcmp(argv[2], "bt") == 0) {PrintBT();}
			else if (strcmp(argv[2], "start") == 0) {SetBoolGo();}
#endif

		}
		else xreport(xreport_callback, clock, console);
	}
	else console->PrintString(USAGE);
}

static void xreport_callback_syslog(const char* strLog, void* context)
{
        (void)context;

#ifndef _WIN32
		//static iDirect::SysloggerWritable slogw;
		//slogw.Print("%s", strLog);
		TRACE("%s", strLog);
#else
		TRACE("%s", strLog);
#endif
}

#ifdef __cplusplus
extern "C" {
#endif
extern void xreportsyslog()
{
	xreport(xreport_callback_syslog, 0, 0);
}
#ifdef __cplusplus
}
#endif

}

#endif
