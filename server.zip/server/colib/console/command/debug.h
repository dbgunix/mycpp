#if !defined(__CONSOLE_DEBUG_COMMAND_H__)
#define __CONSOLE_DEBUG_COMMAND_H__

namespace colib
{

class Writable;
class MemberSet;

void HandleDebugCommand(Writable *to, int argc, char *argv[], MemberSet &mset, const char *name);

}

#endif
