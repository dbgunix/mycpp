//options_command.cpp

#if 0

#include<console/command/options_command.h>
//#include<config/params.h>
#include<options/options.h>
#include<options/options_group.h>
#include <stdlib.h>
#include <string.h>

OptionsCommandControlObj::OptionsCommandControlObj()
	:
	m_ctx(0), m_opts(0), m_read_only(true)
{}

void	OptionsCommand(OptionsCommandControlObj *context, Console::Session* console, int argc, char* argv[])
{
	const char* usage =
		"Usage:"
//		"\tflash                      - write to flash (modem only)\n"
//		"\treload                     - refresh with options\n"
		"\tshow [<group>] [<key>]     - display entries\n"
		"\tshowgroups                 - display group names\n";
//		"\tset  <group> <key> <value> - [group] key = value\n"
//		"\tdel  <group> <key>         - remove key from group\n"
//		"\tdel  <group>               - remove entire group\n";

	//reviewed by Chao Liu for FIPS
	if ( !console->CSPEnabled() )
	{
		return;
	}

	colib::Options *options = context->m_opts;
	if ( !options )
	{
		console->Print("Options pointer is NULL!!\n");
		return;
	}

    if ( argc == 1 )
	{
		console->Print(usage);
		return;
	}

	if ( strcmp(argv[1], "flash") == 0 )
	{
		bool disable_flash = false;
		options->GetValue("OPTIONS_FILE", "disable_options_flash_command", disable_flash, false);
		if ( !disable_flash && context->m_on_save.IsSet() )
		{
			//call callback
			context->m_on_save.Dispatch(context, console);
		}
		else
		{
			console->Print("Options flash command is disabled\n");
		}
	}
	else if ( strcmp(argv[1], "reload") == 0 )	// This is hidden console command for safety reason
	{
		if ( context->m_on_refresh.IsSet() )
		{
			//call callback
			context->m_on_refresh.Dispatch(context, console);
		}
		else
		{
			console->Print("No reload action associate with the options\n");
		}
	}
	else if ( ( strcmp(argv[1], "set") == 0 ) && ( argc >= 5 ) )
	{
		if ( context->m_read_only )
		{
			console->Print("Options set command not allowed\n");
		}
		else
		{
			const colib::Group* group = options->GetGroup(argv[2], true);
			colib::string value;
			for ( int index = 4; index < argc; ++index )
			{
				value += argv[index];
				if ( (index + 1) < argc ) value += " ";
			}
			console->Print("key = '%s', value = '%s'\n", argv[3], value.c_str());
			options->Put(group->GetName(), argv[3], value);
		}
	}
	else if ( ( strcmp(argv[1], "del") == 0 ) && ( argc >= 3 ) )
	{
		if ( context->m_read_only )
		{
			console->Print("Options del command not allowed\n");
		}
		else
		{
			const colib::Group* group = options->GetGroup(argv[2]);
			// delete an entire group
			if ( group && ( argc == 3 ) ) options->Remove(argv[2]);
			// delete a key within a group
			else if ( group && ( argc == 4 ) ) options->Remove(argv[2], argv[3]);
			else console->Print("No group \"%s\".\n", argv[2]);
        }
	}
	else if ( strcmp(argv[1], "show") == 0 )
	{
		colib::string output;
		if ( argc == 2 ) output = options->DumpToStr();
		else
		{
			const colib::Group* group = options->GetGroup(argv[2]);
			colib::string  keyname = ( argc >= 4 ) ? argv[3] : "";
			if ( group ) group->DumpToStr(output, keyname);
		}
		if ( output.is_empty() )
			console->Print("Requested info not found!\n");
		else console->Print("%s\n", output.c_str() );
	}
	else if ( strcmp(argv[1], "showgroups") == 0 )
	{
		colib::Dlist<const colib::Group*> list;
		options->RetrieveGroupsIntoDlist(list);
		for ( colib::Dlist<const colib::Group*>::Node* group_node = list.GetHead(); group_node != 0; group_node = list.GetNext(group_node) )
		{
			const colib::Group* group = group_node->GetData();
			console->Print("[%s]\n", group->GetName());
		}
	}
	else console->Print(usage);
}

#endif
