//options_command.hpp

#ifndef COMMAND_OPTIONS_HPP
#define COMMAND_OPTIONS_HPP

#if 0

#include<console/session.h>
#include<utils/callback.h>

namespace colib
{
class Options;
}

class OptionsCommandControlObj
{
	public:
		OptionsCommandControlObj();
		~OptionsCommandControlObj() {};
		void* m_ctx;
		colib::Options* m_opts;
		bool m_read_only;
		Callback2<OptionsCommandControlObj*, Console::Session*>		m_on_save;
		Callback2<OptionsCommandControlObj*, Console::Session*>		m_on_refresh;
};

void OptionsCommand(OptionsCommandControlObj *context, Console::Session* console, int argc, char* argv[]);

#endif

#endif

