#ifndef COMMAND_HEAP_HPP
#define COMMAND_HEAP_HPP

namespace colib
{

#if 0
class Writable;

void CommandHeap(void* context, Writable* console, int argc, char* argv[]);

#ifdef __cplusplus
extern "C" {
#endif
void xreportsyslog();
#ifdef __cplusplus
}
#endif

#endif

}

#endif
