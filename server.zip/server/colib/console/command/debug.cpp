#include<console/command/debug.h>
#include<utils/trace/writable.h>

#include <string.h>
#include <ctype.h>

namespace colib
{

void HandleDebugCommand(Writable *to, int argc, char *argv[], MemberSet &mset, const char *name)
{
	if (!to)
	{
		return;
	}

	const char* debug_usage = "Usage: <debug_command> on|off|<level>\n";
	if (argc < 1)
	{
		to->PrintString(debug_usage);
	}
	else
	{
		int level = 0;
		if (!strcmp(argv[0],"off"))
		{
			to->Print("Disabling %s output\n", name);
			mset.DropWritable(to);
			return;
		}
		else if (!strcmp(argv[0],"on"))
		{
			level = 3;
		}
		else if (isdigit(*argv[0]))
		{
			level = atoi(argv[0]);
		}
		else
		{
			to->PrintString(debug_usage);
			return;
		}
		to->Print("Enabling %s output (DebugLevel:%d)\n", name, level);
		mset.AddWritable(level, to);
	}
}

}
