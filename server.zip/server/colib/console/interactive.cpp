#include<console/interactive.h>
#include<console/session.h>
#include<console/command.h>

#include <string.h>

namespace colib
{
	InteractiveExit::InteractiveExit(ConsoleSession* session, InteractiveShell* shell)
		:
		ConsoleState(session), m_shell(shell)
	{
	};

	InteractiveExit::~InteractiveExit()
	{
	}

	bool			InteractiveExit::Activate()
	{
		bool result = ConsoleState::Activate();
		if ( result ) 
		{
			m_shell->CleanUp();
			ConsoleState::GetSession()->ExitInteractive();
		}
		return result;
	}

	InteractiveShell::~InteractiveShell()
	{
	}

	InteractiveShell::InteractiveShell(ConsoleSession* session, Handler* handler, Releaser* releaser, void* ctx)
		:	
		ConsoleState(session),
		m_handler(handler), m_releaser(releaser), m_ctx(ctx),
		m_shell_prompt(session, false),
		m_shell_exit(session, this)
	{
		ConsoleState::SetSuccess(session ? session->GetState() : 0);			
		m_shell_prompt.SetSuccess(this);
		m_shell_prompt.SetFailure(&m_shell_exit);
	}

	bool			InteractiveShell::Activate()
	{
		bool result = ConsoleState::Activate();
		
		ConsoleSession* session = ConsoleState::GetSession();

		if ( session && result )
		{
			int argc = COMMAND_ARGC_MAX;
			char* argv[COMMAND_ARGC_MAX];
			ConsoleCommand::ParseLine(m_shell_prompt.GetBuffer(), argc, argv);
			result = m_handler(m_ctx, session, &m_shell_prompt, argc, argv);
		
			if ( !result ) session->SetState(&m_shell_exit);
			else session->SetState(&m_shell_prompt);
		}
		
		return result;
	}

	void			InteractiveShell::Deactivate()
	{
	}

	void			InteractiveShell::Reset()
	{
		ConsoleState::Reset();
		m_shell_prompt.Reset();
	}

	unsigned		InteractiveShell::Process(const void* data, unsigned length)
	{
		(void)data;
		(void)length;
		return 0;
	}

	void			InteractiveShell::CleanUp()
	{
		m_releaser(m_ctx);
	}	
}//end namespace colib


