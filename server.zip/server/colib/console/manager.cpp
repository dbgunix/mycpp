#include<console/manager.h>
#include<console/server.h>
#include<console/session.h>

#include <string.h>

namespace colib
{
	ConsoleManager&		ConsoleManager::GetInstance()
	{
		static ConsoleManager _instance;
		return _instance;
	}

	ConsoleManager::~ConsoleManager()
	{
	}

	ConsoleManager::ConsoleManager()
	{
	}

	string				ConsoleManager::GetName() const
	{
		if ( m_name != "" ) return m_name;
		return "console";
	}

	void				ConsoleManager::SetName(string name)
	{
		m_name = name;
	}

	void				ConsoleManager::Register(ConsoleServer* server)
	{
		if ( server ) 
		{
			if ( server->m_node == 0 ) server->m_node = m_servers.Append(server);
			else server->m_node->MoveTo(&m_servers);	
		}
	}

	void			ConsoleManager::Unregister(ConsoleServer* server)
	{
		if ( server ) 
		{
			delete server->m_node;
			server->m_node = 0;
		}
	}

	int				ConsoleManager::Write(const void* buf, unsigned int len)
	{
		for ( ConsoleServer::NODE* node = m_servers.GetHead();
				node != 0; node = m_servers.GetNext(node) )
		{
			ConsoleServer* server = node->GetData();
			if ( server->GetBroadcast() ) server->Write(buf, len);
		}

		return len;
	}

	void			ConsoleManager::PrintStatus(string heading, ConsoleSession* con)
	{
		if ( !con ) return;	
		
		con->Print("%sManager [Broadcast = On]: %s\n", heading.c_str(), GetName().c_str());
	
		for ( ConsoleServer::NODE* node = m_servers.GetHead();
				node != 0; node = m_servers.GetNext(node) )
		{
			node->GetData()->PrintStatus(heading+"\t", con);
		}
	}

	void			ConsoleManager::Command(void* ctx, ConsoleSession* con, int argc, char* argv[])
	{
		(void)ctx;
		if ( !con ) return;
		ConsoleManager&	Manager = ConsoleManager::GetInstance();
		Manager.ProcessConsoleCommand(con, argc-1, argv+1);
	}

	void			ConsoleManager::ProcessConsoleCommand(ConsoleSession* con, int argc, char* argv[])
	{
		if ( !con ) return;

		if ( ( argc > 0 ) && ( strcmp(argv[0], "list") == 0 ) )
		{	
			PrintStatus("", con);
			return;
		}
		
		con->ProcessConsoleCommand(con, argc, argv);
	}

}//end namespace colib

