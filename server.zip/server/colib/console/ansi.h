#ifndef BIOS_ANSI_H
#define BIOS_ANSI_H

#define	ANSI_ESC				"\x1B"
#define	ANSI_END				"\x07"

#define	ANSI_TITLE				"]0;"

#define	ANSI_SCREEN_40x25bw		ANSI_ESC "[=0,7h"
#define	ANSI_SCREEN_40x25co		ANSI_ESC "[=1,7h"
#define	ANSI_SCREEN_80x25bw		ANSI_ESC "[=2,7h"
#define	ANSI_SCREEN_80x25co		ANSI_ESC "[=3,7h"
#define	ANSI_SCREEN_CLEAR		ANSI_ESC "[2J"

#define ANSI_CUH				ANSI_ESC "[0;0H"
#define ANSI_CUU(n)				ANSI_ESC "[" #n "A"
#define ANSI_CUD(n)				ANSI_ESC "[" #n "B"
#define ANSI_CUF(n)				ANSI_ESC "[" #n "C"
#define ANSI_CUB(n)				ANSI_ESC "[" #n "D"
#define	ANSI_SAVE				ANSI_ESC "[s"
#define	ANSI_LOAD				ANSI_ESC "[u"

#ifdef USE_ANSI_COLORS
	#define ANSI_COLOR(s)		ANSI_ESC s
#else
	#define ANSI_COLOR(s)		""
#endif

#define	ANSI_REVERSE			ANSI_COLOR("[7m")
#define	ANSI_RESTORE			ANSI_COLOR("[0m")

#define	ANSI_BG_BLACK			ANSI_COLOR("[40m")
#define	ANSI_BG_RED				ANSI_COLOR("[41m")
#define	ANSI_BG_GREEN			ANSI_COLOR("[42m")
#define	ANSI_BG_YELLOW			ANSI_COLOR("[43m")
#define	ANSI_BG_BLUE			ANSI_COLOR("[44m")
#define	ANSI_BG_MAGENTA			ANSI_COLOR("[45m")
#define	ANSI_BG_CYAN			ANSI_COLOR("[46m")
#define	ANSI_BG_WHITE			ANSI_COLOR("[47m")
#define ANSI_BG_DEFAULT			ANSI_BG_BLACK

#define	ANSI_FG_NORM_BLACK		ANSI_COLOR("[0;30m")
#define	ANSI_FG_NORM_RED		ANSI_COLOR("[0;31m")
#define	ANSI_FG_NORM_GREEN		ANSI_COLOR("[0;32m")
#define	ANSI_FG_NORM_YELLOW		ANSI_COLOR("[0;33m")
#define	ANSI_FG_NORM_BLUE		ANSI_COLOR("[0;34m")
#define	ANSI_FG_NORM_MAGENTA	ANSI_COLOR("[0;35m")
#define	ANSI_FG_NORM_CYAN		ANSI_COLOR("[0;36m")
#define	ANSI_FG_NORM_WHITE		ANSI_COLOR("[0;37m")
#define ANSI_FG_DEFAULT			ANSI_FG_NORM_WHITE

#define	ANSI_FG_BOLD_BLACK		ANSI_COLOR("[1;30m")
#define	ANSI_FG_BOLD_RED		ANSI_COLOR("[1;31m")
#define	ANSI_FG_BOLD_GREEN		ANSI_COLOR("[1;32m")
#define	ANSI_FG_BOLD_YELLOW		ANSI_COLOR("[1;33m")
#define	ANSI_FG_BOLD_BLUE		ANSI_COLOR("[1;34m")
#define	ANSI_FG_BOLD_MAGENTA	ANSI_COLOR("[1;35m")
#define	ANSI_FG_BOLD_CYAN		ANSI_COLOR("[1;36m")
#define	ANSI_FG_BOLD_WHITE		ANSI_COLOR("[1;37m")

#define ANSI_DEFAULT			ANSI_COLOR("[0;37;40m")

#define ANSI_RESET(title)		ANSI_DEFAULT ANSI_CUH ANSI_SCREEN_CLEAR

#endif

