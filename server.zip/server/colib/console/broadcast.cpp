#include<console/broadcast.h>
#include<console/manager.h>
#include<utils/string.h>

namespace colib
{	
	int		ConsoleBroadcast(const char* buf, unsigned int len)
	{
		return ConsoleManager::GetInstance().Write(buf, len);
	}

	int		ConsoleBroadcast(const char* format, va_list args)
	{
		string str = string::vFormat(format, args);
		return ConsoleBroadcast(str.c_str(), str.get_length());
	}

	int		ConsoleBroadcast(const char* format, ...)
	{
		va_list args;
		va_start(args, format);
		int result = ConsoleBroadcast(format, args);
		va_end(args);
		return result;
	}
	
}//end namespace colib

