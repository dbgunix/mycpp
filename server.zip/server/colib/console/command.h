#ifndef CONSOLE_COMMAND_H
#define CONSOLE_COMMAND_H

#include<utils/string.h>
#include<utils/data_struct/dlist.h>
#include <map>

namespace colib
{
	static const int COMMAND_ARGC_MAX = 32;

	extern const char* COMMAND_HELP;
	extern const char* COMMAND_EXIT;
	extern const char* COMMAND_QUIT;

	class ConsoleSession;

	class ConsoleCommand
	{
		public:

			typedef void				Handler(	void*			context,
													ConsoleSession*	session,
													int				argc,
													char*			argv[]);

			static ConsoleCommand*		Register(	unsigned		role,
													Handler*		handler,
													void*			context,
													string			path,
													string			description);

			static bool					Register(	void*			context,
													string			keyword,
													Handler*		handler,
													string			description,
													unsigned		role);

			static bool					Unregister(	string 			path);

			ConsoleCommand*				RegisterSubcmd(
													unsigned		role,
													Handler*		handler,
													string			keyword,
													string			description,
													void*			ctx = 0);

			bool						UnregisterSubcmd(
													string			keyword);

			void						GetAllCommands(Dlist<string> &list);

			void						UnregisterAllCommands();

		public:

			virtual			 			~ConsoleCommand();
										ConsoleCommand();
										ConsoleCommand(const ConsoleCommand&);

			virtual unsigned			GetRole() const;
			virtual void				SetRole(unsigned role);

			virtual string				GetKeyword() const;
			virtual void				SetKeyword(string keyword);

			virtual string				GetDescription() const;
			virtual void				SetDescription(string description);

			virtual void				SetContext(void *ctx);

			virtual void				SetHandler(Handler* handler);
			virtual Handler*			GetHandler();

			virtual void				SetAutoSubDispatch(bool auto_dispatch);

			ConsoleCommand*				SearchCommand(string keyword);

			virtual void				DoDispatch(	unsigned		role,
													ConsoleSession*	session,
													char*			line);

			virtual void				DoDispatch(	unsigned		role,
													ConsoleSession*	session,
													int				argc,
													char*			argv[]);

			static void					ParseLine(char* line, int& argc, char* argv[]);

			bool						DispatchSubcmd(unsigned role, ConsoleSession* session, void *ctx, int argc, char *argv[], bool override_ctx = true);

			void						DoHelp(ConsoleSession *session, const char *filter);

			ConsoleCommand& operator=(const ConsoleCommand&) = delete;

		protected:

			unsigned					m_role;
			Handler*					m_handler;
			void*						m_context;
			string						m_keyword;
			string						m_description;
			bool						m_auto_sub_dispatch;

		private:
			typedef std::map<string, ConsoleCommand>	COMMAND_MAP;
			COMMAND_MAP					m_commands;
	};

	class RootConsoleCommand : public ConsoleCommand
	{
		public:

			static RootConsoleCommand&		GetInstance();
			void							RegisterBuiltinConsoleCommand();

		private:

			virtual							~RootConsoleCommand() {};
											RootConsoleCommand() {};

			virtual void					Initialize();
	};

}//end namespace colib

#endif

