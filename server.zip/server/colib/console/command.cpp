#include<console/command.h>
#include<console/role.h>
#include<console/session.h>
#include<console/manager.h>

#include <string.h>

namespace colib
{
	const char*	COMMAND_HELP = "help";
	const char* COMMAND_EXIT = "exit";
	const char* COMMAND_QUIT = "quit";
		
	static void		sub_dispatch(	void*			context,
									ConsoleSession*	session,
									int				argc,
									char*			argv[])
	{
		ConsoleCommand *command = 0;
		if ( context ) command = static_cast<ConsoleCommand*>(context);

		if ( argc > 1 )
		{
			if ( strcmp(argv[1], COMMAND_HELP) == 0 )
			{
				if ( command )	command->DoHelp(session, argc > 2 ? argv[2] : 0 );
			}
			else session->Print("Unknown Command: '%s'\n", argv[1]);
		}
		else if ( argc == 1 )
		{
			if ( command )	command->DoHelp(session, 0);
		}
	}

	static void		root_dispatch(	void*			context,
									ConsoleSession*	session,
									int				argc,
									char*			argv[])
	{
		if ( argc > 1 )
		{
			if ( 
				( strcmp(argv[1], COMMAND_EXIT) == 0 ) ||
				( strcmp(argv[1], COMMAND_QUIT) == 0 )	
				)
			{
				session->Print("stop console ...\r\n");
				session->StopConsole();
			}
			else sub_dispatch(context, session, argc, argv);
		}
	}

	ConsoleCommand*		ConsoleCommand::Register(	unsigned	role,
													Handler*	handler,
													void*		context,
													string		path,
													string		description)
	{
		ConsoleCommand* parent = &RootConsoleCommand::GetInstance();
	
		char buffer[128];
		strncpy(buffer, path.c_str(), sizeof(buffer)-1);
		char* keyword = buffer;
		char* slash;

		while ( (slash = strstr(keyword, "/")) != 0 )
		{
			*slash = '\0';
			ConsoleCommand* command = parent->SearchCommand(keyword);
			if ( command == 0 ) 
			{
				command = parent->RegisterSubcmd(role, sub_dispatch, keyword, "", 0);
				if ( command )
				{
					command->SetAutoSubDispatch(true);
					command->SetContext(command);
				}
			}
			if ( !command ) return 0;

			// OR in any role flags.
			command->SetRole(command->GetRole() | role);
			parent = command;
			keyword = (slash + 1);
		}

		return parent->RegisterSubcmd(role, handler, keyword, description, context);
	}

	bool				ConsoleCommand::Unregister(string path)
	{	
		ConsoleCommand* parent = &RootConsoleCommand::GetInstance();
		
		char buffer[128];
		strncpy(buffer, path.c_str(), sizeof(buffer)-1);
		char* keyword = buffer;
		char* slash;

		while ( (slash = strstr(keyword, "/")) != 0 )
		{
			*slash = '\0';
			ConsoleCommand* command = parent->SearchCommand(keyword);
			if ( command == 0 ) return false;
			parent = command;
			keyword = (slash + 1);
		}

		return parent->UnregisterSubcmd(keyword);
	}

	ConsoleCommand*		ConsoleCommand::RegisterSubcmd(
										unsigned	role, 
										Handler*	handler,
										string		name, 
										string		description, 
										void*		ctx)
	{
		ConsoleCommand& command = m_commands[name];	// Create if not exist
	
		command.SetRole(role);
		command.SetHandler(handler);
		command.SetKeyword(name);
		command.SetDescription(description);
		command.SetContext(ctx);
	
		return &command;
	}

	bool				ConsoleCommand::UnregisterSubcmd(string keyword)
	{
		m_commands.erase(keyword);
		return true;
	}

	bool				ConsoleCommand::Register(	
										void*		context,
										string		keyword,
										Handler*	handler,
										string		description,
										unsigned	role)
	{
		return ( 0 != Register(role, handler, context, keyword, description) );
	}

	ConsoleCommand::~ConsoleCommand()
	{
	}

	ConsoleCommand::ConsoleCommand()
		:
		m_role(0), m_handler(0), m_context(0), m_auto_sub_dispatch(false)
	{
	}
	
	ConsoleCommand::ConsoleCommand(const ConsoleCommand&)
		:
		m_role(0), m_handler(0), m_context(0), m_auto_sub_dispatch(false)
	{
	}

	unsigned		ConsoleCommand::GetRole() const
	{
		return m_role;
	}

	void			ConsoleCommand::SetRole(unsigned role)
	{
		m_role = role;
	}

	string			ConsoleCommand::GetKeyword() const
	{
		return m_keyword;
	}

	void			ConsoleCommand::SetKeyword(string keyword)
	{
		m_keyword = keyword;
	}

	string			ConsoleCommand::GetDescription() const
	{
		return m_description;
	}

	void			ConsoleCommand::SetDescription(string description)
	{
		m_description = description;
	}
	
	void 			ConsoleCommand::SetContext(void *context)
	{
		m_context = context;
	}

	void			ConsoleCommand::SetHandler(Handler* handler)
	{
		m_handler = handler;
	}

	ConsoleCommand::Handler*	ConsoleCommand::GetHandler()
	{
		return m_handler;
	}

	void			ConsoleCommand::SetAutoSubDispatch(bool auto_sub_dispatch)
	{
		m_auto_sub_dispatch = auto_sub_dispatch;
	}

	ConsoleCommand*	ConsoleCommand::SearchCommand(string keyword)
	{
		COMMAND_MAP::iterator it = m_commands.find(keyword);
		if ( it != m_commands.end() ) return &it->second;
		return 0;
	}

	void			ConsoleCommand::DoDispatch(	
											unsigned		role,
											ConsoleSession*	session,
											char*			line)
	{	
		int argc = COMMAND_ARGC_MAX;
		char* argv[COMMAND_ARGC_MAX];
		ParseLine(line, argc, argv);	
		DoDispatch(role, session, argc, argv); 
	}
		
	void			ConsoleCommand::ParseLine(char* line, int& argc, char* argv[])
	{
		int MAX_TO_PARSE = argc;
			
		argc = 0;
		argv[argc++] = 0;
		char ch = '\0';
		while ((*line != '\0') && (argc < MAX_TO_PARSE))
		{
			switch (*line)
			{
				case ' ':
				case '\t':
				{
					*line = '\0';
					break;
				}
				default:
				{
					if (ch == '\0')
					{
						argv[argc++] = line;
					}
					break;
				}
			}
			ch = *line++;
		}
	}

	void		ConsoleCommand::DoDispatch(	unsigned	role,
											ConsoleSession*	session,
											int			argc,
											char*		argv[])
	{
		if ( m_auto_sub_dispatch &&	DispatchSubcmd(role, session, 0, argc, argv, false) ) return;

		if ( ( m_handler != 0 ) && ConsoleCheckPermission(GetRole(), role) ) m_handler(m_context, session, argc, argv);
	}

	bool		ConsoleCommand::DispatchSubcmd(unsigned role, ConsoleSession* session, void *ctx, int argc, char *argv[], bool override_ctx)
	{
		if ( argc <= 1 ) return false;

		ConsoleCommand* command = SearchCommand(string(argv[1]));
	
		if ( command )
		{
			if ( !ConsoleCheckPermission(command->GetRole(), role) )
			{
				// no permission
				return false;
			}

			if ( command->GetHandler() != 0 )
			{
				// call the subcmd with the overriden context
				if ( override_ctx )	command->m_handler(ctx, session, argc-1, argv+1);
				else command->DoDispatch(role, session, argc-1, argv+1);
				return true;
			}

			return false;
		}
	
		if ( strcmp(argv[1], COMMAND_HELP) == 0 )
		{
			DoHelp(session, argc > 2 ? argv[2] : 0);
			return true;
		}

		return false;
	}

	void			ConsoleCommand::DoHelp(ConsoleSession *session, const char *filter )
	{
		unsigned role = session->GetRole();

		for ( COMMAND_MAP::iterator it = m_commands.begin();
				it != m_commands.end(); ++it )
		{
			ConsoleCommand& command = it->second;
			if ( !ConsoleCheckPermission(command.GetRole(), role) )
			{
				//user does not have perms to "help" this command
				continue;
			}

			if ( !filter ||	( command.GetKeyword() == string(filter) ) )
			{
				session->Print("%-15s %s\r\n", command.GetKeyword().c_str(), command.GetDescription().c_str());
			}
		}
	}


	void 			ConsoleCommand::GetAllCommands(Dlist<string>& list)
	{	
		for ( COMMAND_MAP::iterator it = m_commands.begin();
				it != m_commands.end(); ++it )
		{
			ConsoleCommand& command = it->second;
			list.Append(command.GetKeyword());
		}
	}

	void 			ConsoleCommand::UnregisterAllCommands()
	{
		m_commands.clear();
	}
	
	RootConsoleCommand&		RootConsoleCommand::GetInstance()
	{
		static RootConsoleCommand _instance;
		static bool initialized = false;

		if ( !initialized )
		{	
			_instance.Initialize();
			initialized = true;	
		}

		return _instance;
	}

	void					RootConsoleCommand::Initialize()
	{		
		SetRole(CONSOLE_ROLE_EVERYONE | CONSOLE_ROLE_ERROR_STATE);
		SetHandler(root_dispatch);
		SetContext(0);
		SetAutoSubDispatch(true);
		RegisterBuiltinConsoleCommand();
	}

	void					RootConsoleCommand::RegisterBuiltinConsoleCommand()
	{
		//
		// Register built-in console related command
		//
		RegisterSubcmd(
				CONSOLE_ROLE_EVERYONE,
				ConsoleManager::Command, 
				"console", 
				"Console control",
				0);
		RegisterSubcmd(
				CONSOLE_ROLE_EVERYONE,
				ConsoleSession::CommandXon,
				"xon", 
				"Allow broadcast trace",
				0);
		RegisterSubcmd(
				CONSOLE_ROLE_EVERYONE,
				ConsoleSession::CommandXoff,
				"xoff", 
				"Disallow broadcast trace",
				0);
		RegisterSubcmd(
				CONSOLE_ROLE_EVERYONE,
				ConsoleSession::CommandClear,
				"clear", 
				"Clear screen",
				0);
		RegisterSubcmd(
				CONSOLE_ROLE_EVERYONE,
				ConsolePCmdMgr::Command,
				"pcmd", 
				"Periodic console commands control",
				0);
	}
}//end namespace colib

