#ifndef CONSOLE_LOGIN_H
#define CONSOLE_LOGIN_H

#include<console/prompt.h>
#include<console/session.h>

namespace colib
{
	const unsigned LOGIN_LENGTH = 128;

	class ConsoleLoginShell : public ConsoleState
	{
		public:

			typedef unsigned Callback(
					ConsoleSession*	session,
					const char*	username,
					const char*	password);

		public:

			virtual 			~ConsoleLoginShell();
								ConsoleLoginShell(ConsoleSession* session, Callback* callback = 0);

			virtual bool		Activate();
			virtual void		Deactivate();
			virtual void		Reset();
			virtual void		Zeroize();
			virtual unsigned	Process(const void* data, unsigned length);

		protected:
		
			Callback*			m_callback;

		private:
			
			ConsolePrompt		m_login_prompt;
			unsigned			m_state;
			char				m_username[LOGIN_LENGTH];
			char				m_password[LOGIN_LENGTH];
	};
	
}//end namespace colib

#endif

