#include<console/periodic.h>
#include<console/role.h>
#include<console/command.h>
#include<console/session.h>
#include<utils/system/memory.h>

#include <string.h>
#include <ctype.h>

namespace colib
{
	PCmd::PCmd()
		:
		m_id(0), m_tick(0), m_argc(0), m_session(0),	
		m_timer("PeriodicCommand")
	{
		for ( int i = 0; i < COMMAND_ARGC_MAX; i++ ) m_argv[i] = 0;
	}

	PCmd::PCmd(const PCmd&)
		:
		m_id(0), m_tick(0), m_argc(0), m_session(0),
		m_timer("PeriodicCommand")
	{
		for ( int i = 0; i < COMMAND_ARGC_MAX; i++ ) m_argv[i] = 0;
	}

	PCmd::~PCmd()
	{
		for ( int i = 0; i < COMMAND_ARGC_MAX; i++ )
		{
			if ( m_argv[i] ) xfree(m_argv[i]);
		}
	}

	void				PCmd::Start()
	{
		if ( m_tick ) 
		{
			m_timer.SetExpireCb(callback(this, &PCmd::OnTimeout));
			m_timer.Start(m_tick);
		}
	}
		
	void				PCmd::OnTimeout(unsigned clock, void *data)
	{
		(void)clock; (void)data;
		
		ConsoleSession* con = m_session;
		if ( !m_session ) return;

		con->Print("\r\n\r\n");
		con->PrintTimestamp();

		for ( int i = 1; i < m_argc; i++ )
		{
			con->Print("%s ", m_argv[i]);
		}
		con->Print("\r\n");

		RootConsoleCommand::GetInstance().DoDispatch(con->GetRole(), con, m_argc, m_argv);
	}
		
	void				PCmd::Dump(ConsoleSession* con)
	{
		if ( con )
		{
			con->Print("%2d : \"", m_id);
			for ( int i = 1; i < m_argc; i++ )
			{
				con->Print("%s ", m_argv[i]);
			}
			con->Print("\" every %d msec\r\n", m_tick);
		}
	}
		
	ConsolePCmdMgr::ConsolePCmdMgr(ConsoleSession* session)
		:
		m_session(session)
	{	
		m_index = 0;
	}

	ConsolePCmdMgr::~ConsolePCmdMgr()
	{
		Clear();
	}

	void				ConsolePCmdMgr::Clear()
	{
		m_pcmds.clear();
		m_index = 0;
	}

	bool				ConsolePCmdMgr::AddPeriodicCommand(unsigned interval, int argc, char* argv[])
	{
		PCmd& pcmd = m_pcmds[m_index];	// Create if not exist

		pcmd.m_session	= m_session;
		pcmd.m_id 		= m_index;
		pcmd.m_tick 	= interval;
		pcmd.m_argc		= argc;

		for ( int i = 0; i < argc; i++ )
		{
			pcmd.m_argv[i] = xstrdup(argv[i]);
		}

		m_index++;

		pcmd.Dump(m_session);
		pcmd.Start();

		return true;
	}

	void				ConsolePCmdMgr::DelPeriodicCommand(int id)
	{
		m_pcmds.erase(id);
	}
	
	void				ConsolePCmdMgr::Dump(ConsoleSession* con)
	{
		for ( PCMD_MAP::iterator it = m_pcmds.begin();
				it != m_pcmds.end(); ++it )
		{
			it->second.Dump(con);
		}
	}
	
	void				ConsolePCmdMgr::Command(void *ctx, ConsoleSession* con, int argc, char* argv[])
	{
		(void)ctx;
		if ( !con ) return;
		ConsolePCmdMgr&	pcmd_mgr = con->GetPeriodicCommandMgr();
		pcmd_mgr.ProcessConsoleCommand(con, argc-1, argv+1);
	}

	void				ConsolePCmdMgr::ProcessConsoleCommand(ConsoleSession* con, int argc, char* argv[])
	{
		const char* usage = "usage:\tdump|clear|del [id]| [n mesc] command";
			
		if ( !con ) return;

		if ( argc == 0 )
		{
			con->Print(usage);
			return;
		}		

		if ( strcmp(argv[0], "dump") == 0 ) 
		{
			this->Dump(con);
		}
		else if ( strcmp(argv[0], "del") == 0 )
		{
			if ( argc == 2 && isdigit((int)(*argv[1])) )
			{
				DelPeriodicCommand(atoi(argv[1]));
			}
			else con->Print(usage);
		}
		else if ( strcmp(argv[0], "clear") == 0 )
		{
			Clear();
		}
		else if ( isdigit((int)(*argv[0])) )
		{
			unsigned interval = atoi(argv[0]);
			AddPeriodicCommand(interval, argc, argv);
		}
		else con->Print(usage);
	}

}//end namespace colib

