#ifndef CONSOLE_MANAGER_H
#define CONSOLE_MANAGER_H

#include<utils/string.h>
#include<utils/trace/writable.h>
#include<utils/data_struct/dlist.h>

namespace colib
{
	class ConsoleServer;

	class ConsoleSession;

	class ConsoleManager : public Writable
	{
		public:

			typedef Dlist<ConsoleServer*>	LIST;

		public:

			static ConsoleManager&			GetInstance();	

			virtual string					GetName() const;
			virtual void					SetName(string name);

			virtual void					Register(ConsoleServer* server);
			virtual void					Unregister(ConsoleServer* server);

			virtual int						Write(const void* buf, unsigned int len);

			static void						Command(void* ctx, ConsoleSession* con, int argc, char* argv[]);
			void							ProcessConsoleCommand(ConsoleSession* con, int argc, char* argv[]);
			void							PrintStatus(string heading, ConsoleSession* con);

		private:	

			virtual 						~ConsoleManager();
											ConsoleManager();

		private:

			string							m_name;
			LIST							m_servers;
	};

}//end namespace colib

#endif

