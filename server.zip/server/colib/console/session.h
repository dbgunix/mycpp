#ifndef CONSOLE_SESSION_H
#define CONSOLE_SESSION_H

#include<utils/trace/writable.h>
#include<utils/data_struct/dlist.h>
#include<console/server.h>
#include<console/state.h>
#include<console/periodic.h>
#include<console/interactive.h>
#include<utils/reg_exp.h>

#include <map>

namespace colib
{
	class ConsoleSession : public Writable
	{
		public:

			typedef Dlist<ConsoleSession*>::Node	NODE;

			typedef std::map<string, unsigned>		Variable_MAP;

		public:

			virtual 					~ConsoleSession();
										ConsoleSession(ConsoleServer* server);

			virtual string				GetName() = 0;
			virtual bool				IsProxyAccess () { return false; }

			virtual string				Prompt();
			virtual void				SetPrompt(string prompt);

			virtual ConsoleServer*		GetServer() const;

			virtual ConsoleState*		GetState() const;
			virtual void				SetState(ConsoleState* state);

			virtual unsigned			GetRole() const;
			virtual void				SetRole(unsigned value);

			virtual bool				GetBroadcast() const;
			virtual void				SetBroadcast(bool value);

			virtual void				DisableBroadcast(bool value);
			virtual void				RelayBroadcast(const void *buf, unsigned int len);

			virtual bool				StartConsole() = 0;
			virtual void				StopConsole() = 0;
			virtual void				ResetConsole();

			virtual bool				IsTrusted() = 0;

			virtual unsigned&			Variable(string name);

			virtual unsigned			Process(const void* data, unsigned length);

			virtual void 				SetGrepString(const char* str);
			virtual int					vPrint(const char* fmt, va_list args);
			virtual int					PrintString(const char* buf);

			virtual bool				BestMatch(string &buffer, string &help);
			virtual void				GetSupportCommands(Dlist<string>& list);

			void						SetSupportCommandsQueryCbk(const Callback1<Dlist<string>&> cbk) { m_support_commands_query_cbk = cbk; }
			void						RootConsoleSupportedCommands(Dlist<string>& list);

			virtual void				PrintTimestamp();
			virtual void				EnableConsoleTimestamp(bool value);

			virtual void				ClearScreen() = 0;

			virtual void				EnterInteractive(InteractiveShell::Handler* handler, InteractiveShell::Releaser* releaser, void* ctx=0);
			virtual void				ExitInteractive();

			ConsolePCmdMgr&				GetPeriodicCommandMgr();

			bool						CSPEnabled();
			void						SetCSPStatus(bool status);
			void						DisplayCSPStatus();

			void						ProcessConsoleCommand(ConsoleSession* con, int argc, char* argv[]);
			void						PrintStatus(string heading, ConsoleSession* con);
			//
			// Built-in Console Command
			//
			static void					CommandXon(void* context, ConsoleSession* con, int argc, char* argv[]);
			static void					CommandXoff(void* context, ConsoleSession* con, int argc, char* argv[]);
			static void					CommandClear(void* context, ConsoleSession* con, int argc, char* argv[]);
			static void					CommandCSP(void* context, ConsoleSession* con, int argc, char* argv[]);

		protected:

			virtual void				SetCustomizedPrompt(string prompt);

		protected:

			ConsoleServer*				m_server;
			ConsoleState*				m_state;
			unsigned					m_role;
			bool						m_broadcast;
			bool						m_disable_broadcast;
			bool						m_print_timestamp;

			Callback1<Dlist<string>&>	m_support_commands_query_cbk;

		protected:

			long						m_clock;
			long						m_csp_enabled_clock;

		private:

			unsigned					Filter(const void* data, unsigned length);

			char						m_filter[4];
			unsigned					m_length;

			Variable_MAP				m_variable_map;

		private:

			NODE*						m_node;

			Regex						m_grep_str;
			string						m_cache_waiting_linefeed;

			string						m_prompt;
			string						m_customized_prompt;

			ConsolePCmdMgr				m_pcommand_mgr;

			InteractiveShell*			m_interactive_shell;

		friend class ConsoleServer;
	};

}//end namespace colib

#endif

