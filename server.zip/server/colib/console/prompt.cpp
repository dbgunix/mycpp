#include<console/prompt.h>
#include<console/session.h>

#include <string.h>

namespace colib
{
	const char CHAR_NULL	= 0x00;
	const char CHAR_BS		= 0x08;
	const char CHAR_TAB		= 0x09;
	const char CHAR_LF		= 0x0A;
	const char CHAR_CR		= 0x0D;
	const char CHAR_SP		= 0x20;
	const char CTRL_C		= 0x03;
	const char CTRL_N		= 0x0E;
	const char CTRL_P		= 0x10;
	const char CTRL_B		= 0x02;
	const char CTRL_F		= 0x06;
	const char CTRL_R		= 0x12;
	const char CTRL_S		= 0x13;
	const char CTRL_D		= 0x04;
	const char CHAR_DEL		= 0x7F;
	const char BACKSPACE[]	= {CHAR_BS, CHAR_SP, CHAR_BS};
	int BACKSPACE_LEN		= sizeof(BACKSPACE);

	ConsolePrompt::~ConsolePrompt()
	{
		ZeroizeBuffer();
	}

	ConsolePrompt::ConsolePrompt(ConsoleSession* session, bool history_flag)
		:	
		ConsoleState(session),
		m_echo('\0'), m_enter('\0'), 
		m_index(0),
		m_history_flag(history_flag), m_history_max(DEFAULT_HISTORY_MAX)
	{
		m_buffer[0] = '\0';
		m_buffer_offset = 0;
		m_emptystr_flag = false;
		m_prev_data = CHAR_NULL;
		m_history_index = 0;
	}
	
	int			ConsolePrompt::Write(const char* data, int len)
	{
		if ( GetSession() ) return GetSession()->Write(data, len);
		return 0;
	}
		
	string		ConsolePrompt::GetPrompt() const
	{
		return m_prompt;
	}

	void		ConsolePrompt::SetPrompt(string value)
	{
		m_prompt = value;
	}

	char		ConsolePrompt::GetEcho() const
	{
		return m_echo;
	}

	void		ConsolePrompt::SetEcho(char value)
	{
		m_echo = value;
	}

	bool		ConsolePrompt::Activate()
	{
		bool result = ConsoleState::Activate();

		if ( result )
		{
			m_buffer_offset = 0;
			this->Write(m_prompt.c_str(), m_prompt.get_length());
			m_buffer[m_index = 0] = '\0';
		}
			
		return result;
	}

	void		ConsolePrompt::Deactivate()
	{
	}

	void		ConsolePrompt::ZeroizeBuffer()
	{
		memset(m_buffer, 0, sizeof(m_buffer)); 
		m_index = 0;
	}

	void		ConsolePrompt::Reset()
	{
		m_command_history.clear();
		m_history_index = 0;
		m_buffer[m_index = 0] = '\0';
	}

	void		ConsolePrompt::EchoBuffer(int start, int end, bool wrap_back)
	{
		int start_idx = ( start > 0 ? start : 0 );
		int end_idx = ( end < (int)strlen(m_buffer) ? end : strlen(m_buffer) );
		for ( int i = start_idx; i <= end_idx; i++ )
		{
			if ( m_buffer[i] )
			{
				char ECHO[] = {(m_echo ? m_echo : m_buffer[i])};
				this->Write(ECHO, 1);
			}
		}
		if ( wrap_back )
		{
			char ECHO[] = {CHAR_BS};
			for ( int i = start_idx; i <= end_idx; i++ )
			{
				if ( m_buffer[i] ) this->Write(ECHO, 1);
			}
		}
	}
		
	void		ConsolePrompt::EraseChar()
	{
		if ( m_index > 0)
		{
			char ECHO[] = {CHAR_BS};
			this->Write(ECHO, 1);
			for ( int i = m_index; i <= (int)strlen(m_buffer); i++ )
			{
				char ECHO[] = {(m_buffer[i] ? (m_echo ? m_echo : m_buffer[i]) : CHAR_SP)};
				this->Write(ECHO, 1);
				m_buffer[i-1] = m_buffer[i];
			}
			m_index--;
			for ( int i = m_index; i <= (int)strlen(m_buffer); i++ )
			{
				char ECHO[] = {CHAR_BS};
				this->Write(ECHO, 1);
			}
		}
	}

	void		ConsolePrompt::EraseLine()
	{
		m_index = strlen(m_buffer);
		while ( m_index > 0 ) EraseChar();
	}

	void		ConsolePrompt::PrintLine(string str)
	{
		m_index = str.get_length();
		memcpy(m_buffer, str.c_str(), m_index);
		m_buffer[m_index] = '\0';
		this->Write(m_buffer, m_index);
	}

	void		ConsolePrompt::History(string str)
	{
		m_history_index = 0;

		if ( str == "" ) return;
		if ( m_command_history.size() && ( m_command_history[0] == str ) ) return;
		if ( m_command_history.size() == m_history_max ) m_command_history.pop_back();
		m_command_history.insert(m_command_history.begin(), str);
	}

	unsigned	ConsolePrompt::Process(const void* data, unsigned length)
	{
		static const char NEWLINE[]		= {CHAR_CR, CHAR_LF};

		(void)length;
		unsigned result = 1;

		switch (*(char*)data)
		{
			case CHAR_NULL: break;
			case CHAR_DEL:
			case CHAR_BS:
			{
				EraseChar();
				break;
			}
			case CHAR_TAB:
			{
				string buffer = m_buffer;					
				string help;					
				ConsoleSession* session = GetSession();

				if ( session )
				{
					if ( session->BestMatch(buffer, help) )
					{
						if ( buffer.get_length() < CONSOLE_CMD_LEN_MAX )
						{
							EraseLine();
					
							PrintLine(buffer.c_str());
						}
					}
					else if ( !help.is_empty() )
					{
						this->Write(NEWLINE, sizeof(NEWLINE));

						this->Write(help.c_str(), help.get_length());

						this->Write(NEWLINE, sizeof(NEWLINE));
							
						static const char* prompt = "> ";
							
						this->Write(prompt, strlen(prompt));
							
						PrintLine(buffer);
					}
				}
				break;
			}
			case CTRL_P:
			{
				if ( m_history_index < m_command_history.size() )
				{
					unsigned index = m_history_index;

					//
					// Comments by Hao:
					//     All those m_prev_data, m_emptystr_flag etc code is a mess to me
					//     However, I have no time to clean them up. 
					//
					if ( ( m_prev_data == CTRL_P ) || (( m_prev_data == CTRL_N ) && !m_emptystr_flag ) )
					{
						++index;
						if ( index == m_command_history.size() ) index--;
					}

					//read the value from the history
					string command = m_command_history[index];
					if ( command != "" )
					{
						EraseLine();
						PrintLine(command);
						m_history_index = index;
						m_emptystr_flag = false;
					}
					m_prev_data = CTRL_P;
				}
				break;
			}
			case CTRL_N:
			{
				if ( m_history_index > 0 )
				{
					unsigned index = m_history_index;
					string command = m_command_history[--index];
					if ( command != "" )
					{
						EraseLine();
						PrintLine(command);
						m_history_index = index;
					}
				}
				else
				{
					EraseLine();
					PrintLine("");
					m_emptystr_flag = true;
				}
				m_prev_data = CTRL_N;
				break;
			}
			case CTRL_C:
			{
				m_history_index = 0;
				m_buffer[m_index = 0] = '\0';
				this->Write(NEWLINE, sizeof(NEWLINE));
				m_session->SetState(m_failure);
				m_prev_data = CHAR_NULL;
				break;
			}
			case CHAR_LF:
			case CHAR_CR:
			{
				if ( (m_enter != CHAR_LF) && (m_enter != CHAR_CR) )
				{
					m_enter = *(char*)data;
				}
				if ( m_enter == *(char*)data )						
				{
					if ( m_history_flag ) History(string(m_buffer));

					if ( m_echo == '*' )
					{	
						//
						// More security: round to nearest power of 2 if echo is "*" 
						//
						unsigned int len = strlen(m_buffer);	
						len--;
						len |= len >> 1;
						len |= len >> 2;
						len |= len >> 4;
						len |= len >> 8;
						len |= len >> 16;
						len++;
						unsigned n = len - strlen(m_buffer);
						while ( n )
						{
							char ECHO[] = {m_echo};
							m_session->Write(ECHO, 1);
							n--;
						}
					}
					this->Write(NEWLINE, sizeof(NEWLINE));
					m_session->SetState(m_success);
				}
				m_prev_data = CHAR_NULL;
				break;
			}
			case CTRL_B:
			{
				if ( m_index > 0 ) 
				{
					char ECHO[] = {CHAR_BS};
					this->Write(ECHO, 1);
					m_index--;
				}
				break;
			}
			case CTRL_F:
			{
				if ( m_index < strlen(m_buffer) ) 
				{
					EchoBuffer(m_index, m_index, false);
					m_index++;
				}
				break;
			}
			case CTRL_R:
			{
				char ECHO[] = {CHAR_BS};
				while ( m_index > 0 )
				{
					this->Write(ECHO, 1);
					m_index--;
				}
				break;
			}
			case CTRL_S:
			{
				while ( m_index < strlen(m_buffer) )
				{
					EchoBuffer(m_index, m_index, false);
					m_index++;
				}
				break;
			}
			case CTRL_D:
			{
				if ( m_index < strlen(m_buffer) )
				{
					for (int i = m_index; i < (int)strlen(m_buffer); i++)
					{
						char ECHO[] = {CHAR_SP};
						this->Write(ECHO, 1);
						m_buffer[i] = m_buffer[i+1];
					}
					char ECHO[] = {CHAR_BS};
					this->Write(ECHO, 1);
					for ( int i = (int)strlen(m_buffer); i > (int)m_index; i-- )
					{
						char ECHO[] = {CHAR_BS, (m_echo ? m_echo : m_buffer[i-1]), CHAR_BS };
						this->Write(ECHO, sizeof(ECHO));
					}
				}
				break;
			}
			default:
			{
				if ( ( strlen(m_buffer) + 1 ) < CONSOLE_CMD_LEN_MAX )
				{	
					for ( int i = strlen(m_buffer); i >= (int)m_index; i-- )
					{
						m_buffer[i+1] = m_buffer[i];
					}
					m_buffer[m_index] =*(char*)data;
					char ECHO[] = {(m_echo ? m_echo : m_buffer[m_index])};
					this->Write(ECHO, 1);
					m_index++;
					EchoBuffer(m_index, strlen(m_buffer), true);
				}
			}
		}

		return result;
	}

	void		ConsolePrompt::ResetBuffer(void)
	{
		m_buffer[m_index = 0] = '\0';
	}
	
	unsigned&	ConsolePrompt::HistoryMax()
	{
		return m_history_max;
	}

	void		ConsolePrompt::OffsetBuffer(int offset)
	{
		m_buffer_offset = offset;
	}

	char*		ConsolePrompt::GetBuffer()
	{
		return m_buffer + m_buffer_offset;
	}

	DumbConsolePrompt::DumbConsolePrompt(ConsoleSession* session)
		:
		ConsolePrompt(session, false)
	{
	}

	DumbConsolePrompt::~DumbConsolePrompt()	
	{
	}

	unsigned	DumbConsolePrompt::Process(const void* data, unsigned length)
	{
		(void)length;
	
		switch (*(char*)data )
		{
			case CHAR_CR:
			{
				m_session->SetState(m_success);
				break;
			}
			default:
			{
				if ( ( strlen(m_buffer) + 1 ) < CONSOLE_CMD_LEN_MAX )
				{
					m_buffer[m_index] = *(char*)data;
					m_index++;
					m_buffer[m_index] = '\0';
				}
			}
		}

		return 1;
	}

}//end namespace colib

