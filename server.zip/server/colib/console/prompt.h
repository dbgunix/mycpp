#ifndef CONSOLE_PROMPT_H
#define CONSOLE_PROMPT_H

#include<console/state.h>
#include<utils/string.h>

#include <vector>

using std::vector;

namespace colib
{
	const unsigned CONSOLE_CMD_LEN_MAX	=	4096;
	const unsigned DEFAULT_HISTORY_MAX	=	32;

	extern const char CHAR_NULL;
	extern const char CHAR_BS;
	extern const char CHAR_TAB;
	extern const char CHAR_LF;
	extern const char CHAR_CR;
	extern const char CHAR_SP;
	extern const char CTRL_C;
	extern const char CTRL_N;
	extern const char CTRL_P;
	extern const char CTRL_B;
	extern const char CTRL_F;
	extern const char CTRL_R;
	extern const char CTRL_S;
	extern const char CTRL_D;
	extern const char CHAR_DEL;

	extern const char BACKSPACE[];
	extern int BACKSPACE_LEN;

	class ConsolePrompt : public ConsoleState
	{
		public:

			virtual 				~ConsolePrompt();
									ConsolePrompt(ConsoleSession* session, bool history_flag);

			virtual string			GetPrompt() const;
			virtual void			SetPrompt(string value);

			virtual char			GetEcho() const;
			virtual void			SetEcho(char value);

			virtual bool			Activate();
			virtual void			Deactivate();
			virtual void			Reset();
				
			virtual unsigned		Process(const void* data, unsigned length);
				
			virtual void			ResetBuffer();
			virtual unsigned&		HistoryMax();
			virtual void			ZeroizeBuffer();
	
			char*					GetBuffer();
			void					OffsetBuffer(int offset);

		protected:

			virtual void			EraseChar();
			virtual void			EraseLine();

			virtual void			PrintLine(string str);
			virtual void			History(string str);

			virtual int				Write(const char* data, int len);

			string					m_prompt;
			char					m_echo;
			char					m_enter;
	
			char					m_buffer[CONSOLE_CMD_LEN_MAX];
			unsigned				m_buffer_offset;
			unsigned				m_index;

			std::vector<string>		m_command_history;
			unsigned				m_history_index;
			bool					m_history_flag;
			unsigned				m_history_max;
			
			bool					m_emptystr_flag;
			char					m_prev_data;
				
		private:

			virtual void			EchoBuffer(int start, int end, bool wrap_back);	
	};
	
	class DumbConsolePrompt : public ConsolePrompt
	{
		public:

									DumbConsolePrompt(ConsoleSession* session);
			virtual					~DumbConsolePrompt();						
	
			virtual unsigned		Process(const void* data, unsigned length);
	};

}//end namespace colib

#endif

