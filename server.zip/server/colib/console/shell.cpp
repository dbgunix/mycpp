#include<console/shell.h>
#include<console/ansi.h>
#include<console/role.h>
#include<console/command.h>
#include<console/session.h>

#include <string.h>
#include <stdio.h>

namespace colib
{
	ConsoleShell::~ConsoleShell()
	{
	}

	ConsoleShell::ConsoleShell(ConsoleSession* session)
		:
		ConsoleState(session),
		m_shell_prompt(session, true)
	{
		m_dispatch = false;
		m_shell_prompt.SetSuccess(this);
		m_shell_prompt.SetFailure(this);
	}

	char*		ConsoleShell::GetGrepStr(char* buf)
	{
		char* str = 0;
		char* p = strchr(buf, '|');
		if ( p )
		{
			*p = '\0';
			p++;
			p = strstr(p, "grep");
			if ( p )
			{
				p += 4;
				char* left = strchr(p, '<');
				char* right = strchr(p, '>');
				if ( left && right && ( left < right ) )
				{
					str = left+1;
					*right = '\0';
				}
				else
				{
					str = strtok(p, " ");
				}
			}
		}
		return str;
	}

	bool		ConsoleShell::Activate()
	{
		bool result = ConsoleState::Activate();

		if ( result )
		{
			ConsoleSession* session = GetSession();
			char* buffer = ShellPrompt()->GetBuffer();

			if ( m_dispatch && strlen(buffer) )
			{
				char* grep = GetGrepStr(buffer);
				if ( session )
				{
					session->SetGrepString(grep);
					RootConsoleCommand::GetInstance().DoDispatch(
							session->GetRole(),
							session,
							buffer);
				}
			}
			m_dispatch = (session->GetState() == this);
			if ( m_dispatch )
			{
				char prompt[128];
				snprintf(prompt, sizeof(prompt)-1,
						"\r\n" ANSI_FG_NORM_GREEN "%s" ANSI_DEFAULT "\r\n> ",
						m_session->Prompt().c_str());
				ShellPrompt()->SetPrompt(string(prompt));
				ShellPrompt()->SetEcho('\0');
				session->SetState(ShellPrompt());
			}
		}
		return result;
	}

	void		ConsoleShell::Deactivate()
	{
	}

	void		ConsoleShell::Reset()
	{
		ConsoleState::Reset();
		ShellPrompt()->Reset();
		m_dispatch = false;
	}

	void		ConsoleShell::EnableDispatch()
	{
		m_dispatch = true;
	}

	unsigned	ConsoleShell::Process(const void* data, unsigned length)
	{
		(void)data;
		(void)length;
		return 0;
	}

	InternalConsoleShell::~InternalConsoleShell()
	{
	}

	InternalConsoleShell::InternalConsoleShell(ConsoleSession* session)
		:
		ConsoleShell(session),
		m_internal_shell_prompt(session)
	{
		m_internal_shell_prompt.SetSuccess(this);
		m_internal_shell_prompt.SetFailure(this);
	}

}//end namespace colib


