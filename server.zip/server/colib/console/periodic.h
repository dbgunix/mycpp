#ifndef CONSOLE_PERIODIC_H
#define CONSOLE_PERIODIC_H

#include<console/command.h>
#include<timer/periodic_timer.h>

#include <map>

namespace colib
{
	class ConsoleSession;
	class ConsolePCmdMgr;

	class PCmd
	{
		public:

			virtual				~PCmd();
								PCmd();
								PCmd(const PCmd&);

			void				Start();
			void				Dump(ConsoleSession* session);
			void				OnTimeout(unsigned clock, void *data);

		protected:

			int					m_id;
			int					m_tick;
			int					m_argc;
			char*				m_argv[COMMAND_ARGC_MAX];
			ConsoleSession*		m_session;

		private:
			
			PeriodicTimer		m_timer;

		friend class ConsolePCmdMgr;
	};

	typedef std::map<unsigned, PCmd>	PCMD_MAP;

	class ConsolePCmdMgr
	{
		public:
	
			virtual				~ConsolePCmdMgr();
								ConsolePCmdMgr(ConsoleSession* session);

			bool				AddPeriodicCommand(unsigned interval, int argc, char* argv[]);
			void				DelPeriodicCommand(int id);
		
			void				Dump(ConsoleSession* con);
			void				Clear();

			static void			Command(void* ctx, ConsoleSession* con, int argc, char* argv[]);
			void 				ProcessConsoleCommand(ConsoleSession *con, int argc, char* argv[]);
				
		private:

			ConsoleSession*		m_session;
			PCMD_MAP			m_pcmds;
			unsigned short		m_index;
	};			

}//end namespace colib

#endif

