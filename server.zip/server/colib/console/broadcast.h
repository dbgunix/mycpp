#ifndef CONSOLE_BROADCAST_H
#define CONSOLE_BROADCAST_H

#include <stdarg.h>

#ifdef __GNUC__
#define PRINT_STYLE __attribute__ ((format (printf, 1, 2)))
#else
#define PRINT_STYLE
#endif

namespace colib
{
	int		ConsoleBroadcast(const char* buf, unsigned int len);
	int 	ConsoleBroadcast(const char* format, ...) PRINT_STYLE;
	int 	ConsoleBroadcast(const char* format, va_list args );
}//end namespace colib

#endif

