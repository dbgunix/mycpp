#ifndef CONSOLE_TELNET_H
#define CONSOLE_TELNET_H

#include<console/session.h>
#include<console/login.h>
#include<console/shell.h>

namespace colib
{
	class ConsoleTelnet : public ConsoleSession
	{
		public:

			virtual 				~ConsoleTelnet();
									ConsoleTelnet(ConsoleServer* server, ConsoleLoginShell::Callback* callback = 0);

			virtual string			GetName() { return "telnet"; }
			virtual bool			IsTrusted() { return false; }

			virtual bool			StartConsole();
			virtual void			StopConsole();
			virtual void			ResetConsole();
			virtual void			ClearScreen();

			ConsoleShell*			TelnetShell() { return &m_shell; }
			ConsoleState*			LeaveState() { return &m_leave; }

		protected:

			virtual unsigned		Process(const void* data, unsigned length);
			virtual int				Send(unsigned char cmd, unsigned char opt);

			ConsoleLoginShell		m_login;
			ConsoleShell			m_shell;
			ConsoleState			m_leave;

		private:

			unsigned char			m_cmd_buffer[3];
			unsigned char			m_cmd_length;
	};

}//end namespace colib

#endif

