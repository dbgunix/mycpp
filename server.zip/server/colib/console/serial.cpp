#include<console/serial.h>
#include<console/role.h>

namespace colib
{
	ConsoleSerial::~ConsoleSerial()
	{
	}

	ConsoleSerial::ConsoleSerial(ConsoleServer* server, ConsoleLoginShell::Callback* callback)
		:	
		ConsoleSession(server),
		m_enter(this),
		m_login(this, callback),
		m_shell(this)
	{
		m_enter.SetSuccess(&m_login);
		m_enter.SetFailure(&m_login);

		m_login.SetSuccess(&m_shell);
		m_login.SetFailure(&m_login);

		m_shell.SetSuccess(&m_login);
		m_shell.SetFailure(&m_login);
	}

	bool		ConsoleSerial::StartConsole()
	{
		m_enter.Reset();
		m_login.Reset();
		m_shell.Reset();

		SetState(&m_enter);

		return true;
	}

	void		ConsoleSerial::StopConsole()
	{
		m_login.Reset();
		m_shell.Reset();

		SetState(&m_login);
	}

	void		ConsoleSerial::ResetConsole()
	{
		ConsoleSession::ResetConsole();

		m_enter.Reset();
		m_login.Reset();
		m_shell.Reset();
	}

	
}//end namespace colib

