#ifndef CONSOLE_SERVER_H
#define CONSOLE_SERVER_H

#include<utils/trace/writable.h>
#include<utils/data_struct/dlist.h>
#include<utils/string.h>

namespace colib
{
	class ConsoleManager;
	class ConsoleSession;

	class ConsoleServer : public Writable
	{
		public:

			typedef Dlist<ConsoleServer*>::Node		NODE;
			typedef Dlist<ConsoleSession*>			LIST;

		public:

			virtual 				~ConsoleServer();
									ConsoleServer();

			virtual string			GetName() const;
			virtual string			GetType() const = 0;

			virtual bool			GetBroadcast();
			virtual void			SetBroadcast(bool value);

			virtual void			Register(ConsoleSession* session);
			virtual void			Unregister(ConsoleSession* session);

			virtual int				Write(const void* buf, unsigned int len);

			void					PrintStatus(string heading, ConsoleSession* con);

			ConsoleServer(const ConsoleServer&) = delete;
			ConsoleServer& operator=(const ConsoleServer&) = delete;

		protected:

			bool					m_broadcast;

		private:

			NODE*					m_node;
			LIST					m_sessions;

		friend class ConsoleManager;
	};

}//end namespace colib

#endif

