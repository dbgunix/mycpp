#include<console/session.h>
#include<console/role.h>
#include<console/command.h>
#include<utils/kernel/SysTime.h>
#include<config/fips.h>

namespace colib
{	

	static const unsigned CONSOLE_SESSION_TIMEOUT = ( 15 * 60 * 1000 );
	static const unsigned CSP_CONSOLE_SESSION_TIMEOUT = ( 15 * 60 * 1000 );
	static const char CONSOLE_CSP_VAR_NAME[] = "CSP_ENABLED";
	
	ConsoleSession::~ConsoleSession(void)
	{
		//
		// delete m_node will automatically be removed from ConsoleServer
		//
		if ( m_node ) delete m_node;
	}

	ConsoleSession::ConsoleSession(ConsoleServer* server)
		:
		m_server(server), m_state(0), m_role(CONSOLE_ROLE_DEFAULT),
		m_broadcast(false), m_disable_broadcast(true), m_print_timestamp(false),
		m_node(0), m_pcommand_mgr(this), m_interactive_shell(0)
	{
		m_length = 0;
		m_clock = 0;
		m_csp_enabled_clock = 0;
		if ( m_server != 0 ) m_server->Register(this);
		SetSupportCommandsQueryCbk(callback(this, &ConsoleSession::RootConsoleSupportedCommands));
	}
	
	//
	// ConsoleSession Prompt are composed as
	// [ServerName] Role@SessionName+MyPrompt
	// Note: ConsoleSession derived class will set/change name
	//
	string					ConsoleSession::Prompt()
	{
		if ( m_customized_prompt != "" ) return m_customized_prompt + m_prompt;

		string role_name = ConsoleRoleToName(m_role);

		return string::Format("[%s] %s@%s%s", 
				( m_server != 0 ) ? m_server->GetName().c_str() : "session",
 				( role_name != "" ) ? role_name.c_str() : "unknown",
 				GetName().c_str(), m_prompt.c_str());
	}
	
	void					ConsoleSession::SetPrompt(string prompt)
	{
		m_prompt = prompt;
	}

	void					ConsoleSession::SetCustomizedPrompt(string prompt)
	{
		m_customized_prompt = prompt;
	}

	ConsoleServer*			ConsoleSession::GetServer() const
	{
		return m_server;
	}

	ConsoleState*			ConsoleSession::GetState() const
	{
		return m_state;
	}

	void					ConsoleSession::SetState(ConsoleState* state)
	{
		if ( m_state != 0 ) m_state->Deactivate();
		m_state = state;
		if ( m_state != 0 ) m_state->Activate();
	}

	unsigned				ConsoleSession::GetRole() const
	{
		return m_role;
	}

	void					ConsoleSession::SetRole(unsigned value)
	{
		m_role = value;
	}

	bool					ConsoleSession::GetBroadcast() const
	{
		return m_broadcast;
	}

	void					ConsoleSession::SetBroadcast(bool value)
	{
		m_broadcast = value;
	}

	void					ConsoleSession::DisableBroadcast(bool value)
	{
		m_disable_broadcast = value;
	}
		
	void					ConsoleSession::RelayBroadcast(const void *buf, unsigned int len)
	{
		if ( m_disable_broadcast ) return;
		if ( m_print_timestamp ) PrintTimestamp();
		Write(buf, len);
	}

	unsigned&				ConsoleSession::Variable(string name)
	{	
		return m_variable_map[name];
	}

	void					ConsoleSession::ResetConsole()
	{
		m_variable_map.clear();
	}

	unsigned				ConsoleSession::Process(const void* data, unsigned length)
	{
		if ( colib::InFipsMode() )
		{
			bool timeout = false;

			unsigned clock = colib::SysTime::Get();
			if ( m_clock != 0 ) timeout = ( ( clock - m_clock ) >= CONSOLE_SESSION_TIMEOUT );
			m_clock = clock;

			unsigned& csp_status = Variable(CONSOLE_CSP_VAR_NAME);
			if ( ( csp_status == 1 ) && ( ( clock - m_csp_enabled_clock ) >= CSP_CONSOLE_SESSION_TIMEOUT ) )
			{
				csp_status = 0;
				m_csp_enabled_clock = 0;
			}
	
			if ( timeout )
			{
				m_clock = 0;
				StopConsole();
				return length;
			}
		}

		return ( m_state != 0 ) ? Filter(data, length) : 0;
	}

	unsigned				ConsoleSession::Filter(const void* data, unsigned length)
	{
		(void)length;

		// NOTE: The best solution is to detect terminal type and doing 
		// corresponding filtering. Currently for the simplicity, support
		// gnome, xterm, hyper-terminal, rxvt
		static const char FILTER[]				= {0x1B, '\0'};
		static const char FILTER_ARROW[]   		= {0x1B, '[', '\0'};
		static const char FILTER_GNOME[]		= {0x1B, 'O', '\0'};
			
		static const char FILTER_1[]			= {0x1B, '[', '1', '\0'};
		static const char FILTER_3[]			= {0x1B, '[', '3', '\0'};
		static const char FILTER_4[]			= {0x1B, '[', '4', '\0'};
		static const char FILTER_7[]			= {0x1B, '[', '7', '\0'};
		static const char FILTER_8[]			= {0x1B, '[', '8', '\0'};
			
		static const char FILTER_UP_ARROW[]		= {0x1B, '[', 'A', '\0'};
		static const char FILTER_DN_ARROW[]		= {0x1B, '[', 'B', '\0'};
		static const char FILTER_RG_ARROW[]		= {0x1B, '[', 'C', '\0'};
		static const char FILTER_LF_ARROW[] 	= {0x1B, '[', 'D', '\0'};
		static const char FILTER_DEL[]			= {0x1B, '[', '3', '~', '\0'};
			
		// Gnome terminal
		static const char FILTER_GNOME_HOME[]	= {0x1B, 'O', 'H', '\0'};
		static const char FILTER_GNOME_END[]	= {0x1B, 'O', 'F', '\0'};
			
		// Hyper terminal
		static const char FILTER_HYPER_HOME[]	= {0x1B, '[', 'H', '\0'};
		static const char FILTER_HYPER_END[]	= {0x1B, '[', 'K', '\0'};
			
		// xterm
		static const char FILTER_X_HOME[]		= {0x1B, '[', '1', '~', '\0'};
		static const char FILTER_X_END[]		= {0x1B, '[', '4', '~', '\0'};
			
		// rxvt
		static const char FILTER_RXVT_HOME[]	= {0x1B, '[', '7', '~', '\0'};
		static const char FILTER_RXVT_END[]		= {0x1B, '[', '8', '~', '\0'};
			
		m_filter[m_length++] = *(char*)data;
		m_filter[m_length] = '\0';

		if ( strcmp(m_filter, FILTER) == 0 ) return 1;
			
		if ( strcmp(m_filter, FILTER_ARROW) == 0 ) return 1;
		if ( strcmp(m_filter, FILTER_GNOME) == 0 ) return 1;
			
		if ( strcmp(m_filter, FILTER_1) == 0 ) return 1;
		if ( strcmp(m_filter, FILTER_3) == 0 ) return 1;
		if ( strcmp(m_filter, FILTER_4) == 0 ) return 1;
		if ( strcmp(m_filter, FILTER_7) == 0 ) return 1;
		if ( strcmp(m_filter, FILTER_8) == 0 ) return 1;

		if ( strcmp(m_filter, FILTER_UP_ARROW) == 0 )
		{
			m_filter[0] = CTRL_P;
			m_length = 1;
		}
		else if ( strcmp(m_filter, FILTER_DN_ARROW) == 0 )
		{
			m_filter[0] = CTRL_N;
			m_length = 1;
		}
		else if ( strcmp(m_filter, FILTER_RG_ARROW) == 0 )
		{
			m_filter[0] = CTRL_F;
			m_length = 1;
		}
		else if ( strcmp(m_filter, FILTER_LF_ARROW) == 0 )
		{
			m_filter[0] = CTRL_B;
			m_length = 1;
		}
		else if (
				( strcmp(m_filter, FILTER_GNOME_HOME) == 0 ) ||
				( strcmp(m_filter, FILTER_HYPER_HOME) == 0 ) ||
				( strcmp(m_filter, FILTER_RXVT_HOME) == 0 ) ||
				( strcmp(m_filter, FILTER_X_HOME) == 0 ) )
		{
			m_filter[0] = CTRL_R;
			m_length = 1;
		}	
		else if (
				( strcmp(m_filter, FILTER_GNOME_END) == 0 ) ||
				( strcmp(m_filter, FILTER_HYPER_END) == 0 ) ||
				( strcmp(m_filter, FILTER_RXVT_END) == 0 ) ||
				( strcmp(m_filter, FILTER_X_END) == 0) )
		{
			m_filter[0] = CTRL_S;
			m_length = 1;
		}
		else if ( strcmp(m_filter, FILTER_DEL) == 0 )
		{
			m_filter[0] = CTRL_D;
			m_length = 1;
		}
			
		const char* pointer= m_filter;
		if ( m_length == 1 )
		{
			int used = m_state->Process(pointer, m_length);
			m_length -= used;
		}
		else m_length = 0;

		return 1;
	}

	void					ConsoleSession::EnableConsoleTimestamp(bool value)
	{
		m_print_timestamp = value;
	}
	
	void					ConsoleSession::PrintTimestamp()
	{
		string output;	
	
		struct timeval val;
		gettimeofday(&val, 0);
		unsigned clock = val.tv_sec;
		clock %= (24*3600); int hour = clock/3600;
		clock %= 3600; int minute = clock/60;
		clock %= 60; int sec = clock;
		clock = val.tv_usec;
		output = string::Format("[%02d:%02d:%02d.%06d] ", hour, minute, sec, clock);
			
		void *pv = (void*)output.c_str();
		unsigned len = output.get_length();
		Write(pv, len);
	}
		
	void					ConsoleSession::SetGrepString(const char* str)
	{
		if ( str == 0 ) m_grep_str.Empty();
		else m_grep_str.SetPattern(str);
	}

	int 					ConsoleSession::vPrint(const char* fmt, va_list args)
	{
		string output;
		output = string::vFormat(fmt, args);
		return this->PrintString(output.c_str());
	}
		
	int 					ConsoleSession::PrintString(const char* buf)
	{
		if ( !buf ) return 0;

		if ( !m_grep_str.IsOk() )
		{
			//
			// No grep, typical
			//
			if ( m_print_timestamp ) PrintTimestamp();
			return Writable::PrintString(buf);
		}
		else
		{
			//
			// With grep, we need to find linefeed first
			//
			const char* linefeed = strchr(buf, '\n');
			const char* p = buf;				
			while ( linefeed )
			{
				string str = m_cache_waiting_linefeed;
				m_cache_waiting_linefeed = "";	// Clear
				str += string(p, (unsigned)(linefeed - p));
				if ( m_grep_str.Matches(str.c_str()) )
				{
					if ( m_print_timestamp ) PrintTimestamp();
					str += "\n";
					Writable::PrintString(str.c_str());
				}
				p = linefeed + 1;
				linefeed = strchr(p, '\n');
			}
			// Cache waiting for linefeed
			if ( p < ( buf + strlen(buf) ) )  m_cache_waiting_linefeed += string(p);
			if ( m_cache_waiting_linefeed.get_length() > 2048 )	// Is 2K bytes a good choice?
			{
				if ( m_grep_str.Matches(m_cache_waiting_linefeed.c_str()) )
				{
					if ( m_print_timestamp ) PrintTimestamp();
					m_cache_waiting_linefeed += "\n";
					Writable::PrintString(m_cache_waiting_linefeed.c_str());
				}
				m_cache_waiting_linefeed = ""; // Clear
			}
			return strlen(buf);
		}
	}
	
	void					ConsoleSession::RootConsoleSupportedCommands(Dlist<string> &list)
	{
		RootConsoleCommand::GetInstance().GetAllCommands(list);
	}

	void					ConsoleSession::GetSupportCommands(Dlist<string> &list)
	{
		m_support_commands_query_cbk.Dispatch(list);
	}

	bool 					ConsoleSession::BestMatch(string &buffer, string &help)
	{
		char* buf = (char*)buffer.c_str();

		while ( (*buf != '\0') && (*buf == ' ') ) buf++;

		char* pcmd = (*buf == '\0') ? 0 : buf;
			
		char* psub = pcmd ? strchr(pcmd, ' ') : 0;

		string command, sub;
			
		if ( psub ) 
		{
			sub = psub;

			*psub = '\0';
		}
			
		if ( pcmd ) command = pcmd;
			
		Dlist<string> all;
			
		GetSupportCommands(all);
			
		Dlist<string> candidates;

		for ( Dlist<string>::Node* node = all.GetHead();
				node != 0; node = all.GetNext(node) )
		{
			char* cmd = (char*)node->GetData().c_str();

			if ( strstr(cmd, command.c_str()) == cmd )
			{
				candidates.Append(node->GetData());
			}
		}
			
		bool result = false;
			
		if ( !candidates.IsEmpty() )
		{
			if ( candidates.Size() == 1 )
			{
				result = true;
					
				command = candidates.GetHead()->GetData();
			}
			else if ( candidates.Size() < 16 )
			{
				for ( Dlist<string>::Node* node = candidates.GetHead();
						node != 0; node = candidates.GetNext(node) )
				{
					help += node->GetData();	
					help += "\t";
				}
			}
			else help = "Too many possibilities";
		}
			
		if ( psub ) *psub = ' ';
			
		if ( result ) 
		{
			buffer = command + sub;
		}
				
		return result;
	}

	bool 					ConsoleSession::CSPEnabled()
	{
		if ( !colib::InFipsMode() )
		{
			return true;
		}

		if ( GetRole() != CONSOLE_ROLE_ADMIN )
		{
			Print("Only admin user can enter in CSP mode\n");
			return false;
		}

		unsigned& csp_status = Variable(CONSOLE_CSP_VAR_NAME);
		if ( csp_status == 1 )
		{
			return true;
		}
	
		Print("CSP not enabled\nPlease run the command \"csp enable\" if you wish to "
				"allow the display and editing of critical security parameters\n");

		return false;
	}
	
	void					ConsoleSession::SetCSPStatus(bool status)
	{
		unsigned csp_status = status ? 1 : 0;
		Variable(CONSOLE_CSP_VAR_NAME) =  csp_status;
		Print("CSP %s\n", status ? "enabled" : "disabled");

		if ( status )
		{
			m_csp_enabled_clock = SysTime::Get();
		}
	}
		
	void			ConsoleSession::DisplayCSPStatus()
	{
		unsigned& csp_status = Variable(CONSOLE_CSP_VAR_NAME);
		if ( csp_status == 1)
		{
			Print("CSP enabled [");
			unsigned now = SysTime::Get();
			unsigned left = CSP_CONSOLE_SESSION_TIMEOUT - (now - m_csp_enabled_clock);
			left /= 1000;
			Print("%02d:%02d left]\n", left / 60, left%60);
		}
		else
		{
			Print("CSP not enabled\n");
		}
	}

	void					ConsoleSession::EnterInteractive(InteractiveShell::Handler* handler, InteractiveShell::Releaser* releaser, void* ctx)
	{

		if ( IsProxyAccess() )
		{
			Print("This command cannot be run through proxy access, please run it with direct access\n");
			return;
		}

		if ( m_interactive_shell ) 
		{
			Print("Only one interactive shell at a time\n");
			return;
		}

		if ( handler && releaser )
		{	
			m_interactive_shell = new InteractiveShell(this, handler, releaser, ctx);
			if ( m_interactive_shell ) SetState(m_interactive_shell);
		}
	}

	void					ConsoleSession::ExitInteractive()
	{
		if ( m_interactive_shell )
		{
			SetState(m_interactive_shell->GetSuccess());	
			delete m_interactive_shell;
			m_interactive_shell = 0;
		}
	}
	
	ConsolePCmdMgr&			ConsoleSession::GetPeriodicCommandMgr()
	{
		return m_pcommand_mgr;
	}

	void					ConsoleSession::ProcessConsoleCommand(ConsoleSession* con, int argc, char* argv[])
	{
		const char* usage = "Usage:\tstatus | prompt [set new_prompt] | env [set var = value] | timestamp {on|off}";

		if ( !con ) return;
		
		if ( !argc ) 
		{
			con->Print(usage);
			return;
		}
	
		if ( 0 == strcmp(argv[0], "status") )
		{
			con->Print("Name: %s\n", GetName().c_str());
			con->Print("Role: %s\n", ConsoleRoleToName(GetRole()).c_str());
			con->Print("ConsoleBroadcast: %s\n", m_disable_broadcast ? "OFF" : "ON");
			con->Print("Prompt: %s\n", m_prompt.c_str());
		}
		else if ( 0 == strcmp(argv[0], "timestamp") )
		{
			if ( argc > 1 )
			{
				if ( 0 == strcmp(argv[1], "on") )
				{
					con->EnableConsoleTimestamp(true);
				}
				else if ( 0 == strcmp(argv[1], "off") )
				{
					con->EnableConsoleTimestamp(false);
				}
				else con->Print(usage);
			}
			else con->Print(usage);
		}
		else if ( 0 == strcmp(argv[0], "prompt") )
		{
			if ( argc > 2 )
			{
				if ( 0 == strcmp(argv[1], "set")  )
				{
					SetCustomizedPrompt(string(argv[2]));
				}
				else con->Print(usage);
			}
			con->Print("Prompt = %s\n", this->Prompt().c_str());
		}
		else if ( 0 == strcmp(argv[0], "env") )
		{
			if ( argc > 4 )
			{
				if ( ( 0 == strcmp(argv[1], "set") ) && ( 0 == strcmp(argv[3], "=") ) )
				{
					if ( 0 == strcmp(argv[2], CONSOLE_CSP_VAR_NAME) )
					{
						con->Print("CSP Variable is read-only!\n");
					 }
					else Variable(string(argv[2])) = atoi(argv[4]);					
				}
			}	

			for ( Variable_MAP::iterator it = m_variable_map.begin();
					it != m_variable_map.end(); ++it )
			{
				con->Print("%s = %d\n", it->first.c_str(), it->second);
			}
		}
		else con->Print(usage);
	}

	void					ConsoleSession::PrintStatus(string heading, ConsoleSession* con)
	{
		if ( !con ) return;	
		
		string role = ConsoleRoleToName(GetRole());
		if ( role == "" ) role = "unknown";

		con->Print("%sSession [Broadcast = %s]: %s@%s\n",
				heading.c_str(), GetBroadcast() ? "On" : "Off",
				role.c_str(), GetName().c_str());
	}
	
	void					ConsoleSession::CommandXon(void* context, ConsoleSession* con, int argc, char* argv[])
	{
		(void)context;
		(void)argc;
		(void)argv;
		if ( con ) con->DisableBroadcast(false);
	}
		
	void					ConsoleSession::CommandXoff(void* context, ConsoleSession* con, int argc, char* argv[])
	{	
		(void)context;
		(void)argc;
		(void)argv;
		if ( con ) con->DisableBroadcast(true);
	}

	void					ConsoleSession::CommandClear(void* context, ConsoleSession* con, int argc, char* argv[])
	{	
		(void)context;
		(void)argc;
		(void)argv;
		if ( con ) con->ClearScreen();
	}

	void					ConsoleSession::CommandCSP(void* context, ConsoleSession* con, int argc, char* argv[])
	{
		(void)context; 
		const char* usage = "Usage\t: enable|disable|status";
	
		if ( argc > 1 )
		{
			if ( 0 == strcmp(argv[1], "enable") )
			{
				con->SetCSPStatus(true);
			}
			else if ( 0 == strcmp(argv[1], "disable") )
			{
				con->SetCSPStatus(false);
			}
			else if ( 0 == strcmp(argv[1], "status") )
			{
				con->DisplayCSPStatus();
			}
			else con->Print(usage);
		}
		else con->Print(usage);
	}

}//end namespace colib

