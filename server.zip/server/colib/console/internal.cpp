#include<console/internal.h>
#include<console/role.h>

namespace colib
{
	ConsoleInternal::~ConsoleInternal()
	{
	}

	ConsoleInternal::ConsoleInternal(ConsoleServer* server, ConsoleLoginShell::Callback* callback)
		:	
		ConsoleSession(server),
		m_login(this, callback),
		m_shell(this),
		m_leave(this)
	{
		m_login.SetSuccess(&m_shell);
		m_login.SetFailure(&m_login);
			
		m_shell.SetSuccess(&m_leave);
		m_shell.SetFailure(&m_leave);
			
		m_leave.SetSuccess(&m_leave);
		m_leave.SetFailure(&m_leave);	
	}


	bool		ConsoleInternal::StartConsole()
	{
		m_login.Reset();
		m_shell.Reset();
		m_leave.Reset();

		SetState(&m_login);

		return true;
	}

	void		ConsoleInternal::StopConsole()
	{
		m_login.Reset();
		m_shell.Reset();
		m_leave.Reset();

		SetState(&m_leave);
	}


	void		ConsoleInternal::ResetConsole()
	{
		ConsoleSession::ResetConsole();

		m_login.Reset();
		m_shell.Reset();
		m_leave.Reset();
	}

}//end namespace colib

