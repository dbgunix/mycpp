#ifndef CONSOLE_STATE_H
#define CONSOLE_STATE_H

namespace colib
{
	class ConsoleSession;

	class ConsoleState
	{
		public:

			virtual 					~ConsoleState();
										ConsoleState(ConsoleSession* session);

			virtual ConsoleState*		GetSuccess() const;
			virtual void				SetSuccess(ConsoleState* state);

			virtual ConsoleState*		GetFailure() const;
			virtual void				SetFailure(ConsoleState* state);

			virtual ConsoleSession*		GetSession() const { return m_session; }

			virtual bool				Activate() { return true; }
			virtual void				Deactivate() {};
			virtual void				Reset() {};

			virtual unsigned			Process(const void* data, unsigned length);
				
		protected:

			ConsoleSession*				m_session;
			ConsoleState*				m_success;
			ConsoleState*				m_failure;
	};
	
}//end namespace colib

#endif

