#include<console/telnet.h>
#include<console/ansi.h>
#include<console/role.h>

namespace colib
{
	static const unsigned char ESC_IAC 		= 0xFF;

	static const unsigned char CMD_SE		= 0xF0;
	static const unsigned char CMD_NOP		= 0xF1;
	static const unsigned char CMD_DM		= 0xF2;
	static const unsigned char CMD_BRK		= 0xF3;
	static const unsigned char CMD_IP		= 0xF4;
	static const unsigned char CMD_AO		= 0xF5;
	static const unsigned char CMD_AYT		= 0xF6;
	static const unsigned char CMD_EC		= 0xF7;
	static const unsigned char CMD_EL		= 0xF8;
	static const unsigned char CMD_GA		= 0xF9;
	static const unsigned char CMD_SB		= 0xFA;
	static const unsigned char CMD_WILL		= 0xFB;
	static const unsigned char CMD_WONT		= 0xFC;
	static const unsigned char CMD_DO		= 0xFD;
	static const unsigned char CMD_DONT		= 0xFE;

	static const unsigned char OPT_BINARY 	= 0x00;
	static const unsigned char OPT_ECHO		= 0x01;
	static const unsigned char OPT_SGA		= 0x03;
	static const unsigned char OPT_LINE		= 0x22;

	ConsoleTelnet::~ConsoleTelnet()
	{
	}

	ConsoleTelnet::ConsoleTelnet(ConsoleServer* server, ConsoleLoginShell::Callback* callback)
		:	
		ConsoleSession(server),
		m_login(this, callback),
		m_shell(this),
		m_leave(this),
		m_cmd_length(0)
	{
		m_login.SetSuccess(&m_shell);
		m_login.SetFailure(&m_login);

		m_shell.SetSuccess(&m_leave);
		m_shell.SetFailure(&m_leave);

		m_leave.SetSuccess(&m_leave);
		m_leave.SetFailure(&m_leave);

		for ( unsigned i = 0; i < sizeof(m_cmd_buffer); i++ )
		{
			m_cmd_buffer[i] = 0;
		}
	}


	bool		ConsoleTelnet::StartConsole()
	{
		m_login.Reset();
		m_shell.Reset();
		m_leave.Reset();

		Send(CMD_WONT,	OPT_LINE);
		Send(CMD_DONT,	OPT_LINE);
		Send(CMD_WILL,	OPT_ECHO);
		Send(CMD_DONT,	OPT_ECHO);
		Send(CMD_WILL,	OPT_SGA);
		Send(CMD_DO,	OPT_SGA);
		Send(CMD_WILL,	OPT_BINARY);
		Send(CMD_DO,	OPT_BINARY);

		SetState(&m_login);

		return true;
	}

	void			ConsoleTelnet::StopConsole()
	{
		SetState(&m_leave);
	}


	void			ConsoleTelnet::ResetConsole()
	{
		ConsoleSession::ResetConsole();

		m_login.Reset();
		m_shell.Reset();
		m_leave.Reset();
	}

	unsigned		ConsoleTelnet::Process(const void* data, unsigned length)
	{
		(void)length;
		unsigned result = 1;

		unsigned char ch = *(unsigned char*)data;
		if ( m_cmd_length > 0 )
		{
			if ( m_cmd_length == 1 )
			{
				if ( ch == ESC_IAC )
				{
					result = ConsoleSession::Process(data, 1);
					if ( result > 0 ) m_cmd_length = 0;
				}
				else m_cmd_buffer[m_cmd_length++] = ch;
			}
			else
			{
				m_cmd_buffer[m_cmd_length++] = ch;

				switch ( m_cmd_buffer[1] )
				{
					case CMD_WILL:
					{
						switch ( m_cmd_buffer[2] )
						{
							case OPT_SGA:
							case OPT_BINARY:
							{
								break;
							}
							default:
							{
								Send(CMD_DONT, m_cmd_buffer[2]);
							}
						}
						break;
					}
					case CMD_DO:
					{
						switch ( m_cmd_buffer[2] )
						{
							case OPT_BINARY:
							case OPT_ECHO:
							case OPT_SGA:
							{
								Send(CMD_WILL, m_cmd_buffer[2]);
								break;
							}
							default:
							{
								Send(CMD_WONT, m_cmd_buffer[2]);
							}
						}
						break;
					}
					default: break;
				}
				m_cmd_length = 0;
			}
		}
		else if ( ch == ESC_IAC ) m_cmd_buffer[m_cmd_length++] = ch;
		else result = ConsoleSession::Process(data, 1);

		return result;
	}

	int				ConsoleTelnet::Send(unsigned char cmd, unsigned char opt)
	{
		unsigned char buffer[3];

		buffer[0] = ESC_IAC;
		buffer[1] = cmd;
		buffer[2] = opt;
			
		return Write(buffer, sizeof(buffer));
	}

	void			ConsoleTelnet::ClearScreen()
	{
		this->Print("\x1b[H\x1b[J");
	}

}//end namespace colib

