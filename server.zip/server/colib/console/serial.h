#ifndef CONSOLE_SERIAL_H
#define CONSOLE_SERIAL_H

#include<console/session.h>
#include<console/login.h>
#include<console/shell.h>

namespace colib
{
	class ConsoleSerial : public ConsoleSession
	{
		public:

			virtual 				~ConsoleSerial();
									ConsoleSerial(ConsoleServer* server, ConsoleLoginShell::Callback* callback = 0);

			virtual string			GetName() { return "serial"; }
			virtual bool			IsTrusted() { return true; }

			virtual bool			StartConsole();
			virtual void			StopConsole();
			virtual void			ResetConsole();
			virtual void			ClearScreen() {};
				
		protected:
		
			ConsoleState			m_enter;
			ConsoleLoginShell		m_login;
			ConsoleShell			m_shell;
	};

}//end namespace colib

#endif

