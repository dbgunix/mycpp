#include<console/server.h>
#include<console/session.h>
#include<console/manager.h>

namespace colib
{
	ConsoleServer::~ConsoleServer()
	{	
		// 
		// delete m_node will automatically be removed from ConsleManager
		//
		if ( m_node ) delete m_node;
	}

	ConsoleServer::ConsoleServer()
		:
		m_broadcast(true), m_node(0)
	{
		ConsoleManager::GetInstance().Register(this);
	}
	
	string					ConsoleServer::GetName() const
	{
		string name = ConsoleManager::GetInstance().GetName();
		if ( name == "" ) name = GetType();
		return name;
	}

	bool					ConsoleServer::GetBroadcast()
	{
		return m_broadcast;
	}

	void					ConsoleServer::SetBroadcast(bool value)
	{
		m_broadcast = value;
	}

	void					ConsoleServer::Register(ConsoleSession* session)
	{
		if ( session )
		{
			if ( session->m_node == 0 ) session->m_node = m_sessions.Append(session);
			else session->m_node->MoveTo(&m_sessions);
		}
	}

	void					ConsoleServer::Unregister(ConsoleSession* session)
	{
		if ( session ) 
		{
			delete session->m_node;
			session->m_node = 0;
		}
	}

	int						ConsoleServer::Write(const void* buf, unsigned int len)
	{
		for ( ConsoleSession::NODE* node = m_sessions.GetHead();
				node != 0; node = m_sessions.GetNext(node) )
		{
			ConsoleSession* session = node->GetData();
			if ( session->GetBroadcast() ) session->RelayBroadcast(buf, len);
		}

		return len;
	}

	void					ConsoleServer::PrintStatus(string heading, ConsoleSession* con)
	{
		if ( !con ) return;
		
		con->Print("%sServer(%s) [Broadcast = %s]\n", 
				heading.c_str(), GetType().c_str(), GetBroadcast() ? "On" : "Off");
	
		for ( ConsoleSession::NODE* node = m_sessions.GetHead();
				node != 0; node = m_sessions.GetNext(node) )
		{
			node->GetData()->PrintStatus(heading+"\t", con);
		}
	}

}//end namespace colib

