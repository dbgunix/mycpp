#ifndef CONSOLE_INTERNAL_H
#define CONSOLE_INTERNAL_H

#include<console/session.h>
#include<console/login.h>
#include<console/shell.h>

namespace colib
{
	class ConsoleInternal : public ConsoleSession
	{
		public:

			virtual 				~ConsoleInternal();
									ConsoleInternal(ConsoleServer* server, ConsoleLoginShell::Callback* callback = 0);

			virtual string			GetName() { return "internal"; }
			virtual bool			IsProxyAccess() { return true; }
			virtual bool			IsTrusted() { return false; }			

			virtual bool			StartConsole();
			virtual void			StopConsole();
			virtual void			ResetConsole();
			virtual void			ClearScreen() {};

			ConsoleState*			LoginShell() { return &m_login; }
			InternalConsoleShell*	InternalShell() { return &m_shell; }
			ConsoleState*			LeaveState() { return &m_leave; }

		protected:

			ConsoleLoginShell		m_login;
			InternalConsoleShell	m_shell;
			ConsoleState			m_leave;
	};
	
}//end namespace colib

#endif

