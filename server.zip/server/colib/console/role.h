#ifndef CONSOLE_ROLE_H
#define CONSOLE_ROLE_H

#include<utils/string.h>

//The Role ERROR_STATE is not a user role but a flag set
//on commands detailing whether they should be available
//in the ERROR_STATE. This is Independant of FIPS, because
//in the error state many console functions could lead
//to crashes.
//The usual user roles are used for authentication and
//access control while in the error state, however,
//the user must not be allowed acces to functions that
//are not also registered to ERROR_STATE

namespace colib
{
	extern const unsigned CONSOLE_ROLE_DEFAULT;
	extern const unsigned CONSOLE_ROLE_USER;
	extern const unsigned CONSOLE_ROLE_ADMIN;
	extern const unsigned CONSOLE_ROLE_CRYPTO;
	extern const unsigned CONSOLE_ROLE_DIAGNOSTIC;

	extern const unsigned CONSOLE_ROLE_EVERYONE;
	extern const unsigned CONSOLE_ROLE_ERROR_STATE;

	unsigned	ConsoleNameToRole(string name);
	string		ConsoleRoleToName(unsigned role);

	unsigned	ConsoleHighestLevelRole();
	unsigned 	ConsoleHigherLevelRoles();

	bool 		ConsoleCheckPermission(unsigned command_role, unsigned session_role );

}//end namespace colib

#endif

