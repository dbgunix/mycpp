#ifndef INTERACTIVE_H
#define INTERACTIVE_H

#include<console/prompt.h>
#include<console/state.h>

namespace colib
{
	class ConsoleSession;

	class InteractiveShell;

	class InteractiveExit : public ConsoleState
	{
		public:

			virtual					~InteractiveExit();
									InteractiveExit(ConsoleSession* session, InteractiveShell* shell);

			virtual bool			Activate();						

		protected:
			
			InteractiveShell*		m_shell;
	};

	class InteractiveShell : public ConsoleState
	{
		public:
				
			typedef bool Handler(	void*			context,
									ConsoleSession*	session,
									ConsolePrompt*	prompt,
									int				argc,
									char*			argv[]);
			
			typedef void Releaser(	void*			context);

		public:
				
			virtual					~InteractiveShell();
									InteractiveShell(ConsoleSession* session, Handler* handler, Releaser* releaser, void* ctx);

			virtual bool			Activate();
			virtual void			Deactivate();			
			virtual void			Reset();
			virtual unsigned		Process(const void* data, unsigned length);
				
			void					CleanUp();

		protected:
				
			Handler*				m_handler;
			Releaser*				m_releaser;
			void*					m_ctx;

		private:

			ConsolePrompt			m_shell_prompt;	
			InteractiveExit			m_shell_exit;
	};

}//end namespace colib

#endif

