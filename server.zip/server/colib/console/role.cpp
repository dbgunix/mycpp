#include<console/role.h>
#include<config/fips.h>
#include<utils/string.h>

#ifdef CONFIG_HAVE_TLS
#include<crypt/fips/fips.h>
#endif

namespace colib
{
	const unsigned CONSOLE_ROLE_DEFAULT			= 0x00000001;
	const unsigned CONSOLE_ROLE_USER			= 0x00000002;
	const unsigned CONSOLE_ROLE_ADMIN			= 0x00000004;
	const unsigned CONSOLE_ROLE_CRYPTO			= 0x00000008;
	const unsigned CONSOLE_ROLE_DIAGNOSTIC		= 0x80000000;

	const unsigned CONSOLE_ROLE_EVERYONE		= 0xEFFFFFFE;
	const unsigned CONSOLE_ROLE_ERROR_STATE		= 0x10000000;

	struct ConsoleRoleName
	{
		unsigned	m_role;
		string		m_name;
	};

	static ConsoleRoleName		console_role_name_map[] =
	{
		{ CONSOLE_ROLE_USER,		"user"},
		{ CONSOLE_ROLE_ADMIN,		"admin"},
		{ CONSOLE_ROLE_CRYPTO,		"crypto"},
		{ CONSOLE_ROLE_DIAGNOSTIC,	"diagnostic"},
		{ CONSOLE_ROLE_DEFAULT,		""}
	};

	unsigned		ConsoleNameToRole(string name)
	{
		unsigned result = CONSOLE_ROLE_DEFAULT;

		ConsoleRoleName* role_name = console_role_name_map;
	
		while ( role_name->m_name != "" )
		{
			if ( role_name->m_name == name )
			{
				result = role_name->m_role;
				break;
			}
			++role_name;
		}

		return result;
	}

	string			ConsoleRoleToName(unsigned role)
	{
		string result;
		
		ConsoleRoleName* role_name = console_role_name_map;

		while ( role_name->m_name != "" )
		{
			if ( role_name->m_role == role )
			{
				result = role_name->m_name;
				break;
			}
			++role_name;
		}

		return result;
	}
		
	unsigned 		ConsoleHighestLevelRole()
	{
		if ( colib::InFipsMode() )	return CONSOLE_ROLE_CRYPTO;
		else return CONSOLE_ROLE_DIAGNOSTIC | CONSOLE_ROLE_ADMIN;
	}

	unsigned 		ConsoleHigherLevelRoles()
	{
		return CONSOLE_ROLE_DIAGNOSTIC | CONSOLE_ROLE_ADMIN | CONSOLE_ROLE_CRYPTO;
	}

	bool			ConsoleCheckPermission(unsigned command_role, unsigned session_role )
	{
		if ( 0 == ( session_role & ( command_role & ~CONSOLE_ROLE_ERROR_STATE ) ) )
			return false;

#ifdef CONFIG_HAVE_TLS
		if ( colib::InErrorState() && 0 == ( CONSOLE_ROLE_ERROR_STATE & command_role ) )
			return false;
#endif

		return true;
	}
	
}//end namespace colib

