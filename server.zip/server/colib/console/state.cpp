#include<console/state.h>
#include<console/session.h>

namespace colib
{
	ConsoleState::~ConsoleState()
	{
	}

	ConsoleState::ConsoleState(ConsoleSession* session)
		:
		m_session(session),  m_success(0), 	m_failure(0)
	{
	}

	ConsoleState*		ConsoleState::GetSuccess() const
	{	
		return m_success;
	}

	void				ConsoleState::SetSuccess(ConsoleState* state)
	{
		m_success = state;
	}

	ConsoleState*		ConsoleState::GetFailure() const
	{
		return m_failure;
	}

	void				ConsoleState::SetFailure(ConsoleState* state)
	{
		m_failure = state;
	}

	unsigned			ConsoleState::Process(const void* data, unsigned length)
	{
		(void)data;
		if ( m_session ) m_session->SetState(m_success);
		return ( length > 0 ) ? 1 : 0;
	}
	
}//end namespace colib

