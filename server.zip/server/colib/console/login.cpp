#include<console/login.h>
#include<console/ansi.h>
#include<console/role.h>

#include <string.h>

namespace colib
{
	static const char DEFAULT_PASSWORD[] = "colib";

	unsigned		DefaultCallback(	
					ConsoleSession*	session,
					const char*	username,
					const char*	password)
	{
		unsigned role = ConsoleNameToRole(username);

		if ( role == CONSOLE_ROLE_ADMIN )
		{
			if ( strcmp(password, DEFAULT_PASSWORD) == 0 )
			{
				role = CONSOLE_ROLE_ADMIN;
			}
			else role = CONSOLE_ROLE_DEFAULT;
		}
		else role = CONSOLE_ROLE_DEFAULT;

		if ( role == CONSOLE_ROLE_DEFAULT ) session->Print("\r\nAccess Denied\r\n");
		session->Print("\r\n");

		return role;
	}

	ConsoleLoginShell::~ConsoleLoginShell()
	{
	}

	ConsoleLoginShell::ConsoleLoginShell(ConsoleSession* session, Callback* callback)
		:	
		ConsoleState(session),
		m_login_prompt(session, false)
	{
		m_callback = ((callback != 0) ? callback : &DefaultCallback);
		m_state = 0;

		m_login_prompt.SetSuccess(this);
		m_login_prompt.SetFailure(this);
	}

	bool		ConsoleLoginShell::Activate()
	{
		bool result = ConsoleState::Activate();

		ConsoleSession* session = GetSession();
		const char* buffer = m_login_prompt.GetBuffer();

		if ( result && session )
		{
			switch ( m_state )
			{
				case 0: // username
				{
					m_state = 1;
					m_login_prompt.SetPrompt(ANSI_FG_NORM_GREEN "Username" ANSI_DEFAULT ": ");
					m_login_prompt.SetEcho('\0');
					session->SetState(&m_login_prompt);
					break;
				}
				case 1: // password
				{
					m_state = 2;
					if ( buffer[0] != '\0' )
					{
						strncpy(m_username, buffer, LOGIN_LENGTH);
						m_username[sizeof(m_username)-1] = '\0';
						m_login_prompt.ZeroizeBuffer();
						m_login_prompt.SetPrompt(ANSI_FG_NORM_GREEN "Password" ANSI_DEFAULT ": ");
						m_login_prompt.SetEcho('*');
					}
					else m_state = 1;
					session->SetState(&m_login_prompt);
					break;
				}
				default: // authenticate
				{
					m_state = 0;
					strncpy(m_password, buffer, LOGIN_LENGTH);
					m_password[sizeof(m_password)-1] = '\0';
					m_login_prompt.ZeroizeBuffer();
					if ( m_callback != 0 )
					{
						unsigned role = m_callback(session, m_username, m_password);
						Zeroize();
						if ( role != CONSOLE_ROLE_DEFAULT)
						{
							session->SetRole(role);
							session->SetState(m_success);
						}
						else
						{	
							session->SetState(m_failure);
						}
					}
					else
					{
						Zeroize();	
						session->SetState(m_failure);
					}
				}
			}
		}
		
		return result;
	}

	void		ConsoleLoginShell::Deactivate()
	{
	}
	
	void		ConsoleLoginShell::Zeroize()
	{
		memset(m_username, 0, sizeof(m_username)); 
		memset(m_password, 0, sizeof(m_password)); 
	}

	void		ConsoleLoginShell::Reset()
	{
		m_login_prompt.Reset();
		m_state = 0;
	}

	unsigned	ConsoleLoginShell::Process(const void* data, unsigned length)
	{
		(void)data;
		(void)length;
		return 0;
	}
	
}//end namespace colib

