#ifndef CONSOLE_SHELL_H
#define CONSOLE_SHELL_H

#include<console/prompt.h>
#include<utils/callback.h>

namespace colib
{
	class ConsoleShell : public ConsoleState
	{
		public:

			virtual 			~ConsoleShell();
								ConsoleShell(ConsoleSession* session);

			virtual bool		Activate();
			virtual void		Deactivate();
			virtual void		Reset();
			virtual unsigned	Process(const void* data, unsigned length);

			virtual void		EnableDispatch();

			virtual ConsolePrompt*	ShellPrompt() { return &m_shell_prompt; }

		protected:

			ConsolePrompt		m_shell_prompt;
			bool				m_dispatch;
			
		protected:

			char*				GetGrepStr(char* buf);	
	};
	
	class InternalConsoleShell : public ConsoleShell
	{
		public:

			virtual				~InternalConsoleShell();
								InternalConsoleShell(ConsoleSession* session);
			
			virtual ConsolePrompt*	ShellPrompt() { return &m_internal_shell_prompt; }

		protected:

			DumbConsolePrompt	m_internal_shell_prompt;			
	};

}//end namespace colib

#endif

