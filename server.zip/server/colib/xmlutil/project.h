//project.h
// vi:set ts=4 sw=4 nowrap:

#ifndef PROJECT_H_ALREADY_INCLUDED
#define PROJECT_H_ALREADY_INCLUDED

#include<xmlutil/options_projection.h>

namespace colib
{

class Options;

bool ProjectOptions(
		const OptionsProjectionFile &filter,
		const Options &from,
		Options &to
		);

}//end namespace colib

#endif

