//treeoptions.cpp
// vi:set ts=4 sw=4 nowrap:

#include <xmlutil/treeoptions.h>
#include <utils/utils.h> // TODO: try to remove

namespace colib
{

void TreeOptions::StartElement( ParseControlContext *ctx, const char *name, const char **attrs)
{
	(void)attrs;

	if(!ctx->m_begun)
	{
		m_name=name;
		ctx->m_begun=true;
		return;
	}

	std::multiset<TreeOptions>::iterator piternew = m_children.insert(TreeOptions( trim_whitespace(colib::string(name)) ));

	((TreeOptions&)*piternew).m_parent = this;

	ctx->m_cur_ctx.push_front( & (TreeOptions&) * piternew );
}

void TreeOptions::EndElement( ParseControlContext *ctx, const char *name )
{
	(void)name;
	Finish(ctx);
}

void TreeOptions::Text( ParseControlContext *ctx, const char *text, int len )
{
	(void)ctx;
	//fprintf(stderr,"  ELEM %s, text: %s\n", m_name.c_str(), colib::string(text,(size_t)len).c_str());
	m_value += trim_whitespace ( colib::string ( text, (unsigned)len ) );
}

colib::string TreeOptions::ToXML(int indent_level )const
{
	colib::string ret;

	AddTabsToString(ret,indent_level);
	ret += colib::string::Format("<%s>",m_name.c_str() );

	if(!m_children.empty() )
		ret += '\n';

	++indent_level;

	if(!m_value.is_empty())
	{
		if( !m_children.empty() )
			AddTabsToString(ret,indent_level);

		ret += colib::string::Format("%s",m_value.c_str() );

		if( !m_children.empty() )
			ret += '\n';
	}

	std::multiset<TreeOptions>::const_iterator childiter;
	for(childiter=m_children.begin();childiter!=m_children.end(); ++childiter)
	{
		ret += childiter->ToXML(indent_level);
	}

	--indent_level;

	if(!m_children.empty() )
		AddTabsToString(ret,indent_level);
	ret += colib::string::Format("</%s>\n",m_name.c_str() );

	return ret;
}

const TreeOptions* TreeOptions::GetChild( const colib::string &name )const
{
	TreeOptions srch;
	srch.m_name=name;

	std::multiset<TreeOptions>::const_iterator finditer = m_children.lower_bound(srch);
	if(finditer == m_children.end() )
		return 0;

	if(finditer->m_name != name)
		return 0;

	return & * finditer;
}

TreeOptions* TreeOptions::Child( const colib::string &name )
{
	TreeOptions srch;
	srch.m_name=name;

	std::multiset<TreeOptions>::iterator finditer = m_children.lower_bound(srch);
	if(finditer == m_children.end() )
		return 0;

	if(finditer->m_name != name)
		return 0;

	return & (TreeOptions&) * finditer;
}

const TreeOptions* TreeOptions::GetChild( const colib::string &name, size_t index )const
{
	std::pair<iter_type, iter_type> range = m_children.equal_range(name);
	if( range.first == range.second )
		return 0;
	while( index > 0 )
	{
		++ range.first;
		if( range.first == range.second )
			return 0;
		--index;
	}
	return &*range.first;
}

TreeOptions* TreeOptions::Child( const colib::string &name, size_t index )
{
	std::pair<iter_type, iter_type> range = m_children.equal_range(name);
	if( range.first == range.second )
		return 0;
	while( index > 0 )
	{
		++ range.first;
		if( range.first == range.second )
			return 0;
		--index;
	}
	return & (TreeOptions&) * range.first;;
}
size_t TreeOptions::GetChildCount( const colib::string &name )const
{
	std::pair<iter_type, iter_type> range = m_children.equal_range(name);
	return std::distance(range.first,range.second);
}

TreeOptions::TreeOptions()
{
	m_parent=0;
}
TreeOptions::TreeOptions( const colib::string &name )
:
	m_name(name)
{
	m_parent=0;
}
TreeOptions::TreeOptions( const TreeOptions &copy )
:
	SAXReaderIf(copy),
	m_value(copy.m_value),
	m_name(copy.m_name),//our parent point is uninitialized at this point, so we have no parent
	m_children(copy.m_children)
{
	m_parent=0;
	SetParentPointersOfChildren();
}
TreeOptions& TreeOptions::operator=( const TreeOptions &copy )
{
	//we cant resort ourself in the list, so neglect to copy the name here
	//m_name = copy.m_name;
	m_value = copy.m_value;
	m_children = copy.m_children;
	SetParentPointersOfChildren();
	return *this;
}

void TreeOptions::SetParentPointersOfChildren()
{
	std::multiset<TreeOptions>::iterator iter;
	for(iter=m_children.begin();iter!=m_children.end();++iter)
	{
		((TreeOptions&)*iter).m_parent=this;
		((TreeOptions&)*iter).SetParentPointersOfChildren();
	}
}

TreeOptions* TreeOptions::InsertChild( const colib::string &name )
{
	std::multiset<TreeOptions>::iterator piternew = m_children.insert(TreeOptions(trim_whitespace(name)));

	((TreeOptions&)*piternew).m_parent = this;

	return & (TreeOptions&) *piternew;
}

TreeOptions* TreeOptions::InsertChild( const colib::string &name, const colib::string &value )
{
	std::multiset<TreeOptions>::iterator piternew = m_children.insert(TreeOptions(trim_whitespace(name)));

	((TreeOptions&)*piternew).m_parent = this;
	((TreeOptions&)*piternew).m_value = value;

	return & (TreeOptions&) *piternew;
}

TreeOptions* TreeOptions::InsertChild( TreeOptions* toins )
{
	TreeOptions *ret = InsertChild(toins->m_name);

	if(ret)
	{
		*ret = *toins;
	}
	return ret;
}

colib::string TreeOptions::GetTreeChildValue( const char *path )const
{
	const char *pnextslash;
	const TreeOptions *at = this;

	while( true )
	{
		colib::string lookname;

		pnextslash = path;
		while( *pnextslash && *pnextslash != '/')
			++pnextslash;

		lookname = colib::string ( path, (unsigned)( pnextslash-path ) );

		at = at->GetChild(lookname);

		if(!at)
			return colib::string();

		path = pnextslash;
		if(*path=='/')
			++path;
		else
			break;
	}

	return at->m_value;
}


}//end namespace colib


