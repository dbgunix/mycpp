//saxif.cpp
// vi:set ts=4 sw=4 nowrap:

#include <xmlutil/saxif.h>

#include <errno.h>
#include <string.h>

namespace colib
{

SAXReaderIf::~SAXReaderIf()
{
}
void SAXReaderIf::StartElement( ParseControlContext *ctx, const char *name, const char **attrs)
{
	(void)ctx;(void)name;(void)attrs;
}

void SAXReaderIf::EndElement( ParseControlContext *ctx, const char *name )
{
	(void)ctx;(void)name;
}

void SAXReaderIf::Text( ParseControlContext *ctx, const char *text, int len )
{
	ctx->m_text_data = colib::string ( text, (unsigned)len );
}

void SAXReaderIf::ChildComplete( ParseControlContext *ctx, SAXReaderIf *child )
{
	(void)ctx;(void)child;
}

void SAXReaderIf::Finish( ParseControlContext *ctx )
{
	ctx->m_cur_ctx.pop_front();

	if(!ctx->m_cur_ctx.empty())
	{
		SAXReaderIf* parent = ctx->m_cur_ctx.front();

		if(parent)
			parent->ChildComplete(ctx,this);
	}
}

bool ParseControlContext::Init()
{
	if(m_parser)
	{
		XML_ParserFree(m_parser);
	}

	m_parser = XML_ParserCreate("UTF-8");
	if(!m_parser)
	{
		m_error="failed to create parser";
		return false;
	}
	XML_SetUserData(m_parser,this);
	XML_SetElementHandler(m_parser, ParseControlContext::StartElement, ParseControlContext::EndElement);
	XML_SetCharacterDataHandler(m_parser, ParseControlContext::HandleContent );

	//m_begun signifies whether or not the first element has been successfully encountered.
	//it is controlled by the derived implementations, but we initialize it to false
	m_begun=false;
	//We stop parsing anytime this becomes true:
	m_stop_for_error=false;

	return true;
}
void ParseControlContext::StartElement( void *userData, const char *name, const char **atts)
{
	ParseControlContext *ctx = (ParseControlContext*)userData;
	if(ctx->m_stop_for_error)
		return;
	if( ctx->m_cur_ctx.empty() || ctx->m_cur_ctx.front()==0 )
	{
		ctx->m_error="current parse context has gone empty [ParseControlContext::StartElement]";
		ctx->m_stop_for_error=true;
		return;
	}
	ctx->m_cur_ctx.front()->StartElement( (ParseControlContext*)userData,name,atts);
}
void ParseControlContext::EndElement( void *userData, const char *name)
{
	ParseControlContext *ctx = (ParseControlContext*)userData;
	if(ctx->m_stop_for_error)
		return;
	if( ctx->m_cur_ctx.empty() || ctx->m_cur_ctx.front()==0 )
	{
		ctx->m_error="current parse context has gone empty [ParseControlContext::EndElement]";
		ctx->m_stop_for_error=true;
		return;
	}
	ctx->m_cur_ctx.front()->EndElement( (ParseControlContext*)userData,name);
}
void ParseControlContext::HandleContent( void *userData, const char *s, int len)
{
	ParseControlContext *ctx = (ParseControlContext*)userData;
	if(ctx->m_stop_for_error)
		return;
	if( ctx->m_cur_ctx.empty() || ctx->m_cur_ctx.front()==0 )
	{
		ctx->m_error="current parse context has gone empty [ParseControlContext::HandleContent]";
		ctx->m_stop_for_error=true;
		return;
	}
	ctx->m_cur_ctx.front()->Text( (ParseControlContext*)userData,s,len);
}

bool ParseControlContext::ReadInFromFile( colib::string path, SAXReaderIf *pif )
{
	m_stop_for_error=false;

	if(path.is_empty())
	{
		m_error="empty arg for path";
		return false;
	}

	if(!Init())
	{
		return false;
	}

	FILE *readfile = fopen(path.c_str(),"r");
	if(!readfile)
	{
		m_error=colib::string::Format("Failed to open\"%s\": %s", path.c_str(), strerror(errno) );
		return false;
	}

	if(pif)
	{
		m_cur_ctx.push_front(pif);
	}

	//do the parsing
	while(true)
	{
		size_t bytes_read;
		void *buff = XML_GetBuffer(m_parser, 1000);
		if( buff == NULL )
		{
			m_error="failed to XML_GetBuffer";
			m_stop_for_error = true;
			break;
		}

		bytes_read = fread(buff, 1, 1000, readfile);
		if( bytes_read < 1000 && ferror(readfile) )
		{
			m_error=colib::string::Format("Failed to read from file: %s", strerror(errno) );
			m_stop_for_error = true;
			break;
		}

		if( !XML_ParseBuffer ( m_parser, (int)bytes_read, (int)( bytes_read == 0 ) ) )
		{
			m_error=colib::string::Format("failed to XML_ParseBuffer at line %ld: %s",
					XML_GetCurrentLineNumber(m_parser), XML_ErrorString(XML_GetErrorCode(m_parser)) );
			m_stop_for_error = true;
			break;
		}

		if( m_stop_for_error )
		{
			break;
		}

		if( bytes_read == 0 )
			//done
			break;
	}

	fclose(readfile);
	return !m_stop_for_error;
}
bool ParseControlContext::ReadInFromFile( FILE *file, SAXReaderIf *pif )
{
	m_stop_for_error=false;

	if(!Init())
	{
		return false;
	}

	if(pif)
	{
		m_cur_ctx.push_front(pif);
	}

	//do the parsing
	while(true)
	{
		size_t bytes_read;
		void *buff = XML_GetBuffer(m_parser, 1000);
		if( buff == NULL )
		{
			m_error="failed to XML_GetBuffer";
			m_stop_for_error = true;
			break;
		}

		bytes_read = fread(buff, 1, 1000, file);
		if( bytes_read < 1000 && ferror(file) )
		{
			m_error=colib::string::Format("Failed to read from file: %s", strerror(errno) );
			m_stop_for_error = true;
			break;
		}

		if( !XML_ParseBuffer ( m_parser, (int)bytes_read, (int)( bytes_read == 0 ) ) )
		{
			m_error=colib::string::Format("failed to XML_ParseBuffer at line %ld: %s",
					XML_GetCurrentLineNumber(m_parser), XML_ErrorString(XML_GetErrorCode(m_parser)) );
			m_stop_for_error = true;
			break;
		}

		if( m_stop_for_error )
		{
			break;
		}

		if( bytes_read == 0 )
			//done
			break;
	}

	return !m_stop_for_error;
}

bool ParseControlContext::ReadInFromString( colib::string xmltext, SAXReaderIf *pif )
{
	m_stop_for_error=false;

	if(!Init())
	{
		return false;
	}

	if(pif)
	{
		m_cur_ctx.push_front(pif);
	}

	if( !XML_Parse(m_parser, xmltext.c_str(), xmltext.get_length() ,true) )
	{
		m_error=colib::string::Format("failed to XML_Parse at line %ld: %s",
				XML_GetCurrentLineNumber(m_parser), XML_ErrorString(XML_GetErrorCode(m_parser)) );
		m_stop_for_error = true;
	}

	return !m_stop_for_error;
}

ParseControlContext::ParseControlContext()
{
	m_parser=0;
}
ParseControlContext::~ParseControlContext()
{
	if(m_parser)
	{
		XML_ParserFree(m_parser);
	}
}

bool SAXReaderIf::LoadFromString( colib::string xmlstring, colib::string &err )
{
	ParseControlContext parser;

	if( !parser.ReadInFromString(xmlstring,this) )
	{
		err = parser.m_error;
		return false;
	}
	return true;
}
bool SAXReaderIf::LoadFromFile( colib::string path, colib::string &err )
{
	ParseControlContext parser;

	if( !parser.ReadInFromFile(path,this) )
	{
		err = parser.m_error;
		return false;
	}
	return true;
}

bool SAXReaderIf::LoadFromFile( FILE *file, colib::string &err )
{
	ParseControlContext parser;

	if( !parser.ReadInFromFile(file,this) )
	{
		err = parser.m_error;
		return false;
	}
	return true;
}


}//end namespace colib


