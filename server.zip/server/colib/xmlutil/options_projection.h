//options_projection.h
// vi:set ts=4 sw=4 nowrap:

#ifndef OPTIONS_PROJECTION_H_ALREADY_INCLUDED
#define OPTIONS_PROJECTION_H_ALREADY_INCLUDED

#include <set>
#include <utils/string.h>
#include <utils/reg_exp.h>
#include <xmlutil/saxif.h>

namespace colib
{

class OptionsProjectionGroup : public SAXReaderIf
{
public:
	bool operator<( const OptionsProjectionGroup &than )const;
	colib::string ToXML(int indent_level=0)const;
	void EndElement( ParseControlContext *ctx, const char *name );

	colib::Regex m_name;
	std::set<colib::Regex> m_keys;
};

class OptionsProjectionFile : public SAXReaderIf
{
public:
	bool operator<( const OptionsProjectionFile &than )const;
	colib::string ToXML(int indent_level=0)const;
	void StartElement( ParseControlContext *ctx, const char *name, const char **attrs);
	void EndElement( ParseControlContext *ctx, const char *name );
	void ChildComplete( ParseControlContext *ctx, SAXReaderIf *child );

	colib::string m_name;
	std::set<OptionsProjectionGroup> m_groups;
};

class OptionsProjectionProcess : public SAXReaderIf
{
public:
	bool operator<( const OptionsProjectionProcess &than )const;
	colib::string ToXML(int indent_level=0)const;
	void StartElement( ParseControlContext *ctx, const char *name, const char **attrs);
	void EndElement( ParseControlContext *ctx, const char *name );
	void ChildComplete( ParseControlContext *ctx, SAXReaderIf *child );

	colib::string m_name;
	std::set<OptionsProjectionFile> m_files;
};

class OptionsProjectionSet : public SAXReaderIf
{
public:
	bool LoadFromFile( colib::string path, colib::string &err );
	colib::string ToXML(int indent_level=0)const;
	void StartElement( ParseControlContext *ctx, const char *name, const char **attrs);
	void ChildComplete( ParseControlContext *ctx, SAXReaderIf *child );

	const OptionsProjectionFile* GetFilter(const char* process_name, const char* options_name) const;
	std::set<OptionsProjectionProcess> m_processes;
};

//Inlines:
inline bool OptionsProjectionGroup::operator<( const OptionsProjectionGroup &than )const
{
	return m_name < than.m_name;
}

inline bool OptionsProjectionFile::operator<( const OptionsProjectionFile &than )const
{
	return m_name < than.m_name;
}

inline bool OptionsProjectionProcess::operator<( const OptionsProjectionProcess &than )const
{
	return m_name < than.m_name;
}


}//end namespace colib

#endif

