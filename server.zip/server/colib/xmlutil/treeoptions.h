//treeoptions.h
// vi:set ts=4 sw=4 nowrap:

#ifndef TREEOPTIONS_H_ALREADY_INCLUDED
#define TREEOPTIONS_H_ALREADY_INCLUDED

#include <set>
#include <utils/string.h>
#include <xmlutil/saxif.h>

namespace colib
{

class TreeOptions : public SAXReaderIf
{
public:
	TreeOptions();
	TreeOptions( const colib::string &name );
	TreeOptions( const TreeOptions &copy );
	TreeOptions& operator=( const TreeOptions &copy );

	colib::string ToXML(int indent_level=0)const;

	//SAX style callback based XML parsing
	virtual void StartElement( ParseControlContext *ctx, const char *name, const char **attrs);
	virtual void EndElement( ParseControlContext *ctx, const char *name );
	virtual void Text( ParseControlContext *ctx, const char *text, int len );

	bool operator<( const TreeOptions &than )const;

	const TreeOptions* GetChild( const colib::string &name )const;
	const TreeOptions* GetChild( const colib::string &name, size_t index )const;
	size_t GetChildCount( const colib::string &name )const;
	const TreeOptions* GetParent()const;

	TreeOptions* Child( const colib::string &name );
	TreeOptions* Child( const colib::string &name, size_t index  );
	TreeOptions* Parent();

	TreeOptions* InsertChild( const colib::string &name );
	TreeOptions* InsertChild( const colib::string &name, const colib::string &value );
	TreeOptions* InsertChild( TreeOptions* toins );
	//bool RemoveChild( TreeOptions *child );
	void Clear();

	bool SetName(colib::string to);
	colib::string GetName()const;
	colib::string GetValue()const{return m_value;}
	void GetValue( colib::string &to) {m_value=to;}

	//returns empty string if not found
	//path separator is '/'
	colib::string GetTreeChildValue( const char *path )const;

	colib::string m_value;

	const std::multiset<TreeOptions>& GetChildren()const;

	typedef std::multiset<TreeOptions>::const_iterator iter_type;

private:
	colib::string m_name;
	std::multiset<TreeOptions> m_children;
	TreeOptions *m_parent;

	void SetParentPointersOfChildren();
};

inline bool TreeOptions::operator<( const TreeOptions &than )const
{
	return m_name < than.m_name;
}

inline TreeOptions* TreeOptions::Parent()
{
	return m_parent;
}

inline const TreeOptions* TreeOptions::GetParent()const
{
	return m_parent;
}
inline colib::string TreeOptions::GetName()const
{
	return m_name;
}
inline bool TreeOptions::SetName(colib::string to)
{
	//this only works if we are a root object with no parent.
	//for this to work with arbitrary treeoptions, we'd have to
	//remove ourself from out parents multi-set and re-insert at the new position
	//To do so efficiently without re-copycontructing everything twice, we would have to
	//be able to edit the internal STL data structures, which we dont attempt to do here
	if( !m_parent )
	{
		m_name = to;
		return true;
	}
	return false;
}
inline const std::multiset<TreeOptions>& TreeOptions::GetChildren()const
{
	return m_children;
}
inline void TreeOptions::Clear()
{
	m_children.clear();
	//m_name.empty(); // we cant resort ourself in the list, so dont do this
	m_value.empty();
}


}//end namespace colib

#endif

