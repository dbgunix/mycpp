//options_projection.cpp
// vi:set ts=4 sw=4 nowrap:

#include <xmlutil/options_projection.h>
#include <stdio.h>
#include <errno.h>
#include <expat.h>
#include <string.h>
#include <utils/utils.h>

//#include "trace/trace.h"

namespace colib
{

bool OptionsProjectionSet::LoadFromFile( colib::string path, colib::string &err )
{
	ParseControlContext parser;

	m_processes.clear();

	if( !parser.ReadInFromFile(path,this) )
	{
		err = parser.m_error;
		return false;
	}
	return true;
}

colib::string OptionsProjectionGroup::ToXML(int indent_level)const
{
	colib::string ret;

	AddTabsToString(ret,indent_level);
	ret += "<name>";
	ret += m_name.GetPattern();
	ret += "</name>\n";

	std::set<colib::Regex>::const_iterator keyiter;
	for(keyiter=m_keys.begin();keyiter!=m_keys.end(); ++keyiter)
	{
		AddTabsToString(ret,indent_level);
		ret += "<key>";
		ret += keyiter->GetPattern();
		ret += "</key>\n";
	}

	return ret;
}

colib::string OptionsProjectionFile::ToXML(int indent_level)const
{
	colib::string ret;

	AddTabsToString(ret,indent_level);
	ret += "<name>";
	ret += m_name;
	ret += "</name>\n";

	std::set<OptionsProjectionGroup>::const_iterator groupiter;
	for(groupiter=m_groups.begin();groupiter!=m_groups.end(); ++groupiter)
	{
		AddTabsToString(ret,indent_level);
		ret += "<group>\n";
		++indent_level;

		ret += groupiter->ToXML(indent_level);

		--indent_level;
		AddTabsToString(ret,indent_level);
		ret += "</group>\n";
	}

	return ret;
}
colib::string OptionsProjectionProcess::ToXML(int indent_level)const
{
	colib::string ret;

	AddTabsToString(ret,indent_level);
	ret += "<name>";
	ret += m_name;
	ret += "</name>\n";

	std::set<OptionsProjectionFile>::const_iterator fileiter;
	for(fileiter=m_files.begin();fileiter!=m_files.end(); ++fileiter)
	{
		AddTabsToString(ret,indent_level);
		ret += "<options>\n";
		++indent_level;

		ret += fileiter->ToXML(indent_level);

		--indent_level;
		AddTabsToString(ret,indent_level);
		ret += "</options>\n";
	}

	return ret;
}

colib::string OptionsProjectionSet::ToXML( int indent_level )const
{
	colib::string ret;

	//output headers:
	if(indent_level==0)
	{
		ret += "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n";
		ret += "<!-- config file: options-file projections -->\n\n";
	}

	AddTabsToString(ret,indent_level);
	ret += "<projectionset>\n";
	++indent_level;

	std::set<OptionsProjectionProcess>::const_iterator prociter;
	for(prociter=m_processes.begin();prociter!=m_processes.end(); ++prociter)
	{
		AddTabsToString(ret,indent_level);
		ret += "<process>\n";
		++indent_level;

		ret += prociter->ToXML(indent_level);

		--indent_level;
		AddTabsToString(ret,indent_level);
		ret += "</process>\n";
	}

	--indent_level;
	AddTabsToString(ret,indent_level);
	ret += "</projectionset>\n";

	return ret;
}

void OptionsProjectionSet::StartElement( ParseControlContext *ctx, const char *name, const char **attrs)
{
	if(!ctx->m_begun )
	{
		if( 0!=strcmp(name,"projectionset"))
		{
			ctx->m_stop_for_error = true;
			ctx->m_error = colib::string::Format("Line %ld, Unknown Element \"%s\", expected \"projectionset\"",
					XML_GetCurrentLineNumber(ctx->m_parser), name );
			Finish(ctx);
		}
		ctx->m_begun=true;
		return;
	}
	else if( !strcmp(name,"process"))
	{
		OptionsProjectionProcess *pnew = new OptionsProjectionProcess;

		ctx->m_cur_ctx.push_front(pnew);
		pnew->StartElement(ctx,name,attrs);
	}
	else
	{
		ctx->m_stop_for_error = true;
		ctx->m_error = colib::string::Format("Line %ld, Unknown Element \"%s\"",
				XML_GetCurrentLineNumber(ctx->m_parser), name );
		Finish(ctx);
	}
}

void OptionsProjectionSet::ChildComplete( ParseControlContext *ctx, SAXReaderIf *child )
{
	OptionsProjectionProcess *pnewchild = (OptionsProjectionProcess*)child;

	if( ctx->m_stop_for_error )
	{
		delete pnewchild;
		return;
	}

	if( m_processes.find( *pnewchild) != m_processes.end() )
	{
		ctx->m_stop_for_error = true;
		ctx->m_error = colib::string::Format("Line %ld, Multiple instances of process \"%s\"",
				XML_GetCurrentLineNumber(ctx->m_parser), ctx->m_text_data.c_str() );
		delete pnewchild;
		return;
	}
	m_processes.insert(*pnewchild);
	delete pnewchild;
	return;
}

const OptionsProjectionFile* OptionsProjectionSet::GetFilter(const char* process_name, const char* options_name) const
{
	OptionsProjectionProcess proj_proc;
	proj_proc.m_name = colib::string(process_name);
	std::set<OptionsProjectionProcess>::const_iterator proc_iter = m_processes.find(proj_proc);
	if(proc_iter == m_processes.end())
	{
		return NULL;
	}
	
	OptionsProjectionFile proj_file;
	proj_file.m_name = colib::string(options_name);
	std::set<OptionsProjectionFile>::const_iterator file_iter = proc_iter->m_files.find(proj_file);
	if(file_iter == proc_iter->m_files.end())
	{
		return NULL;
	}

	return &(*file_iter);
}

void OptionsProjectionProcess::StartElement( ParseControlContext *ctx, const char *name, const char **attrs)
{
	if( !strcmp(name,"options"))
	{
		OptionsProjectionFile *pnew = new OptionsProjectionFile;

		ctx->m_cur_ctx.push_front(pnew);
		pnew->StartElement(ctx,name,attrs);
	}
}

void OptionsProjectionProcess::EndElement( ParseControlContext *ctx, const char *name )
{
	if( !strcmp(name,"name"))
	{
		if( ctx->m_text_data.is_empty() )
		{
			ctx->m_stop_for_error = true;
			ctx->m_error = colib::string::Format("Line %ld, Empty process name",
					XML_GetCurrentLineNumber(ctx->m_parser) );
			Finish(ctx);
			return;
		}
		m_name = ctx->m_text_data;
	}
	else if( !strcmp(name,"process"))
	{
		Finish(ctx);
	}
}

void OptionsProjectionProcess::ChildComplete( ParseControlContext *ctx, SAXReaderIf *child )
{
	OptionsProjectionFile *pnewchild = (OptionsProjectionFile*)child;

	if( ctx->m_stop_for_error )
	{
		delete pnewchild;
		Finish(ctx);
		return;
	}

	if( m_files.find( *pnewchild) != m_files.end() )
	{
		ctx->m_stop_for_error = true;
		ctx->m_error = colib::string::Format("Line %ld, Multiple instances of file \"%s\"",
				XML_GetCurrentLineNumber(ctx->m_parser), ctx->m_text_data.c_str() );
		delete pnewchild;
		Finish(ctx);
		return;
	}
	m_files.insert(*pnewchild);
	delete pnewchild;
	return;
}

void OptionsProjectionFile::StartElement( ParseControlContext *ctx, const char *name, const char **attrs)
{
	if( !strcmp(name,"group"))
	{
		OptionsProjectionGroup *pnewgroup = new OptionsProjectionGroup;

		ctx->m_cur_ctx.push_front(pnewgroup);
		pnewgroup->StartElement(ctx,name,attrs);
	}
}

void OptionsProjectionFile::EndElement( ParseControlContext *ctx, const char *name )
{
	if( !strcmp(name,"name"))
	{
		if( ctx->m_text_data.is_empty() )
		{
			ctx->m_stop_for_error = true;
			ctx->m_error = colib::string::Format("Line %ld, Empty options file name",
					XML_GetCurrentLineNumber(ctx->m_parser) );
			Finish(ctx);
			return;
		}
		m_name = ctx->m_text_data;
	}
	else if( !strcmp(name,"options"))
	{
		Finish(ctx);
	}
}

void OptionsProjectionFile::ChildComplete( ParseControlContext *ctx, SAXReaderIf *child )
{
	OptionsProjectionGroup *pnewchild = (OptionsProjectionGroup*)child;

	if( ctx->m_stop_for_error )
	{
		delete pnewchild;
		Finish(ctx);
		return;
	}

	if( m_groups.find( *pnewchild) != m_groups.end() )
	{
		ctx->m_stop_for_error = true;
		ctx->m_error = colib::string::Format("Line %ld, Multiple instances of group \"%s\"",
				XML_GetCurrentLineNumber(ctx->m_parser), ctx->m_text_data.c_str() );
		delete pnewchild;
		Finish(ctx);
		return;
	}
	m_groups.insert(*pnewchild);
	delete pnewchild;
	return;
}

void OptionsProjectionGroup::EndElement( ParseControlContext *ctx, const char *name )
{
	if( !strcmp(name,"name"))
	{
		if( ctx->m_text_data.is_empty() )
		{
			ctx->m_stop_for_error = true;
			ctx->m_error = colib::string::Format("Line %ld, Empty group name",
					XML_GetCurrentLineNumber(ctx->m_parser) );
			Finish(ctx);
			return;
		}
		if( !m_name.SetPattern(ctx->m_text_data) )
		{
			ctx->m_stop_for_error = true;
			ctx->m_error = colib::string::Format("Line %ld, %s",
					XML_GetCurrentLineNumber(ctx->m_parser), m_name.GetLastError().c_str() );
			Finish(ctx);
			return;
		}
	}
	else if( !strcmp(name,"key"))
	{
		if( ctx->m_text_data.is_empty() )
		{
			ctx->m_stop_for_error = true;
			ctx->m_error = colib::string::Format("Line %ld, Empty key name",
					XML_GetCurrentLineNumber(ctx->m_parser) );
			Finish(ctx);
			return;
		}
		Regex newreg;
		if( !newreg.SetPattern(ctx->m_text_data) )
		{
			ctx->m_stop_for_error = true;
			ctx->m_error = colib::string::Format("Line %ld, %s",
					XML_GetCurrentLineNumber(ctx->m_parser), newreg.GetLastError().c_str() );
			Finish(ctx);
			return;
		}
		if( m_keys.find(newreg) != m_keys.end() )
		{
			ctx->m_stop_for_error = true;
			ctx->m_error = colib::string::Format("Line %ld, Multiple instances of key \"%s\"",
					XML_GetCurrentLineNumber(ctx->m_parser), ctx->m_text_data.c_str() );
			Finish(ctx);
			return;
		}

		m_keys.insert(newreg);
	}
	else if( !strcmp(name,"group"))
	{
		Finish(ctx);
	}
}

}//end namespace colib

