//saxif.h
// vi:set ts=4 sw=4 nowrap:

#ifndef SAXIF_H_ALREADY_INCLUDED
#define SAXIF_H_ALREADY_INCLUDED

#include <expat.h>
#include <list>
#include <stdio.h>
#include <utils/string.h>

namespace colib
{

class ParseControlContext;
class SAXReaderIf
{
public:
	virtual ~SAXReaderIf();
	virtual void StartElement( ParseControlContext *ctx, const char *name, const char **attrs);
	virtual void EndElement( ParseControlContext *ctx, const char *name );
	virtual void Text( ParseControlContext *ctx, const char *text, int len );

	virtual void ChildComplete( ParseControlContext *ctx, SAXReaderIf *child );

	void Finish( ParseControlContext *ctx );

	//blocking loaders:
	bool LoadFromString( colib::string xmlstring, colib::string &err );
	bool LoadFromFile( colib::string path, colib::string &err );
	bool LoadFromFile( FILE *file, colib::string &err );

};

class ParseControlContext
{
public:
	ParseControlContext();
	~ParseControlContext();

	std::list< SAXReaderIf* > m_cur_ctx;
	XML_Parser m_parser;
	bool m_stop_for_error;
	colib::string m_error;
	colib::string m_text_data;
	bool m_begun;

	bool Init();
	bool ReadInFromFile( colib::string path, SAXReaderIf *pif=0 );
	bool ReadInFromFile( FILE *file, SAXReaderIf *pif=0 );
	bool ReadInFromString( colib::string xmltext, SAXReaderIf *pif=0 );
	static void StartElement( void *userData, const char *name, const char **atts);
	static void EndElement( void *userData, const char *name);
	static void HandleContent( void *userData, const char *s, int len);
};

}//end namespace colib

#endif

