//project.cpp
// vi:set ts=4 sw=4 nowrap:

#include <xmlutil/project.h>
#include <options/options.h>

namespace colib
{

bool	ProjectOptions(
		const OptionsProjectionFile &filter,
		const Options &from,
		Options &to )
{
	to.Clear();

	//iterate over each group

	OptionsNodeEdit toNodeEdit = to.GetRootOptionsNodeEdit();

	OptionsNodeIterator grpiter = from.begin();
	for(; grpiter != from.end(); ++ grpiter) {
		OptionsNode group_from = *grpiter;
		const char* group_name = grpiter.Key();
		
		if (!group_name) continue;

		//iterate over each projgroup
		std::set<OptionsProjectionGroup>::const_iterator pat_grp_iter;
		for ( pat_grp_iter = filter.m_groups.begin(); pat_grp_iter != filter.m_groups.end(); ++pat_grp_iter )
		{
			//if group name matches
			if (pat_grp_iter->m_name.Matches(group_name) )
			{	
				bool all_present = true;

				//iterate over each key in group
			
				OptionsNodeIterator keyiter = group_from.begin();
				for (; keyiter != group_from.end(); ++ keyiter) 

				{	
					//const Key* key_from = keyiter->GetData();
					OptionsNode key_from = *keyiter;
					const char* key_name = keyiter.Key();

					if (!key_name) continue;

					bool added = false;
					//iterate over each filterkey
					std::set<colib::Regex>::const_iterator pattern_iter;
					for ( pattern_iter = pat_grp_iter->m_keys.begin(); pattern_iter != pat_grp_iter->m_keys.end(); ++pattern_iter )
					{
						// if(match) add
						if ( pattern_iter->Matches(key_name) )
						{
							//find or add new group if not exist and add the key.
							toNodeEdit.GetChildNodeEdit(group_name, true).AddObject(key_name, key_from, true);
							added = true;
							break;
						}
					}
					if ( !added ) all_present = false;
				}
				if ( all_present ) break;
			}
		}
	}

	return true;
}

}//end namespace colib



