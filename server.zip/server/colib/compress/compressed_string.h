//compressed_string.h
// vi:set ts=4 sw=4 nowrap:

#ifndef COMPRESSED_STRING_H_ALREADY_INCLUDED
#define COMPRESSED_STRING_H_ALREADY_INCLUDED

#include<utils/string.h>
#include<utils/xdr.h>

namespace colib
{

class CompressedString
{
public:
	CompressedString();
	~CompressedString();

	bool Compress(const string &str);
	bool Decompress( string &str );

	bool XdrProc( CXDR *xdr );

	string GetLastError() const { return m_last_error; }

private:
	char *m_buf;
	unsigned long m_buf_size;
	unsigned long m_orig_size;
	unsigned int m_compress_algorithm;
	string m_last_error;
};

}

#endif

