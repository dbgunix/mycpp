#include<compress/compress_base.h>

namespace colib
{

Compress::Compress()
	: m_algo_id(0)
	, m_threshold(COMPRESS_BASE_THRESHOLD)
{
}

Compress::Compress(unsigned char algo_id)
	: m_algo_id(algo_id)
	, m_threshold(COMPRESS_BASE_THRESHOLD)
{
}

}
