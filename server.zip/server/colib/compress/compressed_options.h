//compressed_options.h
// vi:set ts=4 sw=4 nowrap:

#ifndef COMPRESSED_OPTIONS_H_ALREADY_INCLUDED
#define COMPRESSED_OPTIONS_H_ALREADY_INCLUDED

#include<message/message.h>

namespace colib
{

class CompressedOptionsDataMsg : public Message
{
public:
	CompressedOptionsDataMsg() {}
	virtual ~CompressedOptionsDataMsg() {}

	void SetOptions(string to) { m_options_string = to; }
	string GetOptions() { return m_options_string; }

	string GetLastError() { return m_last_error; }

private:
	virtual bool XdrProc(CXDR* pXDR);

	string m_options_string;
	string m_last_error;
};

}// end namespace colib

#endif

