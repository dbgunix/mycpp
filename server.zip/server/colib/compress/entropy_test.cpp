#include<compress/entropy_test.h>

#include <string.h>
#include <math.h>
#include <stdint.h>

namespace colib
{

namespace EntropyTest
{

namespace
{

double s_log_table[MAX_BUFFER_SIZE + 1];

bool build_log_table()
{
	s_log_table[0] = 0;
	for (unsigned ix = 1; ix < sizeof(s_log_table) / sizeof(s_log_table[0]); ++ix)
		s_log_table[ix] = ix * log10(ix);
	return true;
}

const bool s_built_log_table = build_log_table();

}

bool IsCompressible(const void *data, unsigned len, float limit)
{
	// Count occurrences of each possible byte value
	unsigned count[256] = { };
	for (const uint8_t *buffer = reinterpret_cast<const uint8_t *>(data), *end = buffer + len;
			buffer < end; ++buffer)
		++count[*buffer];

	// Calculate Shannon Entropy
	double entropy = s_log_table[len];
	for (const unsigned *cnt = count, *end = count + 256; cnt < end; ++cnt)
		if (*cnt > 0)
			entropy -= s_log_table[*cnt];

	return entropy < limit * len;
}

}

}
