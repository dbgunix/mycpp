//compressed_string.cpp
// vi:set ts=4 sw=4 nowrap:

#include<compress/compressed_string.h>
#include<compress/zlib_compress.h>

#include <string.h>

namespace colib
{

CompressedString::CompressedString()
	: m_buf(0)
	, m_buf_size(0)
	, m_orig_size(0)
	, m_compress_algorithm(0)
{
}

CompressedString::~CompressedString()
{
	if(m_buf)
	{
		delete [] m_buf;
		m_buf=0;
	}
}

bool CompressedString::Compress(const string &str)
{
	if(m_buf)
	{
		delete [] m_buf;
		m_buf=0;
	}
	//create a temp buffer the size of the string
	//try to compress, if the string is uncompressible, simply store it as is
	//only return false if there is a memory error
	if(str.is_empty())
	{
		m_compress_algorithm=0;
		m_orig_size=0;
		m_buf_size=0;
		return true;
	}

	m_orig_size = str.get_length();
	// We don't want to compress, if the compressed size is
	// larger than original, therefore we don't flollow
	// Zlib manual
	//m_buf_size=(m_orig_size* 1.1) + 12; //regarding Zlib manual
	m_buf_size= m_orig_size;
	m_buf = new char[ m_orig_size ];
	if(!m_buf)
	{
		m_last_error = "out of memory";
		return false;
	}

	ZlibCompress compressor;
	Compress::CompressRes res = compressor.CompressBlock(m_buf, &m_buf_size, str.c_str(), m_orig_size);

	switch (res)
	{
		case Compress::SMALLPACKET:
		case Compress::UNCOMPRESSIBLE:
		case Compress::NOTCOMPRESSED:
			memcpy(m_buf,str.c_str(),m_orig_size);
			m_compress_algorithm=0;
			m_buf_size=m_orig_size;
			return true;
		case Compress::SUCCEED:
			m_compress_algorithm=compressor.GetAlgorithm();
			return true;
		case Compress::ALGOFAILURE:
		case Compress::OUTOFMEMORY:
		case Compress::HEADERFAILURE:
			break;
	}
	// ALGOFAILURE, OUTOFMEMORY, HEADERFAILURE or unknown result
	m_last_error = compressor.GetLastError();
	delete [] m_buf;
	m_buf=0;
	return false;
}

bool CompressedString::Decompress(string &str)
{
	str.empty();
	if(!m_buf)
		return true;

	if(m_compress_algorithm == 0)
	{
		str = string(m_buf, static_cast<unsigned int>(m_buf_size));
		return true;
	}

	if( !str.set_maxlength(m_orig_size) )
	{
		m_last_error = "out of memory";
		return false;
	}

	char *dest = str.get_buffer();
	unsigned long dest_size = m_orig_size;
	ZlibCompress compressor;

	Compress::CompressRes res = compressor.DecompressBlock(dest, &dest_size, m_buf, m_buf_size);

	if( res == Compress::SUCCEED )
	{
		dest[dest_size] = 0;
		return true;
	}

	str.empty();

	m_last_error = compressor.GetLastError();

	return false;
}

bool CompressedString::XdrProc( CXDR *xdr )
{
	if (xdr->GetOp() == CXDR::XDR_DECODE)
	{
		if(m_buf)
		{
			delete [] m_buf;
			m_buf=0;
		}
		unsigned alg(0), buf_size(0), orig_size(0);
		if(
			!xdr->XdrUint(&alg) ||
			!xdr->XdrUint(&buf_size) ||
			!xdr->XdrUint(&orig_size)
			)
		{
			return false;
		} 

		m_compress_algorithm = alg;
		m_buf_size = buf_size;
		m_orig_size = orig_size;

		if(m_buf_size > xdr->GetRemaining() )
		{
			m_last_error = "improbable size given";
			return false;
		}
		if( m_buf_size > 0 )
		{
			m_buf = new char [m_buf_size];
			if(!m_buf)
			{
				m_last_error = "out of memory";
				return false;
			}
		}
	}
	else
	{
		// encode
		unsigned alg(m_compress_algorithm), buf_size(m_buf_size), orig_size(m_orig_size);
		if(
			!xdr->XdrUint(&alg) ||
			!xdr->XdrUint(&buf_size) ||
			!xdr->XdrUint(&orig_size)
			)
		{
			return false;
		}
	}

	if( m_buf_size>0 && !xdr->XdrBytes(m_buf,m_buf_size) )
	{
		return false;
	}
	return true;
}

}
