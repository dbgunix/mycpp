#include<compress/zlib_compress.h>

#include <zlib.h>

namespace colib
{

ZlibCompress::ZlibCompress()
	: Compress(1)
{
}

Compress::CompressRes ZlibCompress::CompressBlock(void *des, unsigned long *des_len, const void *src, unsigned long src_len)
{

	int err = compress((Bytef*)des, des_len, (Bytef*)src, src_len);
	if(err != Z_OK)
	{
		if(err == Z_BUF_ERROR)
		{
			m_last_error = "output buffer is not large enough";
			return UNCOMPRESSIBLE;
		}
		else
		{
			m_last_error = "out of memory";
			return ALGOFAILURE;
		}
	}
	else if(*des_len >= src_len)
	{
		m_last_error = colib::string::Format("compressed len:%lu clear text len: %lu", *des_len, src_len);
		return UNCOMPRESSIBLE;
	}
	return SUCCEED;
}

Compress::CompressRes ZlibCompress::DecompressBlock(void *des, unsigned long *des_len, const void *src, unsigned long src_len)
{
	int err = uncompress((Bytef*)des, des_len, (Bytef*)src, src_len);
	if(err == Z_OK)
	{
		return SUCCEED;
	}
	else
	{
		m_last_error = "failed to uncompress buffer";
		return ALGOFAILURE;
	}
}

}
