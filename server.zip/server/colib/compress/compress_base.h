#ifndef COMPRESS_BASE_H
#define COMPRESS_BASE_H

#include "entropy_test.h"
#include<utils/string.h>
#include<utils/data_buffer.h>
#include<utils/system/macros.h>

namespace colib
{

class Compress
{
public:
	enum CompressRes
	{
		SUCCEED,
		SMALLPACKET,
		ALGOFAILURE,
		UNCOMPRESSIBLE,
		NOTCOMPRESSED,
		OUTOFMEMORY,
		HEADERFAILURE
	};

	Compress();
	Compress(unsigned char algo_id);
	virtual ~Compress(){};

	virtual CompressRes CompressBlock(void *des, unsigned long  *des_len, const void *src, unsigned long src_len) = 0;
	virtual CompressRes DecompressBlock(void *des, unsigned long *des_len, const void *src, unsigned long src_len) = 0;

	template <uint32_t N>
	CompressRes CompressMssg(DataBuffer<N>* pPacket);
	template <uint32_t N>
	CompressRes DecompressMssg(DataBuffer<N>* pPacket);

	// Compresses payload in place without changing payload offset, thus leaving headers intact in
	// buffer.  E.g., buf.RemoveHeader(hlen); CompressMssgInPlace(buf); buf.InsertHeader(hlen);
	template <uint32_t N>
	CompressRes CompressMssgInPlace(DataBuffer<N>* pPacket);

	// Decompresses payload in place without changing payload offset, thus leaving headers intact in
	// buffer
	template <uint32_t N>
	CompressRes DecompressMssgInPlace(DataBuffer<N>* pPacket);

	void SetThreshold(int threshold) { m_threshold = threshold; }
	int GetThreshold() const { return m_threshold; }

	colib::string GetLastError() const { return m_last_error; };

	unsigned char GetAlgorithm() const { return m_algo_id; }

	static const unsigned HEADER_LENGTH = sizeof(uint16_t); // caller may need this

protected:
	unsigned char m_algo_id;
	colib::string m_last_error;

private:
	static const int BLOCK_PADDING = 128;
	//according to RFC 1951 compress threshold is around 90
	static const int COMPRESS_BASE_THRESHOLD = 90;
	template <uint32_t N>
	CompressRes InsertHeader(DataBuffer<N>* packet, bool compressed, unsigned long orig_len);
	int m_threshold;
};

template <uint32_t N>
Compress::CompressRes Compress::CompressMssg(DataBuffer<N>* pPacket)
{
	const int BLOCK_SIZE = N + BLOCK_PADDING; // depends on template param

	CompressRes retVal = SUCCEED;
	unsigned char output_block[BLOCK_SIZE];
	unsigned long  encoded_len = BLOCK_SIZE;
	unsigned long decoded_len = pPacket->GetLength();

	if((int)decoded_len <= m_threshold)
	{
		m_last_error = string::Format("packet length too small, length: %lu threshold: %d",
				decoded_len, m_threshold);
		retVal = SMALLPACKET;
	}
	else
	{
		retVal = CompressBlock(output_block, &encoded_len, pPacket->GetData(), decoded_len);

		if(retVal == SUCCEED)
		{
			if(pPacket->SetLength(encoded_len))
			{
				memcpy(pPacket->GetData(), output_block, encoded_len);
			}
			else
			{
				retVal = ALGOFAILURE; // pkt is invalid, must not be forwarded
			}
		}
	}

	CompressRes HeaderRetVal = InsertHeader(pPacket, (retVal==SUCCEED), decoded_len);

	if(HeaderRetVal == SUCCEED)
	{
		return retVal;
	}
	else
	{
		return HeaderRetVal;
	}
}

template <uint32_t N>
Compress::CompressRes Compress::DecompressMssg(DataBuffer<N>* pPacket)
{
	const int BLOCK_SIZE = N + BLOCK_PADDING; // depends on template param

	//get header
	uint16_t hdr = NET_GET16(pPacket->GetData());
	unsigned long length = hdr >> 2;
	unsigned char algo_id = hdr & 0x3;

	pPacket->RemoveHeader(HEADER_LENGTH);
	if(algo_id == 0)
	{
		return NOTCOMPRESSED;
	}
	if(algo_id != m_algo_id)
	{
		m_last_error = "compression algorithm don't match";
		return ALGOFAILURE;
	}

	unsigned char output_block[BLOCK_SIZE];
	unsigned long decoded_len = BLOCK_SIZE;
	CompressRes retVal = DecompressBlock(output_block, &decoded_len, pPacket->GetData(), pPacket->GetLength());

	if(retVal == SUCCEED && decoded_len != length)
	{
		retVal = ALGOFAILURE;
	}
	if(retVal == SUCCEED)
	{
		if(pPacket->SetLength(decoded_len))
		{
			memcpy(pPacket->GetData(), output_block, decoded_len);
		}
		else
		{
			m_last_error = "packet is not large enough to hold uncompressed data.";
			retVal = OUTOFMEMORY;
		}
	}

	return retVal;
}

template <uint32_t N>
Compress::CompressRes Compress::CompressMssgInPlace(DataBuffer<N>* pPacket)
{
	const int BLOCK_SIZE = N + BLOCK_PADDING;

	CompressRes retVal = SUCCEED;
	unsigned char output_block[BLOCK_SIZE];
	unsigned long encoded_len = BLOCK_SIZE;
	unsigned long decoded_len = pPacket->GetLength();

	if((int)decoded_len <= m_threshold)
	{
		m_last_error = string::Format("packet length too small, length: %lu threshold: %d",
			decoded_len, m_threshold);
		retVal = SMALLPACKET;
	}
	else if (!EntropyTest::IsCompressible(pPacket->GetData(), decoded_len))
	{
		m_last_error = "insufficient entropy";
		retVal = UNCOMPRESSIBLE;
	}
	else
	{
		retVal = CompressBlock(output_block, &encoded_len, pPacket->GetData(), decoded_len);
		if(retVal == SUCCEED && !pPacket->SetLength(encoded_len))
		{
			retVal = ALGOFAILURE;
		}
	}

	// Place compression header at start of old payload to avoid overwriting preceding headers.
	if(!pPacket->AddTrailer(HEADER_LENGTH) || !pPacket->RemoveHeader(HEADER_LENGTH))
	{
		return HEADERFAILURE; // failure, pkt now invalid, ignore previous retVal
	}

	char *payload = pPacket->GetData();

	if(retVal != SUCCEED)
	{
		// Compression failed (rare), shift payload right to make room for header.
		memmove(payload, payload - HEADER_LENGTH, pPacket->GetLength());
	}

	CompressRes HeaderRetVal = InsertHeader(pPacket, retVal==SUCCEED, decoded_len);
	if(HeaderRetVal != SUCCEED)
	{
		return HeaderRetVal; // failure, pkt now invalid, ignore previous retVal
	}

	if(retVal == SUCCEED)
	{
		memcpy(payload, output_block, encoded_len); // copy compressed payload to pkt
	}

	return retVal;
}

template <uint32_t N>
Compress::CompressRes Compress::DecompressMssgInPlace(DataBuffer<N>* pPacket)
{
	const int BLOCK_SIZE = N + BLOCK_PADDING;

	//parse header
	uint16_t hdr = NET_GET16(pPacket->GetData());
	uint16_t length = hdr >> 2;
	unsigned char algo_id = hdr & 3;

	if(algo_id == 0)
	{
		// Remove compression header and move payload to close gap
		pPacket->RemoveTrailer(HEADER_LENGTH);
		memmove(pPacket->GetData(), pPacket->GetData() + HEADER_LENGTH, pPacket->GetLength());
		return NOTCOMPRESSED;
	}
	if(algo_id != m_algo_id)
	{
		m_last_error = "compression algorithm don't match";
		return ALGOFAILURE;
	}

	unsigned char output_block[BLOCK_SIZE];
	unsigned long decoded_len = BLOCK_SIZE;
	CompressRes retVal = DecompressBlock(output_block, &decoded_len,
			pPacket->GetData() + HEADER_LENGTH, pPacket->GetLength() - HEADER_LENGTH);

	if (retVal == SUCCEED)
	{
		if (decoded_len != length)
		{
			retVal = ALGOFAILURE;
		}
		else if(pPacket->SetLength(decoded_len))
		{
			// Place decompressed payload at start of compression header to avoid need to move
			// preceding headers
			memcpy(pPacket->GetData(), output_block, decoded_len);
		}
		else
		{
			m_last_error = "packet is not large enough to hold uncompressed data.";
			retVal = OUTOFMEMORY;
		}
	}

	return retVal;
}

template<uint32_t N>
Compress::CompressRes Compress::InsertHeader(DataBuffer<N>* pPacket, bool compressed,
	unsigned long orig_len)
{
	if(!pPacket->InsertHeader(HEADER_LENGTH))
	{
		//maybe we shall allocate another mssg?
		m_last_error = "Packet does not have enough space for header";
		return HEADERFAILURE;
	}

	unsigned char algo_id = compressed ? m_algo_id : 0;

	//length: 14 bits, algo_id: 2 bits
	uint16_t hdr = (orig_len << 2) | (algo_id & 3);

	NET_SET16(pPacket->GetData(), hdr);

	return SUCCEED;
}

}

#endif
