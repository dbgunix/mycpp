#ifndef ZLIBCOMPRESS_H
#define ZLIBCOMPRESS_H

#include<compress/compress_base.h>

namespace colib
{

class ZlibCompress : public Compress
{
public:
	ZlibCompress();
	~ZlibCompress() {}

	virtual CompressRes CompressBlock(void *des, unsigned long *des_len, const void *src, unsigned long src_len);
	virtual CompressRes DecompressBlock(void *des, unsigned long *des_len, const void *src, unsigned long src_len);
};

}

#endif
