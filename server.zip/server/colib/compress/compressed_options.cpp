//compressed_options.cpp
// vi:set ts=4 sw=4 nowrap:

#include<compress/compressed_options.h>
#include<compress/compressed_string.h>

namespace colib
{

bool CompressedOptionsDataMsg::XdrProc(CXDR* xdr)
{
	CompressedString temp;

	if (xdr->GetOp() == CXDR::XDR_ENCODE)
	{
		if( !temp.Compress(m_options_string) )
		{
			m_last_error = temp.GetLastError();
			return false;
		}
	}

	if (!temp.XdrProc(xdr) )
	{
		m_last_error = temp.GetLastError();
		return false;
	}

	if (xdr->GetOp() == CXDR::XDR_DECODE)
	{
		if( !temp.Decompress(m_options_string) )
		{
			m_last_error = temp.GetLastError();
			return false;
		}
	}
	return true;
}

}// end namespace colib

