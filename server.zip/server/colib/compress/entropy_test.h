#ifndef _ENTROPY_TEST_H
#define _ENTROPY_TEST_H

namespace colib
{

// Test to see if a data block is compressible or not
namespace EntropyTest
{
	// default TCP chunk size is 6k, allow for larger custom value
	// anything >= OTA MTU is sufficient for UDP
	const unsigned MAX_BUFFER_SIZE = 8192;

	// Computes the Shannon entropy density of a data block in bits/byte, returns true if
	// block is compressible (if density less than limit).
	bool IsCompressible(const void *data, unsigned len, float limit = 1.93);
}

}

#endif

