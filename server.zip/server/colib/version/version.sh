#!/bin/bash

export VERSION_STR="0.0.0.5"
