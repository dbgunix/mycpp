//version_str.cpp
// vi:set ts=4 sw=4 nowrap:

#include <stdio.h>

#include<version/version.h>
#include<version/version_str.h>

class AppVersionString
{
public:
	AppVersionString();
	colib::string GetApplicationVersion() const { return m_version_string; }
private:
	colib::string m_version_string;
};

AppVersionString::AppVersionString()
	: m_version_string(16)
{
	for (int ii(0); ii < colib::GetVersionNumbersCount(); ++ii)
	{
		if (ii > 0)
		{
			m_version_string += '.';
		}
		m_version_string.AppendFmt("%d", colib::GetVersionNumber(ii));
	}
}

static AppVersionString g_version_string;

colib::string GetApplicationVersion()
{
	return g_version_string.GetApplicationVersion();
}


bool IsThreeDigitMatch(const colib::string str_version)
{
	if(str_version.is_empty())
		return false;

	int ver_digit[4];
	int iNum = sscanf(str_version.c_str(),"%i.%i.%i.%i", &ver_digit[0], &ver_digit[1], &ver_digit[2], &ver_digit[3]);
	if(4 != iNum){
	//	TRACE("Error parsing version string: %s\n", str_version.c_str());
		return false;
	}

	// compare three digits only
	for(int i=0; i < 3; ++i) {
		if(colib::GetVersionNumber(i) != ver_digit[i])
			return false;
	}

	return true;
}

