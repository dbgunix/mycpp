//version_str.h
// vi:set ts=4 sw=4 nowrap:

#ifndef VERSION_STR_H_ALREADY_INCLUDED
#define VERSION_STR_H_ALREADY_INCLUDED

#include<utils/string.h>

colib::string GetApplicationVersion();

bool IsThreeDigitMatch(const colib::string str_version);

#endif

