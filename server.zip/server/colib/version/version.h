//version.h

#ifndef __VERSION_H__
#define __VERSION_H__

namespace AppVersion
{

extern const char *label;

extern const char *comment;
extern const char *built_user;
extern const char *built_date;
extern const char *built_gcc_version;
extern const char *built_kernel_version;
extern const char *built_host_name;
extern const char *built_os_name;
extern const char *built_platform;


extern const char *description;

extern unsigned int g_version[4];

} // end namespace AppVersion

namespace colib
{

const char *GetApplicationName();
int GetVersionNumber( int index );
int GetVersionNumbersCount();

}

#endif

