//version.cpp

#include<version/version.h>

namespace AppVersion
{

//*********************************************************************************
//**** when changing the version please update the file "version.sh" as well ********
#define My_MAJOR_VERSION     0
#define My_MINOR_VERSION     0
#define My_REVISION_NUMBER   0
#define My_PATCH_NUMBER      5


#ifdef __GNUC__
__attribute__((weak)) const char *label = "unlabeled";

__attribute__((weak)) const char *comment = "no comment";

__attribute__((weak)) const char *description = "unlabeled build";

__attribute__((weak)) unsigned int g_version[4] = {My_MAJOR_VERSION,My_MINOR_VERSION,My_REVISION_NUMBER,My_PATCH_NUMBER};

#else //not defined __GNUC__
unsigned int g_version[4] = {My_MAJOR_VERSION,My_MINOR_VERSION,My_REVISION_NUMBER,My_PATCH_NUMBER};
#endif

} // end namespace AppVersion

namespace colib
{
#if defined( __GNUC__)
__attribute__((weak)) const char *GetApplicationName()
{
	return "XXUnnamedApplicationXX";
}
#endif

static const int version_numbers_count = sizeof(::AppVersion::g_version)/sizeof(::AppVersion::g_version[0]);

#if defined( __GNUC__)
int GetVersionNumber( int index )
{
	if(index>=0 && index< version_numbers_count)
	{
		return ::AppVersion::g_version[index];
	}
	return -1;
}

int GetVersionNumbersCount()
{
	return (int)version_numbers_count;
}
#endif

}


