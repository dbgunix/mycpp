#include<socket/socket_buffer_pool.h>
#include<utils/trace/writable.h>

namespace colib
{

// Use fewer buffers on embedded targets due to memory constraints:
// NOTE: temporary solution (hopefully)
#if defined(PLATFORM_HUB)
static const int MAX_SOCKET_BUFFERS = 5000;
#elif defined(PLATFORM_NUEVO)
static const int MAX_SOCKET_BUFFERS = 500;
#else
static const int MAX_SOCKET_BUFFERS = 250000;
#endif

SocketBufferPool::SocketBufferPool()
	: BufferPool<SocketBuffer>(MAX_SOCKET_BUFFERS)
	, m_initialized(false)
{
}

SocketBufferPool& SocketBufferPool::GetInstance()
{
	static SocketBufferPool m_instance;
	return m_instance;
}

bool SocketBufferPool::Init(int amount)
{
	bool ret = true;
	if (!m_initialized)
	{
		ret = Allocate(amount) == amount;
		m_initialized = true; //TODO: set to "ret" instead?
	}
	return ret;
}

void SocketBufferPool::ConsoleCommand(Writable* con, int argc, char* argv[])
{
	(void)argc;
	(void)argv;

	if (!con)
	{
		return;
	}

	con->Print("SocketBufferPool: %d / %d available\n", Available(), NumAllocated());
}


}
