#include <socket/stream/stream_server.h>
#include <socket/stream/stream_client_handler.h>
#include <utils/trace/trace.h>
#include <utils/trace/writable.h>
#include <event_loop/event_loop.h>
#include <console/command/debug.h>

#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <sys/socket.h>
#include <ctype.h>

namespace colib
{

StreamServer::StreamServer(const char *name, StreamBase::TlsOpt tls, StreamBase::XdrOpt xdr)
	: FileDescriptorHandler(name, -1, READ_NOTIFY_FLAG)
	, m_clients()
	, m_clients_to_close()
	, m_client_on_read()
	, m_client_on_awaken()
	, m_client_on_close()
	, m_client_on_write_done()
	, m_new_client_cb()
	, m_client_close_act(callbackRt(this, &StreamServer::ClosePendingClients), string::Format("%s_client_close", name))
	, m_listen_addr()
	, m_trace_set()
	, m_tls_opt(tls)
	, m_xdr_opt(xdr)
	, m_socket_params()
	, m_expected_client_common_name()
	, m_next_uid(1)  
{
}

StreamServer::~StreamServer()
{
	DeleteClients();
	if (m_listen_addr.GetType() == PF_UNIX)
	{
		unlink(reinterpret_cast<sockaddr_un*>(m_listen_addr.m_data)->sun_path);
	}
}

bool StreamServer::Init(string listen_addr)
{
	// in case of multiple Init calls
	Shutdown();

	if (!m_listen_addr.SetFromString(listen_addr))
	{
		TRACE("%s::%s -- Failed to parse address: %s\n", m_name.c_str(), __FUNCTION__, listen_addr.c_str());
		return false;
	}

	if (m_listen_addr.GetType() == PF_UNIX)
	{
		unlink(reinterpret_cast<sockaddr_un*>(m_listen_addr.m_data)->sun_path);
	}

	//create the socket
	m_fd = socket(m_listen_addr.GetType(), SOCK_STREAM, 0 );

	if (m_fd < 0)
	{
		TRACE("%s::%s -- socket() failure: %s\n", m_name.c_str(), __FUNCTION__, strerror(errno));
		return false;
	}

	if (!MakeNonBlocking())
	{
		close(m_fd);
		m_fd = -1;
		return false;
	}

	int enable = 1;
	if (setsockopt(m_fd,SOL_SOCKET, SO_REUSEADDR, &enable, sizeof(enable)) < 0)
	{
		TRACE("%s::%s -- failed to set reuseaddr %s\n", m_name.c_str(), __FUNCTION__, strerror(errno));
		close(m_fd);
		m_fd = -1;
		return false;
	}
	//bind the socket
	if (bind(m_fd, m_listen_addr.m_data, m_listen_addr.m_data_len) < 0)
	{
		TRACE("%s::%s -- failed to bind socket to %s: %s\n", m_name.c_str(), __FUNCTION__, listen_addr.c_str(), strerror(errno));
		close(m_fd);
		m_fd = -1;
		return false;
	}
	//listen
	if (listen(m_fd, SOMAXCONN) < 0)
	{
		TRACE("%s::%s -- failed to listen on %s: %s\n", m_name.c_str(), __FUNCTION__, listen_addr.c_str(), strerror(errno));
		close(m_fd);
		m_fd = -1;
		return false;
	}

	//attach to event loop
	if (!EventLoop::GetInstance().AddHandler(*this))
	{
		TRACE("%s::%s -- failed to register with event loop\n", m_name.c_str(), __FUNCTION__);
		close(m_fd);
		m_fd = -1;
		return false;
	}
	SetFlag(FileDescriptorHandler::READ_NOTIFY_FLAG);

	return true;
}

bool StreamServer::Reload(const OptionsNode& base_opts, const OptionsNode& tls_opts)
{
	bool ret = m_socket_params.GetParams().LoadFromOptions(base_opts);
	if (m_tls_opt == StreamBase::TlsOpt::ENABLE_TLS)
	{
		ret = m_socket_params.GetTlsParams().LoadFromOptions(tls_opts) && ret;
	}
	return ret;
}

void StreamServer::Shutdown()
{
	if (m_fd > 0)
	{
		member_TRACE(&m_trace_set, 0, "%s: shutting down\n", m_name.c_str());
		EventLoop::GetInstance().RemoveHandler(*this);
		close(m_fd);
		m_fd = -1;
	}
	m_clients_to_close.clear();
	DeleteClients();
}

void StreamServer::ScheduleClose(int fd)
{
	member_TRACE(&m_trace_set, 4, "SCH with fd %d requesting close\n", fd);
	m_clients_to_close.push_back(fd);
	EventLoop::GetInstance().AddActivity(&m_client_close_act);
}

bool StreamServer::SendMsgToClient(int client_id, Message &msg)
{
	auto it(m_clients.find(client_id));
	if (it == m_clients.end())
	{
		member_TRACE(&m_trace_set, 0, "Unable to find client %d to send msg %d\n", client_id, msg.GetType());
		return false;
	}
	return it->second->WriteMessage(msg);
}

StreamWriteError StreamServer::GetClientLastWriteError(int client_id) const
{
	auto it(m_clients.find(client_id));
	if (it == m_clients.end()) return StreamWriteError::INVALID_FD;
	return it->second->GetLastWriteError();
}

bool StreamServer::SendCEncodableItemToClient(int client_id, CEncodableItem &msg)
{
	auto it(m_clients.find(client_id));
	if (it == m_clients.end())
	{
		member_TRACE(&m_trace_set, 0, "Unable to find client %d to send EncodableItem\n", client_id);
		return false;
	}
	return it->second->WriteXdrData(msg);
}

bool StreamServer::SendBytesToClient(int client_id, const char* data, int length)
{
	auto it(m_clients.find(client_id));
	if (it == m_clients.end())
	{
		member_TRACE(&m_trace_set, 0, "Unable to find client %d to send bytes\n", client_id);
		return false;
	}
	return it->second->WriteBytes(data, length);
}

bool StreamServer::SendMsgToAllClients(Message &msg)
{
	for (auto it(m_clients.begin()); it != m_clients.end(); ++it)
	{
		it->second->WriteMessage(msg);
	}
	return true;
}

bool StreamServer::SendBytesToAllClients(const char* buf, int len)
{
	for (auto it(m_clients.begin()); it != m_clients.end(); ++it)
	{
		it->second->WriteBytes(buf, len);
	}
	return true;
}

bool StreamServer::CloseClientHandler(int id)
{
	auto it(m_clients.find(id));
	if (it != m_clients.end())
	{
		member_TRACE(&m_trace_set, 3, "Server initiated close of client %d\n", id);
		ScheduleClose(id);
		return true;
	}
	else
	{
		member_TRACE(&m_trace_set, 0, "Failed to find client %d for server initiated close\n", id);
		return false;
	}
}

void StreamServer::SetClientCallbacks(StreamClientHandler *ch)
{
	if (m_xdr_opt != StreamBase::XdrOpt::ENABLE_XDR)
	{
		ch->SetReadCallback(m_client_on_read);
	}
	ch->SetAwakenCallback(m_client_on_awaken);
	ch->SetCloseCallback(m_client_on_close);
	ch->SetWriteDoneCallback(m_client_on_write_done);
}

StreamClientHandler* StreamServer::AllocClient(int fd)
{
	return new StreamClientHandler(string::Format("%s_client%d", m_name.c_str(), fd), fd, *this, m_tls_opt, m_xdr_opt);
}

StreamClientHandler* StreamServer::CreateClient(int fd, const SocketAddr& local_addr, const SocketAddr& peer_addr)
{
	StreamClientHandler* new_sch = AllocClient(fd);
	//
	if (
		( m_tls_opt == StreamBase::TlsOpt::ENABLE_TLS ) &&
		( m_socket_params.GetTlsParams()[SocketParams::TlsParam_tls_auth_peer].AsInt() > 1 )
		)
	{
		new_sch->SetTlsPeerName(m_expected_client_common_name);
	}
	//
    new_sch->SetSocketAddr(local_addr, peer_addr);
	new_sch->SetUId(m_next_uid++);
	SetClientCallbacks(new_sch);
	m_new_client_cb.Dispatch(new_sch);
	return new_sch;
}

void StreamServer::DeleteClients()
{
	member_TRACE(&m_trace_set, 5, "%s deleting all clients (%zu)\n", m_name.c_str(), m_clients.size());
	for (auto it(m_clients.begin()); it != m_clients.end(); ++it)
	{
		delete it->second;
	}
	m_clients.clear();
}

eCallbackRt StreamServer::ClosePendingClients()
{
	for (auto it(m_clients_to_close.begin()); it != m_clients_to_close.end(); ++it)
	{
		std::map<int, StreamClientHandler*>::iterator it2 = m_clients.find(*it);
		if (it2 != m_clients.end())
		{
			member_TRACE(&m_trace_set, 4, "%s: closing client fd %d\n", m_name.c_str(), *it);
			it2->second->NotifyClosed();
			delete it2->second;
			m_clients.erase(it2);
		}
	}
	m_clients_to_close.clear();
	return DontRunAgain;
}

void StreamServer::UpdateFlag()
{
	SetFlag(FileDescriptorHandler::READ_NOTIFY_FLAG);
}

void StreamServer::read()
{
	if (m_fd < 0)
	{
		member_TRACE(&m_trace_set, 0, "%s::%s -- fd is %d\n", m_name.c_str(), __FUNCTION__, m_fd);
		return;
	}

	SocketAddr rem(PF_INET6); //for both IPv4 and IPv6
	int new_fd = accept(m_fd, rem.m_data, &rem.m_data_len);

	if (new_fd < 0)
	{
		member_TRACE(&m_trace_set, 0, "%s::%s -- Error in accept: %s\n", m_name.c_str(), __FUNCTION__, strerror(errno));
		return;
	}

	member_TRACE(&m_trace_set, 3, "%s::%s -- Accepting connection from %s\n", m_name.c_str(), __FUNCTION__, rem.PutToString().c_str());

	StreamClientHandler *pnew = CreateClient(new_fd, m_listen_addr, rem);

	auto ins_result = m_clients.insert(std::make_pair(pnew->GetId(), pnew));
	if (!ins_result.second)
	{
		member_TRACE(&m_trace_set, 0, "%s::%s -- failed to insert new client handler with fd %d\n", m_name.c_str(), __FUNCTION__, new_fd);
		delete pnew;
	}
	else if (!pnew->Init(m_listen_addr, rem))
	{
		member_TRACE(&m_trace_set, 0, "%s::%s -- failed to init new client handler with fd %d\n", m_name.c_str(), __FUNCTION__, new_fd);
		m_clients.erase(ins_result.first);
		delete pnew;
	}
	else
	{
		member_TRACE(&m_trace_set, 3, "%s::%s -- successfully added new client handler with fd %d\n", m_name.c_str(), __FUNCTION__, new_fd);
	}
}

void StreamServer::write()
{
	member_TRACE(&m_trace_set, 0, "%s -- unexpected write event\n", m_name.c_str());
	UpdateFlag();
}

void StreamServer::TrustedClientRequired()
{
	static const int level_verify_trust = 1;
	SetTlsAuthLevel(level_verify_trust);
}

void StreamServer::TrustedClientWithCommonNameRequired(string client_common_name)
{
	static const int level_verify_trust_and_cn = 2;
	SetTlsAuthLevel(level_verify_trust_and_cn);
	m_expected_client_common_name = client_common_name;
}

string StreamServer::ConsoleHelp() const
{
	return "status | client <list | #> | stats | params | tls_params | debug";
}

void StreamServer::ConsoleCommand(Writable *to, int argc, char *argv[])
{
	string usage = "Usage: " + ConsoleHelp();

	if (!to)
	{
		return;
	}

	if (argc < 1)
	{
		to->PrintString(usage.c_str());
	}
	else if (!strcmp(argv[0], "status"))
	{
		to->Print(
			"Name: %s\n"
			"Listen Address: %s\n"
			"Number of clients: %d\n"
			"TLS: %s\n"
			"XDR: %s\n",
			m_name.c_str(),
			m_listen_addr.PutToString().c_str(),
			m_clients.size(),
			m_tls_opt == StreamBase::TlsOpt::ENABLE_TLS ? "Enabled" : "Disabled",
			m_xdr_opt == StreamBase::XdrOpt::ENABLE_XDR ? "Enabled" : "Disabled");
	}
	else if (!strcmp(argv[0], "client"))
	{
		if (argc < 2)
		{
			to->PrintString(usage);
		}
		else if (!strcmp(argv[1], "list"))
		{
			if (m_clients.empty())
			{
				to->PrintString("No connected clients\n");
			}
			else for (auto it(m_clients.cbegin()); it != m_clients.cend(); ++it)
			{
				to->Print("[%d] Peer: %s Local: %s\n", it->first, it->second->GetPeerAddrStr().c_str(), it->second->GetLocalAddrStr().c_str());
			}
		}
		else if (isdigit(*argv[1]))
		{
			int client_id = atoi(argv[1]);
			SchMap::iterator it = m_clients.find(client_id);
			if (it != m_clients.end())
			{
				it->second->ConsoleCommand(to, argc-2, argv+2);
			}
			else
			{
				to->Print("Client %d not found, check list\n", client_id);
			}
		}
		else
		{
			to->PrintString(usage);
		}
	}
	else if (!strcmp(argv[0], "stats"))
	{
		// TODO: stats (e.g. # clients created/destroyed?)
	}
	else if (!strcmp(argv[0], "params"))
	{
		m_socket_params.GetParams().ConsoleCommand(to, argc-1, argv+1);
	}
	else if (!strcmp(argv[0], "tls_params"))
	{
		if (m_tls_opt == StreamBase::TlsOpt::ENABLE_TLS)
		{
			m_socket_params.GetTlsParams().ConsoleCommand(to, argc-1, argv+1);
		}
		else
		{
			to->PrintString("TLS not enabled for this server\n");
		}
	}
	else if (!strcmp(argv[0], "debug"))
	{
		HandleDebugCommand(to, argc-1, argv+1, m_trace_set, GetName().c_str());
	}
	else
	{
		to->PrintString(usage.c_str());
	}
}

}
