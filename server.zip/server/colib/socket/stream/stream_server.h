#if !defined(__STREAM_SERVER_H__)
#define __STREAM_SERVER_H__

#include <event_loop/fdh.h>
#include <utils/string.h>
#include <utils/callback.h>
#include <socket/socket_addr.h>
#include <socket/stream/stream_base.h>
#include <config/value.h>
#include <socket/stream/socket_params.h>

#include <list>
#include <map>
#include <vector>

namespace colib
{

class Writable;
class StreamClientHandler;

class StreamServer : public FileDescriptorHandler
{
public:
	typedef std::map<int, StreamClientHandler*> SchMap;
	StreamServer(const char *name, StreamBase::TlsOpt tls, StreamBase::XdrOpt xdr);
	virtual ~StreamServer();

	//this creates a socket
	bool Init(string listen_addr);
	bool Reload(const OptionsNode& base_opts, const OptionsNode& tls_opts);
	void Shutdown();
	void ScheduleClose(int fd);

    const SchMap& GetClients() const { return m_clients; }
	int GetNumClients() const { return m_clients.size(); }
	const SocketAddr& GetListenAddr() const { return m_listen_addr; }

	// TODO: could these callbacks use StreamClientHandler instead of streambase?  and is there any benefit?
	void SetReadCallback(const Callback1<StreamBase*> &read_cb) { m_client_on_read = read_cb; }
	void SetCloseCallback(const Callback1<StreamBase*> &close_cb) { m_client_on_close = close_cb; }
	void SetAwakenCallback(const Callback1<StreamBase*> &awaken_cb) { m_client_on_awaken = awaken_cb; }
	void SetWriteDoneCallback(const Callback1<StreamBase*> &write_done_cb) { m_client_on_write_done = write_done_cb; }
	void SetNewClientCallback(const Callback1<StreamClientHandler*> &new_client_cb) { m_new_client_cb = new_client_cb; }
	// callbacker clearers
	void ClearReadCallback() { m_client_on_read.Clear(); }
	void ClearCloseCallback() { m_client_on_close.Clear(); }
	void ClearAwakenCallback() { m_client_on_awaken.Clear(); }
	void ClearWriteDoneCallback() { m_client_on_write_done.Clear(); }
	void ClearNewClientCallback() { m_new_client_cb.Clear(); }

	bool SendMsgToClient(int client_id, Message &msg);
	bool SendCEncodableItemToClient(int client_id, CEncodableItem &msg);
	bool SendBytesToClient(int client_id, const char* data, int length);
	bool SendMsgToAllClients(Message &msg);
    bool SendBytesToAllClients(const char* buf, int len);
	bool CloseClientHandler(int id);

	virtual string ConsoleHelp() const;
	virtual void ConsoleCommand(Writable *to, int argc, char *argv[]);

	// wrapper function to enforce trust check
	void TrustedClientRequired();
	// wrapper function to enforce trust and common name check
	void TrustedClientWithCommonNameRequired(string client_common_name);
	//
	void SetTlsAuthLevel(int level) { m_socket_params.GetTlsParams()[SocketParams::TlsParam_tls_auth_peer] = level; }

	// for StreamClientHandlers
	const ValueList& GetParams() { return m_socket_params.GetParams(); }
	const ValueList& GetTlsParams() { return m_socket_params.GetTlsParams(); }

	void AddWritable(int level, Writable *out) { m_trace_set.AddWritable(level, out); }

	StreamWriteError GetClientLastWriteError(int client_id) const;

protected:

	void SetClientCallbacks(StreamClientHandler *ch);
	virtual StreamClientHandler* CreateClient(int fd, const SocketAddr& local_addr, const SocketAddr& peer_addr);
	virtual StreamClientHandler* AllocClient(int fd);
	void DeleteClients();
	eCallbackRt ClosePendingClients();
	void UpdateFlag();

	SchMap m_clients;
	std::vector<int> m_clients_to_close;

	Callback1<StreamBase*> m_client_on_read;
	Callback1<StreamBase*> m_client_on_awaken;
	Callback1<StreamBase*> m_client_on_close;
	Callback1<StreamBase*> m_client_on_write_done;
	Callback1<StreamClientHandler*> m_new_client_cb;

	ActivityHold m_client_close_act;

	SocketAddr m_listen_addr;
	MemberSet m_trace_set;

	const StreamBase::TlsOpt m_tls_opt;
	const StreamBase::XdrOpt m_xdr_opt;

	SocketParams m_socket_params;
	string m_expected_client_common_name;

private:
	/// These callbacks are to be used only by the event loop
	virtual void read();
	virtual void write();

	int m_next_uid;
};

}

#endif
