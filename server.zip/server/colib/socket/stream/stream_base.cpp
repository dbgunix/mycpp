#include <socket/stream/stream_base.h>
#include <socket/stream/socket_engine_tls.h>
#include <socket/stream/socket_engine.h>
#include <utils/trace/writable.h>
#include <utils/trace/trace.h>
#include <utils/system/machine.h>

namespace colib
{

StreamBase::StreamBase(const char *name, int fd, TlsOpt tls, XdrOpt xdr, const ValueList &params, const ValueList &tls_params)
	: m_local_addr()
	, m_peer_addr()
	, m_tls_opt(tls)
	, m_xdr_opt(xdr)
	, m_engine(NULL)
	, m_msg_proc(new MessageProcessor(name, *this, m_trace_set))
	, m_trace_set()
	, m_on_read()
	, m_on_close()
	, m_on_awaken()
	, m_on_write_done()
	, m_on_tx_queue_available()
	, m_connected(false)
	, m_last_write_error(StreamWriteError::NONE)
	, m_params(params)
	, m_tls_params(tls_params)
{
#ifdef CONFIG_HAVE_TLS
	if (tls == TlsOpt::ENABLE_TLS)
	{
		m_engine = new SocketEngineTLS(name, fd, *this, m_trace_set);
	}
	else
#endif
	{
		m_engine = new SocketEngine(name, fd, *this, m_trace_set);
	}

	if (xdr == XdrOpt::ENABLE_XDR)
	{
		m_on_read = callback<MessageProcessor, StreamBase*>(m_msg_proc, &MessageProcessor::SocketReadEvent);
		//m_msg_proc->SetMsgErrorCb();
	}
}

StreamBase::~StreamBase()
{
	if (NULL != m_engine)
	{
		delete m_engine;
	}
	if (NULL != m_msg_proc)
	{
		delete m_msg_proc;
	}
}

void StreamBase::SetReadCallback(const Callback1<StreamBase*> &read_cb)
{
	// do not overwrite read cb if in XDR mode
	if ( IsXdrEnabled() )
	{
		member_TRACE(&m_trace_set, 0, "%s: cannot set read callback in XDR mode\n", GetName().c_str());
	}
	else
	{
		m_on_read = read_cb;
	}
}

void StreamBase::ClearReadCallback()
{
	// do not overwrite read cb if in XDR mode
	if ( IsXdrEnabled() )
	{
		member_TRACE(&m_trace_set, 0, "%s: cannot clear read callback in XDR mode\n", GetName().c_str());
	}
	else
	{
		m_on_read.Clear();
	}
}

bool StreamBase::Init()
{
	return m_engine->Init();
}

int StreamBase::WriteBytes(const char *buf, int len)
{
	if ( IsXdrEnabled() )
	{
		// if in XDR mode we need to prepend length
		// make sure we can send data + length, send both or neither
		if (!m_engine->TestWriteBytesSpace(len + sizeof(len)))
		{
			member_TRACE(&m_trace_set, 2, "%s: Not safe to write buffer and prepend length (%d + %zu)\n", GetName().c_str(), len, sizeof(len));
			m_last_write_error = StreamWriteError::TX_QUEUE_FULL;
			return -1;
		}
		int tmp_len = FLIP(len);
		int ret = m_engine->WriteBytes(reinterpret_cast<const char*>(&tmp_len), sizeof(tmp_len), m_last_write_error);
		if (ret <= 0)
		{
			return ret;
		}
	}
	return m_engine->WriteBytes(buf, len, m_last_write_error);
}

void StreamBase::CloseEvent()
{
	m_on_close.Dispatch(this);
	// don't set the connected flag until after callback
	// has run. this allows CB handler to check connected status
	m_connected = false;
}

void StreamBase::AwakenEvent()
{
	m_connected = true;
	m_on_awaken.Dispatch(this);
}

void StreamBase::ConsoleStats(Writable *to, int argc, char *argv[])
{
	to->Print("Engine Stats:\n");
	m_engine->GetStats().ConsoleCommand(to, argc, argv);
}

void StreamBase::ConsoleTlsStats(Writable *to, int argc, char *argv[])
{
	if ( m_engine->GetTlsStats() ) m_engine->GetTlsStats()->ConsoleCommand(to, argc, argv);
}

void StreamBase::ConsoleTlsState(Writable *to, int argc, char *argv[])
{
	(void)argc; (void)argv;
	to->Print("%s\n", m_engine->GetTlsState().c_str());
}

void StreamBase::ConsoleMsgProc(Writable *to, int argc, char* argv[])
{
	if ( IsXdrEnabled() )
	{
		m_msg_proc->ConsoleCommand(to, argc, argv);
	}
	else
	{
		to->PrintString("XDR is not enabled\n");
	}
}

}
