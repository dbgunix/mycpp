// telnet.cpp
// vi:set ts=4 sw=4 nowrap:

#include <socket/stream/console/telnet.h>
#include <socket/stream/console/console.h>
#include <config/fips.h>

#ifdef CONFIG_HAVE_TLS
#include <crypt/fips/fips.h>
#endif

namespace colib
{
	TelnetConsoleSession::TelnetConsoleSession(
			ConsoleServer* server,
			ConsoleLoginShell::Callback* callback,
			StreamConsoleSession& session)
		:
		ConsoleTelnet(server, callback),
		m_stream_session(session),
		m_is_trusted(false)
	{
	}

	TelnetConsoleSession::~TelnetConsoleSession()
	{
	}

	int				TelnetConsoleSession::Write(const void *buf, unsigned int len)
	{
		return m_stream_session.Write(static_cast<const char*>(buf), len);
	}

	void			TelnetConsoleSession::SetState(ConsoleState* state)
	{
		if ( state == ConsoleTelnet::LeaveState() )
		{
			SetBroadcast(false);
		}
		else if ( state == ConsoleTelnet::TelnetShell() )
		{
			SetBroadcast(true);
		}
	
		ConsoleTelnet::SetState(state);
	}

	void			TelnetConsoleSession::StopConsole()
	{
		ConsoleTelnet::StopConsole();
		m_stream_session.DisconnectSocket();
	}

	string			TelnetConsoleSession::Prompt()
	{
		string warning;

#ifdef CONFIG_HAVE_TLS
		if ( colib::InFipsMode() && colib::InErrorState() )
		{
			warning = "FIPS ERROR STATE ";
		}
#endif

		return ConsoleTelnet::Prompt() + " " + warning;
	}

	string			TelnetConsoleSession::GetName()
	{
		string name = ConsoleTelnet::GetName();
	
		name += ":";
		name += m_stream_session.GetPeerAddr();

		return name;
	}

}//end namespace colib

