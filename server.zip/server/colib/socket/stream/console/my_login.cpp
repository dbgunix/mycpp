#include <crypt/passwd/token.h>
#include <config/fips.h>
#include <config/value.h>
#include <config/global_params.h>
#include <console/role.h>
#include <console/session.h>
#include <socket/stream/console/my_login.h>
#include <socket/stream/console/console.h>

namespace colib
{

const char* internal_authorization_magic_word = "SFj8DWG5N8KywMTb0cE61IwtjL";
const char* internal_reject_magic_word = "ip79ICkZ112eztVZ3aiZMyUl6XVX0/STS";

static bool GetPasswordHash( unsigned role, const char *&hash )
{
	if( role == CONSOLE_ROLE_USER)
	{
		hash = GLOBALSTRPARAM(SECURITY, password);
	}
	else if( role == CONSOLE_ROLE_ADMIN)
	{
		hash = GLOBALSTRPARAM(SECURITY, admin_password);
	}
	else
	{
		return false;
	}

	return true;
}

static bool TokenVerify(const char* passwd, const char* hash)
{
    return (strncmp(passwd, hash, strlen(hash)) == 0);
}

unsigned MyLoginCallback( ConsoleSession* session, const char* username, const char* password)
{
	unsigned role = ConsoleNameToRole(username);
	const char *hash = 0;

	if(role == CONSOLE_ROLE_CRYPTO && 
		!(colib::InFipsMode() && session->IsTrusted()))
	{
		role = CONSOLE_ROLE_DEFAULT;
	}

	if( role == CONSOLE_ROLE_DEFAULT ||
		!GetPasswordHash(role,hash) ||
		0==hash ||
		!TokenVerify(password, hash) )
	{
		session->Print("\nAccess Denied\n");
		return CONSOLE_ROLE_DEFAULT;
	}

	session->Print("\n");

	return role;
}

unsigned InternalLoginCallback(ConsoleSession* session, const char* username, const char* password)
{
	unsigned role = MyLoginCallback(session, username, password);

	InternalConsoleSession* console = static_cast<InternalConsoleSession*>(session);
	if ( role != CONSOLE_ROLE_DEFAULT )
	{
		console->Write(internal_authorization_magic_word, strlen(internal_authorization_magic_word));
	}
	else
	{
		console->Write(internal_reject_magic_word, strlen(internal_reject_magic_word));
	}

	return role;
}

}
