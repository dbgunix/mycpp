// uni_console.h
// vi:set ts=4 sw=4 nowrap:

#ifndef UNI_CONSOLE_H_ALREADY_INCLUDED
#define UNI_CONSOLE_H_ALREADY_INCLUDED

#include <socket/stream/console/console.h>
#include <socket/stream/stream_client.h>

#include <map>

namespace colib
{
	class UniTelnetConsoleServer : public StreamConsoleServer
	{
		public:

										UniTelnetConsoleServer();
			virtual						~UniTelnetConsoleServer() {};

			ConsoleSession*				NewTelnetConsole(StreamConsoleSession&);
			StreamConsoleSession*		NewStreamConsoleSession(bool, const Callback1<char*>&, StreamConsoleServer*, StreamClientHandler*);
	};

	class UniInternalConsoleServer : public StreamConsoleServer
	{
		public:

										UniInternalConsoleServer();
			virtual						~UniInternalConsoleServer() {};

			ConsoleSession*				NewInternalConsole(StreamConsoleSession&);
			StreamConsoleSession*		NewStreamConsoleSession(bool, const Callback1<char*>&, StreamConsoleServer*, StreamClientHandler*);
	};

	class UniConsoleProcInfo
	{
		public:

										UniConsoleProcInfo(string proc_name, int proc_id);
										UniConsoleProcInfo();
			virtual						~UniConsoleProcInfo() {};

			string						m_proc_name;
			int							m_proc_id;
			Dlist<string>				m_commands_support;
	};

	typedef std::map<string, UniConsoleProcInfo>	UniProcMAP;

	class UniConsoleSession;

	class UniConsoleServer
	{
		public:

			static UniConsoleServer&	GetInstance();
			static string				ConnectPath(string proc_name, int proc_id);

			bool 						InitTelnet(string my_proc_name, string listen_addr);
			bool						InitInternal(string my_proc_name, string listen_addr);

			StreamConsoleSession*		FindConsoleSession(ConsoleSession* con);

			void						OnInternalConsoleClosed(StreamBase*);

			bool						AddProcess(string proc_name, int proc_id);
			void						DelProcess(string proc_name, int proc_id);
			UniConsoleProcInfo*			FindProcess(string proc_name, int proc_id);

			void						UpdateProcCommandsSupport(string proc_name, int proc_id, Dlist<string>& list);
			UniConsoleSession*			SearchUniConsoleSession(ConsoleSession* con);

			typedef bool				ProcIterator(UniConsoleProcInfo* proc, void* context);
			void						ProcIterate(ProcIterator* iterator, void* context);

			typedef bool 				SessionIterator(StreamConsoleSession* session, void* context);
			void						SessionIterate(SessionIterator* iterator, void* context);

			//
			// Console command
			//
			static void					Command(void* ctx, ConsoleSession* con, int argc, char* argv[]);
			static void					Session(void* ctx, ConsoleSession* con, int argc, char* argv[]);
			static void					Connect(void* ctx, ConsoleSession* con, int argc, char* argv[]);

			void						ConsoleCommand(ConsoleSession* con, int argc, char* argv[]);

		private:

										UniConsoleServer();
			virtual 					~UniConsoleServer();

		private:

			string						m_my_proc_name;
			UniProcMAP					m_proc_map;

			bool						m_telnet_initialized;
			UniTelnetConsoleServer		m_telnet;
			bool						m_internal_initialized;
			UniInternalConsoleServer	m_internal;

		friend class UniConsoleSession;
	};

	class RemoteAccess : public ConsoleState
	{
		public:

										RemoteAccess(ConsoleSession* session, ConsolePrompt* shell_prompt, bool manual);
			virtual 					~RemoteAccess();

			virtual bool				Activate();
			bool						Init(UniConsoleProcInfo* proc);
			void						ChangeShellPrompt(ConsolePrompt* shell_prompt) { m_shell_prompt = shell_prompt; }

			bool						InLogin() { return m_in_login; }
			void						SetManual() { m_manual = true; }
			int							SendToRemote(const char* buf, int len);
			void						ForwardCommand(const char* command, int len);

			Callback1<RemoteAccess*>	m_on_manual_login_succeed;
			Callback1<RemoteAccess*>	m_on_manual_login_failed;

		private:

			void						OnReadRemote(StreamBase*);

			bool						SearchMagicWord(char* buf, int num, const char* magic_word, int& magic_word_index);

		private:

			ConsolePrompt*				m_shell_prompt;

			StreamClient				m_access;
			bool						m_manual;
			bool						m_in_login;

			int							m_authorize_magic_word_index;
			int							m_reject_magic_word_index;

		private:

			string						m_proc_name;
			int							m_proc_id;

		friend class UniConsoleSession;
	};

	class UniConsoleShell : public ConsoleState
	{
		public:
										UniConsoleShell(ConsoleSession* session, ConsolePrompt* shell_prompt);
			virtual						~UniConsoleShell();

			virtual bool				Activate();

			Callback2<string, string>	m_on_switch;

		private:

			ConsolePrompt*				m_shell_prompt;
	};

	class UniConsoleSession : public StreamConsoleSession
	{
		public:
										UniConsoleSession(
												bool telnet,
												const Callback1<char*> &event_cb,
												StreamConsoleServer* parent,
												StreamClientHandler *socket);
			virtual						~UniConsoleSession();

			RemoteAccess*				AddRemoteShell(UniConsoleProcInfo* proc, bool manual);
			void						DelRemoteShell(string proc_name, int proc_id);
			bool						OnRemoteShellAccessClosed(StreamBase*);
			void						AutoLogin(const char* username, const char* password);
			void						RemoteLogin(const char* username, const char* password);

			bool						SetConsole(ConsoleSession* console);

			// Console command
			void						ConnectConsoleCommand(ConsoleSession *con, int argc, char* argv[]);
			void						SessionConsoleCommand(ConsoleSession *con, int argc, char* argv[]);

		protected:

			RemoteAccess*				FindRemoteShell(string proc_name, int proc_id);

			void						OnSwitchShell(string proc_name, string proc_id);
			void						OnRemoteShellManualLoginDone(RemoteAccess* shell);
			void						StartRemoteShellManualLogin(RemoteAccess* shell);

			void						UniConsoleSupportedCommands(Dlist<string>& list);

		private:

			bool						m_telnet;
			UniConsoleShell*			m_uni_shell;
			Dlist<RemoteAccess*>	 	m_remote_shells;
			ConsoleState*				m_default_shell;
			ConsoleLoginShell*			m_manual_login_shell;
			RemoteAccess*				m_remote_manual_login;

			ConsoleSession*				m_console_session;
			ConsoleShell*				m_session_shell;
	};

	unsigned UniTelnetLoginCallback(ConsoleSession* con, const char* username, const char* password);
	unsigned UniInternalLoginCallback(ConsoleSession* con, const char* username, const char* password);
	unsigned RemoteLoginCallback(ConsoleSession* con, const char* username, const char* password);

}//end namespace iDirect
#endif

