// internal.h
// vi:set ts=4 sw=4 nowrap:

#ifndef CONSOLE_INTERNAL_H_ALREADY_INCLUDED
#define CONSOLE_INTERNAL_H_ALREADY_INCLUDED

#include <console/internal.h>

namespace colib
{
	class StreamConsoleSession;

	class InternalConsoleSession : public ConsoleInternal
	{
		public:

										InternalConsoleSession(
												ConsoleServer*, 
												ConsoleLoginShell::Callback*, 
												StreamConsoleSession&);
			virtual						~InternalConsoleSession();					
			//
			// Functions for Console
			//
			virtual int					Write(const void *buf, unsigned int len);
			virtual void				StopConsole();
			virtual void				SetState(ConsoleState* state);
			virtual string				Prompt();

		private:
		
			StreamConsoleSession&		m_stream_session;
	};

}//end namespace colib


#endif

