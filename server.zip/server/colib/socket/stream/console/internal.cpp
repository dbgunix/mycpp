// internal.cpp
// vi:set ts=4 sw=4 nowrap:

#include <socket/stream/console/internal.h>
#include <socket/stream/console/console.h>
#include <config/fips.h>
//#include <crypt/fips/fips.h>

namespace colib
{
	InternalConsoleSession::InternalConsoleSession(
			ConsoleServer* server,
			ConsoleLoginShell::Callback* callback,
			StreamConsoleSession& session)
		:
		ConsoleInternal(server, callback),
		m_stream_session(session)
	{
	}

	InternalConsoleSession::~InternalConsoleSession()
	{
	}

	int				InternalConsoleSession::Write(const void *buf, unsigned int len)
	{
		return m_stream_session.Write(static_cast<const char*>(buf), len);
	}

	void			InternalConsoleSession::SetState(ConsoleState* state)
	{
		if ( state == ConsoleInternal::LeaveState() )
		{
			SetBroadcast(false);
		}
		else if ( state == ConsoleInternal::InternalShell() )
		{
			SetBroadcast(true);
		}
	
		ConsoleInternal::SetState(state);
	}

	void			InternalConsoleSession::StopConsole()
	{
		ConsoleInternal::StopConsole();
		m_stream_session.DisconnectSocket();
	}

	string			InternalConsoleSession::Prompt()
	{
		string warning;

#ifdef CONFIG_HAVE_TLS
		if ( colib::InFipsMode() && colib::InErrorState() )
		{
			warning = "FIPS ERROR STATE ";
		}
#endif

		return ConsoleInternal::Prompt() + " " + warning;
	}

}//end namespace colib

