#include <socket/stream/console/console.h>
#include <socket/stream/console/my_login.h>
#include <socket/stream/stream_client_handler.h>
#include <config/global_params.h>
#include <config/fips.h>
#include <socket/socket_addr.h>
#include <socket/socket_buffer_pool.h>
#include <utils/trace/trace.h>
#include <console/broadcast.h>
#include <console/role.h>
#include <version/version.h>
#include <version_registrar/version_registrar.h>

#include <stdio.h>
//#include <crypt/fips/fips.h>
namespace colib
{

void console_TRACE(int level, const char *fmt, va_list args)
{
	if (GLOBALPARAM(GENERAL, debug_level) >= level)
	{
		ConsoleBroadcast(fmt,args);
	}
}

void console_TRACE(const char *fmt, va_list args)
{
	ConsoleBroadcast(fmt,args);
}

void TraceToConsole()
{
	g_pfTRACE0 = console_TRACE; // ________  these are two different pointers
	g_pfTRACE1 = console_TRACE; // ___/	     because of the parameters.
}

ConsoleGlobal&		ConsoleGlobal::GetInstance()
{
	static ConsoleGlobal _instance;

	return _instance;
}

void ConsoleGlobal::RegisterConsoleCommand()
{
	ConsoleCommand::Register(
			CONSOLE_ROLE_EVERYONE | CONSOLE_ROLE_ERROR_STATE,
			(ConsoleCommand::Handler*)CmdTraceLevel, NULL,
			"tlev", "Trace control");
	ConsoleCommand::Register(
			CONSOLE_ROLE_ADMIN | CONSOLE_ROLE_ERROR_STATE,
			(ConsoleCommand::Handler*)CmdTerminate, NULL,
			"TERMINATE", "Kill process");
	ConsoleCommand::Register(
			CONSOLE_ROLE_EVERYONE | CONSOLE_ROLE_ERROR_STATE,
			(ConsoleCommand::Handler*)CmdVersion, NULL,
			"version", "Build information");
	ConsoleCommand::Register(
			CONSOLE_ROLE_EVERYONE | CONSOLE_ROLE_ERROR_STATE,
			(ConsoleCommand::Handler*)CmdGecho, NULL,
			"gecho", "Global echo");
	ConsoleCommand::Register(
			CONSOLE_ROLE_EVERYONE | CONSOLE_ROLE_ERROR_STATE,
			(ConsoleCommand::Handler*)CmdEventLoop, NULL,
			"eloop", "EventLoop control");
	ConsoleCommand::Register(
			CONSOLE_ROLE_EVERYONE | CONSOLE_ROLE_ERROR_STATE,
			(ConsoleCommand::Handler*)CmdParams, NULL,
			"params", "Global params");
	ConsoleCommand::Register(
			CONSOLE_ROLE_EVERYONE | CONSOLE_ROLE_ERROR_STATE,
			(ConsoleCommand::Handler*)CmdSbPool, NULL,
			"sbuf", "Socket buffer pool");

	/*
	ConsoleCommand::Register(
			CONSOLE_ROLE_EVERYONE | CONSOLE_ROLE_ERROR_STATE,
			(ConsoleCommand::Handler*)CmdHeap, NULL,
			"heap", "Memory usage");
			*/

}

StreamConsoleServer::StreamConsoleServer(bool telnet)
	: ConsoleServer()
	, m_stream_svr("stream console server", StreamBase::TlsOpt::DISABLE_TLS, StreamBase::XdrOpt::DISABLE_XDR)
	, m_telnet(telnet)
	, m_sessions()
	, m_session_event_notification()
{
	m_stream_svr.SetNewClientCallback(callback(this, &StreamConsoleServer::NewSession));
	m_stream_svr.SetCloseCallback(callback(this, &StreamConsoleServer::SessionClosed));
}

StreamConsoleServer::StreamConsoleServer(const char* name, bool telnet)
	: ConsoleServer()
	, m_stream_svr(name, StreamBase::TlsOpt::DISABLE_TLS, StreamBase::XdrOpt::DISABLE_XDR)
	, m_telnet(telnet)
	, m_sessions()
	, m_session_event_notification()
{
	m_stream_svr.SetNewClientCallback(callback(this, &StreamConsoleServer::NewSession));
	m_stream_svr.SetCloseCallback(callback(this, &StreamConsoleServer::SessionClosed));
}

bool StreamConsoleServer::Init(string listen_addr)
{
	bool ret = m_stream_svr.Init(listen_addr);
	if (ret)
	{
		TraceToConsole();
	}
	return ret;
}

void StreamConsoleServer::SetEventNotifcationCallback(const Callback1<char*> &event_cb)
{
	if (m_telnet)
	{
		m_session_event_notification = event_cb;
	}
}

void StreamConsoleServer::SessionClosed(StreamBase *ch)
{
	// find session, delete it
	std::map<StreamClientHandler*, StreamConsoleSession*>::iterator it = m_sessions.find(static_cast<StreamClientHandler*>(ch));
	if (it != m_sessions.end())
	{
		delete it->second;
		m_sessions.erase(it);
	}
}

StreamConsoleSession* StreamConsoleServer::FindConsoleSession(ConsoleSession* session)
{
	for ( std::map<StreamClientHandler*, StreamConsoleSession*>::iterator it = m_sessions.begin();
			it != m_sessions.end(); ++it )
	{
		if ( it->second && ( it->second->GetConsole() == session ) ) return it->second;
	}

	return 0;
}

ConsoleSession* StreamConsoleServer::NewTelnetConsole(StreamConsoleSession& stream_session)
{
	return new TelnetConsoleSession(this, &MyLoginCallback, stream_session);
}

ConsoleSession* StreamConsoleServer::NewInternalConsole(StreamConsoleSession& stream_session)
{
	return new InternalConsoleSession(this, &InternalLoginCallback, stream_session);
}

StreamConsoleSession* StreamConsoleServer::NewStreamConsoleSession(
												bool telnet,
												const Callback1<char*> &event_cb,
												StreamConsoleServer* parent,
												StreamClientHandler* socket)
{
	return new StreamConsoleSession(telnet, event_cb, parent, socket);
}

void StreamConsoleServer::NewSession(StreamClientHandler *ch)
{
	// create new session, provide ch ptr
	StreamConsoleSession *new_sess = NewStreamConsoleSession(m_telnet, m_session_event_notification, this, ch);

	bool ret = (new_sess != NULL);
	if ( ret )
	{
		if (m_telnet) ret = new_sess->SetConsole(NewTelnetConsole(*new_sess));
		else ret = new_sess->SetConsole(NewInternalConsole(*new_sess));
	}

	if ( ret )
	{
		new_sess->Init();
		m_sessions.insert(std::pair<StreamClientHandler*, StreamConsoleSession*>(ch, new_sess));
	}
	else if (new_sess) delete new_sess;
}

void StreamConsoleServer::SessionIterate(SessionIterator* iterator, void* context)
{
	for ( std::map<StreamClientHandler*, StreamConsoleSession*>::iterator it = m_sessions.begin();
			it != m_sessions.end(); ++it )
	{
		if ( iterator(it->second, context) ) return;
	}
}

GlobalTelnetConsoleServer& GlobalTelnetConsoleServer::GetInstance()
{
	static GlobalTelnetConsoleServer instance;
	return instance;
}

bool GlobalTelnetConsoleServer::Init(string listen_addr)
{
	if (m_initialized)
	{
		return true;
	}

	SocketAddr addr(listen_addr);
	if ( ( addr.GetType() != PF_INET ) && ( addr.GetType() != PF_INET6 ) ) return false;

	if (StreamConsoleServer::Init(listen_addr))
	{
		m_initialized = true;
	}

	if ( m_initialized)
	{
		ConsoleCommand::Register(
				CONSOLE_ROLE_EVERYONE | CONSOLE_ROLE_ERROR_STATE,
				(ConsoleCommand::Handler*)GlobalTelnetConsoleServer::Command, NULL,
				"tconsvr", "Telnet Console Server control");
	}
	return m_initialized;
}

void GlobalTelnetConsoleServer::Command(void* ctx, ConsoleSession* con, int argc, char* argv[])
{
	(void)ctx;
	GlobalTelnetConsoleServer::GetInstance().ConsoleCommand(con, argc, argv);
}

GlobalTelnetConsoleServer::GlobalTelnetConsoleServer()
		: StreamConsoleServer("GlobalTelnetConsoleServer", true)
		, m_initialized(false)
{
	SocketBufferPool::GetInstance(); // guarantee dtor order
}

GlobalInternalConsoleServer& GlobalInternalConsoleServer::GetInstance()
{
	static GlobalInternalConsoleServer instance;
	return instance;
}

bool GlobalInternalConsoleServer::Init(string listen_addr)
{
	if (m_initialized)
	{
		return true;
	}

	SocketAddr addr(listen_addr);
	if ( addr.GetType() != PF_UNIX ) return false;

	if (StreamConsoleServer::Init(listen_addr))
	{
		m_initialized = true;
	}

	if ( m_initialized)
	{
		ConsoleCommand::Register(
				CONSOLE_ROLE_EVERYONE | CONSOLE_ROLE_ERROR_STATE,
				(ConsoleCommand::Handler*)GlobalInternalConsoleServer::Command, NULL,
				"iconsvr", "Internal Console Server control");
	}

	return m_initialized;
}

void GlobalInternalConsoleServer::Command(void* ctx, ConsoleSession* con, int argc, char* argv[])
{
	(void)ctx;
	GlobalInternalConsoleServer::GetInstance().ConsoleCommand(con, argc, argv);
}

GlobalInternalConsoleServer::GlobalInternalConsoleServer()
	: StreamConsoleServer("GlobalInternalConsoleServer", false)
	, m_initialized(false)
{
	SocketBufferPool::GetInstance(); // guarantee dtor order
}

int StreamConsoleSession::Write(const char *buf, int bufsize)
{
	int ret = bufsize > 0 ? 0 : -1;
	while (bufsize>0)
	{
		//if( m_tx_queue.Count() > m_queue_limit )
		//	break;
		SocketBuffer *mnew = SocketBufferPool::GetInstance().Get();
		if(!mnew)
			break;
		int consumed = 0;
		int written = CopyToBuffer(mnew->GetData(), buf, bufsize, consumed, mnew->MaxLength());
		mnew->SetLength(written);
		//m_tx_queue.Append(mnew);
		if (!m_socket->WriteBuffer(mnew))
		{
			SocketBufferPool::GetInstance().Return(mnew);
			break;
		}
		buf += consumed;
		bufsize -= consumed;
		ret += consumed;
	}
	//UpdateFlag();
	return ret;
}

int StreamConsoleSession::CopyToBuffer(char*dest, const char*src, int size, int &consumed, int max)
{
	consumed = 0;
	char prev='\0';
	int ndx;
	for( ndx=0; ndx < size && ndx < max; ndx++)
	{
		if( *src == '\n' && prev != '\r' )
		{
			//we must have at least two bytes of space for the \n -> \r \n translation
			if( ndx + 1 >= max )
			{
				break;
			}
			prev='\r';
			*dest++ = '\r';
			++size; //size logicall incleased, since we gave it a ghost \r
			continue;
		}
		prev=*src;
		*dest++ = *src++;
		++consumed;
	}
	return ndx;
}

void StreamConsoleSession::DisconnectSocket()
{
	if ( m_socket ) m_socket->Disconnect();
}

void StreamConsoleSession::Init()
{
	if ( m_socket )
	{
		m_socket->SetReadCallback(callback(this, &StreamConsoleSession::SocketReadEvent));
		m_socket->SetAwakenCallback(callback(this, &StreamConsoleSession::SessionAwake));
	}
}

void StreamConsoleSession::SessionAwake(StreamBase *sock)
{
	(void)sock;

	if ( m_telnet )
	{
		m_peer_addr =  m_socket->GetPeerAddrStr();
		colib::SocketAddr::ExtractTypeFromString(m_peer_addr);
		char buffer[64];
		snprintf(buffer, sizeof(buffer)-1, "%s started", m_console->GetName().c_str());
		m_event_notification.Dispatch( buffer);

		SocketAddr peer_sock;
		if (peer_sock.SetFromString(m_socket->GetPeerAddrStr()) && peer_sock.IsAddrLoopBack())
		{
			(static_cast<TelnetConsoleSession*>(m_console))->SetTrusted(true);
		}
	}

	m_console->StartConsole();
}

void StreamConsoleSession::SocketReadEvent(StreamBase *sock)
{
	(void)sock; //TODO: could sanity check sock against m_socket
	char buffer[CONSOLE_CMD_LEN_MAX];

	char* data = buffer;
	int num = m_socket->ReadBytes(buffer, sizeof(buffer));
	while ( num > 0 )
	{
		int used = m_console->Process(data, num);
		data += used;
		num -= used;
	}
}

StreamConsoleSession::~StreamConsoleSession()
{
	if ( m_console )
	{
		if ( m_telnet )
		{
			char buffer[64];
			snprintf(buffer, sizeof(buffer)-1, "%s closed", m_console->GetName().c_str());
			m_event_notification.Dispatch( buffer);
		}
		delete m_console;
	}
}

void CmdTraceLevel(void* ctx, ConsoleSession* con, int argc, char* argv[])
{
	(void)ctx;
	if ( !con ) return;

	if ( argc == 1 )
	{
		con->Print("Current global trace level is %d\n", GLOBALPARAM(GENERAL, debug_level));
		return;
	}

	int newlevel = atoi (argv[1]);
	if (newlevel >= 0 && newlevel <= 5)
	{
		if ((newlevel >= 4) && !con->CSPEnabled() )
		{
			return;
		}
		GLOBALPARAM(GENERAL, debug_level) = newlevel;
		con->Print ("Changed global trace level to %d\n", newlevel);
	}
	else
	{
		con->Print ("ERROR: Invalid global trace level: %d\n", newlevel);
		con->Print ("       Global trace level remains: %d\n", GLOBALPARAM(GENERAL, debug_level));
	}
}

void CmdTerminate(void *ctx, ConsoleSession *con, int argc, char* argv[])
{
	(void)ctx;(void)con;(void)argc;(void)argv;
	EventLoop::GetInstance().Terminate(true);
}

void CmdVersion(void *ctx, ConsoleSession *con, int argc, char* argv[])
{
	(void)ctx;

	if (argc <= 1)
	{
		VersionRegistrar::GetInstance().PrintBrief(con);
	}
	else if (strcmp(argv[1], "full") == 0)
	{
		VersionRegistrar::GetInstance().PrintFull(con);
	}
}

void CmdGecho(void *ctx, ConsoleSession *con, int argc, char* argv[])
{
	(void)ctx; (void)con;
	string caten;
	for(int at=1;at<argc;++at)
	{
		caten += argv[at];
		caten += " ";
	}
	caten+='\n';
	//Global trace
	TRACE( 1, "%s", caten.c_str() );
}

void CmdEventLoop(void *ctx, ConsoleSession *con, int argc, char* argv[])
{
	(void)ctx;
	EventLoop::GetInstance().ConsoleCommand(con, argc-1, argv+1);
}

void CmdParams(void *ctx, ConsoleSession *con, int argc, char* argv[])
{
	(void)ctx;
	GlobalParams::GetInstance().ConsoleCommand(con, argc-1, argv+1);
}

void CmdSbPool(void *ctx, ConsoleSession *con, int argc, char* argv[])
{
	(void)ctx;
	SocketBufferPool::GetInstance().ConsoleCommand(con, argc-1, argv+1);
}

}//end namespace colib
