// uni_console.cpp
// vi:set ts=4 sw=4 nowrap:

#include <socket/stream/console/uni_console.h>
#include <console/role.h>
#include <console/command.h>
#include <console/broadcast.h>
#include <socket/stream/console/my_login.h>
#include <utils/trace/trace.h>

#include <stdlib.h>
#include <ctype.h>
#include <string.h>

namespace colib
{
	UniTelnetConsoleServer::UniTelnetConsoleServer()
		:
		StreamConsoleServer(true)
	{
	}

	ConsoleSession*			UniTelnetConsoleServer::NewTelnetConsole(StreamConsoleSession& stream_session)
	{
		return new TelnetConsoleSession(this, UniTelnetLoginCallback, stream_session);
	}

	StreamConsoleSession*	UniTelnetConsoleServer::NewStreamConsoleSession(
								bool telnet, 
								const Callback1<char*> &event_cb, 
								StreamConsoleServer* parent, 
								StreamClientHandler* socket)		
	{
		(void)telnet;
		return new UniConsoleSession(true, event_cb, parent, socket);
	}

	UniInternalConsoleServer::UniInternalConsoleServer()
		:
		StreamConsoleServer(false)
	{
	}

	ConsoleSession*			UniInternalConsoleServer::NewInternalConsole(StreamConsoleSession& stream_session)
	{
		return new InternalConsoleSession(this, UniInternalLoginCallback, stream_session);
	}
	
	StreamConsoleSession*	UniInternalConsoleServer::NewStreamConsoleSession(
								bool telnet, 
								const Callback1<char*> &event_cb, 
								StreamConsoleServer* parent, 
								StreamClientHandler* socket)		
	{
		(void)telnet;
		return new UniConsoleSession(false, event_cb, parent, socket);
	}	

	UniConsoleProcInfo::UniConsoleProcInfo(string proc_name, int proc_id)
		:
		m_proc_name(proc_name), m_proc_id(proc_id)
	{
	}

	UniConsoleProcInfo::UniConsoleProcInfo()
		:
		m_proc_id(0)
	{
	}

	UniConsoleServer&		UniConsoleServer::GetInstance()
	{
		static UniConsoleServer instance;
		return instance;
	}

	UniConsoleServer::UniConsoleServer()
		:
		m_telnet_initialized(false),
		m_internal_initialized(false)	
	{	
		ConsoleCommand::Register(
				CONSOLE_ROLE_EVERYONE | CONSOLE_ROLE_ERROR_STATE,
				(ConsoleCommand::Handler*)UniConsoleServer::Command, NULL,
				"uconsvr", "UniConsole Server control");

		ConsoleCommand::Register(
				CONSOLE_ROLE_EVERYONE | CONSOLE_ROLE_ERROR_STATE,
				(ConsoleCommand::Handler*)UniConsoleServer::Session, NULL,
				"usession", "UniConsole Session control");
		
		ConsoleCommand::Register(
				CONSOLE_ROLE_EVERYONE | CONSOLE_ROLE_ERROR_STATE,
				(ConsoleCommand::Handler*)UniConsoleServer::Connect, NULL,
				"connect", "Connect to child internal console server");
	}

	UniConsoleServer::~UniConsoleServer()
	{
	}

	bool					UniConsoleServer::InitTelnet(string my_proc_name, string listen_addr)
	{	
		if ( m_telnet_initialized )
		{
			return true;
		}
	
		SocketAddr addr(listen_addr);
		if ( ( addr.GetType() != PF_INET ) && ( addr.GetType() != PF_INET6 ) ) return false;

		if ( m_telnet.Init(listen_addr) )
		{
			m_telnet_initialized = true;
		}
	
		if ( ( m_my_proc_name != "" ) && ( m_my_proc_name != my_proc_name ) )
		{
			TRACE("Warning - UniConsoleServer::InitTelnet change proc_name from %s to %s\n", 
					m_my_proc_name.c_str(), my_proc_name.c_str());
		}
		m_my_proc_name = my_proc_name;

		return m_telnet_initialized;
	}
	
	bool					UniConsoleServer::InitInternal(string my_proc_name, string listen_addr)
	{	
		if ( m_internal_initialized )
		{
			return true;
		}
	
		SocketAddr addr(listen_addr);
		if ( addr.GetType() != PF_UNIX ) return false;

		if ( m_internal.Init(listen_addr) )
		{
			m_internal_initialized = true;
		}
	
		if ( ( m_my_proc_name != "" ) && ( m_my_proc_name != my_proc_name ) )
		{
			TRACE("Warning - UniConsoleServer::InitInternal change proc_name from %s to %s\n", 
					m_my_proc_name.c_str(), my_proc_name.c_str());
		}
		m_my_proc_name = my_proc_name;

		return m_internal_initialized;
	}

	void					UniConsoleServer::Command(void* ctx, ConsoleSession* con, int argc, char* argv[])
	{
		(void)ctx;	
		UniConsoleServer::GetInstance().ConsoleCommand(con, argc, argv);
	}

	void					UniConsoleServer::ConsoleCommand(ConsoleSession* con, int argc, char* argv[])
	{
		const char* usage = "Usage:\tstatus|proc|telnet|internal\n";

		argc--; argv++;
		
		if ( argc == 0 ) 
		{
			con->Print(usage);
			return;
		}
		
		if ( !strcmp(argv[0], "status") )
		{
			con->Print("Telnet UniConsole Server is %sup\n", m_telnet_initialized ? "" : "NOT ");
			con->Print("Internal UniConsole Server is %sup\n", m_internal_initialized ? "" : "NOT ");
			con->Print("%d process are known\n", m_proc_map.size());
		}
		else if ( !strcmp(argv[0], "proc") )
		{
			con->Print("%s\n", m_my_proc_name.c_str());
			Dlist<string> list;
			RootConsoleCommand::GetInstance().GetAllCommands(list);
			for (Dlist<string>::Node* node = list.GetHead();
				node != 0; node = list.GetNext(node) )
			{
				con->Print("%s ", node->GetData().c_str());
			}
			con->Print("\n");
		
			for ( UniProcMAP::iterator it = m_proc_map.begin();
					it != m_proc_map.end(); ++it )
			{
				UniConsoleProcInfo& proc = it->second;
				con->Print("%s %d\n", proc.m_proc_name.c_str(), proc.m_proc_id);	
				list = proc.m_commands_support;
				for (Dlist<string>::Node* node = list.GetHead();
						node != 0; node = list.GetNext(node) )
				{
					con->Print("%s ", node->GetData().c_str());
				}	
				con->Print("\n");
			}
		}
		else if ( !strcmp(argv[0], "telnet") )
		{
			m_telnet.ConsoleCommand(con, argc, argv);
		}	
		else if ( !strcmp(argv[0], "internal") )
		{
			m_internal.ConsoleCommand(con, argc, argv);
		}
		else con->Print(usage);
	}
	
	StreamConsoleSession*	UniConsoleServer::FindConsoleSession(ConsoleSession* con)
	{	
		StreamConsoleSession* session = m_telnet.FindConsoleSession(con);
		if ( !session ) session = m_internal.FindConsoleSession(con);
		return session;
	}

	void					UniConsoleServer::Session(void* ctx, ConsoleSession* con, int argc, char* argv[]) 
	{
		(void)ctx;	
		StreamConsoleSession* session = UniConsoleServer::GetInstance().FindConsoleSession(con);
		if ( !session ) con->Print("Run command fail - cannot find obj associated with this Console Session\n");
		else (static_cast<UniConsoleSession*>(session))->SessionConsoleCommand(con, argc-1, argv+1);
	}
	
	void					UniConsoleServer::Connect(void* ctx, ConsoleSession* con, int argc, char* argv[]) 
	{
		(void)ctx;	
		StreamConsoleSession* session = UniConsoleServer::GetInstance().FindConsoleSession(con);
		if ( !session ) con->Print("Run command fail - cannot find obj associated with this Console Session\n");
		else (static_cast<UniConsoleSession*>(session))->ConnectConsoleCommand(con, argc-1, argv+1);
	}

	string					UniConsoleServer::ConnectPath(string proc_name, int proc_id)
	{
		return string::Format("UniConsole_%s_%d", proc_name.c_str(), proc_id);
	}

	bool					UniConsoleServerOnInternalConsoleSocketDown(StreamConsoleSession* session, void* context)
	{
		StreamBase* socket = static_cast<StreamBase*>(context);

		if ( socket )
		{
			return (static_cast<UniConsoleSession*>(session))->OnRemoteShellAccessClosed(socket);
		}

		return false;
	}

	void					UniConsoleServer::OnInternalConsoleClosed(StreamBase* socket)
	{
		m_telnet.SessionIterate(UniConsoleServerOnInternalConsoleSocketDown, socket);
		m_internal.SessionIterate(UniConsoleServerOnInternalConsoleSocketDown, socket);
	}

	UniConsoleProcInfo*		UniConsoleServer::FindProcess(string proc_name, int proc_id)
	{
		string keyword = UniConsoleServer::ConnectPath(proc_name, proc_id);

		UniProcMAP::iterator it = m_proc_map.find(keyword);
		if ( it != m_proc_map.end() ) return &it->second;

		return 0;
	}

	bool					UniConsoleServer::AddProcess(string proc_name, int proc_id)
	{
		string keyword = UniConsoleServer::ConnectPath(proc_name, proc_id);

		UniProcMAP::iterator it = m_proc_map.find(keyword);
		if ( it != m_proc_map.end() ) return false;

		UniConsoleProcInfo& proc = m_proc_map[keyword];
		proc.m_proc_name = proc_name;
		proc.m_proc_id = proc_id;
	
		ConsoleBroadcast("Process %s %d detected - use \"connect\" to start the console\n", proc_name.c_str(), proc_id);

		return true;	
	}

	bool					UniConsoleServerOnProcessRemoved(StreamConsoleSession* session, void* context)
	{
		UniConsoleProcInfo* proc = static_cast<UniConsoleProcInfo*>(context);

		if ( proc )
		{
			(static_cast<UniConsoleSession*>(session))->DelRemoteShell(proc->m_proc_name, proc->m_proc_id);
		}

		return false;	// return false to make iteration over all UniConsoleSession(s)
	}

	void					UniConsoleServer::DelProcess(string proc_name, int proc_id)
	{
		string keyword = UniConsoleServer::ConnectPath(proc_name, proc_id);
		UniProcMAP::iterator it = m_proc_map.find(keyword);
	
		if ( it != m_proc_map.end() )
		{
			UniConsoleProcInfo* proc_to_remove = &it->second;
			m_telnet.SessionIterate(UniConsoleServerOnProcessRemoved, proc_to_remove);
			m_internal.SessionIterate(UniConsoleServerOnProcessRemoved, proc_to_remove);
			m_proc_map.erase(it);
		}	
	}	

	void					UniConsoleServer::UpdateProcCommandsSupport(string proc_name, int proc_id, Dlist<string>& list)
	{	
		string keyword = UniConsoleServer::ConnectPath(proc_name, proc_id);
		UniProcMAP::iterator it = m_proc_map.find(keyword);
	
		if ( it == m_proc_map.end() )
		{
			AddProcess(proc_name, proc_id);
			it = m_proc_map.find(keyword);
		}
		
		if ( it != m_proc_map.end() )
		{
			it->second.m_commands_support = list;
		}
	}

	void					UniConsoleServer::ProcIterate(ProcIterator* iterator, void* context)
	{
		for ( UniProcMAP::iterator it = m_proc_map.begin();
				it != m_proc_map.end(); ++it )
		{
			if ( iterator(&it->second, context) ) return;
		}
	}

	void					UniConsoleServer::SessionIterate(SessionIterator* iterator, void* context)
	{
		m_telnet.SessionIterate(iterator, context);
		m_internal.SessionIterate(iterator, context);
	}

	RemoteAccess::RemoteAccess(ConsoleSession* session, ConsolePrompt* shell_prompt, bool manual)
		:
		ConsoleState(session), m_shell_prompt(shell_prompt),
		m_access("ConsoleRemoteAccess", StreamBase::TlsOpt::DISABLE_TLS, StreamBase::XdrOpt::DISABLE_XDR),
		m_manual(manual), m_in_login(true), 
		m_authorize_magic_word_index(0), 
		m_reject_magic_word_index(0), 
		m_proc_id(0)
	{
		m_access.SetReadCallback(callback(this, &RemoteAccess::OnReadRemote));
		m_access.SetCloseCallback(callback(&UniConsoleServer::GetInstance(), &UniConsoleServer::OnInternalConsoleClosed));
	}

	RemoteAccess::~RemoteAccess()
	{	
		m_access.ClearReadCallback();
		m_access.ClearCloseCallback();
	}

	int						RemoteAccess::SendToRemote(const char* buf, int len)
	{
		int bytes = m_access.WriteBytes(buf, len);
		static const char RETURN[] = {CHAR_CR};
		m_access.WriteBytes(RETURN, sizeof(RETURN));
		return bytes;
	}

	void					RemoteAccess::ForwardCommand(const char* command, int len)
	{
		if ( m_in_login ) return;
		SendToRemote(command, len);
	}

	bool					RemoteAccess::Activate()
	{
		bool result = ConsoleState::Activate();

		if ( result )
		{
			char* buffer = m_shell_prompt->GetBuffer();
			ForwardCommand(buffer, strlen(buffer));
			// 
			// Unset shell prompt because remote console server will print its own prompt
			//
			m_shell_prompt->SetPrompt("");
		}

		ConsoleState::GetSession()->SetState(m_shell_prompt);
	
		return result;
	}

	bool					RemoteAccess::Init(UniConsoleProcInfo* proc)
	{	
		if ( proc == 0 ) return false;	
		m_proc_name = proc->m_proc_name;
		m_proc_id = proc->m_proc_id;
		string connect_addr = "UNIX;" + UniConsoleServer::ConnectPath(m_proc_name, m_proc_id);
		return m_access.Connect(connect_addr, "", false);
	}

	bool					RemoteAccess::SearchMagicWord(char* buf, int num, const char* magic_word, int& magic_word_index)
	{
		int magic_word_size = strlen(magic_word);

		int buf_index = 0;

		// If already in middle of search
		if ( magic_word_index )
		{
			while ( ( magic_word_index < magic_word_size ) && ( buf_index < num ) )
			{
				if ( buf[buf_index] != *(magic_word+magic_word_index) )
				{
					magic_word_index = 0;
					break;
				}
				magic_word_index++;
				buf_index++;
			}
		
			if ( magic_word_index == magic_word_size ) return true;
			if ( magic_word_index && ( buf_index == num ) ) return false;
		}

		char* next = strchr(buf+buf_index, *magic_word);	
		if ( !next ) return false;
	
		magic_word_index = 1;
		next++;
	
		return SearchMagicWord(next, num-(next-buf), magic_word, magic_word_index);
	}

	void					RemoteAccess::OnReadRemote(StreamBase* socket)
	{	
		(void)socket;
		char buffer[128];

		while ( true )
		{
			int num = m_access.ReadBytes(buffer, sizeof(buffer));

			if ( num <= 0 ) break;

			if ( m_in_login )
			{
				if ( SearchMagicWord(buffer, num, internal_authorization_magic_word, m_authorize_magic_word_index) )
				{
					m_in_login = false;
					
					if ( m_manual )
					{
						ConsoleState::GetSession()->Print("Access Granted");
						m_on_manual_login_succeed.Dispatch(this);
					}
					/*
					else
					{	
						ConsoleState::GetSession()->Print("%s(%d) AutoLogin succeed\n", 
						m_proc_name.c_str(), m_proc_id);
					}
					*/
				}
				else if ( SearchMagicWord(buffer, num, internal_reject_magic_word, m_reject_magic_word_index) )
				{	
					if ( m_manual )
					{
						ConsoleState::GetSession()->Print("Sorry, Access Denied\n");
						m_on_manual_login_failed.Dispatch(this);
					}
					/*
					else
					{	
						ConsoleState::GetSession()->Print("%s(%d) AutoLogin failed, try use \"connect\" to manually login\n", 
						m_proc_name.c_str(), m_proc_id);
					}
					*/
				}
				return;
			}

			ConsoleState::GetSession()->Write(buffer, num);
		}
	}

	UniConsoleShell::UniConsoleShell(ConsoleSession* session, ConsolePrompt* shell_prompt)
		:
		ConsoleState(session), m_shell_prompt(shell_prompt)
	{
	}

	UniConsoleShell::~UniConsoleShell()
	{
	}

	bool					UniConsoleShell::Activate()
	{	
		bool result = ConsoleState::Activate();

		if ( result )
		{
			string proc_name = "";		// Empty proc name means stay with current
			string proc_id_str = "";	// Empty proc id means only proc name is specified

			char* buffer = m_shell_prompt->GetBuffer();	
			//
			// Bug 33911: Close parent console if "exit" or "quit", do not forward to remote
			//
			if ( 
				( strcmp(buffer, COMMAND_EXIT) == 0 ) ||
				( strcmp(buffer, COMMAND_QUIT) == 0 ) 
			   )
			{
				GetSession()->StopConsole();
				return result;
			}

			char* data = buffer;
			char* p = strchr(data, ';');
			if ( p )
			{
				*p = '\0';
				int c = (int)(*data);
				while ( !isalpha(c) && !isdigit(c) && ((char)c != '\0') && ((char)c != '*') )
				{
					data++;
					c = (int)(*data);
				}					
		
				proc_name = strtok(data, " ");
				proc_id_str = strtok(NULL, " ");

				m_shell_prompt->OffsetBuffer(p-buffer+1);
			}

			m_on_switch.Dispatch(proc_name, proc_id_str);
		}

		return result;
	}

	UniConsoleSession::UniConsoleSession(
											bool telnet,
											const Callback1<char*> &event_cb, 
											StreamConsoleServer* parent, 
											StreamClientHandler *sock)
		:
		StreamConsoleSession(telnet, event_cb, parent, sock),	
		m_telnet(telnet), 
		m_uni_shell(0), m_default_shell(0), 
		m_manual_login_shell(0), m_remote_manual_login(0),
		m_console_session(0), m_session_shell(0)
	{
	}

	UniConsoleSession::~UniConsoleSession()
	{
		if ( m_uni_shell ) delete m_uni_shell;

		for ( Dlist<RemoteAccess*>::Node* node = m_remote_shells.GetHead();
				node != 0; node = m_remote_shells.GetNext(node) )
		{
			delete node->GetData();
		}
		m_remote_shells.Clear();

		if ( m_manual_login_shell ) delete m_manual_login_shell;
	}

	bool					UniConsoleSession::SetConsole(ConsoleSession* console)
	{
		if ( !StreamConsoleSession::SetConsole(console) ) return false;		
		m_console_session = console;
		m_console_session->SetSupportCommandsQueryCbk(callback(this, &UniConsoleSession::UniConsoleSupportedCommands));

		if ( m_telnet ) m_session_shell = (static_cast<ConsoleTelnet*>(m_console_session))->TelnetShell();
		else m_session_shell = (static_cast<ConsoleInternal*>(m_console_session))->InternalShell();
		if ( !m_session_shell ) return false;

		m_uni_shell = new UniConsoleShell(m_console_session, m_session_shell->ShellPrompt());
		if ( !m_uni_shell ) return false;
		m_uni_shell->m_on_switch = callback(this, &UniConsoleSession::OnSwitchShell);

		m_manual_login_shell = new ConsoleLoginShell(m_console_session, &RemoteLoginCallback);
		if ( !m_manual_login_shell ) return false;

		m_session_shell->ShellPrompt()->SetSuccess(m_uni_shell);
		m_default_shell = m_session_shell;
			
		return true;
	}

	RemoteAccess*			UniConsoleSession::FindRemoteShell(string proc_name, int proc_id)
	{	
		for ( Dlist<RemoteAccess*>::Node* node = m_remote_shells.GetHead();
				node != 0; node = m_remote_shells.GetNext(node) )
		{
			RemoteAccess* shell = node->GetData();
			if ( shell && ( shell->m_proc_name == proc_name ) && ( shell->m_proc_id == proc_id ) ) return shell;
		}
		return 0;	
	}

	void					UniConsoleSession::DelRemoteShell(string proc_name, int proc_id)
	{	
		for ( Dlist<RemoteAccess*>::Node* node = m_remote_shells.GetHead();
				node != 0; node = m_remote_shells.GetNext(node) )
		{
			RemoteAccess* shell = node->GetData();
			if ( shell && ( shell->m_proc_name == proc_name ) && ( shell->m_proc_id == proc_id ) )
			{
				m_console_session->Print("\nConsole to %s %d stopped\n", proc_name.c_str(), proc_id);
				if ( m_default_shell == static_cast<ConsoleState*>(shell) ) m_default_shell = m_session_shell;
				if ( m_remote_manual_login == shell )
				{
					m_remote_manual_login = 0;
					m_console_session->SetState(m_session_shell->ShellPrompt());
				}
				m_remote_shells.Remove(node);
				delete shell;
				return;
			}
		}
	}

	RemoteAccess*			UniConsoleSession::AddRemoteShell(UniConsoleProcInfo* proc, bool manual)
	{
		if ( proc == 0 ) return 0;
		RemoteAccess* shell = FindRemoteShell(proc->m_proc_name, proc->m_proc_id);
	
		if ( !shell ) 
		{
			shell = new RemoteAccess(m_console_session, m_session_shell->ShellPrompt(), manual);

			if ( shell && shell->Init(proc) )
			{
				m_remote_shells.Append(shell);
				if ( manual ) StartRemoteShellManualLogin(shell);
			}
			else
			{
				if ( shell )
				{
					m_console_session->Print("UniConsoleSession - FAILED TO INIT INTERNAL CONSOLE CONNECTION TO %s(%d)!!\n", 
							proc->m_proc_name.c_str(), proc->m_proc_id);
					delete shell;
					shell = 0;
				}
			}
		}
	
		return shell;
	}

	void					UniConsoleSession::OnSwitchShell(string proc_name, string proc_id_str)
	{
		Dlist<RemoteAccess*> extra_remote_access;

		if ( proc_name != "" )
		{
			if ( proc_name == "*" ) // All 
			{	
				// All remote access shell 
				for ( Dlist<RemoteAccess*>::Node* node = m_remote_shells.GetHead();
						node != 0; node = m_remote_shells.GetNext(node) )
				{
					extra_remote_access.Append(node->GetData());
				}
				// UniConsole shell
				m_default_shell = m_session_shell;
			}
			else if ( proc_name == UniConsoleServer::GetInstance().m_my_proc_name ) 
			{
				m_default_shell = m_session_shell;
			}
			else 
			{
				m_default_shell = 0;
				for ( Dlist<RemoteAccess*>::Node* node = m_remote_shells.GetHead();
						node != 0; node = m_remote_shells.GetNext(node) )
				{
					RemoteAccess* shell = node->GetData();
					if ( shell->m_proc_name == proc_name )
					{
						if ( proc_id_str == "*" ) 
						{
							extra_remote_access.Append(shell);
						}
						else // proc_id_str: "empty" means find first good
						{
							if ( 
								proc_id_str.is_empty() ||
								( isdigit(*proc_id_str.c_str()) && ( shell->m_proc_id == atoi(proc_id_str.c_str()) ) )
							   )
							{
								if ( shell->InLogin() )
								{
									if ( proc_id_str.is_empty() ) continue;	// Continue search next 
								}
								else
								{
									extra_remote_access.Append(shell);
								}
								break;
							}
						}
					}
				}
				//
				Dlist<RemoteAccess*>::Node* tail = extra_remote_access.GetTail();
				if ( !tail )
				{
					m_console_session->Print("\nConsole to %s %s not exist!\n", 
							proc_name.c_str(), proc_id_str.c_str());
				}
				else
				{	
					m_default_shell = tail->GetData();
					extra_remote_access.Remove(tail);
				}
			}
		}
		//
		for ( Dlist<RemoteAccess*>::Node* node = extra_remote_access.GetHead();
				node != 0; node = extra_remote_access.GetNext(node) )
		{
			RemoteAccess* shell = node->GetData();
			char* command = m_session_shell->ShellPrompt()->GetBuffer();
			shell->ForwardCommand(command, strlen(command));
		}
		//
		if ( m_default_shell )
		{
			m_console_session->SetState(m_default_shell);
		}
		else
		{
			m_console_session->Print("\nError detected! Switch to local Console ...\n");
			m_default_shell = m_session_shell;
			// Igore the command line and go to prompt directly
			m_console_session->SetState(m_session_shell->ShellPrompt());
		}
	}

	void					UniConsoleSession::StartRemoteShellManualLogin(RemoteAccess* shell)
	{	
		if ( shell )
		{
			shell->m_on_manual_login_succeed = callback(this, &UniConsoleSession::OnRemoteShellManualLoginDone);
			shell->m_on_manual_login_failed = callback(this, &UniConsoleSession::StartRemoteShellManualLogin);
			m_remote_manual_login = shell;
			m_remote_manual_login->m_authorize_magic_word_index = 0;
			m_remote_manual_login->m_reject_magic_word_index = 0;
			m_manual_login_shell->Reset();
			m_manual_login_shell->SetSuccess(m_remote_manual_login);
			m_console_session->SetState(m_manual_login_shell);
		}
	}

	void					UniConsoleSession::OnRemoteShellManualLoginDone(RemoteAccess* shell)
	{
		if ( shell != m_remote_manual_login ) 
		{
			m_console_session->Print("Invalid manual login callback detected!\n");
			return;
		}
		
		if ( m_manual_login_shell ) m_manual_login_shell->Reset();
		m_remote_manual_login = 0;

		m_console_session->SetState(m_session_shell->ShellPrompt());
		m_default_shell = shell;
	}

	bool					UniConsoleSession::OnRemoteShellAccessClosed(StreamBase* socket)
	{	
		for ( Dlist<RemoteAccess*>::Node* node = m_remote_shells.GetHead();
				node != 0; node = m_remote_shells.GetNext(node) )
		{
			RemoteAccess* shell = node->GetData();
			if ( shell && ( socket == &shell->m_access ) )
			{
				DelRemoteShell(shell->m_proc_name, shell->m_proc_id);
				return true;
			}
		}

		return false;
	}

	void					UniConsoleSession::UniConsoleSupportedCommands(Dlist<string>& list)
	{
		if ( m_default_shell == m_session_shell )
		{
			m_console_session->RootConsoleSupportedCommands(list);
			return;
		}
		
		if ( m_default_shell )
		{
			RemoteAccess* shell = static_cast<RemoteAccess*>(m_default_shell);
			UniConsoleProcInfo* config = UniConsoleServer::GetInstance().FindProcess(shell->m_proc_name, shell->m_proc_id);
			if ( config ) list = config->m_commands_support;
		}
	}

	void						UniConsoleSession::ConnectConsoleCommand(ConsoleSession *con, int argc, char* argv[])
	{
		const char* usage = "Usage:\tproc_name proc_id\n";
	
		if ( !m_telnet ) 
		{
			con->Print("\"Connect\" console command not supported by internal console session\n");
			return;
		}

		if ( argc != 2 )
		{
			con->Print(usage);
			return;
		}
	
		string proc_name = argv[0];
		int proc_id = atoi(argv[1]);
	
		for ( UniProcMAP::iterator it = UniConsoleServer::GetInstance().m_proc_map.begin();
				it != UniConsoleServer::GetInstance().m_proc_map.end(); ++it )
		{
			UniConsoleProcInfo& proc = it->second;
			if ( ( proc.m_proc_name == proc_name ) && ( proc.m_proc_id == proc_id ) )
			{
				RemoteAccess* shell = FindRemoteShell(proc_name, proc_id );
				if ( shell )
				{
					if ( !shell->InLogin() )
					{
						con->Print("Console to %s(%d) already exists\n", proc_name.c_str(), proc_id);
					}
					else
					{
						shell->SetManual();
						StartRemoteShellManualLogin(shell);
					}
				}
				else
				{	
					m_default_shell = AddRemoteShell(&proc, true);
				}
				return;
			}
		}
	
		con->Print("No process %s(%d)\n", proc_name.c_str(), proc_id);	
	}
	
	void					UniConsoleSession::SessionConsoleCommand(ConsoleSession* con, int argc, char* argv[])
	{
		(void)argc; (void)argv;

		for ( Dlist<RemoteAccess*>::Node* node = m_remote_shells.GetHead();
				node != 0; node = m_remote_shells.GetNext(node) )
		{
			RemoteAccess* shell = node->GetData();
			if ( shell )
			{
				con->Print("%s %d: %s\n", shell->m_proc_name.c_str(), shell->m_proc_id, shell->InLogin() ? "Not Logged in" : "Logged in");
			}
		}	
	}

	void						UniConsoleSession::AutoLogin(const char* username, const char* password)
	{	
		for ( UniProcMAP::iterator it = UniConsoleServer::GetInstance().m_proc_map.begin();
				it != UniConsoleServer::GetInstance().m_proc_map.end(); ++it )
		{
			UniConsoleProcInfo& proc = it->second;
			RemoteAccess* shell = AddRemoteShell(&proc, false);
			if ( shell )
			{
				static const char RETURN[] = {CHAR_CR};	
				shell->SendToRemote(username, strlen(username));
				shell->SendToRemote(RETURN,sizeof(RETURN));
				shell->SendToRemote(password, strlen(password));
				shell->SendToRemote(RETURN,sizeof(RETURN));
			}
		}
		m_default_shell = m_session_shell;
	}
	
	void						UniConsoleSession::RemoteLogin(const char* username, const char* password)
	{	
		if ( m_remote_manual_login )
		{
			m_remote_manual_login->SendToRemote(username, strlen(username));
			m_remote_manual_login->SendToRemote(password, strlen(password));
		}
	}
	
	unsigned					UniTelnetLoginCallback(ConsoleSession* con, const char* username, const char* password)
	{	
		unsigned role = MyLoginCallback(con, username, password);

		if ( role != CONSOLE_ROLE_DEFAULT )
		{
			//
			// Automatically use the same username/password to login
			//
			StreamConsoleSession* sess = UniConsoleServer::GetInstance().FindConsoleSession(con);
			if ( sess ) (static_cast<UniConsoleSession*>(sess))->AutoLogin(username, password);
		}

		return role;
	}
		
	unsigned					UniInternalLoginCallback(ConsoleSession* con, const char* username, const char* password)
	{	
		unsigned role = InternalLoginCallback(con, username, password);

		if ( role != CONSOLE_ROLE_DEFAULT )
		{
			//
			// Automatically use the same username/password to login
			//
			StreamConsoleSession* sess = UniConsoleServer::GetInstance().FindConsoleSession(con);
			if ( sess ) (static_cast<UniConsoleSession*>(sess))->AutoLogin(username, password);
		}

		return role;
	}

	unsigned					RemoteLoginCallback(ConsoleSession* con, const char* username, const char* password)
	{		
		StreamConsoleSession* sess = UniConsoleServer::GetInstance().FindConsoleSession(con);
		if ( sess ) (static_cast<UniConsoleSession*>(sess))->RemoteLogin(username, password);
		return con->GetRole();
	}

}//end namespace colib
