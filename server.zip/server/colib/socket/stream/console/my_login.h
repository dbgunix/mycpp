#ifndef MY_CONSOLE_LOGIN_H
#define MY_CONSOLE_LOGIN_H

namespace colib
{

extern const char* internal_authorization_magic_word;
extern const char* internal_reject_magic_word;

class ConsoleSession;

unsigned MyLoginCallback(ConsoleSession* session, const char* username, const char* password);
unsigned InternalLoginCallback(ConsoleSession* session, const char* username, const char* password);

}


#endif
