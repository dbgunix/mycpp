// telnet.h
// vi:set ts=4 sw=4 nowrap:

#ifndef CONSOLE_TELNET_H_ALREADY_INCLUDED
#define CONSOLE_TELNET_H_ALREADY_INCLUDED

#include <console/telnet.h>

namespace colib
{
	class StreamConsoleSession;

	class TelnetConsoleSession : public ConsoleTelnet
	{
		public:

										TelnetConsoleSession(
												ConsoleServer*, 
												ConsoleLoginShell::Callback*, 
												StreamConsoleSession&);
			virtual						~TelnetConsoleSession();					
			//
			// Functions for Console
			//
			virtual int					Write(const void *buf, unsigned int len);
			virtual void				StopConsole();
			virtual void				SetState(ConsoleState* state);
			virtual bool				IsTrusted() const { return m_is_trusted; }
			virtual void				SetTrusted(bool bTrusted) { m_is_trusted = bTrusted; }
			virtual string				Prompt();
			virtual string				GetName();

		private:
		
			StreamConsoleSession&		m_stream_session;
			bool						m_is_trusted;
	};

}//end namespace colib


#endif

