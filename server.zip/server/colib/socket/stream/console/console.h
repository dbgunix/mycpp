#if !defined(__STREAM_CONSOLE_H__)
#define __STREAM_CONSOLE_H__

#include <console/server.h>
#include <socket/stream/console/telnet.h>
#include <socket/stream/console/internal.h>
#include <socket/stream/stream_server.h>

namespace colib
{

void console_TRACE(const char* fmt, va_list args);
void console_TRACE(int level, const char* fmt, va_list args);
void TraceToConsole();

class ConsoleGlobal
{
public:
	static ConsoleGlobal& GetInstance();
	void RegisterConsoleCommand();

private:
	ConsoleGlobal() {};
};

class StreamBase;
class StreamClientHandler;
class StreamConsoleSession;

class StreamConsoleServer : public ConsoleServer
{
public:
	virtual ~StreamConsoleServer() {}	// Memory leak?
	string GetType() const { return m_telnet ? "telnet" : "internal"; }
	virtual bool Init(string listen_addr);
	void SetEventNotifcationCallback(const Callback1<char*> &event_cb);

	StreamConsoleSession* FindConsoleSession(ConsoleSession* con);

	typedef bool SessionIterator(StreamConsoleSession* session, void* context);
	void SessionIterate(SessionIterator* iterator, void* context);

	void ConsoleCommand(ConsoleSession *con, int argc, char *argv[]) { m_stream_svr.ConsoleCommand(con, argc-1, argv+1); }

protected:
	StreamConsoleServer(bool telnet);
	StreamConsoleServer(const char* name, bool telnet);
	virtual StreamConsoleSession* NewStreamConsoleSession(bool, const Callback1<char*>&, StreamConsoleServer*, StreamClientHandler*);
	virtual ConsoleSession* NewTelnetConsole(StreamConsoleSession&);
	virtual ConsoleSession* NewInternalConsole(StreamConsoleSession&);

private:
	void NewSession(StreamClientHandler *ch);
	void SessionClosed(StreamBase *ch);
	StreamServer m_stream_svr;
	bool m_telnet;
	// data structure for sessions
	/// map of SCH to StreamConsoleSession
	std::map<StreamClientHandler*, StreamConsoleSession*> m_sessions;
	Callback1<char*> m_session_event_notification;
};

class GlobalTelnetConsoleServer : public StreamConsoleServer
{
public:
	static GlobalTelnetConsoleServer& GetInstance();
	bool Init(string listen_addr);
	static void Command(void* ctx, ConsoleSession* con, int argc, char* argv[]);

private:
	bool m_initialized;
	GlobalTelnetConsoleServer();
};

class GlobalInternalConsoleServer : public StreamConsoleServer
{
public:
	static GlobalInternalConsoleServer& GetInstance();
	bool Init(string listen_addr);
	static void Command(void* ctx, ConsoleSession* con, int argc, char* argv[]);

private:
	bool m_initialized;
	GlobalInternalConsoleServer();
};

class StreamConsoleSession
{
public:
	StreamConsoleSession(bool telnet, const Callback1<char*> &event_cb, StreamConsoleServer *parent, StreamClientHandler *socket)
		: m_telnet(telnet)
		, m_parent(parent)
		, m_socket(socket)
		, m_event_notification(event_cb)
		, m_console(0)
		, m_session_name(m_telnet ? "TelnetConsole" : "InternalConsole")
	{
	}
	virtual ~StreamConsoleSession();

	void Init();
	string GetPeerAddr() { return m_peer_addr; }

	ConsoleSession* GetConsole() const { return m_console; }
	virtual bool SetConsole(ConsoleSession* console)
	{
		m_console = console;
		return m_console;
	}

	int Write(const char *buf, int len);
	void DisconnectSocket();

	StreamConsoleSession(const StreamConsoleSession&) = delete;
	StreamConsoleSession& operator=(const StreamConsoleSession&) = delete;

protected:
	bool m_telnet;
	StreamConsoleServer *m_parent;
	StreamClientHandler *m_socket;
	Callback1<char*> m_event_notification;
	ConsoleSession* m_console;

	string m_session_name;
	string m_peer_addr;

private:
	int CopyToBuffer(char *dest, const char *src, int size, int &consumed, int max);
	void SessionAwake(StreamBase *sock);
	void SocketReadEvent(StreamBase *sock);
};

void CmdTraceLevel(void *ctx, ConsoleSession *con, int argc, char* argv[]);
void CmdTerminate(void *ctx, ConsoleSession *con, int argc, char* argv[]);
void CmdVersion(void *ctx, ConsoleSession *con, int argc, char* argv[]);
void CmdGecho(void *ctx, ConsoleSession *con, int argc, char* argv[]);
void CmdEventLoop(void *ctx, ConsoleSession *con, int argc, char* argv[]);
void CmdParams(void *ctx, ConsoleSession *con, int argc, char* argv[]);
void CmdSbPool(void *ctx, ConsoleSession *con, int argc, char* argv[]);
//void CmdHeap(void* context, ConsoleSession* console, int argc, char* argv[]);

}//end namespace colib

#endif
