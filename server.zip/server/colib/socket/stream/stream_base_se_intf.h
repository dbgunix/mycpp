#if !defined(__STREAM_BASE_SE_INTF_H__)
#define __STREAM_BASE_SE_INTF_H__

#include <utils/string.h>

namespace colib
{

class SocketEngineBase;
class SocketEngineTLS;
class SocketAddr;
class ValueList;

class StreamBaseSeIntf
{
public:
	virtual ~StreamBaseSeIntf() { }

private:
	friend class SocketEngineBase;
	friend class SocketEngineTLS;
	// events
	virtual void ReadEvent() = 0;
	virtual void CloseEvent() = 0;
	virtual void AwakenEvent() = 0;
	virtual void WriteDoneEvent() = 0;
	virtual void TxQueueAvailableEvent() = 0;
	// requests
	virtual void CloseNeeded() = 0;
	// queries
	virtual string GetPeerAddrStr() const = 0;
	virtual const ValueList& GetParams()  const = 0;
	virtual const ValueList& GetTlsParams() const = 0;
};

}

#endif
