#if !defined(__TLS_CORE_H__)
#define __TLS_CORE_H__

#include <socket/stream/tls_context.h>
#include <timer/oneshot_timer.h>
#include <utils/callback.h>
#include <config/value.h>
#include <socket/socket_buffer.h>
#include <crypt/pki/format/x509_cert.h>
#include <utils/trace/writable.h>

#ifdef CONFIG_HAVE_TLS 
#include <openssl/ssl.h>

namespace colib
{
	class SocketEngineTLS;
	class MemberSet;
	class ConsoleSession;

	class TlsCore
	{
		public:
			enum HandshakeResult
			{
				SUCCESS = 0,
				FAILURE,
				IN_PROGRESS_READ,
				IN_PROGRESS_WRITE
			};

			enum Stats
			{
				Stat_num_verify_common_name_succeed,
				Stat_num_verify_common_name_failed,
				Stat_latest_verify_common_name_failed_reason,
				Stat_num_collect_session_info_succeed,
				Stat_num_collect_session_info_failed,
				Stat_latest_collect_session_info_failed_reason
			};

									TlsCore(SocketEngineTLS& parent, MemberSet& trace_set);
			virtual					~TlsCore();

			ValueList&				GetStats() { return m_stats; }
			string					Print() const;

			bool 					Init(int fd);

			void					SetConnectHandshake();
			HandshakeResult			Handshake();

			void					Cleanup();
			void					Shutdown();

			bool					IsConnecting() const;
			bool					IsDisconnecting() const;
			//
			// Expected Peer Common Name
			//
			void					SetExpectedPeerCommonName(string common_name);
			string					GetExpectedPeerCommonName() const;
			//
			int						SSL_write(SocketBuffer* mssg);
			int						SSL_read(SocketBuffer* mssg);
			int						SSL_error(int res) const;
			bool					DataPending() const;
			//
			string					GetPeerCertStrPEM() const;
			x509_Certificate&		GetPeerCert() { return m_peer_certificate; }

			void					ConsoleCommand(ConsoleSession* con, int argc, char* argv[]);

		private:

			void					CollectSessionInfo();
			HandshakeResult			VerifyPeer();
			bool					VerifyPeerCommonName();

			void					OnHandshakeTimerExpired(unsigned int, void*);

		private:
			typedef int(*SSL_Handshake)(SSL*);

			static const int		CIPHER_DESC_SIZE = 256;

			SocketEngineTLS&		m_parent;
			MemberSet&				m_trace_set;

			SSL_Handshake			m_handshake_func;
			OneShotTimer			m_handshake_timer;
			//
			bool					m_connecting;
			bool					m_shutdown_in_progress;
			//
			SSL*					m_tls;
			char					m_cipher_description[CIPHER_DESC_SIZE];
			string					m_expected_peer_common_name;
			x509_Certificate		m_peer_certificate;
			CertVerifyOpt			m_verify_opt;
			//
			const ValueList&		m_params;
			ValueList				m_stats;
	};
	#define TLSCOREPARAM(param)		m_params[SocketParams::TlsParam_##param].AsInt()
	#define TLSCORESTAT(stat)		m_stats[TlsCore::Stat_##stat].AsInt()

	inline void		TlsCore::SetConnectHandshake()
	{
		m_handshake_func = SSL_connect;
	}

	inline bool		TlsCore::IsConnecting() const
	{
		return m_connecting;
	}

	inline bool		TlsCore::IsDisconnecting() const
	{
		return m_shutdown_in_progress;
	}

	inline void		TlsCore::SetExpectedPeerCommonName(string common_name)
	{
		m_expected_peer_common_name = common_name;
	}

	inline string	TlsCore::GetExpectedPeerCommonName() const
	{
		return m_expected_peer_common_name;
	}

	inline int		TlsCore::SSL_write(SocketBuffer* mssg)
	{
		return ::SSL_write(m_tls, mssg->GetData(), mssg->GetLength());
	}

	inline int		TlsCore::SSL_read(SocketBuffer *mssg)
	{
	   	return ::SSL_read(m_tls, mssg->GetData(), mssg->MaxLength());
	}

	inline int		TlsCore::SSL_error(int res) const
	{
		return SSL_get_error(m_tls, res);
	}

	inline bool		TlsCore::DataPending() const
	{
		return SSL_pending(m_tls) > 0;
	}
}

#endif
