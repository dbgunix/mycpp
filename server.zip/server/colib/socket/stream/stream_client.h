#if !defined(__STREAM_CLIENT_H__)
#define __STREAM_CLIENT_H__

#include<socket/socket_addr.h>
#include<socket/stream/stream_base.h>
#include<socket/stream/socket_params.h>
#include<timer/oneshot_timer.h>

namespace colib
{

class Writable;

class StreamClient : public StreamBase
{
public:
	enum Stats
	{
	};

	StreamClient(const char *name, StreamBase::TlsOpt tls, StreamBase::XdrOpt xdr);
	virtual ~StreamClient() { }

	void EnableAutoRetry(int max_retries, int retry_interval_msec);
	void DisableAutoRetry();
	void SetAutoRetryFailedCb(const Callback1<StreamClient&> &cbk) { m_retry_failed_cb = cbk; }

	bool Connect(string server_addr, string local_addr, bool blocking_connect);
	void Disconnect(bool reconnect = false);
	bool Reload(const OptionsNode& base_opts, const OptionsNode& tls_opts);
	bool IsConnecting() const;

	virtual string ConsoleHelp() const;
	virtual void ConsoleCommand(Writable *to, int argc, char *argv[]);
	void SetTlsAuthLevel(int level) { m_socket_params.GetTlsParams()[SocketParams::TlsParam_tls_auth_peer] = level; }
	void AddWritable(int level, Writable *out) { m_trace_set.AddWritable(level, out); }

	// wrapper function to enforce trust check
	void TrustedServerRequired();
	// wrapper function to enforce trust + common name check
	void TrustedServerWithCommonNameRequired(string server_common_name);

private:
	eCallbackRt DisconnectAct();
	void RetryTimerExpired(unsigned clock, void *data);
	void CheckRetry();
	bool DoConnect();
	void DoDisconnect();
	virtual void AwakenEvent();
	// called by socketengine via intf
	void CloseNeeded();

	bool m_is_initialized;
	bool m_blocking_connect;
	SocketParams m_socket_params;
	ActivityHold m_close_act;
	// retry elements
	OneShotTimer m_retry_timer;
	int m_retry_interval_msec;
	int m_max_retries;
	int m_num_retries;
	Callback1<StreamClient&> m_retry_failed_cb;
	bool m_local_addr_provided;
	string m_connect_err;
};

}

#endif
