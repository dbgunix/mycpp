#if !defined(__STREAM_ERR_H__)
#define __STREAM_ERR_H__

namespace colib
{

enum class StreamWriteError
{
	NONE,
	INVALID_FD,
	INVALID_LENGTH,
	TX_QUEUE_FULL,
	ENCODE_FAILED,
	BUF_UNAVAILABLE
};

}

#endif
