#if !defined(__MESSAGE_PROCESSOR_H__)
#define __MESSAGE_PROCESSOR_H__

#include <event_loop/activity_hld.h>
#include <utils/callback.h>
#include <message/message.h>
#include <config/value.h>
#include <socket/socket_buffer.h>
#include "socket/stream/stream_err.h"

#include <map>

namespace colib
{

class StreamBase;
class MemberSet;
class Writable;

class MessageProcessor
{
public:
	static const int MAX_MSG_LENGTH = 16 * 1024; // 2M

	enum Stats
	{
		Stat_rx_reg_messages,
		Stat_reg_message_fail_permissions,
		Stat_rx_any_messages,
		Stat_rx_unreg_messages,
		Stat_tx_messages,
		Stat_encode_failures,
		Stat_tx_errors,
		Stat_rx_length_errors
	};
	ValueList& GetStats() { return m_stats; }

	MessageProcessor(const char* name, StreamBase& parent, MemberSet& trace_set);
	~MessageProcessor();
	bool WriteXdrData(CEncodableItem &data, StreamWriteError& err_code);
	bool WriteMessage(Message &msg, StreamWriteError& err_code);
	void SocketReadEvent(StreamBase *stream_socket);

	void Register(int msg_type, const Callback3<char*, int, StreamBase*> &cbk);
	void UnRegister(int msg_type);
	void UnRegisterAll();
	void SetAnyXdrCb(const Callback3<char*, int, StreamBase*> &cbk) { m_any_xdr_cb = cbk; }
	void ClearAnyXdrCb() { m_any_xdr_cb.Clear(); }
	void SetMsgErrorCb(const Callback1<StreamBase*> &cbk) { m_msg_error_cb = cbk; }
	void ClearMsgErrorCb() { m_msg_error_cb.Clear(); }

	void ConsoleCommand(Writable *to, int argc, char *argv[]);

private:
	void ParseData(char *data, int len);
	eCallbackRt ReadXdr();
	void DumpReg(Writable *to) const;
	void ResetMsgCounts();

	struct MsgCbDesc
	{
		int m_msg_type;
		Callback3<char*, int, StreamBase*> m_cbk;
		uint32_t m_hit_count;

		MsgCbDesc(int type, const Callback3<char*, int, StreamBase*> &cbk);
		MsgCbDesc(const MsgCbDesc &other);
		MsgCbDesc& operator=(const MsgCbDesc &other);
	};

	typedef std::map<int, MsgCbDesc> CbkRegMap;

	string m_name;
	CbkRegMap m_cbk_map;
	Callback3<char*, int, StreamBase*> m_any_xdr_cb;
	Callback1<StreamBase*> m_msg_error_cb;

	static const int INITIAL_BUF_SIZE = 128*1024;
	char *m_rx_buf;
	int m_capacity;
	int m_data_length;
	int m_offset;
	bool m_in_progress;

	StreamBase& m_parent;
	ActivityHold m_message_handler;
	MemberSet &m_trace_set;
	ValueList m_stats;

	MessageProcessor(const MessageProcessor&);
	void operator=(const MessageProcessor&);
};

#define MSGPROCSTAT(stat) m_stats[MessageProcessor::Stat_##stat].AsInt()

}

#endif
