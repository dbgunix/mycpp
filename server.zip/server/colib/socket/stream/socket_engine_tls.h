#if !defined(__SOCKET_ENGINE_TLS_H__)
#define __SOCKET_ENGINE_TLS_H__


#ifdef CONFIG_HAVE_TLS
#include <socket/stream/socket_engine_base.h>
#include <socket/stream/tls_core.h>

namespace colib
{

class StreamBaseSeIntf;

class SocketEngineTLS : public SocketEngineBase
{
public:
	SocketEngineTLS(const char *name, int fd, StreamBaseSeIntf &parent, MemberSet &trace_set);
	bool Init();
	virtual bool Connect(string server_addr, string& local_addr, bool blocking_connect, string& err);
	virtual void Disconnect();
	void TLS_ShutdownProgress(bool tls_shutdown_complete);
	void SetTlsPeerName(string name) { m_tls_core.SetExpectedPeerCommonName(name); }
	virtual string GetTlsPeerName() const { return m_tls_core.GetExpectedPeerCommonName(); }

	const ValueList& GetTlsParams() const { return m_tls_params; }
	virtual ValueList* GetTlsStats() { return &m_tls_core.GetStats(); }
	virtual string GetTlsState() const { return m_tls_core.Print(); }

	virtual string GetPeerCertStrPEM() const { return m_tls_core.GetPeerCertStrPEM(); }

private:
	void HandleHandshake(const char* source);
	void read();
	void write();

	const ValueList& m_tls_params;
	TlsCore m_tls_core;
};

}

#endif

#endif
