#if !defined(__SOCKET_PARAMS_H__)
#define __SOCKET_PARAMS_H__

#include<config/value.h>

namespace colib
{

class SocketParams
{
public:
	SocketParams();

	enum Params
	{
		Param_tx_queue_limit
	};

	ValueList& GetParams() { return m_params; }
	const ValueList& GetParams() const { return m_params; }

	enum TlsParams
	{
		TlsParam_tls_auth_peer,
		TlsParam_tls_handshake_timeout_sec
	};

	ValueList& GetTlsParams() { return m_tls_params; }
	const ValueList& GetTlsParams() const { return m_tls_params; }

	void Reset() { m_params.Reset(); m_tls_params.Reset(); }

private:
	ValueList m_params;
	ValueList m_tls_params;
};

/*
class SocketTlsParams()
{
};
*/

}

#endif
