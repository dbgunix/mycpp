#if !defined(__SOCKET_ENGINE_BASE_H__)
#define __SOCKET_ENGINE_BASE_H__

#include <event_loop/fdh.h>
#include <socket/stream/stream_err.h>
#include <config/value.h>

#include <list>

namespace colib
{

class MemberSet;
class StreamBaseSeIntf;
class SocketAddr;
class SocketBuffer;
class SocketBufferPool;

class SocketEngineBase : public FileDescriptorHandler
{
public:
	enum Stats
	{
		Stat_rx_bytes,
		Stat_tx_bytes,
		Stat_rx_queue_size,
		Stat_tx_queue_size,
		Stat_read_fail_no_sbuf
	};
	ValueList& GetStats();

	virtual ValueList* GetTlsStats() { return 0; }
	virtual string GetTlsState() const { return ""; }

	virtual ~SocketEngineBase();

	virtual bool Init();

	bool TestWriteBytesSpace(int bufsize);

	int ReadBytes(char *buf, int len);
	SocketBuffer* ReadBuffer();
	int WriteBytes(const char* buf, int len, StreamWriteError& err_code);
	bool WriteBuffer(SocketBuffer* buf, StreamWriteError& err_code);
	bool WriteBufferList(std::list<SocketBuffer*>& buf_list, StreamWriteError& err_code);

	virtual bool Connect(string server_addr, string& local_addr, bool blocking_connect, string& err);
	virtual void Disconnect();
	bool IsConnecting() const { return m_connecting; }
	bool IsTxQueueFull() const { return m_tx_queue_full; }

	void EnableRead() { FileDescriptorHandler::EnableRead(); UpdateFlag(); }
	void EnableWrite() { FileDescriptorHandler::EnableWrite(); UpdateFlag(); }
	void DisableRead() { FileDescriptorHandler::DisableRead(); }
	void DisableWrite() { FileDescriptorHandler::DisableWrite(); }
	bool MakeNonBlocking() { return FileDescriptorHandler::MakeNonBlocking(); }

	virtual void SetTlsPeerName(string name) { (void)name; }
	virtual string GetTlsPeerName() const { return ""; }
	virtual string GetPeerCertStrPEM() const { return ""; }
	void GetLocalName(SocketAddr& local_addr);

	void PrintRxQueue(Writable* to) const;

protected:
	SocketEngineBase(const char *name, int fd, StreamBaseSeIntf &parent, MemberSet &trace_set);

	void UpdateFlag();
	bool TxQueueSpaceAvailable(int num_buf_needed) const;
	bool SpaceToWriteBytes(int bufsize) const;
	void InitiateClose();
	void ReadEvent();
	void CloseEvent();
	void AwakenEvent();
	void WriteDoneEvent();
	void TxQueueAvailableEvent();
	void CloseNeeded();
	string GetPeerAddrStr() const;

	StreamBaseSeIntf &m_parent;
	MemberSet &m_trace_set;
	SocketBufferPool& m_buf_pool; // not strictly needed, will be used later

	std::list<SocketBuffer*> m_tx_queue;
	std::list<SocketBuffer*> m_rx_queue;

	bool m_need_to_close;
	bool m_need_to_empty_buf;
	bool m_connecting;
	bool m_tx_queue_full;

	const ValueList &m_params; // shared params
	ValueList m_stats;

private:
	void ReturnQueue(std::list<SocketBuffer*>& queue);

	SocketEngineBase(const SocketEngineBase&);
	void operator=(const SocketEngineBase&);
};

#define SOCKETENGINEPARAM(param) m_params[SocketParams::Param_##param].AsInt()
#define SOCKETENGINESTAT(stat) m_stats[SocketEngineBase::Stat_##stat].AsInt()

}

#endif
