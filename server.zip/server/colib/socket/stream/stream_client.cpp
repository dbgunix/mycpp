#include <socket/stream/stream_client.h>
#include <socket/stream/socket_engine.h>
#include <socket/stream/socket_engine_tls.h>
#include <utils/trace/writable.h>
#include <utils/trace/trace.h>
#include <event_loop/event_loop.h>
#include <console/command/debug.h>

namespace colib
{

StreamClient::StreamClient(const char *name, StreamBase::TlsOpt tls, StreamBase::XdrOpt xdr)
	: StreamBase(name, -1, tls, xdr, m_socket_params.GetParams(), m_socket_params.GetTlsParams())
	, m_is_initialized(false)
	, m_blocking_connect(false)
	, m_close_act(callbackRt(this, &StreamClient::DisconnectAct), string::Format("%s_close_act", name))
	, m_retry_timer(string::Format("%s_connect_retry", name))
	, m_retry_interval_msec(-1)
	, m_max_retries(0)
	, m_num_retries(0)
	, m_local_addr_provided(false)
	, m_connect_err(64)
{
	m_retry_timer.SetExpireCb(callback(this, &StreamClient::RetryTimerExpired));
}

void StreamClient::EnableAutoRetry(int max_retries, int retry_interval_msec)
{
	m_max_retries = max_retries;
	m_retry_interval_msec = retry_interval_msec;
}

void StreamClient::DisableAutoRetry()
{
	m_max_retries = 0;
	m_retry_interval_msec = -1;
}

bool StreamClient::Connect(string server_addr, string local_addr, bool blocking_connect)
{
	// store the blocking connect preference in case it is needed during auto-reconnect
	m_blocking_connect = blocking_connect;
	// explicit connect resets retry attempts
	m_num_retries = 0;
	// cancel current retry (in case it's active)
	m_retry_timer.Stop();
	// disconnect the existing connection (in case there is one)
	m_trace_set.Trace(5, "%s disconnecting due to explicit connect\n", GetName().c_str());
	DoDisconnect();

	// use local address if it's set
	if (!local_addr.is_empty())
	{
		m_local_addr = local_addr;
		m_local_addr_provided = true;
	}
	else
	{
		/* no local addr provided
		 * clear current addr to prevent passing old information
		 * to SocketEngine's Connect (which would incorrectly
		 * call bind() and use the old address)
		 */
		m_local_addr.clear();
		m_local_addr_provided = false;
	}

	bool conn_success = false;
	// server address is required
	if (!server_addr.is_empty())
	{
		m_peer_addr = server_addr;
		m_trace_set.Trace(5, "%s attemping connection to %s\n", GetName().c_str(), GetPeerAddrStr().c_str());
		conn_success = DoConnect();
		if (!conn_success)
		{
			TRACE("%s\n", m_connect_err.c_str());
			CheckRetry();
		}
	}
	else
	{
		TRACE("%s::%s -- no server address provided\n", GetName().c_str(), __FUNCTION__);
	}
	return conn_success;
}

void StreamClient::Disconnect(bool reconnect )
{
	m_trace_set.Trace(4, "%s starting explicit disconnect\n", GetName().c_str());
	// for explicit disconnect, stop retry timer
  if(!reconnect)
  {
	  m_retry_timer.Stop();
  }
	DoDisconnect();
}

void StreamClient::CheckRetry()
{
	// is auto retry enabled
	if (m_max_retries > 0)
	{
		// do we have any attempts left?
		if (m_num_retries < m_max_retries)
		{
			m_retry_timer.Start(m_retry_interval_msec);
			++m_num_retries;
		}
		else
		{
			// reached retry limit, trigger callback
			m_retry_failed_cb.Dispatch(*this);
		}
	}
}

bool StreamClient::DoConnect()
{
	// empty the string, but keep the memory
	m_connect_err.reset();
	bool ret = m_engine->Connect(m_peer_addr, m_local_addr, m_blocking_connect, m_connect_err);

	if (ret)
	{
		// init if we are not already
		if (!m_is_initialized && !Init())
		{
			ret = false;
			m_connect_err.AppendFmt("%s: Init() failed after connect", GetName().c_str());
		}
		else
		{
			// already initialized or init succeeded
			m_is_initialized = true;
		}
	}
	else
	{
		CheckRetry();
	}
	return ret;
}

void StreamClient::DoDisconnect()
{
	m_engine->Disconnect();
	m_is_initialized = false;
}

void StreamClient::AwakenEvent()
{
	m_trace_set.Trace(3, "%s connected to %s\n", GetName().c_str(), m_peer_addr.c_str());
	StreamBase::AwakenEvent();
}

bool StreamClient::Reload(const OptionsNode& base_opts, const OptionsNode& tls_opts)
{
	bool ret = m_socket_params.GetParams().LoadFromOptions(base_opts);
	if ( IsTlsEnabled() )
	{
		ret = m_socket_params.GetTlsParams().LoadFromOptions(tls_opts) && ret;
	}
	return ret;
}

void StreamClient::CloseNeeded()
{
	m_trace_set.Trace(5, "%s starting disconnect due to peer\n", GetName().c_str());
	EventLoop::GetInstance().AddActivity(&m_close_act);
}

bool StreamClient::IsConnecting() const
{
	return m_engine->IsConnecting();
}

eCallbackRt StreamClient::DisconnectAct()
{
	// CloseNeeded/DisconnectAct should only be called when the socket engine needs a disconnect
	// This is a case where we invoke the retry logic
	DoDisconnect();
	CheckRetry();
	return DontRunAgain;
}

void StreamClient::RetryTimerExpired(unsigned int clock, void* data)
{
	(void)clock;
	(void)data;

	if (!m_local_addr_provided)
	{
		m_local_addr.clear();
	}
	m_trace_set.Trace(5, "%s attempting reconnect to %s\n", GetName().c_str(), GetPeerAddrStr().c_str());
	if (!DoConnect())
	{
		m_trace_set.Trace(0, "%s\n", m_connect_err.c_str());
	}
}

void StreamClient::TrustedServerRequired()
{
	static const int level_verify_trust = 1;
	SetTlsAuthLevel(level_verify_trust);
}

void StreamClient::TrustedServerWithCommonNameRequired(string server_common_name)
{
	static const int level_verify_trust_and_cn = 2;
	SetTlsPeerName(server_common_name);
	SetTlsAuthLevel(level_verify_trust_and_cn);
}

string StreamClient::ConsoleHelp() const
{
	return "status | stats | params | tls_stats | tls_params | tls_state | msg_proc | debug";
}

void StreamClient::ConsoleCommand(Writable *to, int argc, char *argv[])
{
	string usage = "Usage: " + ConsoleHelp();
	
	if (!to)
	{
		return;
	}

	if (argc < 1)
	{
		to->PrintString(usage.c_str());
	}
	else if (!strcmp(argv[0], "status"))
	{
		to->Print(
			"Name: %s\n"
			"Local Address: %s\n"
			"Foreign Address: %s (%c)\n"
			"TLS: %s\n"
			"XDR: %s\n",
			GetName().c_str(),
			m_local_addr.c_str(),
			m_peer_addr.c_str(), IsConnected() ? '*' : 'X',
			IsTlsEnabled() ? "Enabled" : "Disabled",
			IsXdrEnabled() ? "Enabled" : "Disabled");
		m_engine->PrintRxQueue(to);
	}
	else if (!strcmp(argv[0], "stats"))
	{
		ConsoleStats(to, argc-1, argv+1);
	}
	else if (!strcmp(argv[0], "params"))
	{
		m_socket_params.GetParams().ConsoleCommand(to, argc-1, argv+1);
	}
	else if (!strcmp(argv[0], "tls_state"))
	{
		if ( IsTlsEnabled() )
		{
			ConsoleTlsState(to, argc-1, argv+1);
		}
		else
		{
			to->PrintString("TLS not enabled for this client\n");
		}
	}
	else if (!strcmp(argv[0], "tls_stats"))
	{
		if ( IsTlsEnabled() )
		{
			ConsoleTlsStats(to, argc-1, argv+1);
		}
		else
		{
			to->PrintString("TLS not enabled for this client\n");
		}
	}
	else if (!strcmp(argv[0], "tls_params"))
	{
		if ( IsTlsEnabled() )
		{
			m_socket_params.GetTlsParams().ConsoleCommand(to, argc-1, argv+1);
		}
		else
		{
			to->PrintString("TLS not enabled for this client\n");
		}
	}
	else if (!strcmp(argv[0], "msg_proc"))
	{
		ConsoleMsgProc(to, argc-1, argv+1);
	}
	else if (!strcmp(argv[0], "debug"))
	{
		HandleDebugCommand(to, argc-1, argv+1, m_trace_set, GetName().c_str());
	}
	else
	{
		to->PrintString(usage.c_str());
	}
}

}
