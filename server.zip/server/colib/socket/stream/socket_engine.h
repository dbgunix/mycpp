#if !defined(__SOCKET_ENGINE_H__)
#define __SOCKET_ENGINE_H__

#include<socket/stream/socket_engine_base.h>

namespace colib
{

class StreamBaseSeIntf;

class SocketEngine : public SocketEngineBase
{
public:
	SocketEngine(const char *name, int fd, StreamBaseSeIntf &parent, MemberSet &trace_set);

private:
	void read();
	void write();
};

}

#endif
