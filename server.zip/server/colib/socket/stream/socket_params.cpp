#include<socket/stream/socket_params.h>

namespace colib
{

static ValueList::ValueHolder InitParams()
{
	return
	{
		Value("tx_queue_limit", 2000)
	};
};

static ValueList::ValueHolder InitTlsParams()
{
	return
	{
		Value("tls_auth_peer", 0, true), // readonly
		Value("tls_handshake_timeout_sec", 12)
	};
};


SocketParams::SocketParams()
	: m_params(InitParams())
	, m_tls_params(InitTlsParams())
{
}

}
