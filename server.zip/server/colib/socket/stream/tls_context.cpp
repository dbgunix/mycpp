#ifdef CONFIG_HAVE_TLS
#include <socket/stream/tls_context.h>
#include <utils/trace/trace.h>
#include <crypt/pki/format/x509_cert.h>
#include <crypt/pki/checker/customer_checker_x509.h>
#include <crypt/pki/hostCert/x509.h>
#include <console/role.h>
#include <utils/trace/trace.h>
#include <console/session.h>

#include <openssl/err.h>

namespace colib
{
	CertVerifyOpt::CertVerifyOpt()
		:
		m_trusted_cert_required(false)
	{
	}

	string		CertVerifyOpt::Print() const
	{
		return string::Format("m_trusted_cert_required = %s", m_trusted_cert_required ? "true" : "false");
	}

	static ValueList::ValueHolder InitStats()
	{
		return
		{
			Value("num_cert_verify_passthru", 0),
			Value("num_cert_verify_succeed", 0),
			Value("num_cert_verify_failed", 0),
			Value("latest_cert_verify_failed_reason", ""),
			Value("num_host_cert_key_update_succeed", 0),
			Value("num_host_cert_key_update_not_ready", 0),
			Value("num_host_cert_key_update_failed", 0),
			Value("latest_host_cert_key_update_failed_reason", ""),
			Value("num_ssl_created", 0),
			Value("num_ssl_returned", 0)
		};
	};

	GlobalSSL::GlobalSSL()
		:
		m_initialized(false),
		m_cert_loaded(false),
		m_key_loaded(false),
		m_ctx(NULL),
		m_cert_verify_opt_idx(0),
		m_stats(InitStats())
	{
		x509_HostCert::GetInstance().SetCertUpdateCallback(callback(this, &GlobalSSL::UpdateHostCertAndKey));
		x509_HostCert::GetInstance().SetKeyUpdateCallback(callback(this, &GlobalSSL::UpdateHostCertAndKey));
	}

	GlobalSSL&		GlobalSSL::GetInstance()
	{
		static GlobalSSL instance;
		return instance;
	}

	bool			GlobalSSL::Init(string& err)
	{
		if ( m_initialized ) return true;	// Already initialized

		if ( !m_ctx )
		{
			SSL_library_init();
			SSL_load_error_strings();
			//
			// Note: need code changes when we migrate to new TLS lib
			//
			m_ctx = SSL_CTX_new(TLSv1_method());
			if ( !m_ctx )
			{
				TRACE(1, "GlobalSSL::Init - Fail to create m_ctx\n");
				Gather_Openssl_Error(err);
				return false;
			}
		}

		SSL_CTX_set_options(m_ctx, SSL_OP_NO_SSLv3);
		//
		// Note: need code changes when we migrate to new TLS lib
		//
		const char *CIPHER_LIST = "DHE-RSA-AES256-SHA:AES256-SHA";
		if ( !SSL_CTX_set_cipher_list(m_ctx, CIPHER_LIST) )
		{
			Gather_Openssl_Error(err);
			return false;
		}
		//
		// Register certifcate verification control index
		//
		m_cert_verify_opt_idx = SSL_get_ex_new_index(0, (void*)"CertVerifyOpt index", NULL, NULL, NULL);
		if ( m_cert_verify_opt_idx == -1 )
		{
			TRACE(1, "GlobalSSL::Init - Fail to register certificate verify option index\n");
			Gather_Openssl_Error(err);
			return false;
		}
		//
		// Override the default cert_verify_callback
		//
		SSL_CTX_set_cert_verify_callback(m_ctx, TlsVerifyCert, NULL);
		//
		// Register console command
		//
		ConsoleCommand::Register(
				CONSOLE_ROLE_EVERYONE | CONSOLE_ROLE_ERROR_STATE,
				(ConsoleCommand::Handler*)CmdGlobalSSL, NULL,
				"ssl", "Global SSL");
		//
		m_initialized = true;
		//
		// In case host certificate and key are ready to load
		//
		UpdateHostCertAndKey();

		return true;
	}

	void			GlobalSSL::UpdateHostCertAndKey()
	{
		string err;

		if ( !m_initialized )
		{
			if ( !Init(err) )
			{
				++GLOBALSSL_STAT(num_host_cert_key_update_failed);
				m_stats[GlobalSSL::Stat_latest_host_cert_key_update_failed_reason].SetFromString(err.c_str());
				return;
			}
		}

		if ( !x509_HostCert::GetInstance().IsOK() )
		{
			++GLOBALSSL_STAT(num_host_cert_key_update_not_ready);
			return;
		}

		const x509_Certificate* x509_cert = static_cast<const x509_Certificate*>(x509_HostCert::GetInstance().GetCert());
		const X509* x509 = x509_cert ? x509_cert->GetX509() : 0;

		if ( !x509 )
		{
			err = "x509 certificate not present";
			++GLOBALSSL_STAT(num_host_cert_key_update_failed);
			m_stats[GlobalSSL::Stat_latest_host_cert_key_update_failed_reason].SetFromString(err.c_str());
			return;
		}

		if ( SSL_CTX_use_certificate(m_ctx, (X509*)x509) != 1 )
		{
			Gather_Openssl_Error(err);
			++GLOBALSSL_STAT(num_host_cert_key_update_failed);
			m_stats[GlobalSSL::Stat_latest_host_cert_key_update_failed_reason].SetFromString(err.c_str());
			return;
		}
		m_cert_loaded = true;

		const x509_RSAkey* x509_key = static_cast<const x509_RSAkey*>(x509_HostCert::GetInstance().GetKey());
		const RSA* rsa = x509_key ? x509_key->GetRSA() : 0;

		if ( !rsa )
		{
			err = "x509 RSA key not present";
			++GLOBALSSL_STAT(num_host_cert_key_update_failed);
			m_stats[GlobalSSL::Stat_latest_host_cert_key_update_failed_reason].SetFromString(err.c_str());
			return;
		}

		if ( SSL_CTX_use_RSAPrivateKey(m_ctx, (RSA*)rsa) != 1 )
		{
			Gather_Openssl_Error(err);
			++GLOBALSSL_STAT(num_host_cert_key_update_failed);
			m_stats[GlobalSSL::Stat_latest_host_cert_key_update_failed_reason].SetFromString(err.c_str());
			return;
		}
		m_key_loaded = true;

		++GLOBALSSL_STAT(num_host_cert_key_update_succeed);
	}

	void		GlobalSSL::Gather_Openssl_Error(string& into)
	{
		char buf[125];
		unsigned long err;

		into.empty();
		while ( 0 != (err = ERR_get_error()) )
		{
			buf[0]='\0';
			ERR_error_string(err, buf);
			into.AppendFmt("Rsaif Error: %s ", buf);
		}
	}

	int 		GlobalSSL::TlsVerifyCert(X509_STORE_CTX* p_store_ctx, void*)
	{
		return GlobalSSL::GetInstance().VerifyCert(p_store_ctx);
	}

	//
	// Callback to override OpenSSL built-in certificate verfication proc
	//
	int 		GlobalSSL::VerifyCert(X509_STORE_CTX* store_ctx)
	{
		string reason;

		if ( store_ctx == NULL )
		{
			reason = "store_ctx NULL";
			++GLOBALSSL_STAT(num_cert_verify_failed);
			m_stats[GlobalSSL::Stat_latest_cert_verify_failed_reason].SetFromString(reason.c_str());
			TRACE("GlobalSSL::VerifyCert - %s\n", reason.c_str());	// sever error
			return 0;
		}
		//
		// Get SSL
		//
		SSL* ssl = static_cast<SSL*>(X509_STORE_CTX_get_ex_data(store_ctx, SSL_get_ex_data_X509_STORE_CTX_idx()));
		if ( ssl == NULL )
		{
			reason = "SSL NULL";
			++GLOBALSSL_STAT(num_cert_verify_failed);
			m_stats[GlobalSSL::Stat_latest_cert_verify_failed_reason].SetFromString(reason.c_str());
			TRACE("GlobalSSL::VerifyCert - %s\n", reason.c_str());	// sever error
			return 0;
		}
		//
		//
		bool trusted_cert_required = true;
		CertVerifyOpt* opt = static_cast<CertVerifyOpt*>(SSL_get_ex_data(ssl, m_cert_verify_opt_idx));
		if ( opt )
		{
			trusted_cert_required = opt->TrustedCertRequired();
		}
		//
		// If trusted cert not required, return 1
		//
		if ( !trusted_cert_required )
		{
			++GLOBALSSL_STAT(num_cert_verify_passthru);
			return 1;
		}
		//
		// Get certificate
		//
		X509* x509 = store_ctx->cert;
		if ( !x509 )
		{
			reason = "peer certificate not present";
			X509_STORE_CTX_set_error(store_ctx, X509_V_ERR_CERT_REJECTED);
			++GLOBALSSL_STAT(num_cert_verify_failed);
			m_stats[GlobalSSL::Stat_latest_cert_verify_failed_reason].SetFromString(reason.c_str());
			return 0;
		}
		//
		// Load certificate
		//
		x509_Certificate cert;
		if ( !cert.LoadX509(x509) )
		{
			reason = "load certificate fail";
			X509_STORE_CTX_set_error(store_ctx, X509_V_ERR_CERT_REJECTED);
			++GLOBALSSL_STAT(num_cert_verify_failed);
			m_stats[GlobalSSL::Stat_latest_cert_verify_failed_reason].SetFromString(reason.c_str());
			return 0;
		}
		//
		// Verify certificate
		//
		if ( !CustomerX509CertChecker::GetInstance().VerifyCert(&cert, reason, 0) )
		{
			//
			// Fail to verify chain of trust
			//
			reason = "cert verify trust fail: " + reason;
			X509_STORE_CTX_set_error(store_ctx, X509_V_ERR_CERT_REJECTED);
			++GLOBALSSL_STAT(num_cert_verify_failed);
			m_stats[GlobalSSL::Stat_latest_cert_verify_failed_reason].SetFromString(reason.c_str());
			return 0;
		}
		//
		// Trust passed, the CommonName need to be checked later
		//
		++GLOBALSSL_STAT(num_cert_verify_succeed);
		return 1;
	}

	bool		GlobalSSL::SetGlobalCtxPasswdCb(TLS_PASSWD_CALLBACK cb)
	{
		if ( !m_ctx || !cb )
		{
			return false;
		}

		SSL_CTX_set_default_passwd_cb(m_ctx, cb);
		return true;
	}

	SSL*		GlobalSSL::CreateNewSSL()
	{
		if ( !m_ctx ) return 0;
		SSL* ret = SSL_new(m_ctx);
		if ( ret ) ++GLOBALSSL_STAT(num_ssl_created);
		return ret;
	}

	void		GlobalSSL::ReturnSSL(SSL* ssl)
	{
		if ( ssl )
		{
			SSL_free(ssl);
			++GLOBALSSL_STAT(num_ssl_returned);
		}
	}

	bool		GlobalSSL::IsOK() const
	{
		return m_initialized && m_cert_loaded && m_key_loaded;
	}

	void		GlobalSSL::CmdGlobalSSL(void* ctx, ConsoleSession* con, int argc, char* argv[])
	{
		(void)ctx;
		GlobalSSL::GetInstance().ConsoleCommand(con, argc-1, argv+1);
	}

	void		GlobalSSL::ConsoleCommand(ConsoleSession* con, int argc, char* argv[])
	{
		const char* usage = "Usage:\tstats|status";

		if ( argc == 0 )
		{
			con->Print(usage);
			return;
		}

		if ( !strcmp(argv[0], "stats") )
		{
			m_stats.ConsoleCommand(con, argc-1, argv+1);
		}
		else if ( !strcmp(argv[0], "status") )
		{
			con->Print(
					"SSL_CTX is %sinitialized\n"
					"Certificate is %sloaded\n"
					"Key is %sloaded\n"
					"m_cert_verify_opt_idx = %d\n",
					m_initialized ? "" : "NOT ",
					m_cert_loaded ? "" : "NOT ",
					m_key_loaded ? "" : "NOT ",
					m_cert_verify_opt_idx);
		}
		else con->Print(usage);
	}

}

#endif
