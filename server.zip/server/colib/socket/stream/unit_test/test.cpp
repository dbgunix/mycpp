#include "stream_test.h"
#include <event_loop/event_loop.h>
#include <options/file_options.h>
#include <socket/stream/stream_base.h>
#include <socket/stream/stream_client_handler.h>
#include <utils/trace/trace.h>
#include <console/command.h>
#include <console/role.h>
#include <console/session.h>
#include <console/manager.h>
#include <socket/stream/console/console.h>
#include <socket/stream/tls_context.h>
#include <socket/socket_buffer_pool.h>
#include <utils/trace/stdio_writable.h>

#ifdef CONFIG_HAVE_TLS
#include <crypt/pki/ca_handler/x509.h>
#endif

#include <signal.h>

static bool SetupTls()
{
	colib::string err;
#ifdef CONFIG_HAVE_TLS
	if (!colib::x509_CaHandler::GetInstance().Init(err))
	{
		printf("CA handler init fail\n");
		return false;
	}
	if (!colib::GlobalSSL::GetInstance().Init(err))
	{
		printf("Failed to init SSL ctx: %s\n", err.c_str());
		return false;
	}
#endif
	return true;
}

static void sigterm_handler(int signum)
{
        (void)signum;
        static bool called = false;

        if (called) abort();

        colib::EventLoop::GetInstance().Terminate(called = true);
}

int main()
{
	signal(SIGTERM, sigterm_handler);
        signal(SIGINT, sigterm_handler);

	// initialize the socket buffer pool
	colib::SocketBufferPool::GetInstance().Init(50);
	// initialize the event loop
	if (!colib::EventLoop::GetInstance().Initialize())
	{
		fprintf(stderr, "Failed to init event loop\n");
		return 1;
	}

	if (!SetupTls())
	{
		fprintf(stderr, "Failed to initialize/setup TLS\n");
		return 1;
	}

	// load options
	colib::FileOptions opt;
	if (!opt.LoadFile("./test_opt.opt"))
	{
		fprintf(stderr, "Failed to load options\n");
		return 1;
	}

	// create process console on port 30000
	colib::GlobalTelnetConsoleServer::GetInstance().Init("INET;127.0.0.1;30000");
	colib::ConsoleManager::GetInstance().SetName("StreamUnitTest");

	// create writable for testing/debug output
	colib::StdioWritable out(stdout);
	// create unit test
	colib::StreamUnitTest stream_tester;
	stream_tester.AddWritable(9, &out);
	if (!stream_tester.Init(&opt))
	{
		return 1;
	}

	colib::EventLoop::GetInstance().Main();
	stream_tester.Shutdown();
	return 0;
}
