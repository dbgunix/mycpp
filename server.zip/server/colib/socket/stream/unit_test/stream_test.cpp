#include "stream_test.h"
#include <event_loop/event_loop.h>
#include <options/options.h>
#include <socket/stream/stream_base.h>
#include <socket/stream/stream_client_handler.h>
#include <utils/trace/trace.h>
#include <console/command.h>
#include <console/role.h>
#include <console/session.h>
#include <socket/stream/console/console.h>
//#include <timer/timekeeper.h>

namespace colib
{

bool StreamUnitTest::TestMessage::XdrProc(CXDR* pXDR)
{
	return Message::XdrProc(pXDR)
		&& pXDR->XdrInt(&m_x)
		&& pXDR->XdrUint(&m_y)
		&& pXDR->XdrDouble(&m_z)
		&& pXDR->XdrShort(&m_a)
		&& pXDR->XdrStringPadded(m_some_str);
}

bool StreamUnitTest::TestResponseMessage::XdrProc(CXDR* pXDR)
{
	return Message::XdrProc(pXDR)
		&& pXDR->XdrFloat(&m_a)
		&& pXDR->XdrUint64(&m_b)
		&& pXDR->XdrBool(&m_c)
		&& pXDR->XdrLong(&m_d);
}

StreamUnitTest::StreamUnitTest()
	: m_client_tls_xdr("TestClientXdrTls", StreamBase::TlsOpt::ENABLE_TLS, StreamBase::XdrOpt::ENABLE_XDR)
	, m_server_tls_xdr("TestServerXdrTls", StreamBase::TlsOpt::ENABLE_TLS, StreamBase::XdrOpt::ENABLE_XDR)
	, m_test_start_act(callbackRt(this, &StreamUnitTest::StartTest1), "StreamTestStartTest1")
	, m_send_timer("SendTimer1", callback(this, &StreamUnitTest::SendMessageClient1))
	, m_large_msg_send_timer("LargeMsgSendTimer", callback(this, &StreamUnitTest::SendLargeMessageClient1))
	, m_client_messages_sent(0)
	, m_debug_output()
{
}

void StreamUnitTest::AddWritable(int level, Writable *out)
{
	// store a "copy" of the level and writable for future use
	m_debug_output = TraceMember(out, level);
	m_trace_set.AddWritable(level, out);
	m_client_tls_xdr.AddWritable(level, out);
	m_server_tls_xdr.AddWritable(level, out);
}

void StreamUnitTest::Shutdown()
{
	// nothing to do here yet
}

bool StreamUnitTest::Init(const Options *opt)
{
	RegisterConsoleCommands();

	// setup server
	if (!InitServer(opt->GetOptionsNode("TEST_SERVER_1")))
	{
		return false;
	}
	// setup client
	if (!InitClient(opt->GetOptionsNode("TEST_CLIENT_1")))
	{
		return false;
	}
	return true;
}

bool StreamUnitTest::InitClient(const OptionsNode& grp)
{
	if (grp.IsEmpty())
	{
		return false;
	}
	int is_active = 0;
	grp.GetValue("active", is_active, 0);
	if (is_active)
	{
		string conn_addr = grp.GetAsString("connect_addr");
		if (conn_addr.is_empty())
		{
			m_trace_set.Trace(2, "missing key connect_addr\n");
			return false;
		}
		if (!m_client_tls_xdr.Connect(conn_addr, "", false))
		{
			m_trace_set.Trace(2, "%s failed to connect to %s\n", m_client_tls_xdr.GetName().c_str(), conn_addr.c_str());
			return false;
		}
		// set client message callback
		m_client_tls_xdr.RegisterMsgHandler(TEST_RESPONSE_ID, callback(this, &StreamUnitTest::ResponseMessageReceived));
		// set connected callback
		m_client_tls_xdr.SetAwakenCallback(callback(this, &StreamUnitTest::ClientConnected));
		int auto_retry_attempts = 0;
		grp.GetValue("auto_retry_attempts", auto_retry_attempts, 0);
		int auto_retry_timeout_msec = 0;
		grp.GetValue("auto_retry_timeout_msec", auto_retry_timeout_msec, 0);
		if (auto_retry_attempts > 0 && auto_retry_timeout_msec > 0)
		{
			m_client_tls_xdr.EnableAutoRetry(auto_retry_attempts, auto_retry_timeout_msec);
		}
	}
	m_trace_set.Trace(3, "%s init successful (%d)\n", m_client_tls_xdr.GetName().c_str(), is_active);
	return true;
}

bool StreamUnitTest::InitServer(const OptionsNode& grp)
{
	int is_active = 0;
	grp.GetValue("active", is_active, 0);
	if (is_active)
	{
		// set server's new client cb
		m_server_tls_xdr.SetNewClientCallback(callback(this, &StreamUnitTest::NewClientCreated));

		string listen_addr = grp.GetAsString("listen_addr");
		if (listen_addr.is_empty())
		{
			m_trace_set.Trace(2, "Empty listen address for %s\n", m_server_tls_xdr.GetName().c_str());
			return false;
		}
		if (!m_server_tls_xdr.Init(listen_addr.c_str()))
		{
			m_trace_set.Trace(2, "Failed to initialize %s\n", m_server_tls_xdr.GetName().c_str());
			return false;
		}
	}
	m_trace_set.Trace(3, "%s init successful (%d)\n", m_server_tls_xdr.GetName().c_str(), is_active);
	return true;
}

void StreamUnitTest::RegisterConsoleCommands()
{
	ConsoleGlobal::GetInstance().RegisterConsoleCommand();
	ConsoleCommand::Register(CONSOLE_ROLE_EVERYONE, (ConsoleCommand::Handler*)ConCmdTestClient1, &m_client_tls_xdr, "client1", "TestClient1 commands");
	ConsoleCommand::Register(CONSOLE_ROLE_EVERYONE, (ConsoleCommand::Handler*)ConCmdTestServer1, &m_server_tls_xdr, "server1", "TestServer1 commands");
}

void StreamUnitTest::ClientConnected(StreamBase* client)
{
	(void)client;
	// add activity to begin test
	EventLoop::GetInstance().AddActivity(&m_test_start_act);
}

eCallbackRt StreamUnitTest::StartTest1()
{
	// wait one second for first timeout, then timeout every three seconds
	m_send_timer.StartStaggered(1000, 3000);
	// this activity doesn't need to run again
	return DontRunAgain;
}

void StreamUnitTest::SendMessageClient1(unsigned int clock, void* data)
{
	(void)clock;
	(void)data;

	static const int MESSAGES_TO_SEND = 5;

	TestMessage tm;
	// fill with dummy values
	tm.m_x = -12345;
	tm.m_y = 67890;
	tm.m_z = 1/3.0;
	tm.m_a = -53;
	tm.m_some_str = "Hello";

	++m_client_messages_sent;
	member_TRACE(&m_trace_set, 8, "Client sending message %d\n", m_client_messages_sent);
	m_client_tls_xdr.WriteMessage(tm);

	if (m_client_messages_sent >= MESSAGES_TO_SEND)
	{
		member_TRACE(&m_trace_set, 8, "Completed sending %d messages\n", m_client_messages_sent);
		m_send_timer.Stop();
		// wait 2 seconds, then send large message
		m_large_msg_send_timer.Start(2000);
	}
}

void StreamUnitTest::SendLargeMessageClient1(unsigned int clock, void* data)
{
	(void)clock;
	(void)data;

	TestMessage tm;
	tm.m_x = 1;
	tm.m_y = 2;
	tm.m_z = 3.0;
	tm.m_a = 4;
	// reserve up front to avoid many reallocs
	tm.m_some_str.set_maxlength(256000);
	// build a large string
	for (int ii(0); ii < 5000; ++ii)
	{
		tm.m_some_str += "ABCDEFGHIJKLMONPQRSTUVWXYZ1234567890";
	}
	member_TRACE(&m_trace_set, 8, "Client sending large message\n");
	m_client_tls_xdr.WriteMessage(tm);
}

void StreamUnitTest::NewClientCreated(StreamClientHandler *sch)
{
	sch->AddWritable(m_debug_output.m_level, m_debug_output.m_member);
	sch->RegisterMsgHandler(TEST_MESSAGE_ID, callback(this, &StreamUnitTest::TestMessageReceived));
}

void StreamUnitTest::TestMessageReceived(char* data, int len, StreamBase *sch)
{
	TestMessage tm;
	tm.Decode(data, len);
	// hack to avoid printing the huge string
	if (tm.m_some_str.get_length() <= 100)
	{
		member_TRACE(&m_trace_set, 3, "Test Message from %s\n\t%d\n\t%u\n\t%.04f\n\t%d\n\t%s\n", sch->GetPeerAddr().PutToString().c_str(),  tm.m_x, tm.m_y, tm.m_z, tm.m_a, tm.m_some_str.c_str());
	}

	TestResponseMessage rsp;
	// fill with dummy values
	rsp.m_a = 2/3.0;
	rsp.m_b = -1;
	rsp.m_c = false;
	rsp.m_d = 123456789;

	member_TRACE(&m_trace_set, 8, "Client handler sending response %d\n", m_client_messages_sent);
	sch->WriteMessage(rsp);
}

void StreamUnitTest::ResponseMessageReceived(char* data, int len, StreamBase* sc)
{
	TestResponseMessage rsp;
	rsp.Decode(data, len);

	member_TRACE(&m_trace_set, 3, "Test Response Message from %s\n\t%.04f\n\t%u\n\t%d\n\t%d\n", 
            sc->GetPeerAddr().PutToString().c_str(),  rsp.m_a, (int)rsp.m_b, (int)rsp.m_c, (int)rsp.m_d);
}

void StreamUnitTest::ConCmdTestClient1(StreamClient *client, ConsoleSession *con, int argc, char *argv[])
{
	if (!con)
	{
		return;
	}
	if (!client)
	{
		con->PrintString("Client is null\n");
	}
	else
	{
		client->ConsoleCommand(con, argc-1, argv+1);
	}
}

void StreamUnitTest::ConCmdTestServer1(StreamServer *server, ConsoleSession *con, int argc, char *argv[])
{
	if (!con)
	{
		return;
	}
	if (!server)
	{
		con->PrintString("Server is null\n");
	}
	else
	{
		server->ConsoleCommand(con, argc-1, argv+1);
	}
}

}
