#if !defined(__STREAM_TEST_H__)
#define __STREAM_TEST_H__

#include <socket/stream/stream_client.h>
#include <socket/stream/stream_server.h>
#include <timer/periodic_timer.h>
#include <timer/oneshot_timer.h>
#include <message/message.h>

namespace colib
{

class ConsoleSession;
class Options;
class StreamBase;
class StreamClientHandler;

class StreamUnitTest
{
public:
	StreamUnitTest();
	~StreamUnitTest() { }

	bool Init(const Options *opt);
	void AddWritable(int level, Writable *out);
	void Shutdown();

private:
	static const int TEST_MESSAGE_ID = 4444;
	class TestMessage : public Message
	{
	public:
		TestMessage() : Message(TEST_MESSAGE_ID) { }

		int m_x;
		unsigned int m_y;
		double m_z;
		short m_a;
		string m_some_str;

		bool XdrProc(CXDR *pXDR);
	};

	static const int TEST_RESPONSE_ID = 8888;
	class TestResponseMessage : public Message
	{
	public:
		TestResponseMessage() : Message(TEST_RESPONSE_ID) { }

		float m_a;
		uint64_t m_b;
		bool m_c;
		long m_d;

		bool XdrProc(CXDR *pXDR);
	};

	StreamClient m_client_tls_xdr;
	StreamServer m_server_tls_xdr;
	ActivityHold m_test_start_act;
	PeriodicTimer m_send_timer;
	OneShotTimer m_large_msg_send_timer;
	MemberSet m_trace_set;
	int m_client_messages_sent;
	TraceMember m_debug_output;

	bool InitClient(const OptionsNode& grp);
	bool InitServer(const OptionsNode& grp);
	void RegisterConsoleCommands();
	void ClientConnected(StreamBase *client);
	eCallbackRt StartTest1();
	void SendMessageClient1(unsigned int clock, void *data);
	void SendLargeMessageClient1(unsigned int clock, void *data);
	void NewClientCreated(StreamClientHandler *sch);
	void TestMessageReceived(char *data, int len, StreamBase *sch);
	void ResponseMessageReceived(char *data, int len, StreamBase *sc);

	static void ConCmdTestClient1(StreamClient *client, ConsoleSession *con, int argc, char *argv[]);
	static void ConCmdTestServer1(StreamServer *server, ConsoleSession *con, int argc, char *argv[]);
};


}

#endif
