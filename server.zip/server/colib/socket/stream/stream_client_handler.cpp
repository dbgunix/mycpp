#include<socket/stream/stream_client_handler.h>
#include<socket/stream/socket_engine.h>
#include<socket/stream/socket_engine_tls.h>
#include<utils/trace/trace.h>
#include<utils/trace/writable.h>
#include<console/command/debug.h>

namespace colib
{

StreamClientHandler::StreamClientHandler(const char* name, int fd, StreamServer &parent, StreamBase::TlsOpt tls, StreamBase::XdrOpt xdr)
	: StreamBase(name, fd, tls, xdr, parent.GetParams(), parent.GetTlsParams())
	, m_parent(parent)
	, m_closing(false)
	, m_uid(0)  
{
}

bool StreamClientHandler::Init(const SocketAddr& local_addr, const SocketAddr& peer_addr)
{
	m_local_addr = local_addr.PutToString();
	m_peer_addr = peer_addr.PutToString();
	bool ret = StreamBase::Init() && m_engine->MakeNonBlocking();
	if (ret)
	{
		if (!EventLoop::GetInstance().AddHandler(*m_engine))
		{
			TRACE("%s -- Failed to register with event loop\n", GetName().c_str());
			ret = false;
		}
	}
	/* If TLS is enabled we cannot generate an awaken event yet
	 * because TLS handshake has not completed
	 * If TLS is not enabled, generate awaken here
	 */
	if (ret && !IsTlsEnabled())
	{
		AwakenEvent();
	}
	return ret;
}

void StreamClientHandler::Disconnect(bool)
{
	DisableRead();
	DisableWrite();
	CloseNeeded();
}

void StreamClientHandler::CloseNeeded()
{
	if (!m_closing)
	{
		member_TRACE(&m_trace_set, 0, "%s -- close needed\n", GetName().c_str());
		m_parent.ScheduleClose(GetId());
		m_closing = true;
	}
}

string StreamClientHandler::ConsoleHelp() const
{
	return "status | stats | tls_stats | tls_state | msg_proc | debug";
}

void StreamClientHandler::ConsoleCommand(Writable *to, int argc, char *argv[])
{
	string usage = "Usage: " + ConsoleHelp();
	
	if (!to)
	{
		return;
	}

	if (argc < 1)
	{
		to->PrintString(usage.c_str());
	}
	else if (!strcmp(argv[0], "status"))
	{
		to->Print(
			"Name: %s\n"
			"Local Address: %s\n"
			"Foreign Address: %s\n",
			GetName().c_str(),
			m_local_addr.c_str(),
			m_peer_addr.c_str());
		m_engine->PrintRxQueue(to);
	}
	else if (!strcmp(argv[0], "stats"))
	{
		ConsoleStats(to, argc-1, argv+1);
	}
	else if (!strcmp(argv[0], "tls_state"))
	{
		if ( IsTlsEnabled() )
		{
			ConsoleTlsState(to, argc-1, argv+1);
		}
		else
		{
			to->PrintString("TLS not enabled for this client handler\n");
		}
	}
	else if (!strcmp(argv[0], "tls_stats"))
	{
		if ( IsTlsEnabled() )
		{
			ConsoleTlsStats(to, argc-1, argv+1);
		}
		else
		{
			to->PrintString("TLS not enabled for this client handler\n");
		}
	}
	else if (!strcmp(argv[0], "msg_proc"))
	{
		ConsoleMsgProc(to, argc-1, argv+1);
	}
	else if (!strcmp(argv[0], "debug"))
	{
		HandleDebugCommand(to, argc-1, argv+1, m_trace_set, GetName().c_str());
	}
	else
	{
		to->PrintString(usage.c_str());
	}
}

}
