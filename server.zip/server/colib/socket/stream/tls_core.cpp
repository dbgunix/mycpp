#ifdef CONFIG_HAVE_TLS
#include <socket/stream/tls_core.h>
#include <utils/trace/trace.h>
#include <socket/stream/socket_engine_tls.h>
#include <socket/stream/socket_params.h>
#include <console/session.h>
#include <crypt/x509utils/ossl_io.h>

#include <openssl/err.h>

namespace colib
{
	static ValueList::ValueHolder InitStats()
	{
		return
		{
			Value("num_verify_common_name_succeed", 0),
			Value("num_verify_common_name_failed", 0),
			Value("latest_verify_common_name_failed_reason", ""),
			Value("num_collect_session_info_succeed", 0),
			Value("num_collect_session_info_failed", 0),
			Value("latest_collect_session_info_failed_reason", "")
		};
	};

	TlsCore::TlsCore(SocketEngineTLS& parent, MemberSet& trace_set)
		:
		m_parent(parent),
		m_trace_set(trace_set),
		m_handshake_func(SSL_accept),
		m_handshake_timer("TlsHandshake"),
		m_connecting(true),
		m_shutdown_in_progress(false),
		m_tls(NULL),
		m_params(parent.GetTlsParams()),
		m_stats(InitStats())
	{
		m_handshake_timer.SetExpireCb(callback(this, &TlsCore::OnHandshakeTimerExpired));
	}

	TlsCore::~TlsCore()
	{
		Cleanup();
	}

	void			TlsCore::Cleanup()
	{
		if ( !m_tls ) return;
		//
		// Stop Tls Handshake Timer if it is running
		//
		m_handshake_timer.Stop();
		//
		// The following code derives from old implementation with major cleanup of useless code
		// (Hao: Jan 14, 2013)
		//
		m_connecting = true;
		SSL_shutdown(m_tls);
		GlobalSSL::GetInstance().ReturnSSL(m_tls);
		ERR_remove_state(0);
		m_tls = NULL;
		return;
	}

	void			TlsCore::CollectSessionInfo()
	{
		string err;

		if ( !m_tls )
		{
			err = "Tls session does not exist";
			member_TRACE(&m_trace_set, 0, "%s: %s\n", m_parent.GetName().c_str(), err.c_str());
			++TLSCORESTAT(num_collect_session_info_failed);
			m_stats[TlsCore::Stat_latest_collect_session_info_failed_reason].SetFromString(err.c_str());
			return;
		}
		//
		// Get Cipher
		//
		const SSL_CIPHER* cipher = SSL_get_current_cipher(m_tls);
		SSL_CIPHER_description(cipher, m_cipher_description, CIPHER_DESC_SIZE);
		//
		// Get Certificate
		//
		X509* peer_x509 = SSL_get_peer_certificate(m_tls);
		if ( !peer_x509 || !m_peer_certificate.LoadX509(peer_x509) )
		{
			err = "peer certificate not loaded";
			member_TRACE(&m_trace_set, 0, "%s: %s\n", m_parent.GetName().c_str(), err.c_str());
			++TLSCORESTAT(num_collect_session_info_failed);
			m_stats[TlsCore::Stat_latest_collect_session_info_failed_reason].SetFromString(err.c_str());
		}
		++TLSCORESTAT(num_collect_session_info_succeed);
	}

	bool			TlsCore::VerifyPeerCommonName()
	{
		string cn, err;

		if ( !m_peer_certificate.GetSubjectCommonName(cn, err) )
		{
			member_TRACE(&m_trace_set, 2, "%s: fail to get peer CommonName: %s\n", m_parent.GetName().c_str(), err.c_str());
			++TLSCORESTAT(num_verify_common_name_failed);
			m_stats[TlsCore::Stat_latest_verify_common_name_failed_reason].SetFromString(err.c_str());
			return false;
		}

		if ( cn != m_expected_peer_common_name )
		{
			err = string::Format("%s != %s", cn.c_str(), m_expected_peer_common_name.c_str());
			member_TRACE(&m_trace_set, 2, "%s: peer CommonName does not match expected (%s)\n",
					m_parent.GetName().c_str(), err.c_str());
			++TLSCORESTAT(num_verify_common_name_failed);
			m_stats[TlsCore::Stat_latest_verify_common_name_failed_reason].SetFromString(err.c_str());
			return false;
		}

		++TLSCORESTAT(num_verify_common_name_succeed);

		return true;
	}

	bool			TlsCore::Init(int fd)
	{
		if ( fd <= 0 ) return false;

		if ( !GlobalSSL::GetInstance().IsOK() )
		{
			TRACE("%s: Global SSL not OK\n", m_parent.GetName().c_str());
			return false;
		}

		Cleanup();

		m_tls = GlobalSSL::GetInstance().CreateNewSSL();
		if ( m_tls == NULL )
		{
			TRACE("%s: Global SSL failed to create new SSL\n", m_parent.GetName().c_str());
			return false;
		}

		BIO* bio = BIO_new_socket(fd, BIO_NOCLOSE);
		SSL_set_bio(m_tls, bio, bio);
		//
		// Important change: always ask peer for cert
		//
		SSL_set_verify(m_tls, SSL_VERIFY_PEER, NULL);
		//
		// Set option
		//
		if ( TLSCOREPARAM(tls_auth_peer) > 0 )
		{
			m_verify_opt.TrustedCertRequired() = true;
		}
		else
		{
			m_verify_opt.TrustedCertRequired() = false;
		}
		SSL_set_ex_data(m_tls, GlobalSSL::GetInstance().CertVerifyOptIndex(), &m_verify_opt);

		return true;
	}

	TlsCore::HandshakeResult	TlsCore::VerifyPeer()
	{
		HandshakeResult ret = SUCCESS;
		//
		CollectSessionInfo();
		//
		// Verify Common Name
		//
		if ( ( TLSCOREPARAM(tls_auth_peer) > 1 ) && !VerifyPeerCommonName() )
		{
			member_TRACE(&m_trace_set, 0, "%s: TLS peer CN authentication failed\n", m_parent.GetName().c_str());
			Shutdown();
			ret = FAILURE;
		}
		//
		return ret;
	}

	TlsCore::HandshakeResult	TlsCore::Handshake()
	{
		HandshakeResult ret = FAILURE;
		int t_result = m_handshake_func(m_tls);
		if ( t_result > 0 )
		{
			member_TRACE(&m_trace_set, 3, "%s: Tls Handshake finished successfully\n", m_parent.GetName().c_str());
			m_connecting = false;
			m_handshake_timer.Stop();
			ret = VerifyPeer();
		}
		else if (0 == t_result)
		{
			member_TRACE(&m_trace_set, 2, "%s: Tls handshake shutdown\n", m_parent.GetName().c_str());
		}
		else //( t_result < 0 )
		{
			//
			// Start a handshake timer
			//
			if ( !m_handshake_timer.IsActive() )
			{
				m_handshake_timer.Start(TLSCOREPARAM(tls_handshake_timeout_sec) * 1000);
			}

			switch (SSL_get_error(m_tls, t_result))
			{
				case SSL_ERROR_WANT_READ:
				{
					member_TRACE(&m_trace_set, 6, "%s: Tls Handshake in progress (want_read)\n", m_parent.GetName().c_str());
					ret = IN_PROGRESS_READ;
					break;
				}
				case SSL_ERROR_WANT_WRITE:
				{
					member_TRACE(&m_trace_set, 6, "%s: Tls Handshake in progress (want_write)\n", m_parent.GetName().c_str());
					ret = IN_PROGRESS_WRITE;
					break;
				}
				default:
				{
					string err;
					GlobalSSL::Gather_Openssl_Error(err);
					member_TRACE(&m_trace_set, 2, "%s: Tls Handshake failure: %s\n", m_parent.GetName().c_str(), err.c_str());
					break;
				}
			}
		}

		if ( ret == FAILURE ) Cleanup();

		return ret;
	}

	string			TlsCore::GetPeerCertStrPEM() const
	{
		string output, err;
		if ( !m_peer_certificate.FormatPEM(output, err) ) output = "";
		return output;
	}

	void			TlsCore::OnHandshakeTimerExpired(unsigned int, void*)
	{
		member_TRACE(&m_trace_set, 3, "%s: Tls Handshake Timeout\n", m_parent.GetName().c_str());
		Shutdown();
	}

	void			TlsCore::Shutdown()
	{
		if ( !m_tls )
		{
			member_TRACE(&m_trace_set, 4, "SSL try to shutdown after clean up\n");
			return;
		}

		bool shutdown_complete = false;

		int res = SSL_shutdown(m_tls);
		if ( res >= 0 )
		{
			Cleanup();
			shutdown_complete = true;
			member_TRACE(&m_trace_set, 3, "%s: Tls session shutdown successfully\n", m_parent.GetName().c_str());
		}
		else
		{
			switch ( SSL_get_error(m_tls, res) )
			{
				case SSL_ERROR_WANT_WRITE:
				case SSL_ERROR_WANT_READ:
				{
					m_shutdown_in_progress = true;
					break;
				}
				default:
				{
					Cleanup();
					shutdown_complete = true;
					member_TRACE(&m_trace_set, 3, "%s: Tls session shutdown failure, close socket anyway\n", m_parent.GetName().c_str());
				}
			}
		}

		m_parent.TLS_ShutdownProgress(shutdown_complete);
	}

	string			TlsCore::Print() const
	{
		return string::Format(
				"m_connecting = %s\n"
				"m_shutdown_in_progress = %s\n"
				"m_expected_peer_common_name = %s\n"
				"m_verify_opt: %s\n"
				"m_cipher = %s\n"
				"m_peer_cert = %s",
				m_connecting ? "true" : "false",
				m_shutdown_in_progress ? "true" : "false",
				m_expected_peer_common_name.c_str(),
				m_verify_opt.Print().c_str(),
				m_cipher_description,
				m_peer_certificate.DumpReadable().c_str());
	}

	void			TlsCore::ConsoleCommand(ConsoleSession* con, int argc, char* argv[])
	{
		const char* usage = "Usage:\tstats|state";

		if ( argc == 0 )
		{
			con->Print(usage);
			return;
		}

		if ( !strcmp(argv[0], "stats") )
		{
			m_stats.ConsoleCommand(con, argc-1, argv+1);
		}
		else if ( !strcmp(argv[0], "state") )
		{
			con->Print("%s\n", this->Print().c_str());
		}
		else con->Print(usage);
	}
}

#endif
