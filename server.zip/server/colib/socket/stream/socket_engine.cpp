#include<socket/stream/socket_engine.h>
#include<utils/trace/trace.h>
#include<socket/socket_buffer_pool.h>

#include <errno.h>
#include <unistd.h>

namespace colib
{

SocketEngine::SocketEngine(const char *name, int fd, StreamBaseSeIntf &parent, MemberSet &trace_set)
	: SocketEngineBase(name, fd, parent, trace_set)
{
}

void SocketEngine::read()
{
	if (m_need_to_close)
	{
		CloseNeeded();
		return;
	}

	if (m_connecting)
	{
		int is_ok;
		socklen_t sz = sizeof(is_ok);
		if (0 != getsockopt(m_fd, SOL_SOCKET, SO_ERROR, &is_ok, &sz) || 0 != is_ok)
		{
			//error
			member_TRACE(&m_trace_set, 0, "%s: failed to connect socket to %s: %s\n", m_name.c_str(), GetPeerAddrStr().c_str(), strerror(is_ok));
			CloseNeeded();
		}
		else
		{
			m_connecting = false;
			UpdateFlag();
			AwakenEvent();
		}
		return;
	}

	if (m_fd < 0)
	{
		member_TRACE(&m_trace_set, 0, "%s read -- invalid fd: %d\n", m_name.c_str(), m_fd);
		return;
	}

	//read from the socket into a SocketBuffer
	SocketBuffer *mnew = m_buf_pool.Get();
	if (mnew)
	{
		int res = ::read(m_fd, mnew->GetData(), mnew->MaxLength());

		if (res < 0)
		{
			//error, free the message buf
			member_TRACE(&m_trace_set, 2, "%s -- read syscall error :%s\n", m_name.c_str(), strerror(errno));
			m_buf_pool.Return(mnew);
		}
		else if (res == 0)
		{
			//this connection is closed, clean it up
			m_buf_pool.Return(mnew);
			member_TRACE(&m_trace_set, 3, "%s peer %s disconnect (read)\n", m_name.c_str(), GetPeerAddrStr().c_str());
			InitiateClose();
		}
		else
		{
			SOCKETENGINESTAT(rx_bytes) += res;
			member_TRACE(&m_trace_set, 8, "%s read %d bytes from %s\n", m_name.c_str(), res, GetPeerAddrStr().c_str());
			mnew->SetLength(res);
			m_rx_queue.push_back(mnew);
			ReadEvent();
		}
	}
	else
	{
		++SOCKETENGINESTAT(read_fail_no_sbuf);
		member_TRACE(&m_trace_set, 0, "%s: Failed to alloc buffer (read)\n", m_name.c_str());
	}
}

void SocketEngine::write()
{
	if (m_need_to_close)
	{
		CloseNeeded();
		return;
	}
	if (m_connecting)
	{
		int is_ok;
		socklen_t sz = sizeof(is_ok);
		if (0 != getsockopt(m_fd, SOL_SOCKET, SO_ERROR, &is_ok, &sz) || 0 != is_ok)
		{
			//error
			member_TRACE(&m_trace_set, 0, "%s: failed to connect socket to %s: %s\n", m_name.c_str(), GetPeerAddrStr().c_str(), strerror(is_ok));
			CloseNeeded();
		}
		else
		{
			m_connecting = false;
			UpdateFlag();
			AwakenEvent();
		}
		return;
	}

	if (m_fd >= 0)
	{
		if (!m_tx_queue.empty())
		{
			SocketBuffer *sbuf = m_tx_queue.front();

			int res = ::write(m_fd, sbuf->GetData(), sbuf->GetLength());
			if (res > 0)
			{
				SOCKETENGINESTAT(tx_bytes) += res;
				member_TRACE(&m_trace_set, 8, "%s wrote %d bytes to %s\n", m_name.c_str(), res, GetPeerAddrStr().c_str());
				sbuf->RemoveHeader(res);
				 // did we write all the data?
				if (sbuf->Empty())
				{
					m_tx_queue.pop_front();
					m_buf_pool.Return(sbuf);
					if (m_tx_queue_full)
					{
						m_tx_queue_full = false;
						TxQueueAvailableEvent();
					}
				}
			}
			else
			{
				member_TRACE(&m_trace_set, 2, "%s write syscall failure: %s\n", m_name.c_str(), strerror(errno));
				if (!(errno == EAGAIN || errno == EBUSY))
				{
					m_tx_queue.pop_front();
					m_buf_pool.Return(sbuf);
					if (m_tx_queue_full)
					{
						m_tx_queue_full = false;
						TxQueueAvailableEvent();
					}
				}
			}
			// anything more to write?
			if (m_tx_queue.empty())
			{
				WriteDoneEvent();
			}
		}
		else
		{
			//why did we get here- we shouldnt have the write flag set when we have
			//nothing to write
			WriteDoneEvent();
			member_TRACE(&m_trace_set, 2, "%s -- nothing to write\n", m_name.c_str());
		}
	}
	else
	{
		member_TRACE(&m_trace_set, 0, "%s - write with invalid fd (%d)\n", m_name.c_str(), m_fd);
	}
	UpdateFlag();
}

}
