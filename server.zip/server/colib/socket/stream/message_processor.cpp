#include <socket/stream/message_processor.h>
#include <socket/stream/stream_base.h>
#include <event_loop/event_loop.h>
#include <utils/trace/trace.h>
#include <utils/system/macros.h>
#include <socket/socket_buffer_pool.h>
#include <socket/sb_multi_encode.h>
#include <utils/trace/writable.h>
#include <message/message_type.h>

namespace colib
{

MessageProcessor::MsgCbDesc::MsgCbDesc(int type, const Callback3<char*, int, StreamBase*> &cbk)
	: m_msg_type(type)
	, m_cbk(cbk)
	, m_hit_count(0)
{
}

MessageProcessor::MsgCbDesc::MsgCbDesc(const MsgCbDesc &other)
	: m_msg_type(other.m_msg_type)
	, m_cbk(other.m_cbk)
	, m_hit_count(other.m_hit_count)
{
}

MessageProcessor::MsgCbDesc& MessageProcessor::MsgCbDesc::operator=(const MessageProcessor::MsgCbDesc &other)
{
	if (this != &other)
	{
		m_msg_type = other.m_msg_type;
		m_cbk = other.m_cbk;
		m_hit_count = other.m_hit_count;
	}
	return *this;
}

static ValueList::ValueHolder InitStats()
{
	return
	{
		Value("rx_reg_messages", 0),
		Value("reg_message_fail_permissions", 0),
		Value("rx_any_messages", 0),
		Value("rx_unreg_messages", 0),
		Value("tx_messages", 0),
		Value("encode_failures", 0),
		Value("tx_errors", 0),
		Value("rx_length_errors", 0)
	};
};

MessageProcessor::MessageProcessor(const char* name, StreamBase& parent, MemberSet& trace_set)
	: m_name(name)
	, m_cbk_map()
	, m_any_xdr_cb()
	, m_msg_error_cb()
	, m_rx_buf(new char[INITIAL_BUF_SIZE])
	, m_capacity(INITIAL_BUF_SIZE)
	, m_data_length(0)
	, m_offset(0)
	, m_in_progress(false)
	, m_parent(parent)
	, m_message_handler(callbackRt(this, &MessageProcessor::ReadXdr), m_name)
	, m_trace_set(trace_set)
	, m_stats(InitStats())
{
}

MessageProcessor::~MessageProcessor()
{
	delete [] m_rx_buf;
	EventLoop::GetInstance().DeleteActivity(&m_message_handler);
}

bool MessageProcessor::WriteXdrData(CEncodableItem &data, StreamWriteError& err_code)
{
	bool ret = false;
	unsigned int len = 0;

	SocketBufferMultiEncoder enc(&m_trace_set);
	if (data.Encode(enc, &len, true))
	{
		if (m_parent.WriteBufferList(enc.GetBufList()))
		{
			member_TRACE(&m_trace_set, 8, "%s -- wrote xdr data (%d bytes)\n", m_name.c_str(), len);
			ret = true;
			++MSGPROCSTAT(tx_messages);
		}
		else
		{
			member_TRACE(&m_trace_set, 1, "%s -- Failed to write encoded buffer (%d bytes)\n", m_name.c_str(), len);
			++MSGPROCSTAT(tx_errors);
		}
	}
	else
	{
		if (enc.IsPoolEmpty())
		{
			err_code = StreamWriteError::BUF_UNAVAILABLE;
			member_TRACE(&m_trace_set, 1, "%s -- Insufficent buffers (%d) to encode data\n", m_name.c_str(), SocketBufferPool::GetInstance().Available());
		}
		else
		{
			err_code = StreamWriteError::ENCODE_FAILED;
			member_TRACE(&m_trace_set, 1, "%s -- Failed to encode data\n", m_name.c_str());
		}
		++MSGPROCSTAT(encode_failures);
	}

	return ret;
}

bool MessageProcessor::WriteMessage(Message &msg, StreamWriteError& err_code)
{
	if (!WriteXdrData(msg, err_code))
	{
		member_TRACE(&m_trace_set, 1, "%s -- Failed to send msg type %d\n", m_name.c_str(),  msg.GetType());
		return false;
	}
	member_TRACE(&m_trace_set, 8, "%s -- sent msg type %d\n", m_name.c_str(), msg.GetType());
	return true;
}

void MessageProcessor::SocketReadEvent(StreamBase *stream_socket)
{
	(void)stream_socket;
	EventLoop::GetInstance().AddActivity(&m_message_handler);
}

void MessageProcessor::Register(int msg_type, const Callback3<char*, int, StreamBase*> &cbk)
{
	MsgCbDesc cbk_reg(msg_type, cbk);

	CbkRegMap::iterator it = m_cbk_map.find(msg_type);
	if (it != m_cbk_map.end())
	{
		// msg id already registered, overwrite callback
		TRACE(4, "%s -- msg type %d double registered\n", m_name.c_str(), msg_type);
		it->second = cbk_reg;
	}
	else
	{
		// not found -- add
		m_cbk_map.insert( std::pair<int, MsgCbDesc>(msg_type, cbk_reg) );
	}
}

void MessageProcessor::UnRegister(int msg_type)
{
	CbkRegMap::iterator it = m_cbk_map.find(msg_type);
	if (it != m_cbk_map.end())
	{
		m_cbk_map.erase(it);
	}
}

void MessageProcessor::UnRegisterAll()
{
	// unlearn specific message handlers
	m_cbk_map.clear();
	// unlearn the "any" handler
	m_any_xdr_cb.Clear();
}

void MessageProcessor::ParseData(char *data, int len)
{
	int msg_type = Message::DecodeMsgType(data);
	/*
	if ( msg_type == TCPConnectionKeepAliveMsgID )
	{
		TRACE(9, "Ignore TCPConnectionKeepAliveMsg\n");
		return;
	}
	*/
	member_TRACE(&m_trace_set, 8, "%s -- received msg type %d\n", m_name.c_str(), msg_type);

	CbkRegMap::iterator it = m_cbk_map.find(msg_type);
	if (it != m_cbk_map.end())
	{
		++MSGPROCSTAT(rx_reg_messages);
		++it->second.m_hit_count;
		if ( m_parent.CheckPermission(msg_type) )
		{
			it->second.m_cbk.Dispatch(data, len, &m_parent);
		}
		else
		{
			member_TRACE(&m_trace_set, 1, "%s -- Msg type %d not pass permission check, discarding\n", m_name.c_str(), msg_type);
			++MSGPROCSTAT(reg_message_fail_permissions);
		}
	}
	else if (m_any_xdr_cb.IsSet())
	{
		++MSGPROCSTAT(rx_any_messages);
		m_any_xdr_cb.Dispatch(data, len, &m_parent);
	}
	else
	{
		member_TRACE(&m_trace_set, 1, "%s -- Msg type %d not registered, discarding\n", m_name.c_str(), msg_type);
		++MSGPROCSTAT(rx_unreg_messages);
	}
}

eCallbackRt MessageProcessor::ReadXdr()
{
	while (1)
	{
		int amount_to_read = 0;
		bool header_only = false;

		// are we starting a new message or finishing an existing one?
		if (!m_in_progress)
		{
			header_only = true;
			amount_to_read = Message::HEADER_LENGTH - m_offset;
		}
		else
		{
			amount_to_read = std::min(m_data_length - m_offset, m_capacity);
		}

		int read_len = m_parent.ReadBytes(m_rx_buf+m_offset, amount_to_read);
		if (read_len <= 0)
		{
			//no more data in buffer
			return DontRunAgain;
		}

		m_offset += read_len;

		if (!header_only)
		{
			if (m_offset == m_data_length)
			{
				ParseData(m_rx_buf, m_data_length);
				m_data_length = 0;
				m_offset = 0;
				m_in_progress = false;
				//dispatch one msg a time, release event loop for other file descriptors
				return RunAgain;
			}
		}
		else if (m_offset == Message::HEADER_LENGTH)
		{
			//receive length
			m_data_length = NET_GET32(m_rx_buf);
			m_offset = 0;
			if (m_data_length <= 0 || m_data_length > MAX_MSG_LENGTH)
			{
				member_TRACE(&m_trace_set, 2, "%s -- Message len abnormal %d (ignoring)\n", m_name.c_str(), m_data_length);
				++MSGPROCSTAT(rx_length_errors);
				m_msg_error_cb.Dispatch(&m_parent);
				m_data_length = 0;
				m_in_progress = false;
				return RunAgain;
			}
			else
			{
				member_TRACE(&m_trace_set, 8, "%s xdr len %d\n", m_name.c_str(), m_data_length);
			}
			if (m_capacity < m_data_length)
			{
				// need to resize (TODO: may want to double)
				delete [] m_rx_buf;
				m_rx_buf = new char[m_data_length];
				m_capacity = m_data_length;
			}
			m_in_progress = true;
		}
	}
}

void MessageProcessor::DumpReg(Writable *to) const
{
	to->Print("%d Registered Message Handler(s)\n", m_cbk_map.size());
	for (auto it(m_cbk_map.cbegin()); it != m_cbk_map.cend(); ++it)
	{
		to->Print("[%d] Received Count: %u\n", it->first, it->second.m_hit_count);
	}
	if (m_any_xdr_cb.IsSet())
	{
		to->PrintString("** \"Any\" handler is registered\n");
	}
}

void MessageProcessor::ResetMsgCounts()
{
	for (auto it(m_cbk_map.begin()); it != m_cbk_map.end(); ++it)
	{
		it->second.m_hit_count = 0;
	}
}

void MessageProcessor::ConsoleCommand(Writable *to, int argc, char *argv[])
{
	const char* usage = "Usage: stats | reg [reset_count]\n";

	if (argc < 1)
	{
		to->PrintString(usage);
	}
	else if (strcmp(argv[0], "stats") == 0)
	{
		m_stats.ConsoleCommand(to, argc-1, argv+1);
	}
	else if (strcmp(argv[0], "reg") == 0)
	{
		if (argc < 2)
		{
			DumpReg(to);
		}
		else if (strcmp(argv[1], "reset_count") == 0)
		{
			ResetMsgCounts();
			DumpReg(to);
		}
		else
		{
			to->PrintString(usage);
		}
	}
	else
	{
		to->PrintString(usage);
	}

}

}
