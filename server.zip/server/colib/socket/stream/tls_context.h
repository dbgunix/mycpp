#if !defined(__TLS_CONTEXT_H__)
#define __TLS_CONTEXT_H__

#include <utils/string.h>
#include <config/value.h>

#ifdef CONFIG_HAVE_TLS
#include <openssl/ssl.h>

namespace colib
{
	class ConsoleSession;

	struct CertVerifyOpt
	{
		public:

									CertVerifyOpt();
			virtual					~CertVerifyOpt() {};

			bool&					TrustedCertRequired() { return m_trusted_cert_required; }
			string					Print() const;

		private:

			bool					m_trusted_cert_required;
			//
			// Add more if needed ...
			//
	};

	class GlobalSSL
	{
		public:

			typedef int(*TLS_PASSWD_CALLBACK)(char*, int, int, void*);

			enum Stats
			{
				Stat_num_cert_verify_passthru,
				Stat_num_cert_verify_succeed,
				Stat_num_cert_verify_failed,
				Stat_latest_cert_verify_failed_reason,
				Stat_num_host_cert_key_update_succeed,
				Stat_num_host_cert_key_update_not_ready,
				Stat_num_host_cert_key_update_failed,
				Stat_latest_host_cert_key_update_failed_reason,
				Stat_num_ssl_created,
				Stat_num_ssl_returned
			};

			static GlobalSSL&		GetInstance();
			static void				Gather_Openssl_Error(string& into);

			bool					Init(string& err);
			bool					SetGlobalCtxPasswdCb(TLS_PASSWD_CALLBACK cb);
			int						CertVerifyOptIndex() { return m_cert_verify_opt_idx; }

			SSL*					CreateNewSSL();
			void					ReturnSSL(SSL* ssl);

			bool					IsOK() const;

			static void				CmdGlobalSSL(void* ctx, ConsoleSession* con, int argc, char* argv[]);
			void					ConsoleCommand(ConsoleSession* con, int argc, char* argv[]);

		private:

			static int				TlsVerifyCert(X509_STORE_CTX* p_store_ctx, void*);

			int						VerifyCert(X509_STORE_CTX* p_store_ctx);

			void					UpdateHostCertAndKey();
			//
			// ctor
			//
									GlobalSSL();
		private:

			bool					m_initialized;
			bool					m_cert_loaded;
			bool					m_key_loaded;
			SSL_CTX*				m_ctx;
			int						m_cert_verify_opt_idx;
			ValueList				m_stats;
	};
	#define GLOBALSSL_STAT(stat)	m_stats[GlobalSSL::Stat_##stat].AsInt()
}

#endif

#endif
