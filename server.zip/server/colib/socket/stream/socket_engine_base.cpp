#include<socket/stream/socket_engine_base.h>
#include<socket/stream/stream_base_se_intf.h>
#include<socket/stream/socket_params.h>
#include<utils/trace/trace.h>
#include<utils/trace/writable.h>
#include<socket/socket_buffer_pool.h>
#include<event_loop/event_loop.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <errno.h>
#include <math.h>
#include <unistd.h>
#include <fcntl.h>

namespace colib
{

static ValueList::ValueHolder InitStats()
{
	return
	{
		Value("rx_bytes", 0),
		Value("tx_bytes", 0),
		Value("rx_queue_size", 0),
		Value("tx_queue_size", 0),
		Value("read_fail_no_sbuf", 0)
	};
};

SocketEngineBase::SocketEngineBase(const char *name, int fd, StreamBaseSeIntf &parent, MemberSet &trace_set)
	: FileDescriptorHandler(name, fd, READ_NOTIFY_FLAG)
	, m_parent(parent)
	, m_trace_set(trace_set)
	, m_buf_pool(SocketBufferPool::GetInstance())
	, m_tx_queue()
	, m_rx_queue()
	, m_need_to_close(false)
	, m_need_to_empty_buf(false)
	, m_connecting(false)
	, m_tx_queue_full(false)
	, m_params(m_parent.GetParams())
	, m_stats(InitStats())
{
}

SocketEngineBase::~SocketEngineBase()
{
	ReturnQueue(m_tx_queue);
	ReturnQueue(m_rx_queue);
}

ValueList& SocketEngineBase::GetStats()
{
	SOCKETENGINESTAT(rx_queue_size) = m_rx_queue.size();
	SOCKETENGINESTAT(tx_queue_size) = m_tx_queue.size();
	return m_stats;
}

bool SocketEngineBase::Init()
{
	return true;
}

bool SocketEngineBase::TestWriteBytesSpace(int bufsize)
{
	m_tx_queue_full = !SpaceToWriteBytes(bufsize);
	return !m_tx_queue_full;
}

bool SocketEngineBase::Connect(string server_addr, string& local_addr, bool blocking_connect, string& err)
{
	m_trace_set.Trace(7, "%s engine triggering internal disconnect\n", GetName().c_str());
	Disconnect();

	m_need_to_close = false;

	SocketAddr server_sock;
	if (!server_sock.SetFromString(server_addr))
	{
		err.AppendFmt("%s::%s -- Failed to parse server address: %s", GetName().c_str(), __FUNCTION__, server_addr.c_str());
		return false;
	}

	//create the socket
	m_fd = socket(server_sock.GetType(), SOCK_STREAM, 0);

	if (m_fd <= 0)
	{
		err.AppendFmt("%s::%s -- socket() failed: %s", GetName().c_str(), __FUNCTION__, strerror(errno));
		return false;
	}

	// if not using blocking connect, make socket non-blocking before connecting
	if (!blocking_connect && !MakeNonBlocking())
	{
		close(m_fd);
		m_fd = -1;
		return false;
	}

	// if we have a bind address, bind before connecting
	if (!local_addr.is_empty())
	{
		SocketAddr local_sock;
		if (!local_sock.SetFromString(local_addr))
		{
			err.AppendFmt("%s::%s -- Failed to parse local address: %s", GetName().c_str(), __FUNCTION__, local_addr.c_str());
			return false;
		}
		int enable = 1;
		if (setsockopt(m_fd, SOL_SOCKET, SO_REUSEADDR, &enable, sizeof(enable)) < 0)
		{
			err.AppendFmt("%s::%s -- failed to set reuseaddr: %s", GetName().c_str(), __FUNCTION__, strerror(errno));
			close(m_fd);
			m_fd = -1;
			return false;
		}
		//bind the socket
		if (bind(m_fd, local_sock.m_data, local_sock.m_data_len) < 0)
		{
			err.AppendFmt("%s::%s -- failed to bind socket to %s: %s", GetName().c_str(), __FUNCTION__, local_addr.c_str(), strerror(errno));
			close(m_fd);
			m_fd = -1;
			return false;
		}
	}

	//connect
	if (connect(m_fd, server_sock.m_data, server_sock.m_data_len) < 0)
	{
		if (errno == EINPROGRESS)
		{
			//we are fine: the socket is non-blocking and we simply have to wait until
			//the connection has been completed or fails
		}
		else
		{
			err.AppendFmt("%s::%s -- failed to connect socket to %s: %s", GetName().c_str(), __FUNCTION__, server_addr.c_str(), strerror(errno));
			close(m_fd);
			m_fd = -1;
			return false;
		}
	}

	// after connect we can fill in our local addr (if needed)
	if (local_addr.is_empty())
	{
		SocketAddr local_sock;
		// set our type based on the server's type
		if (local_sock.SetType(server_sock.GetType())
			&& getsockname(m_fd, local_sock.m_data, &local_sock.m_data_len) == 0)
		{
			local_addr = local_sock.PutToString();
		}
	}

	m_connecting = true;

	// if using blocking connect, make socket non-blocking after connecting
	if (blocking_connect && !MakeNonBlocking())
	{
		close(m_fd);
		m_fd = -1;
		return false;
	}

	//attach to event loop, with the write notify flag enabled. Once we become writable,
	//that tells us that the socket has awakened. We will set readable after we get connected.
	if (!EventLoop::GetInstance().AddHandler(*this))
	{
		err.AppendFmt("%s::%s -- failed to add FDH to event loop", GetName().c_str(), __FUNCTION__);
		close(m_fd);
		m_fd = -1;
		return false;
	}
	SetFlag(FileDescriptorHandler::WRITE_NOTIFY_FLAG);

	return true;
}

void SocketEngineBase::Disconnect()
{
	ReturnQueue(m_tx_queue);
	ReturnQueue(m_rx_queue);
	if (m_fd > 0)
	{
		member_TRACE(&m_trace_set, 3, "%s disconnecting\n", m_name.c_str());
		EventLoop::GetInstance().RemoveHandler(*this);
		close(m_fd);
		m_fd = -1;
		m_need_to_close = false;
		CloseEvent();
	}
}

bool SocketEngineBase::SpaceToWriteBytes(int bufsize) const
{
	if (bufsize <= 0)
	{
		return true;
	}

	/* before figuring out how many buffers we need,
	 * see if the last (most recent) buffer is not full
	 * and use what space we can from it
	 */
	int temp_bufsize = bufsize;
	SocketBuffer *tail = !m_tx_queue.empty() ? m_tx_queue.back() : NULL;
	if (tail)
	{
		bufsize -= tail->BytesAvailable();
		if (bufsize <= 0)
		{
			return true;
		}
	}

	bool ret = false;
	// figure out how many buffers we need
	const double bytes_buf_convert = 1.0/SOCKET_BUFFER_SIZE;
	int num_of_buf_needed = static_cast<int>(ceil(bufsize * bytes_buf_convert));
	// is there room in the tx queue for that number of buffers?
	if (!TxQueueSpaceAvailable(num_of_buf_needed))
	{
		member_TRACE(&m_trace_set, 0, "%s -- queue_limit hit (%d), refusing to queue %d bytes\n", m_name.c_str(), SOCKETENGINEPARAM(tx_queue_limit), temp_bufsize);
	}
	else
	{
		ret = true;
	}

	return ret;
}

bool SocketEngineBase::TxQueueSpaceAvailable(int num_bufs_needed) const
{
	return static_cast<int>(m_tx_queue.size() + num_bufs_needed) <= SOCKETENGINEPARAM(tx_queue_limit);
}

void SocketEngineBase::InitiateClose()
{
	if (m_rx_queue.empty())
	{
		member_TRACE(&m_trace_set, 8, "%s::%s -- rx queue is empty\n", m_name.c_str(), __FUNCTION__);
		m_need_to_close = true;
	}
	else
	{
		member_TRACE(&m_trace_set, 8, "%s::%s -- rx queue is not empty\n", m_name.c_str(), __FUNCTION__);
		m_need_to_empty_buf = true;
	}
	ReturnQueue(m_tx_queue);
	UpdateFlag();
}

void SocketEngineBase::UpdateFlag()
{
	if (m_fd > 0)
	{
		unsigned int new_flag = (m_need_to_close || !m_need_to_empty_buf) ? FileDescriptorHandler::READ_NOTIFY_FLAG : 0;
		if (!m_tx_queue.empty() || m_need_to_close )
		{
			new_flag |= FileDescriptorHandler::WRITE_NOTIFY_FLAG;
		}
		SetFlag(new_flag);
	}
}

SocketBuffer* SocketEngineBase::ReadBuffer()
{
	SocketBuffer *ret = NULL;
	if (!m_rx_queue.empty())
	{
		ret = m_rx_queue.front();
		m_rx_queue.pop_front();
	}
	if (m_need_to_empty_buf && m_rx_queue.empty())
	{
		m_need_to_empty_buf = false;
		InitiateClose();
	}
	return ret;
}

int SocketEngineBase::ReadBytes(char *buf, int bufsize)
{
	if (m_need_to_close)
	{
		return 0;
	}

	if (m_fd <= 0)
	{
		return -1;
	}

	if (bufsize <= 0 || NULL == buf)
	{
		member_TRACE(&m_trace_set, 0, "%s -- invalid request to read %d bytes from queue to %p\n", m_name.c_str(), bufsize, buf);
		return -1;
	}

	int bytes_copied = -1;
	if (!m_rx_queue.empty())
	{
		SocketBuffer *sbuf = m_rx_queue.front();
		int bytes_to_copy = std::min(sbuf->GetLength(), static_cast<uint32_t>(bufsize));
		memcpy(buf, sbuf->GetData(), bytes_to_copy);
		sbuf->RemoveHeader(bytes_to_copy);
		if (sbuf->Empty())
		{
			// off the queue and back to the free list
			m_rx_queue.pop_front();
			m_buf_pool.Return(sbuf);
		}
		bytes_copied = bytes_to_copy;
	}
	// if we are keeping the socket open to empty the rx_queue
	// and the queue is empty, close the socket
	if (m_need_to_empty_buf && m_rx_queue.empty())
	{
		m_need_to_empty_buf = false;
		InitiateClose();
	}
	return bytes_copied;
}

bool SocketEngineBase::WriteBuffer(SocketBuffer* buf, StreamWriteError& err_code)
{
	bool ret = false;
	if (m_fd <= 0)
	{
		err_code = StreamWriteError::INVALID_FD;
		member_TRACE(&m_trace_set, 2, "%s -- cannot write buffer, invalid fd (%d)\n", m_name.c_str(), m_fd);
	}
	else if (!TxQueueSpaceAvailable(1)) // 1 = one socket buffer
	{
		err_code = StreamWriteError::TX_QUEUE_FULL;
		m_tx_queue_full = true;
	}
	else
	{
		m_tx_queue.push_back(buf);
		UpdateFlag();
		ret = true;
	}
	return ret;
}

bool SocketEngineBase::WriteBufferList(std::list<SocketBuffer*>& buf_list, StreamWriteError& err_code)
{
	bool ret = false;
	if (m_fd <= 0)
	{
		err_code = StreamWriteError::INVALID_FD;
		member_TRACE(&m_trace_set, 2, "%s -- cannot write buffer list(%zu), invalid fd (%d)\n", m_name.c_str(), buf_list.size(), m_fd);
	}
	else if (!TxQueueSpaceAvailable(buf_list.size()))
	{
		err_code = StreamWriteError::TX_QUEUE_FULL;
		m_tx_queue_full = true;
	}
	else
	{
		// take ownership of socketbuffers
		m_tx_queue.splice(m_tx_queue.end(), buf_list);
		UpdateFlag();
		ret = true;
	}
	return ret;
}

int SocketEngineBase::WriteBytes(const char* buf, int bufsize, StreamWriteError& err_code)
{
	if (m_fd <= 0)
	{
		err_code = StreamWriteError::INVALID_FD;
		member_TRACE(&m_trace_set, 2, "%s -- cannot write bytes, invalid fd (%d)\n", m_name.c_str(), m_fd);
		return -1;
	}
	if (!SpaceToWriteBytes(bufsize))
	{
		err_code = StreamWriteError::TX_QUEUE_FULL;
		m_tx_queue_full = true;
		return -1;
	}
	if (bufsize < 0)
	{
		err_code = StreamWriteError::INVALID_LENGTH;
		return -1;
	}

	int ret = 0;
	bool tail_filled = false;
	bool append_needed = true;
	SocketBuffer *write_buf;

	while (bufsize > 0)
	{
		// start by assuming we will need a new buffer
		write_buf = NULL;

		int iQueueCount = m_tx_queue.size(); // needed for logging
		// check if we can use the existing "tail" buffer in the tx queue
		if (!tail_filled)
		{
			member_TRACE(&m_trace_set, 5, "%s::%s -- tail not filled, queue_count: %d,  to write: %d bytes\n", m_name.c_str(), __FUNCTION__, iQueueCount, bufsize);
			write_buf = !m_tx_queue.empty() ? m_tx_queue.back() : NULL;
			/* if there is an existing buffer but no space available then
			 * mark it as unusable by setting to null
			 */
			if (write_buf && write_buf->BytesAvailable() <= 0)
			{
				write_buf = NULL;
			}
			append_needed = false;
			tail_filled = true;
		}
		// no existing buffer to use, need to allocate a new one
		if (!write_buf)
		{
			member_TRACE(&m_trace_set, 5, "%s::%s -- allocating buffer, queue_count: %d, to write: %d bytes\n", m_name.c_str(), __FUNCTION__, iQueueCount, bufsize);

			write_buf = m_buf_pool.Get();
			if (!write_buf)
			{
				member_TRACE(&m_trace_set, 0, "%s::%s -- Failed to get buffer from pool\n", m_name.c_str(), __FUNCTION__);
				break;
			}
			append_needed = true;
		}

		int write_amount = std::min(write_buf->BytesAvailable(), bufsize);

		if (append_needed)
		{
			member_TRACE(&m_trace_set, 5, "%s::%s -- append needed, queue_count: %d, to write: %d bytes\n", m_name.c_str(), __FUNCTION__, iQueueCount, bufsize);

			m_tx_queue.push_back(write_buf);
		}

		/* the actual copy
		 * (return value not needed, write amount is bounded by space available) */
		write_buf->AppendData(buf, write_amount);
		// update "state"
		buf += write_amount;
		bufsize -= write_amount;
		ret += write_amount;
	}

	UpdateFlag();
	return ret;
}

void SocketEngineBase::ReadEvent()
{
	m_parent.ReadEvent();
}

void SocketEngineBase::CloseEvent()
{
	m_parent.CloseEvent();
}

void SocketEngineBase::AwakenEvent()
{
	m_parent.AwakenEvent();
}

void SocketEngineBase::WriteDoneEvent()
{
	m_parent.WriteDoneEvent();
}

void SocketEngineBase::TxQueueAvailableEvent()
{
	m_parent.TxQueueAvailableEvent();
}

void SocketEngineBase::CloseNeeded()
{
	m_parent.CloseNeeded();
}

string SocketEngineBase::GetPeerAddrStr() const
{
	return m_parent.GetPeerAddrStr();
}

void SocketEngineBase::ReturnQueue(std::list<SocketBuffer*> &queue)
{
	for (auto it(queue.cbegin()); it != queue.cend(); ++it)
	{
		m_buf_pool.Return(*it);
	}
	queue.clear();
}

void SocketEngineBase::PrintRxQueue(Writable* to) const
{
	to->Print("Rx Queue size: %d\n", m_rx_queue.size());
	for (auto it(m_rx_queue.cbegin()); it != m_rx_queue.cend(); ++it)
	{
		to->Print("\t%p -> %d bytes\n", &(*it), (*it)->GetLength());
	}
}

void SocketEngineBase::GetLocalName(SocketAddr& local_addr)
{
	if (m_fd > 0)
	{
		getsockname(m_fd, local_addr.m_data, &local_addr.m_data_len);
	}
}

}
