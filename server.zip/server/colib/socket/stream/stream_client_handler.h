#if !defined(__STREAM_CLIENT_HANDLER_H__)
#define __STREAM_CLIENT_HANDLER_H__

#include<socket/socket_addr.h>
#include<event_loop/event_loop.h>
#include<socket/stream/stream_base.h>
#include<socket/stream/stream_server.h>


namespace colib
{

class Writable;

class StreamClientHandler : public StreamBase
{
public:
	StreamClientHandler(const char *name, int fd, StreamServer &parent, StreamBase::TlsOpt tls, StreamBase::XdrOpt xdr);
	virtual bool Init(const SocketAddr& local_addr, const SocketAddr& peer_addr);

    void SetSocketAddr(const SocketAddr& local_addr, const SocketAddr& peer_addr) {
        m_local_addr = local_addr.PutToString();
        m_peer_addr = peer_addr.PutToString();
    }

	void Disconnect(bool reconnect=false);
	void NotifyClosed() { CloseEvent(); }

	virtual string ConsoleHelp() const;
	virtual void ConsoleCommand(Writable *to, int argc, char *argv[]);

	void AddWritable(int level, Writable *out) { m_trace_set.AddWritable(level, out); }

	virtual int GetId() const { return m_uid; }

protected:

	StreamServer &m_parent;

private:
	// called by socketengine via intf
	void CloseNeeded();
	void SetUId(int uid) { m_uid = uid; }

	bool m_closing;
	int m_uid;

friend class StreamServer;
};

}

#endif
