#ifdef CONFIG_HAVE_TLS
#include <socket/stream/socket_engine_tls.h>
#include <socket/socket_buffer_pool.h>
#include <socket/stream/stream_base_se_intf.h>
#include <utils/trace/trace.h>

#include <openssl/err.h>

namespace colib
{

SocketEngineTLS::SocketEngineTLS(const char *name, int fd, StreamBaseSeIntf &parent, MemberSet &trace_set)
	: SocketEngineBase(name, fd, parent, trace_set)
	, m_tls_params(parent.GetTlsParams())
	, m_tls_core(*this, m_trace_set)
{
}

bool SocketEngineTLS::Init()
{
	return m_tls_core.Init(m_fd);
}

bool SocketEngineTLS::Connect(string server_addr, string& local_addr, bool blocking_connect, string& err)
{
	m_tls_core.SetConnectHandshake();
	return SocketEngineBase::Connect(server_addr, local_addr, blocking_connect, err);
}

void SocketEngineTLS::Disconnect()
{
	member_TRACE(&m_trace_set, 4, "%s: TLS cleanup due to disconnect\n", m_name.c_str());
	m_tls_core.Cleanup();
	SocketEngineBase::Disconnect();
}

void SocketEngineTLS::TLS_ShutdownProgress(bool tls_shutdown_complete)
{
	if (tls_shutdown_complete)
	{
		InitiateClose();
	}
	SetFlag(FileDescriptorHandler::ALL_FLAGS);
}

void SocketEngineTLS::read()
{
	if (m_fd < 0)
	{
		member_TRACE(&m_trace_set, 0, "%s read attempt with invalid fd (%d)\n", m_name.c_str(), m_fd);
		return;
	}

	if (m_need_to_close)
	{
		CloseNeeded();
		return;
	}
	if (m_connecting)
	{
		int is_ok;
		socklen_t sz = sizeof(is_ok);
		if( 0 != getsockopt(m_fd, SOL_SOCKET, SO_ERROR, &is_ok, &sz) || 0 != is_ok )
		{
			//error
			member_TRACE(&m_trace_set, 0, "%s: failed to connect socket to %s: %s\n", m_name.c_str(), GetPeerAddrStr().c_str(), strerror(is_ok));
			m_tls_core.Shutdown();
		}
		else
		{
			m_connecting = false;
			// can't notify awaken at this point, TLS handshake not finished
			SetFlag(FileDescriptorHandler::ALL_FLAGS);
		}
		return;
	}

	if (m_tls_core.IsConnecting())
	{
		HandleHandshake("r");
		return;
	}

	if (m_tls_core.IsDisconnecting())
	{
		m_tls_core.Shutdown();
		return;
	}

	//read from the socket into a SocketBuffer
	bool finished = false;
	bool close = false;
	do
	{
		SocketBuffer *mnew = m_buf_pool.Get();
		if(!mnew)
		{
			++SOCKETENGINESTAT(read_fail_no_sbuf);
			member_TRACE(&m_trace_set, 0, "%s: Failed to alloc buffer (read)\n", m_name.c_str());
			break;
		}

		int res = m_tls_core.SSL_read(mnew);
		switch (m_tls_core.SSL_error(res))
		{
			case SSL_ERROR_NONE:
				SOCKETENGINESTAT(rx_bytes) += res;
				member_TRACE(&m_trace_set, 8, "%s read %d bytes from %s\n", m_name.c_str(), res, GetPeerAddrStr().c_str());
				mnew->SetLength(res);
				m_rx_queue.push_back(mnew);
				ReadEvent();
				finished = !m_tls_core.DataPending();
				break;
			case SSL_ERROR_ZERO_RETURN:
				// close_notify received
				member_TRACE(&m_trace_set, 3, "%s peer %s disconnect (read)\n", m_name.c_str(), GetPeerAddrStr().c_str());
				m_buf_pool.Return(mnew);
				close = true;
				finished = true;
				break;
			case SSL_ERROR_WANT_READ:
				//partialy received a Tls record, wait for more
				m_buf_pool.Return(mnew);
				member_TRACE(&m_trace_set, 7, "%s: SSL_ERROR_WANT_READ in read()\n", m_name.c_str());
				finished = true;
				break;
			default:
				m_buf_pool.Return(mnew);
				member_TRACE(&m_trace_set, 3, "%s: Tls session closed prematurely\n", m_name.c_str());
				close = true;
				finished = true;
				break;
		}

	}
	while(!finished);

	if (close)
	{
		m_tls_core.Cleanup();
		InitiateClose();
	}
}

void SocketEngineTLS::write()
{
	if (m_fd < 0)
	{
		member_TRACE(&m_trace_set, 0, "%s write attempt with invalid fd (%d)\n", m_name.c_str(), m_fd);
		return;
	}

	if (m_need_to_close)
	{
		CloseNeeded();
		return;
	}

	if (m_connecting)
	{
		int is_ok;
		socklen_t sz = sizeof(is_ok);
		if( 0 != getsockopt(m_fd, SOL_SOCKET, SO_ERROR, &is_ok, &sz) || 0 != is_ok )
		{
			//error
			member_TRACE(&m_trace_set, 0, "%s: failed to connect socket to %s: %s\n", m_name.c_str(), GetPeerAddrStr().c_str(), strerror(is_ok));
			m_tls_core.Shutdown();
		}
		else
		{
			m_connecting = false;
			// can't notify awaken at this point, TLS handshake not finished
			SetFlag(FileDescriptorHandler::ALL_FLAGS);
		}
		return;
	}

	if (m_tls_core.IsConnecting())
	{
		HandleHandshake("w");
		return;
	}

	if (m_tls_core.IsDisconnecting())
	{
		m_tls_core.Shutdown();
		return;
	}

	if (m_tx_queue.empty())
	{
		//why did we get here- we shouldnt have the write flag set when we have
		//nothing to write
		WriteDoneEvent();
		member_TRACE(&m_trace_set, 2, "%s -- write() nothing to write\n", m_name.c_str());
	}
	else
	{
		SocketBuffer *sbuf = m_tx_queue.front();
		int res = m_tls_core.SSL_write(sbuf);
		int err = m_tls_core.SSL_error(res);
		switch (err)
		{
			case SSL_ERROR_NONE:
				SOCKETENGINESTAT(tx_bytes) += res;
				member_TRACE(&m_trace_set, 8, "%s wrote %d bytes to %s\n", m_name.c_str(), res, GetPeerAddrStr().c_str());
				sbuf->RemoveHeader(res);
				if (sbuf->Empty())
				{
					m_tx_queue.pop_front();
					m_buf_pool.Return(sbuf);
					if (m_tx_queue_full)
					{
						m_tx_queue_full = false;
						TxQueueAvailableEvent();
					}
				}
				break;
			case SSL_ERROR_WANT_WRITE:
				member_TRACE(&m_trace_set, 7, "%s: SSL_ERROR_WANT_WRITE in write()\n", m_name.c_str());
				break;
			case SSL_ERROR_SYSCALL:
			{
				member_TRACE(&m_trace_set, 0, "%s: SSL_ERROR_SYSCALL error! - ret value %d (errno: %d (%s)\n", m_name.c_str(), res, errno, strerror(errno));
				unsigned long iEr;
				while((iEr = ERR_get_error()) != 0)
				{
					member_TRACE(&m_trace_set, 0, "SSL_ERROR_SYSCALL error! - ERR_get_error %lu\n", iEr);
				}
				break;
			}
			default:
				member_TRACE(&m_trace_set, 1, "Tls write error %d -ret value %d\n", err, res);
				break;
		}

		if (m_tx_queue.empty())
		{
			WriteDoneEvent();
		}
	}
	UpdateFlag();
}

void SocketEngineTLS::HandleHandshake(const char* source)
{
	switch (m_tls_core.Handshake())
	{
		case TlsCore::SUCCESS:
			member_TRACE(&m_trace_set, 6, "%s: (%s)TLS Handshake success\n", GetName().c_str(), source);
			AwakenEvent();
			UpdateFlag();
			break;
		case TlsCore::FAILURE:
			member_TRACE(&m_trace_set, 6, "%s: (%s)TLS Handshake failure\n", GetName().c_str(), source);
			InitiateClose();
			break;
		case TlsCore::IN_PROGRESS_READ:
			member_TRACE(&m_trace_set, 6, "%s: (%s)TLS Handshake in prog read\n", GetName().c_str(), source);
			UpdateFlag();
			break;
		case TlsCore::IN_PROGRESS_WRITE:
			member_TRACE(&m_trace_set, 6, "%s: (%s)TLS Handshake in prog write\n", GetName().c_str(), source);
			SetFlag(FileDescriptorHandler::ALL_FLAGS);
			break;
	}
}

}

#endif
