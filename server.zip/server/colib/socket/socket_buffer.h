#if !defined(__SOCKET_BUFFER_H__)
#define __SOCKET_BUFFER_H__

#include<socket/socket_addr.h>
#include<utils/data_buffer.h>

//#define DEBUG_SOCKET_BUFFER 1

namespace colib
{

const int SOCKET_BUFFER_INITIAL_OFFSET = 0;
//const int SOCKET_BUFFER_MTU = 1536;
const int SOCKET_BUFFER_MTU = 8*1024;
const int SOCKET_BUFFER_SIZE = SOCKET_BUFFER_INITIAL_OFFSET + SOCKET_BUFFER_MTU;

class SocketBuffer : public DataBuffer<SOCKET_BUFFER_SIZE>
{
public:
	SocketBuffer();
	~SocketBuffer();

	int SetBuf(const char* pBuff, int length);
	void Reset() { ResetData(SOCKET_BUFFER_INITIAL_OFFSET); }
	SocketAddr& GetSocketAddr() { return m_addr; }

private:
	/** address to use for sending (if connectionless)
	 * address of sender (when receiving)
	 */
	SocketAddr m_addr;

	// copy/assignment protection
	SocketBuffer(const SocketBuffer&);
	void operator=(const SocketBuffer&);
};

}
#endif
