//socket_addr.cpp
// vi:set ts=4 sw=4 nowrap:

#include <socket/socket_addr.h>
#include <utils/trace/trace.h>
#include <utils/system/environ.h>

#include <netinet/in.h>
#include <sys/un.h>
#include <sys/ioctl.h>
#include <arpa/inet.h>
#include <net/if.h>
#include <netdb.h>
#include <stdio.h>
#include <errno.h>
#include <unistd.h>
#include <stdlib.h>
#include <algorithm>

#ifndef UNIX_PATH_MAX
#define UNIX_PATH_MAX 108
#endif

namespace colib
{

static const bool CONVERT_IPV4_IPV6 = false;

static bool alloc_of_type(SocketAddr *psa, int type)
{
	switch(type)
	{
		case PF_INET6:
			psa->m_data_len=sizeof(sockaddr_in6);
			psa->m_data=reinterpret_cast<sockaddr*>(new unsigned char[psa->m_data_len]);
			break;
		case PF_INET:
			psa->m_data_len=sizeof(sockaddr_in);
			psa->m_data=reinterpret_cast<sockaddr*>(new unsigned char[psa->m_data_len]);
			break;
		case PF_UNIX:
			psa->m_data_len=sizeof(sockaddr_un);
			psa->m_data=reinterpret_cast<sockaddr*>(new unsigned char[psa->m_data_len]);
			break;
		default:
			psa->m_data=0;
			psa->m_data_len=0;
			break;
	}
	if (!psa->m_data)
	{
		psa->m_data_len=0;
		return false;
	}
	// initialize the memory
	memset(psa->m_data, 0, psa->m_data_len);
	psa->m_data->sa_family=type;
	return true;
}

SocketAddr::SocketAddr()
	: m_data(0)
	, m_data_len(0)
{
}

SocketAddr::SocketAddr(int type)
	: m_data(0)
	, m_data_len(0)
{
	if (!alloc_of_type(this,type))
	{
		// nothing to do
	}
}

SocketAddr::SocketAddr(const SocketAddr &of)
	: m_data(0)
	, m_data_len(0)
{
	if(of.m_data)
	{
		m_data = reinterpret_cast<sockaddr*>(new char [of.m_data_len]);
		m_data_len = of.m_data_len;
		memcpy(m_data,of.m_data,m_data_len);
	}
}

SocketAddr::SocketAddr(string from_str)
	: m_data(0)
	, m_data_len(0)
{
	if (!SetFromString(from_str))
	{
		Clear();
	}
}

SocketAddr::SocketAddr(const sockaddr *sock_addr, socklen_t len)
	: m_data(0)
	, m_data_len(0)
{
	if (!SetTo(sock_addr, len))
	{
		Clear();
	}
}

SocketAddr::SocketAddr(sockaddr *sock_addr, socklen_t len, unsigned short portno_host_order)
	: m_data(0)
	, m_data_len(0)
{
	if (!SetTo(sock_addr, len, portno_host_order))
	{
		Clear();
	}
}

SocketAddr::~SocketAddr()
{
	Clear();
}

void SocketAddr::Clear()
{
	if (m_data)
	{
		delete [] (reinterpret_cast<char*>(m_data));
	}
	m_data = 0;
	m_data_len = 0;
}

SocketAddr& SocketAddr::operator=(const SocketAddr &to)
{
	if (this != &to)
	{
		SetTo(to);
	}
	return *this;
}

bool SocketAddr::operator==(const SocketAddr &to) const
{
	if (m_data_len != to.m_data_len)
	{
		return false;
	}
	if (!m_data)
	{
		return to.m_data == NULL;
	}
	if (!to.m_data)
	{
		return false;
	}
	return !memcmp(m_data,to.m_data,m_data_len);
}

bool SocketAddr::FromStringIPv4(string str)
{
	char buf[INET_ADDRSTRLEN + 8]; // ip address + space for port
	strncpy(buf, str.c_str(), sizeof(buf));
	buf[sizeof(buf)-1] = '\0'; // make sure null terminated
	char *port = strchr(buf,';');
	if (port == NULL)
	{
		return false;
	}
	*port='\0';
	port = port + 1;
	//buf is the IPv4 address, port is the port number
	sockaddr_in *pin = reinterpret_cast<sockaddr_in*>(m_data);
	if (inet_pton(PF_INET, buf, &(pin->sin_addr)) <= 0)
	{
		return false;
	}
	pin->sin_port=htons(atoi(port));
	return true;
}

bool SocketAddr::FromStringIPv4ToIPv6(string str)
{
	const char ipv6_ipv4_prefix[] = "::ffff:";
	char buf[INET6_ADDRSTRLEN + 8]; // ip address + space for port
	strncpy(buf, ipv6_ipv4_prefix, sizeof(ipv6_ipv4_prefix));
	int offset = sizeof(ipv6_ipv4_prefix) - 1;
	// converting v4 -> v6, set type
	if (!SetType(PF_INET6))
	{
		return false;
	}
	strncpy(buf+offset, str.c_str(), INET6_ADDRSTRLEN-offset);
	buf[sizeof(buf)-1] = '\0';  // make sure null terminated
	char *port = strchr(buf,';');
	if(port==NULL)
	{
		return false;
	}
	*port='\0';
	port=port+1;
	//buf is the converted IPv4 address, port is the port number
	sockaddr_in6 *pin6 = reinterpret_cast<sockaddr_in6*>(m_data);
	if(inet_pton(PF_INET6, buf, &(pin6->sin6_addr)) <= 0)
	{
		return false;
	}
	pin6->sin6_port=htons(atoi(port));
	return true;
}

bool SocketAddr::FromStringIPv6(string str)
{
	char buf[INET6_ADDRSTRLEN + 8]; // ip address + space for port
	strncpy(buf, str.c_str(), sizeof(buf));
	buf[sizeof(buf)-1] = '\0';  // make sure null terminated
	char *port = strchr(buf,';');
	if(port == NULL)
	{
		return false;
	}
	*port='\0';
	port=port+1;
	//buf is the IPv6 address, port is the port number
	sockaddr_in6 *pin6 = reinterpret_cast<sockaddr_in6*>(m_data);
	if(inet_pton(PF_INET6, buf, &(pin6->sin6_addr)) <= 0)
	{
		return false;
	}
	pin6->sin6_port=htons(atoi(port));
	return true;
}

bool SocketAddr::FromStringUnix(string str)
{
	sockaddr_un *pun = reinterpret_cast<sockaddr_un*>(m_data);
	if( str.is_empty() || str.get_length() >= UNIX_PATH_MAX )
		return false;
	strcpy(pun->sun_path,str.c_str());
	return true;
}

bool SocketAddr::SetFromString(string str)
{
	int type = SocketAddr::ExtractTypeFromString(str);
	if (!SetType(type))
	{
		return false;
	}

	switch (type)
	{
		case PF_INET:
			return CONVERT_IPV4_IPV6 ? FromStringIPv4ToIPv6(str) : FromStringIPv4(str);
		case PF_INET6:
			return FromStringIPv6(str);
		case PF_UNIX:
			return FromStringUnix(str);
		default:
			return false;
	}
}

string SocketAddr::ToStringIPv4(const sockaddr_in *pin, unsigned short portno_host_order)
{
	if (CONVERT_IPV4_IPV6)
	{
		sockaddr_in6 pin6;
		pin6.sin6_family = PF_INET6;
		// convert IPv4 address to ::ffff:aaaa.bbbb.ccccc.dddd
		pin6.sin6_addr.s6_addr32[3] = pin->sin_addr.s_addr;
		pin6.sin6_addr.s6_addr32[2] = 0xffff0000;
		pin6.sin6_addr.s6_addr32[1] = 0;
		pin6.sin6_addr.s6_addr32[0] = 0;
		return ToStringIPv6(&pin6, portno_host_order);
	}
	else
	{
		char buf[INET_ADDRSTRLEN];
		inet_ntop(PF_INET, &(pin->sin_addr), buf, INET_ADDRSTRLEN);
		return string::Format("INET;%s;%u", buf, portno_host_order);
	}
}

string SocketAddr::ToStringIPv4(uint32_t addr_net_order, unsigned short portno_host_order)
{
	if (CONVERT_IPV4_IPV6)
	{
		sockaddr_in6 pin6;
		pin6.sin6_family = PF_INET6;
		// convert IPv4 address to ::ffff:aaaa.bbbb.ccccc.dddd
		pin6.sin6_addr.s6_addr32[3] = addr_net_order;
		pin6.sin6_addr.s6_addr32[2] = 0xffff0000;
		pin6.sin6_addr.s6_addr32[1] = 0;
		pin6.sin6_addr.s6_addr32[0] = 0;
		return ToStringIPv6(&pin6, portno_host_order);
	}
	else
	{
		char buf[INET_ADDRSTRLEN];
		sockaddr_in pin;
		pin.sin_family = PF_INET;
		pin.sin_addr.s_addr = addr_net_order;
		inet_ntop(PF_INET, &(pin.sin_addr), buf, INET_ADDRSTRLEN);
		return string::Format("INET;%s;%u", buf, portno_host_order);
	}
}

string SocketAddr::ToStringIPv6(const sockaddr_in6 *pin6, unsigned short portno_host_order)
{
	char buf[INET6_ADDRSTRLEN];
	inet_ntop(PF_INET6, &(pin6->sin6_addr), buf, INET6_ADDRSTRLEN);
	return string::Format("INET6;%s;%u", buf, portno_host_order);
}

string SocketAddr::ToStringUnix(const sockaddr_un *pun)
{
	return string("UNIX;") + pun->sun_path;
}

string SocketAddr::PutToString() const
{
	switch (GetType())
	{
		case PF_INET:
		{
			const sockaddr_in *pin = reinterpret_cast<const sockaddr_in*>(m_data);
			return SocketAddr::ToStringIPv4(pin, ntohs(pin->sin_port));
		}
		case PF_INET6:
		{
			const sockaddr_in6 *pin6 = reinterpret_cast<const sockaddr_in6*>(m_data);
			return SocketAddr::ToStringIPv6(pin6, ntohs(pin6->sin6_port));
		}
		case PF_UNIX:
		{
			return SocketAddr::ToStringUnix(reinterpret_cast<const sockaddr_un*>(m_data));
		}
		default :
			return "";
	}
}

string SocketAddr::PutToString(uint32_t addr_net_order, unsigned short portno_host_order)
{
	return ToStringIPv4(addr_net_order, portno_host_order);
}

string SocketAddr::PutToString(const SocketAddr &sock_addr, unsigned short portno_host_order)
{
	switch (sock_addr.GetType())
	{
		case PF_INET:
		{
			const sockaddr_in *pin = reinterpret_cast<const sockaddr_in*>(sock_addr.m_data);
			return SocketAddr::ToStringIPv4(pin, portno_host_order);
		}
		case PF_INET6:
		{
			const sockaddr_in6 *pin6 = reinterpret_cast<const sockaddr_in6*>(sock_addr.m_data);
			return SocketAddr::ToStringIPv6(pin6, portno_host_order);
		}
		case PF_UNIX:
		{
			return SocketAddr::ToStringUnix(reinterpret_cast<const sockaddr_un*>(sock_addr.m_data));
		}
		default:
			return "";
	}
}

bool SocketAddr::GetAddrString(string AddrPort, string &AddrOnly)
{
	SocketAddr sock_addr;
	if (!sock_addr.SetFromString(AddrPort))
	{
		return false;
	}
	switch (sock_addr.GetType())
	{
		case PF_UNIX:
		{
			sockaddr_un *pun = reinterpret_cast<sockaddr_un*>(sock_addr.m_data);
			AddrOnly = pun->sun_path;
			break;
		}
		case PF_INET:
		case PF_INET6:
		{
			AddrOnly = sock_addr.GetIpString();
			break;
		}
		default:
			return false;
	}
	return true;
}

string SocketAddr::PutToString(const SocketAddr &sock_addr)
{
	return sock_addr.PutToString();
}

string SocketAddr::PutToString(const sockaddr * sock_addr, unsigned short portno_host_order)
{
	if (sock_addr == NULL)
	{
		return "";
	}

	switch (sock_addr->sa_family)
	{
		case PF_INET:
		{
			const sockaddr_in *pin = reinterpret_cast<const sockaddr_in*>(sock_addr);
			return SocketAddr::ToStringIPv4(pin, portno_host_order);
		}
		case PF_INET6:
		{
			const sockaddr_in6 *pin6 = reinterpret_cast<const sockaddr_in6*>(sock_addr);
			return SocketAddr::ToStringIPv6(pin6, portno_host_order);
		}
		case PF_UNIX:
		{
			return SocketAddr::ToStringUnix(reinterpret_cast<const sockaddr_un*>(sock_addr));
		}
	}
	return "";
}

string SocketAddr::PutToString(const sockaddr * sock_addr)
{
	if (sock_addr == NULL)
	{
		return "";
	}

	switch(sock_addr->sa_family)
	{

		case PF_INET:
		{
			const sockaddr_in *pin = reinterpret_cast<const sockaddr_in*>(sock_addr);
			return SocketAddr::ToStringIPv4(pin, ntohs(pin->sin_port));
		}
		case PF_INET6:
		{
			const sockaddr_in6 *pin6 = reinterpret_cast<const sockaddr_in6*>(sock_addr);
			return SocketAddr::ToStringIPv6(pin6, ntohs(pin6->sin6_port));
		}
		case PF_UNIX:
		{
			return SocketAddr::ToStringUnix(reinterpret_cast<const sockaddr_un*>(sock_addr));
		}
	}
	return "";
}

string SocketAddr::PutToString(string ip_addr, unsigned short port)
{
	struct addrinfo *res;
	struct addrinfo hints;
	memset(&hints, '\0', sizeof(hints));
	hints.ai_flags = AI_NUMERICHOST;
	int e = getaddrinfo(ip_addr.c_str(), NULL, &hints, &res);
	if (e != 0)
	{
		// not a valid IP address
		return "";
	}

	string result;
	switch(res->ai_family)
	{
		case PF_INET:
			result = CONVERT_IPV4_IPV6 ? string::Format("INET6;::ffff:%s;%u", ip_addr.c_str(), port) : string::Format("INET;%s;%u", ip_addr.c_str(), port);
			break;
		case PF_INET6:
			result=string::Format("INET6;%s;%u", ip_addr.c_str(), port);
			break;
	}

	freeaddrinfo(res);

	return result;
}

bool SocketAddr::SetToIPv4AddrPort(uint32_t addr_net_byte_order, unsigned short portno_host_byte_order)
{
	if (!SetType(PF_INET))
	{
		return false;
	}
	sockaddr_in *pin = reinterpret_cast<sockaddr_in*>(m_data);
	memset(reinterpret_cast<char*>(pin)+sizeof(sa_family_t), 0, sizeof(sockaddr_in)-sizeof(sa_family_t));
	pin->sin_addr.s_addr = addr_net_byte_order;
	pin->sin_port = htons(portno_host_byte_order);
	return true;
}

bool SocketAddr::SetTo(const SocketAddr &sock_addr)
{
	bool ret = false;

	if (sock_addr.m_data && SetType(sock_addr.GetType()))
	{
		memcpy(m_data,sock_addr.m_data,std::min(m_data_len, sock_addr.m_data_len));
		ret = true;
	}
	return ret;
}

bool SocketAddr::SetTo(const SocketAddr &sock_addr, unsigned short portno_host_order)
{
	if(!SetTo(sock_addr))
		return false;

	unsigned short t_port=htons(portno_host_order); // net byte order
	switch(sock_addr.GetType())
	{
		case PF_INET6:
			reinterpret_cast<sockaddr_in6*>(m_data)->sin6_port = t_port;
			break;
		case PF_INET:
			reinterpret_cast<sockaddr_in*>(m_data)->sin_port = t_port;
			break;
		default:
			return false;
	}

	return true;
}

bool SocketAddr::SetTo(const sockaddr *sock_addr, socklen_t len)
{
	bool ret = false;

	if (sock_addr && SetType(sock_addr->sa_family))
	{
		memcpy(m_data, sock_addr, std::min(m_data_len, len));
		ret = true;
	}
	return ret;
}

bool SocketAddr::SetTo(sockaddr *sock_addr, socklen_t len, unsigned short portno_host_order)
{
	if(!SetTo(sock_addr,len))
	{
		return false;
	}

	unsigned short t_port=htons(portno_host_order); // net byte order
	switch(sock_addr->sa_family)
	{
		case PF_INET6:
			reinterpret_cast<sockaddr_in6*>(m_data)->sin6_port = t_port;
			break;
		case PF_INET:
			reinterpret_cast<sockaddr_in*>(m_data)->sin_port = t_port;
			break;
		default:
			return false;
	}

	return true;
}

bool SocketAddr::SetType( int type )
{
	if( GetType() == type )
		return true;

	Clear();
	return alloc_of_type(this,type);
}

int SocketAddr::ExtractTypeFromString( string &str )
{
	const char *pch = str.c_str();
	if( !pch || !pch[0] )
		return PF_UNSPEC;

	if( 0 == strncmp(pch,"INET;",5) )
	{
		str = pch+5;
		return PF_INET;
	}
	else if( 0 == strncmp(pch,"INET6;",6) )
	{
		str = pch+6;
		return PF_INET6;
	}
	else if( 0 == strncmp(pch,"UNIX;",5) )
	{
		str = pch+5;
		return PF_UNIX;
	}

	return PF_UNSPEC;
}

bool SocketAddr::IsTypeFormat(string str)
{
	string tmp(str);
	return (ExtractTypeFromString(tmp) != PF_UNSPEC);
}

int SocketAddr::GetPortFromString(const char* str)
{
	int port = -1;
	const char* end_type = strstr(str, ";");
	if (end_type != NULL)
	{
		const char* port_start = strstr(++end_type, ";");
		if (port_start != NULL)
		{
			port = atoi(++port_start);
		}
	}
	return port;
}

bool SocketAddr::IsMulticastAddress() const
{
	switch(GetType())
	{
		case PF_INET:
		{
			uint32_t address = reinterpret_cast<const sockaddr_in*>(m_data)->sin_addr.s_addr;
			return ((ntohl(address) & 0xF0000000ul) == 0xE0000000ul);
		}
		case PF_INET6:
			return IN6_IS_ADDR_MULTICAST(&(reinterpret_cast<const sockaddr_in6*>(m_data)->sin6_addr));
	}
	return false;
}

bool SocketAddr::JoinMulticastGroup(int fd, string multicast_interface)
{
	ip_mreqn membership;
	ipv6_mreq mcast_request;
	char *mem_obj = NULL;
	socklen_t mem_obj_size = 0;
	int level = 0;
	int mcast_add_opt = 0;
	int mcast_if_opt = 0;

	// make sure this socket_addr is a multicast address
	if (!IsMulticastAddress())
	{
		return false;
	}

	switch (GetType())
	{
		case PF_INET:
			memset(&membership, 0, sizeof(ip_mreqn));
			membership.imr_multiaddr.s_addr = reinterpret_cast<sockaddr_in*>(m_data)->sin_addr.s_addr;
			mem_obj = reinterpret_cast<char *>(&membership);
			mem_obj_size = sizeof(membership);
			level = IPPROTO_IP;
			mcast_add_opt = IP_ADD_MEMBERSHIP;
			mcast_if_opt = IP_MULTICAST_IF;
			break;
		case PF_INET6:
			memset(&mcast_request, 0, sizeof(mcast_request));
			memcpy(&mcast_request.ipv6mr_multiaddr, &(reinterpret_cast<struct sockaddr_in6*>(m_data)->sin6_addr), sizeof(mcast_request.ipv6mr_multiaddr));
			mem_obj = reinterpret_cast<char *>(&mcast_request);
			mem_obj_size = sizeof(mcast_request);
			level = IPPROTO_IPV6;
			mcast_add_opt = IPV6_JOIN_GROUP;
			mcast_if_opt = IPV6_MULTICAST_IF;
			break;
		default:
			return false;
	}
	if( multicast_interface.is_empty() )
	{
		//default == try to join on all interfaces
		struct if_nameindex *ifs = if_nameindex();

		if(ifs == 0)
		{
			TRACE("SocketAddr::JoinMulticastGroup - no interfaces!\n");
			return false;
		}

		bool pass_1 = false;
		for( size_t at =0; ifs[at].if_index != 0; ++at )
		{
			membership.imr_ifindex = ifs[at].if_index;
			if( 0 != setsockopt(fd, level, mcast_add_opt, mem_obj, mem_obj_size) )
			{
				TRACE("SocketAddr::JoinMulticastGroup - failed to join on interface %zu \"%s\": %s\n",
						at,
						ifs[at].if_name,
						strerror(errno) );
				//return false;
				//dont quit yet, keep going
			}
			else
			{
				pass_1 = true;
			}
		}
		if_freenameindex(ifs);

		return pass_1;
	}
	else
	{
		//join only on specific interface:
		membership.imr_ifindex = if_nametoindex(multicast_interface.c_str());
		if( 0 == membership.imr_ifindex )
		{
			TRACE("SocketAddr::JoinMulticastGroup - failed to join, no such interface: \"%s\"\n",
					multicast_interface.c_str() );
		}

		if( 0 != setsockopt(fd, level, mcast_add_opt, mem_obj, mem_obj_size) )
		{
			TRACE("SocketAddr::JoinMulticastGroup - failed to join on interface %d \"%s\": %s\n",
					membership.imr_ifindex,
					multicast_interface.c_str(),
					strerror(errno));
			return false;
		}

		if( 0 != setsockopt(fd, level, mcast_if_opt, mem_obj, mem_obj_size) )
			return false;
	}
	return true;
}

bool SocketAddr::SetMulticastTransmitInterface(int fd, string multicast_interface)
{
	// make sure this socket_addr is a multicast address
	if (!IsMulticastAddress())
	{
		return false;
	}

	ip_mreqn membership;
	ipv6_mreq mcast_request;
	char *mem_obj = NULL;
	socklen_t mem_obj_size = 0;
	int level = 0;
	int mcast_if_opt = 0;

	// Currently handle IPv4/6
	switch (GetType())
	{
		case PF_INET:
			memset(&membership, 0, sizeof(ip_mreqn));
			membership.imr_multiaddr.s_addr = reinterpret_cast<sockaddr_in*>(m_data)->sin_addr.s_addr;
			mem_obj = reinterpret_cast<char *>(&membership);
			mem_obj_size = sizeof(membership);
			level = IPPROTO_IP;
			mcast_if_opt = IP_MULTICAST_IF;
			break;
		case PF_INET6:
			memset(&mcast_request, 0, sizeof(mcast_request));
			memcpy(&mcast_request.ipv6mr_multiaddr, &(reinterpret_cast<struct sockaddr_in6*>(m_data)->sin6_addr), sizeof(mcast_request.ipv6mr_multiaddr));
			mem_obj = reinterpret_cast<char *>(&mcast_request);
			mem_obj_size = sizeof(mcast_request);
			level = IPPROTO_IPV6;
			mcast_if_opt = IPV6_MULTICAST_IF;
			break;
		default:
			TRACE("Unable to set multicast intf for unknown protocol family %d\n", GetType());
			return false;
	}

	if (multicast_interface.is_empty())
	{
		membership.imr_ifindex = 0;
	}
	else
	{
		//join only on specific interface:
		membership.imr_ifindex = if_nametoindex(multicast_interface.c_str());
		if (0 == membership.imr_ifindex)
		{
			TRACE("SocketAddr::SetMulticastTransmitInterface - no such interface %s!\n", multicast_interface.c_str() );
			return false;
		}
	}

	if (0 != setsockopt(fd, level, mcast_if_opt, mem_obj, mem_obj_size))
	{
		TRACE("Unable to set multicast intf: %s (fd: %d, level: %d, opt %d)\n", strerror(errno), fd, level, mcast_if_opt);
		return false;
	}
	return true;
}


bool SocketAddr::GetIPv4AddrPort(uint32_t &addr_net_byte_order, unsigned short &portno_host_byte_order)
{
	if ( GetType() != PF_INET )
	{
		return false;
	}
	sockaddr_in *pin = reinterpret_cast<sockaddr_in*>(m_data);
	addr_net_byte_order = pin->sin_addr.s_addr;
	portno_host_byte_order = ntohs(pin->sin_port);
	return true;
}

bool SocketAddr::GetIPv4AddrPortFromString(const char* str, uint32_t& addr_net, uint16_t& port_host)
{
	char buf[INET_ADDRSTRLEN + 8 + 8]; // ip address + space for port + type
	strncpy(buf, str, sizeof(buf));
	buf[sizeof(buf)-1] = '\0'; // make sure null terminated
	// verify v4
	if (strncmp(buf, "INET", 4) != 0)
	{
		return false;
	}
	char* ip = strchr(buf,';');
	if (NULL == ip)
	{
		return false;
	}
	++ip;
	char* port = strchr(ip,';'); // skip past IP
	if (NULL == port)
	{
		return false;
	}
	*port='\0';
	++port;
	//ip is the IPv4 address, port is the port number
	struct in_addr v4_addr;
	if (inet_pton(PF_INET, ip, &v4_addr) <= 0)
	{
		return false;
	}
	addr_net = v4_addr.s_addr;
	port_host = atoi(port);
	return true;
}

string SocketAddr::GetInterfaceName()
{
	//TODO: Support IPV6
	//currently this function just support IPv4 address
	string res;
	if ( GetType() != PF_INET )
	{
		return res;
	}

	//create a temporary socket for query
	int skfd = socket(PF_INET, SOCK_DGRAM, 0);
	if (0 >= skfd)
	{
		return res;
	}

	//get ethernet interface list
	struct if_nameindex* if_list = if_nameindex();
	if ( if_list )
	{
		struct if_nameindex* list_ptr = if_list;
		bool found = false;
		while ( !found && if_list && (0 != if_list->if_index) )
		{
			//get interface address
			struct ifreq ifr;
			strncpy(ifr.ifr_name, if_list->if_name, sizeof(ifr.ifr_name));
			if ( 0 == ioctl(skfd, SIOCGIFADDR, &ifr) )
			{
				sockaddr_in* inet_addr = reinterpret_cast<sockaddr_in*>(&ifr.ifr_addr);
				if ( inet_addr->sin_addr.s_addr == reinterpret_cast<sockaddr_in*>(m_data)->sin_addr.s_addr )
				{
					found = true;
					res = if_list->if_name;
				}
			}
			++if_list;
		}
		if_freenameindex(list_ptr);
	}
	close(skfd);

	return res;
}

void SocketAddr::SetAnyAddress(unsigned short portno_host_order)
{
	switch (GetType())
	{
		case PF_INET:
		{
			sockaddr_in *pin = reinterpret_cast<sockaddr_in*>(m_data);
			pin->sin_addr.s_addr = INADDR_ANY;
			pin->sin_port = htons(portno_host_order);
			break;
		}
		case PF_INET6:
		{
			sockaddr_in6 *pin6 = reinterpret_cast<sockaddr_in6*>(m_data);
			pin6->sin6_addr = in6addr_any;
			pin6->sin6_port = htons(portno_host_order);
			break;
		}
		default:
			break;
	}
}

string SocketAddr::FormatIPv4AddrPort(uint32_t addr_net_order, unsigned short portno_host_order)
{
	return PutToString(addr_net_order, portno_host_order);
}

string SocketAddr::GetAddrAny(unsigned short portno_host_order)
{
	// assume the kernel support: IPv4 only, or IPv6 only, or both IPv4&6
	// if IPV6 is supported by the kernel, then IPv6 precdeds IPv4
	// otherwise, IPv4 address will be returned
	string result;
#if defined(__ARMEB__) || defined(__PPC__)
	// for now, force ixp and ppc to v4
	result=string::Format("INET;0.0.0.0;%u", portno_host_order);
#else
	string ipv6_addr_any="::";


	struct addrinfo *res;
	struct addrinfo hints;
	memset(&hints, '\0', sizeof(hints));
	hints.ai_flags = AI_NUMERICHOST | AI_ADDRCONFIG;
	int e = getaddrinfo(ipv6_addr_any.c_str(), NULL, &hints, &res);
	if (e != 0)
	{
		// does not support IPv6
		result=string::Format("INET;0.0.0.0;%u", portno_host_order);
	}
	else
	{
		freeaddrinfo(res);
		// suport IPv6
		result=string::Format("INET6;::;%u", portno_host_order);
	}
#endif

	return result;
}

string SocketAddr::GetAddrLoopBack(unsigned short portno_host_order)
{
	// assume the kernel support: IPv4 only, or IPv6 only, or both IPv4&6
	// if IPV6 is supported by the kernel, then IPv6 precdeds IPv4
	// otherwise, IPv4 address will be returned
	string result;
/*
#ifdef __ARMEB__
	//phoenix platform, the linux kernel always support IPv6
	result=string::Format("INET6;::1;%u", portno_host_order);
#else
	string ipv6_addr_any="::1";


	struct addrinfo *res;
	struct addrinfo hints;
	memset(&hints, '\0', sizeof(hints));
	hints.ai_flags = AI_NUMERICHOST | AI_ADDRCONFIG;
	int e = getaddrinfo(ipv6_addr_any.c_str(), NULL, &hints, &res);
	if (e != 0)
	{
		// does not support IPv6
		result=string::Format("INET;127.0.0.1;%u", portno_host_order);
	}
	else
	{
		freeaddrinfo(res);
		// suport IPv6
		result=string::Format("INET6;::1;%u", portno_host_order);
	}
#endif
*/
    // currently, the "telnet" in falcon does not support IPv6
    // always use IPv4 loopback. It doesn't matter if telnet locally.
	result=string::Format("INET;127.0.0.1;%u", portno_host_order);

	return result;
}

bool SocketAddr::IsAddrLoopBack() const
{
	bool is_loopback = false;
	switch(GetType())
	{
		case PF_INET:
		{
			sockaddr_in *pin = reinterpret_cast<sockaddr_in*>(m_data);
			is_loopback = pin->sin_addr.s_addr == htonl(INADDR_LOOPBACK);
			break;
		}
		case PF_INET6:
		{
			sockaddr_in6 *pin6 = reinterpret_cast<sockaddr_in6*>(m_data);
			if (IN6_IS_ADDR_LOOPBACK(&(pin6->sin6_addr)))
			{
				is_loopback = true;
			}
			else if (IN6_IS_ADDR_V4MAPPED(&(pin6->sin6_addr)))
			{
				//::ffff:127.0.0.1
				uint32_t* a = reinterpret_cast<uint32_t*>(&pin6->sin6_addr);
				is_loopback = a[3] == htonl(INADDR_LOOPBACK);
			}
			break;
		}
	}
	return is_loopback;
}

string SocketAddr::GetIpString() const
{
	const char *res = NULL;
	int type = GetType();
	switch (type)
	{
		case PF_INET:
		{
			char ip_dst[INET_ADDRSTRLEN];
			sockaddr_in *pin = reinterpret_cast<sockaddr_in*>(m_data);
			res = inet_ntop(type, &pin->sin_addr, ip_dst, sizeof(ip_dst));
			break;
		}
		case PF_INET6:
		{
			char ip_dst[INET6_ADDRSTRLEN];
			sockaddr_in6 *pin6 = reinterpret_cast<sockaddr_in6*>(m_data);
			res = inet_ntop(type, &pin6->sin6_addr, ip_dst, sizeof(ip_dst));
			break;
		}
	}
	string ip_string(res);
	return ip_string;
}

uint16_t SocketAddr::GetPort() const
{
	uint16_t port = 0;
	switch (GetType())
	{
		case PF_INET:
		{
			sockaddr_in *pin = reinterpret_cast<sockaddr_in*>(m_data);
			port = pin->sin_port;
			break;
		}
		case PF_INET6:
		{
			sockaddr_in6 *pin6 = reinterpret_cast<sockaddr_in6*>(m_data);
			port = pin6->sin6_port;
			break;
		}
	}
	return port;
}

void SocketAddr::SetPort(uint16_t port_host_order)
{
	switch (GetType())
	{
		case PF_INET:
		{
			sockaddr_in *pin = reinterpret_cast<sockaddr_in*>(m_data);
			pin->sin_port = htons(port_host_order);
			break;
		}
		case PF_INET6:
		{
			sockaddr_in6 *pin6 = reinterpret_cast<sockaddr_in6*>(m_data);
			pin6->sin6_port = htons(port_host_order);
			break;
		}
	}
}

// TODO: replace with something more generic
uint32_t SocketAddr::GetIPv4Addr() const
{
	if (GetType() != PF_INET)
	{
		return 0xFFFFFFFF;
	}
	sockaddr_in *pin = reinterpret_cast<sockaddr_in*>(m_data);
	return pin->sin_addr.s_addr;
}

}
