#if !defined(__SOCKET_BUFFER_POOL_H__)
#define __SOCKET_BUFFER_POOL_H__

#include<utils/buffer_pool.h>
#include<socket/socket_buffer.h>

namespace colib
{

class Writable;

class SocketBufferPool : public BufferPool<SocketBuffer>
{
public:
	static SocketBufferPool& GetInstance();
	bool Init(int amount);
	virtual ~SocketBufferPool() { }

	void ConsoleCommand(Writable* con, int argc, char* argv[]);

private:
	bool m_initialized;
	SocketBufferPool();
};

}

#endif
