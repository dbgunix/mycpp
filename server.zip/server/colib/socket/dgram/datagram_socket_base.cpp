#include<socket/dgram/datagram_socket_base.h>
#include<socket/socket_buffer_pool.h>
#include<utils/trace/trace.h>
#include<event_loop/event_loop.h>

#include <errno.h>
#include <fcntl.h>
#include <sys/un.h>
#include <unistd.h>

namespace colib
{

static ValueList::ValueHolder InitStats()
{
	return
	{
		Value("rx_bytes", 0),
		Value("tx_bytes", 0),
		Value("rx_datagrams", 0),
		Value("tx_datagrams", 0)
	};
};

/** DatagramSocketBase ctor
 * \param[in] name Name of the socket
 */
DatagramSocketBase::DatagramSocketBase(string name)
	: DatagramSocketConfig(name)
	, m_rx_buf()
	, m_tx_queue()
	, m_buf_pool(SocketBufferPool::GetInstance())
	, m_on_read()
	, m_max_queue_depth(DEFAULT_MAX_QUEUE_DEPTH)
	, m_stats(InitStats())
{
}

/// DatagramSocketBase dtor
DatagramSocketBase::~DatagramSocketBase()
{
	ReturnTxQueue();
}

bool DatagramSocketBase::JoinMulticastGroup(string multicast_addr, string multicast_intf)
{
	bool res = false;
	SocketAddr mcast_sock_addr;
	if (mcast_sock_addr.SetFromString(multicast_addr) && mcast_sock_addr.IsMulticastAddress())
	{
		res = mcast_sock_addr.JoinMulticastGroup(m_fd, multicast_intf);
	}
	return res;
}

bool DatagramSocketBase::SetMulticastTTL(int ttl, string& err)
{
	bool ret = 0 == setsockopt(m_fd, IPPROTO_IP, IP_MULTICAST_TTL, &ttl, sizeof(ttl));
	if (!ret)
	{
		err.AppendFmt("Failed to set multicast TTL to %d (fd: %d): %s\n", ttl, m_fd, strerror(errno));
	}
	return ret;
}

/// Update the event loop write flag based on tx queue
void DatagramSocketBase::UpdateFlag()
{
	if (m_tx_queue.empty())
	{
		RemoveFlag(FileDescriptorHandler::WRITE_NOTIFY_FLAG);
	}
	else
	{
		AddFlag(FileDescriptorHandler::WRITE_NOTIFY_FLAG);
	}
}

/// Return all buffers in Tx queue to the buffer pool
void DatagramSocketBase::ReturnTxQueue()
{
	// return tx queue to pool
	for (auto it(m_tx_queue.begin()); it != m_tx_queue.end(); ++it)
	{
		m_buf_pool.Return(*it);
	}
	m_tx_queue.clear();
}

/** Read bytes from receive buffer
 * \param[out] buf Buffer to copy bytes into
 * \param[in] len Length of \a buf
 * \return Number of bytes read
 */
int DatagramSocketBase::ReadBytes(char *buf, int len)
{
	if (len <= 0 || NULL == buf)
	{
		return -1;
	}
	int bytes = std::min(m_rx_buf.GetLength(), static_cast<uint32_t>(len));
	memcpy(buf, m_rx_buf.GetData(), bytes);
	m_rx_buf.Reset(); // TODO: assumes caller got all the data they wanted
	return bytes;
}

/** Read receive buffer
 * \return The single Socketbuffer in the receive queue
 */
SocketBuffer* DatagramSocketBase::ReadBuf()
{
	return &m_rx_buf;
}

/// Perform a syscall read from the socket (fd)
void DatagramSocketBase::read()
{
	int n = recvfrom(m_fd, m_rx_buf.GetData(), m_rx_buf.MaxLength(), 0, m_rx_buf.GetSocketAddr().m_data, &m_rx_buf.GetSocketAddr().m_data_len);
	if (n > 0)
	{
		++DGRAMSTAT(rx_datagrams);
		DGRAMSTAT(rx_bytes) += n;
		member_TRACE(&m_trace_set, 5, "%s::read - %d bytes\n", m_name.c_str(), n);
		m_rx_buf.SetLength(n);
		m_on_read.Dispatch(&m_rx_buf);
		// TODO: reset here?
	}
}

/// Close and cleanup the socket
void DatagramSocketBase::Close()
{
	m_retry_timer.Stop();
	CloseSocket();
	m_max_queue_depth = DEFAULT_MAX_QUEUE_DEPTH;
	m_connected = false; // unnecessary, but harmless when connectionless
	ReturnTxQueue();
}

/// Add a socketbuffer to the tx queue
void DatagramSocketBase::QueueBuffer(SocketBuffer *buf)
{
	m_tx_queue.push_back(buf);
	AddFlag(FileDescriptorHandler::WRITE_NOTIFY_FLAG);
}

}
