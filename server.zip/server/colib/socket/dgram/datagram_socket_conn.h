#if !defined(__DATAGRAM_SOCKET_H__)
#define __DATAGRAM_SOCKET_H__

#include<utils/string.h>
#include<socket/dgram/datagram_socket_base.h>
#include<utils/callback.h>

namespace colib
{

class Message;

class DatagramSocketConn : public DatagramSocketBase
{
public:
	DatagramSocketConn(string name);
	virtual ~DatagramSocketConn() { }

	bool Init(string connect_addr, string local_addr, string multicast_intf);
	bool BindToDevice(string &status);

	bool WriteBytes(const char *buf, int len);
	bool WriteBuf(SocketBuffer *buf);
	bool WriteMessage(Message &msg);

	void SetDisconnectedCallback(const Callback1<DatagramSocketConn*> &disc_cb) { m_on_peer_disconnected = disc_cb; }

	void ConsoleCommand(Writable *to, int argc, char *argv[]);

private:
	virtual void write();

	/// callback to trigger if peer disconnects
	Callback1<DatagramSocketConn*> m_on_peer_disconnected;
};

}

#endif
