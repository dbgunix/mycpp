#include<socket/dgram/datagram_socket_connless.h>
#include<socket/socket_buffer.h>
#include<socket/socket_buffer_pool.h>
#include<utils/trace/trace.h>
#include<message/message.h>
#include<console/command/debug.h>

#include <errno.h>

namespace colib
{

/** DatagramSocketConnless ctor
 * \param[in] name Name of the socket
 */
DatagramSocketConnless::DatagramSocketConnless(string name)
	: DatagramSocketBase(name)
{
}

/** Perform all initialization steps for a datagram socket
 * \param[in] local_addr String with the local address (optional)
 * \param[in] multicast_interface String with the multicast interface (optional)
 * \return True if initialization succeeded, false if not
 */
bool DatagramSocketConnless::Init(string local_addr, string multicast_interface)
{
	Close();
	int type = PF_UNSPEC;

	if (!ConfigureBindAddr(type, local_addr))
	{
		return false;
	}

	// if type is PF_UNSPEC at this point then no local addr provided
	// for now, use default PF of PF_INET
	if (type == PF_UNSPEC)
	{
		type = PF_INET;
	}

	if (!SetupSocket(type))
	{
		return false;
	}

	if (m_local_addr.GetType() != PF_UNSPEC && !BindSocket(multicast_interface))
	{
		return false;
	}
	if (!m_rx_buf.GetSocketAddr().SetType(type))
	{
		return false;
	}

	return RegisterWithEventLoop();
}

/** Write bytes to the socket
 * \param[in] buf Bytes to write
 * \param[in] len Length of \a buf
 * \param[in] toaddr Socket address of destination
 * \param[in] addr_len Length of \a toaddr
 * \return True if \a len bytes were written, false if not
 * \note This is an all-or-nothing write
 */
bool DatagramSocketConnless::WriteBytes(const char *buf, int len, const sockaddr *toaddr, socklen_t addr_len)
{
	if (len <= 0 || !SafeToWriteBuf())
	{
		return false;
	}

	bool ret = false;
	SocketBuffer *tx_buf = m_buf_pool.Get();
	if (tx_buf)
	{
		if (tx_buf->SetBuf(buf, len) == len)
		{
			if (tx_buf->GetSocketAddr().SetTo(toaddr, addr_len))
			{
				QueueBuffer(tx_buf);
				ret = true;
			}
			else
			{
				m_buf_pool.Return(tx_buf);
				m_trace_set.Trace(0, "%s::%s invalid sendto addr (%p)\n", GetName().c_str(), __func__, toaddr);
			}
		}
		else
		{
			m_buf_pool.Return(tx_buf);
			m_trace_set.Trace(0, "%s::%s failed to copy buffer (%p, %d)\n", GetName().c_str(), __func__, buf, len);
		}
	}
	return ret;
}

/** Write a Socketbuffer to the socket
 * \param[in] buf SocketBuffer to write
 * \param[in] toaddr Socket address of destination
 * \param[in] addr_len Length of \a toaddr
 * \return True if the write succeeded, false if not
 */
bool DatagramSocketConnless::WriteBuf(SocketBuffer *buf, const sockaddr *toaddr, socklen_t addr_len)
{
	bool ret = false;
	if (buf && SafeToWriteBuf())
	{
		if (buf->GetSocketAddr().SetTo(toaddr, addr_len))
		{
			QueueBuffer(buf);
			ret = true;
		}
		else
		{
			m_trace_set.Trace(0, "%s::%s invalid sendto addr (%p)\n", GetName().c_str(), __func__, toaddr);
		}
	}
	return ret;
}

/** Write a Message to the socket
 * \param[in] msg Message to write
 * \param[in] toaddr Socket address of destination
 * \param[in] addr_len Length of \a toaddr
 * \return True if the write succeeded, false if not
 */
bool DatagramSocketConnless::WriteMessage(Message& msg, const sockaddr* toaddr, socklen_t addr_len)
{
	bool ret = false;
	if (SafeToWriteBuf())
	{
		SocketBuffer *sbuf = m_buf_pool.Get();
		if (sbuf)
		{
			if (sbuf->GetSocketAddr().SetTo(toaddr, addr_len))
			{
				unsigned int len = sbuf->MaxLength();
				if (msg.Encode(sbuf->GetData(), &len))
				{
					sbuf->SetLength(len);
					QueueBuffer(sbuf);
					ret = true;
				}
				else
				{
					m_trace_set.Trace(0, "%s::%s failed to encode msg %d\n", GetName().c_str(), __func__, msg.GetType());
					m_buf_pool.Return(sbuf);
				}
			}
			else
			{
				m_buf_pool.Return(sbuf);
				m_trace_set.Trace(0, "%s::%s invalid sendto addr (%p)\n", GetName().c_str(), __func__, toaddr);
			}
		}
	}
	return ret;
}

/// Perform a syscall write to the socket
void DatagramSocketConnless::write()
{
	// write should not get called if the tx queue is empty
	// in case it does, turn off write events and return
	if (m_tx_queue.empty())
	{
		RemoveFlag(FileDescriptorHandler::WRITE_NOTIFY_FLAG);
		return;
	}

	SocketBuffer *tx_buf = *m_tx_queue.begin();

	int n = sendto(m_fd, tx_buf->GetData(), tx_buf->GetLength(), 0, tx_buf->GetSocketAddr().m_data, tx_buf->GetSocketAddr().m_data_len);

	if (n < 0)
	{
		if (errno == EAGAIN)
		{
			member_TRACE(&m_trace_set, 5, "(%s)::%s (%d bytes) - EAGAIN\n", GetName().c_str(), __FUNCTION__, tx_buf->GetLength());
			RemoveFlag(FileDescriptorHandler::WRITE_NOTIFY_FLAG);
			m_retry_timer.Start(DGRAM_RETRY_TIMEOUT);
			return;
		}
		else
		{
			member_TRACE(&m_trace_set, 2, "(%s)::%s sendto failed: %d (%s)\n", GetName().c_str(), __FUNCTION__, errno, strerror(errno));
		}
	}
	else if (n > 0)
	{
		++DGRAMSTAT(tx_datagrams);
		DGRAMSTAT(tx_bytes) += n;
		member_TRACE(&m_trace_set, 8, "%s wrote %d bytes\n", GetName().c_str(), n);
	}
	// release buf
	m_buf_pool.Return(tx_buf);
	m_tx_queue.pop_front();
	member_TRACE(&m_trace_set, 6, "%s::%s - queue @ %zu\n", GetName().c_str(), __FUNCTION__, m_tx_queue.size());
	UpdateFlag();
}

/** Process a DatagramSocketConnless console command
 * \param[in] to Writable to use for output
 * \param[in] argc Number of arguments
 * \param[in] argv Array of arguments
 */
void DatagramSocketConnless::ConsoleCommand(Writable *to, int argc, char *argv[])
{
	const char *usage = "Usage: status | stats | debug\n";
	if (!to)
	{
		return;
	}

	if (argc < 1)
	{
		to->PrintString(usage);
	}
	else if (!strcmp(argv[0], "status"))
	{
		to->Print("Name: %s\nLocal Address: %s\nForeign Address: N/A (no connection)\n", m_name.c_str(), m_local_addr.PutToString().c_str());
	}
	else if (!strcmp(argv[0], "stats"))
	{
		m_stats.ConsoleCommand(to, argc-1, argv+1);
	}
	else if (!strcmp(argv[0], "debug"))
	{
		HandleDebugCommand(to, argc-1, argv+1, m_trace_set, m_name.c_str());
	}
	else
	{
		to->PrintString(usage);
	}
}

}
