#include <event_loop/event_loop.h>
#include <socket/socket_buffer_pool.h>
#include <utils/trace/stdio_writable.h>
#include <options/file_options.h>
#include <socket/stream/console/console.h>
#include <console/manager.h>
#include <socket/dgram/unit_test/dgram_test.h>

#include <signal.h>
#include <stdio.h>

static void sigterm_handler(int signum)
{
        (void)signum;
        static bool called = false;

        if (called) abort();

        colib::EventLoop::GetInstance().Terminate(called = true);
}

int main()
{
	signal(SIGTERM, sigterm_handler);
	signal(SIGINT, sigterm_handler);

	// initialize the socket buffer pool
	colib::SocketBufferPool::GetInstance().Init(50);
	// initialize the event loop
	if (!colib::EventLoop::GetInstance().Initialize())
	{
		fprintf(stderr, "Failed to init event loop\n");
		return 1;
	}

	// create process console on port 30000
	colib::GlobalTelnetConsoleServer::GetInstance().Init("INET;127.0.0.1;30000");
	colib::ConsoleManager::GetInstance().SetName("DgramUnitTest");

	// create writable for testing/debug output
	colib::StdioWritable out(stdout);
	// create unit test
	colib::DgramUnitTest dgram_tester;
	dgram_tester.AddWritable(9, &out);
	if (!dgram_tester.Init())
	{
		fprintf(stderr, "Failed to init unit test\n");
		return 1;
	}

	colib::EventLoop::GetInstance().Main();
	return 0;
}
