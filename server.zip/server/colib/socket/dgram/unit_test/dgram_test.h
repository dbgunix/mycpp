#if !defined(__STREAM_TEST_H__)
#define __STREAM_TEST_H__

#include <socket/dgram/datagram_socket_conn.h>
#include <socket/dgram/datagram_socket_connless.h>
#include <timer/periodic_timer.h>
#include <timer/oneshot_timer.h>
#include <message/message.h>
#include <event_loop/activity_hld.h>

namespace colib
{

class ConsoleSession;
class SocketBuffer;

class DgramUnitTest
{
public:
	DgramUnitTest();
	~DgramUnitTest() { }

	bool Init();
	void AddWritable(int level, Writable *out);
	void Shutdown();
	eCallbackRt StartTest1();

private:
	DatagramSocketConn m_dgram_host1;
	DatagramSocketConnless m_dgram_host2;

	ActivityHold m_test_start_act;
	PeriodicTimer m_send_timer;
	OneShotTimer m_large_msg_send_timer;
	MemberSet m_trace_set;
	int m_num_host1_data_sent;
	TraceMember m_debug_output;

	void RegisterConsoleCommands();
	void SendDataHost1(unsigned int clock, void *data);
	void SendLargeDataHost1(unsigned int clock, void *data);
	void Host1DataReceived(SocketBuffer *buf);
	void Host2DataReceived(SocketBuffer *buf);

	static void ConCmdDgramHost1(DatagramSocketConn *dgram_sock, ConsoleSession *con, int argc, char *argv[]);
	static void ConCmdDgramHost2(DatagramSocketConnless *dgram_sock, ConsoleSession *con, int argc, char *argv[]);
};


}

#endif
