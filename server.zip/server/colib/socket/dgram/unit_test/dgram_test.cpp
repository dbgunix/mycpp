#include <socket/dgram/unit_test/dgram_test.h>
#include <event_loop/event_loop.h>
#include <options/options.h>
#include <utils/trace/trace.h>
#include <console/command.h>
#include <console/role.h>
#include <console/session.h>
#include <socket/socket_buffer_pool.h>
#include <socket/stream/console/console.h>

namespace colib
{

DgramUnitTest::DgramUnitTest()
	: m_dgram_host1("Dgram_Connection")
	, m_dgram_host2("Dgram_no_Connection")
	, m_test_start_act(callbackRt(this, &DgramUnitTest::StartTest1), "StreamTestStartTest1")
	, m_send_timer("SendTimer1")
	, m_large_msg_send_timer("SendLargeMsgTimer")
	, m_num_host1_data_sent(0)
	, m_debug_output()
{
	m_send_timer.SetExpireCb(callback(this, &DgramUnitTest::SendDataHost1));
	m_large_msg_send_timer.SetExpireCb(callback(this, &DgramUnitTest::SendLargeDataHost1));
}

void DgramUnitTest::RegisterConsoleCommands()
{
	ConsoleGlobal::GetInstance().RegisterConsoleCommand();
	ConsoleCommand::Register(CONSOLE_ROLE_EVERYONE, (ConsoleCommand::Handler*)ConCmdDgramHost1, &m_dgram_host1, "host1", "Dgram Host1 (Conn) commands");
	ConsoleCommand::Register(CONSOLE_ROLE_EVERYONE, (ConsoleCommand::Handler*)ConCmdDgramHost2, &m_dgram_host2, "host2", "Dgram Host2 (NoConn) commands");
}

bool DgramUnitTest::Init()
{
	RegisterConsoleCommands();
	// set connect address
	if (!m_dgram_host1.Init("INET;127.0.0.1;23445", "", ""))
	{
		return false;
	}
	// connectionless datagram sockets do support a bind address
	// NOTE that this address is the bind address
	if (!m_dgram_host2.Init("INET;127.0.0.1;23445", ""))
	{
		return false;
	}
	// setup read callbacks
	m_dgram_host1.SetReadCallback(callback(this, &DgramUnitTest::Host1DataReceived));
	m_dgram_host2.SetReadCallback(callback(this, &DgramUnitTest::Host2DataReceived));
	// add activity to start test
	EventLoop::GetInstance().AddActivity(&m_test_start_act);
	return true;
}

void DgramUnitTest::AddWritable(int level, Writable *out)
{
	// for testing/debug only
	m_trace_set.AddWritable(level, out);
	m_dgram_host1.AddWritable(level, out);
	m_dgram_host2.AddWritable(level, out);
}

eCallbackRt DgramUnitTest::StartTest1()
{
	m_send_timer.StartStaggered(2000, 1000);
	return DontRunAgain;
}

void DgramUnitTest::SendDataHost1(unsigned int clock, void *data)
{
	(void)clock;
	(void)data;

	static const int NUM_TIMES_TO_SEND = 5;

	++m_num_host1_data_sent;
	char dgram_data[1200];
	// NOTE: contents of dgram_data irrelevant for current test
	member_TRACE(&m_trace_set, 8, "Host1 sending %d bytes to %s\n", sizeof(dgram_data), m_dgram_host1.GetConnectAddr().PutToString().c_str());
	m_dgram_host1.WriteBytes(dgram_data, sizeof(dgram_data));

	if (m_num_host1_data_sent >= NUM_TIMES_TO_SEND)
	{
		member_TRACE(&m_trace_set, 8, "Completed sending %d messages\n", m_num_host1_data_sent);
		m_send_timer.Stop();
		m_large_msg_send_timer.Start(1000);
	}
}

void DgramUnitTest::SendLargeDataHost1(unsigned int clock, void *data)
{
	(void)clock;
	(void)data;

	const int DATA_SIZE = 8192;

	char* large_data = new char[DATA_SIZE];
	member_TRACE(&m_trace_set, 8, "Dgram Host1 sending %d bytes to %s\n", DATA_SIZE, m_dgram_host1.GetConnectAddr().PutToString().c_str());
	m_dgram_host1.WriteBytes(large_data, DATA_SIZE);
	delete [] large_data;
}

void DgramUnitTest::Host1DataReceived(SocketBuffer *buf)
{
	member_TRACE(&m_trace_set, 8, "Dgram Host1 received %d bytes from %s\n", buf->GetLength(), buf->GetSocketAddr().PutToString().c_str());
}

void DgramUnitTest::Host2DataReceived(SocketBuffer *buf)
{
	member_TRACE(&m_trace_set, 8, "Dgram Host2 received %d bytes from %s\n", buf->GetLength(), buf->GetSocketAddr().PutToString().c_str());
	// send reply using buffers
	SocketBuffer *rsp = SocketBufferPool::GetInstance().Get();
	if (!rsp)
	{
		member_TRACE(&m_trace_set, 0, "Failed to get buffer from pool\n");
	}
	// NOTE: contents of rsp_data irrelevant for current test
	const int RSP_SIZE = 1300;
	char rsp_data[RSP_SIZE];
	rsp->SetBuf(rsp_data, RSP_SIZE);
	member_TRACE(&m_trace_set, 8, "Dgram Host2 sending %d bytes to %s\n", RSP_SIZE, buf->GetSocketAddr().PutToString().c_str());
	m_dgram_host2.WriteBuf(rsp, buf->GetSocketAddr().m_data, buf->GetSocketAddr().m_data_len);
	// WriteBuf transfers ownership of "rsp", do not return rsp to pool
}

void DgramUnitTest::ConCmdDgramHost1(DatagramSocketConn *dgram_sock, ConsoleSession *con, int argc, char* argv[])
{
	if (!con)
	{
		return;
	}
	if (!dgram_sock)
	{
		con->Print("Host1 is null");
	}
	else
	{
		dgram_sock->ConsoleCommand(con, argc-1, argv+1);
	}
}

void DgramUnitTest::ConCmdDgramHost2(DatagramSocketConnless *dgram_sock, ConsoleSession *con, int argc, char* argv[])
{
	if (!con)
	{
		return;
	}
	if (!dgram_sock)
	{
		con->Print("Host2 is null");
	}
	else
	{
		dgram_sock->ConsoleCommand(con, argc-1, argv+1);
	}
}

}
