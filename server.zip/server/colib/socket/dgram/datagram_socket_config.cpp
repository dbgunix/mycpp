#include<socket/dgram/datagram_socket_config.h>
#include<utils/trace/trace.h>
#include<event_loop/event_loop.h>

#include <errno.h>
#include <fcntl.h>
#include <sys/un.h>
#include <unistd.h>

namespace colib
{

/** DatagramSocketConfig ctor
 * \param[in] name Name of the datagram socket
 */
DatagramSocketConfig::DatagramSocketConfig(string name)
	: FileDescriptorHandler(name, -1, READ_NOTIFY_FLAG)
	, m_retry_timer(name)
	, m_connected(false)
{
	m_retry_timer.SetExpireCb(callback(this, &DatagramSocketConfig::OnRetryTimerExpired));
}

/// DatagramSocketConfig dtor
DatagramSocketConfig::~DatagramSocketConfig()
{
	if (m_local_addr.GetType() == PF_UNIX)
	{
		unlink((reinterpret_cast<sockaddr_un*>(m_local_addr.m_data))->sun_path);
	}
}

/** Set the local address from a string
 * \param[out] type Type of \a local_addr
 * \param[in] local_addr String with local address (can be empty)
 * \return True if local address successfully configured from string, false if not
 */
bool DatagramSocketConfig::ConfigureBindAddr(int &type, string local_addr)
{
	if (!local_addr.is_empty())
	{
		if (!m_local_addr.SetFromString(local_addr))
		{
			TRACE("%s::%s -- Failed to parse listen address: %s\n", m_name.c_str(), __func__, local_addr.c_str());
			return false;
		}
		type = m_local_addr.GetType();
		if (type == PF_UNIX)
		{
			unlink((reinterpret_cast<sockaddr_un*>(m_local_addr.m_data))->sun_path);
		}
	}
	return true;
}

/** Bind socket to local address and join multicast group on local
 * address and specified interface
 * \param[in] multicast_interface String with multicast interface (e.g. "eth0")
 * \return True if bind succeeds and multicast join succeeds (if applicable), false if either fails
 */
bool DatagramSocketConfig::BindSocket(string multicast_interface)
{
	if (bind(m_fd, m_local_addr.m_data, m_local_addr.m_data_len) < 0)
	{
		TRACE("%s::%s Fail to bind socket, ip address=%s errno: %d (%s) \n", m_name.c_str(), __func__, m_local_addr.PutToString().c_str(), errno, strerror(errno));
		return false;
	}
	if (m_local_addr.IsMulticastAddress())
	{
		if (!m_local_addr.JoinMulticastGroup(m_fd, multicast_interface))
		{
			TRACE("%s::%s -- Failed to join multicast group %s on interface \"%s\": %s\n", m_name.c_str(), __func__, m_local_addr.PutToString().c_str(), multicast_interface.c_str(), strerror(errno) );
			return false;
		}
	}
	AddFlag(FileDescriptorHandler::READ_NOTIFY_FLAG);

	return true;
}

/** Set the foreign address from a string
 * \param[in,out] type PF of socket (based on local address), UNSPEC if not used
 * \param[in] connect_addr String with foreign address (can be empty)
 * \return True if configuration succeeds, false if not
 */
bool DatagramSocketConfig::ConfigureConnectAddr(int &type, string connect_addr)
{
	if (!connect_addr.is_empty())
	{
		if (!m_connect_addr.SetFromString(connect_addr))
		{
			TRACE("%s::%s -- Failed to parse connect address: %s\n", m_name.c_str(), __func__, connect_addr.c_str());
			return false;
		}
		// if type is unset, then no local addr was provided.
		// set type based on connect addr
		if (type == PF_UNSPEC)
		{
			type = m_connect_addr.GetType();
		}
		// if type is set, then there was a local addr provided.
		// local_addr type and connect_addr type must match
		else if (m_local_addr.GetType() != m_connect_addr.GetType())
		{
			TRACE("%s::%s -- Can't connect and listen on different socket types: <%s> <%s>\n", m_name.c_str(), __func__, m_connect_addr.PutToString().c_str(), m_local_addr.PutToString().c_str() );
			return false;
		}
	}
	return true;
}

/** Connect the socket to the configured foreign address
 * If foreign address is a multicast address, configure the multicast
 * interface using the string provided
 * \param[in] multicast_interface String with multicast interface (e.g. "eth0")
 * \return True if the connect succeeds, false if not
 */
bool DatagramSocketConfig::ConnectSocket(string multicast_interface)
{
	m_connected = (connect(m_fd, m_connect_addr.m_data, m_connect_addr.m_data_len) == 0);
	if (m_connect_addr.IsMulticastAddress())
	{
		if (!m_connect_addr.SetMulticastTransmitInterface(m_fd, multicast_interface))
		{
			TRACE("%s::%s -- Failed to set multicast transmit interface to \"%s\": %s\n", m_name.c_str(), __func__, multicast_interface.c_str(), strerror(errno) );
			return false;
		}
	}
	return true;
}

/** Register this socket with the event loop
 * \return True if the registration succeeded, false if not
 */
bool DatagramSocketConfig::RegisterWithEventLoop()
{
	if (!EventLoop::GetInstance().AddHandler(*this))
	{
		TRACE("%s -- Failed to add FDH to event loop\n", m_name.c_str());
		return false;
	}
	return true;
}

/// Close the socket and unregister from the event loop
void DatagramSocketConfig::CloseSocket()
{
	if (m_fd >= 0)
	{
		EventLoop::GetInstance().RemoveHandler(*this);
		close(m_fd);
		m_fd = -1;
	}
}

/** Create and configure the system socket
 * \param[in] type Domain of socket to setup
 * \return True if setup succeeded, false if not
 */
bool DatagramSocketConfig::SetupSocket(int type)
{
	m_fd = socket(type, SOCK_DGRAM, 0);

	if (m_fd < 0)
	{
		TRACE("%s::%s -- socket() failed (type %d): %s\n", m_name.c_str(), __func__, type, strerror(errno));
		return false;
	}

	if (!MakeNonBlocking())
	{
		return false;
	}

	int reuse = 1;
	if (setsockopt(m_fd, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse)) < 0)
	{
		TRACE("%s::%s -- socket REUSEADDR failed: (%s)\n", m_name.c_str(), __func__, strerror(errno));
		return false;
	}
	return true;
}

/** Handle retry timer expiration
 * \param[in] clock Milliseconds of timer expiration (not wall clock) (unused)
 * \param[in] data Data context (unused)
 */
void DatagramSocketConfig::OnRetryTimerExpired(unsigned int clock, void *data)
{
	(void)clock;
	(void)data;
	member_TRACE(&m_trace_set, 9, "%s -- retry timeout\n", m_name.c_str());
	AddFlag(FileDescriptorHandler::WRITE_NOTIFY_FLAG);
}

}
