#if !defined(__DATAGRAM_SOCKET_LG_H__)
#define __DATAGRAM_SOCKET_LG_H__

#include "datagram_buf.h"
#include <socket/dgram/datagram_socket_config.h>
#include <config/value.h>

#include <deque>

// NOTE: this object is a temporary (hopefully) workaround, use at your own risk

namespace colib
{

class Message;

class DatagramSocketLg : public DatagramSocketConfig
{
public:
	enum Stats
	{
		Stat_rx_bytes,
		Stat_tx_bytes,
		Stat_rx_datagrams,
		Stat_tx_datagrams,
		Stat_encode_failed,
		Stat_invalid_sendto_addr,
		Stat_set_buffer_failed
	};
	enum WriteType
	{
		SEND,
		SENDTO
	};

	DatagramSocketLg(string name);
	virtual ~DatagramSocketLg();

	bool Init(string connect_addr, string local_addr, string multicast_intf);
	bool Init(string local_addr, string multicast_intf);

	void SetReadCallback(const Callback1<DatagramBuf*> &read_cb) { m_on_read = read_cb; }
	bool JoinMulticastGroup(string multicast_addr, string multicast_intf);

	int GetTxQueueDepth() const { return m_tx_queue.size(); }
	int GetMaxQueueDepth() const { return m_max_queue_depth; }
	void SetMaxQueueDepth(int depth) { m_max_queue_depth = depth; }

	void Close();

	int ReadBytes(char *buf, int len);
	DatagramBuf* ReadBuf();

	bool WriteBytes(const char* buf, int len);
	bool WriteBuf(DatagramBuf* buf);
	bool WriteMessage(Message& msg);
	bool WriteBytes(const char* buf, int len, const sockaddr* toaddr, socklen_t addr_len);
	bool WriteBuf(DatagramBuf* buf, const sockaddr* toaddr, socklen_t addr_len);
	bool WriteMessage(Message& msg, const sockaddr* toaddr, socklen_t addr_len);

	void ConsoleCommand(Writable *to, int argc, char *argv[]);

	void SetDisconnectedCallback(const Callback1<DatagramSocketLg&> &disc_cb) { m_on_peer_disconnected = disc_cb; }

private:
	static const int DEFAULT_MAX_QUEUE_DEPTH = 2000;  // We could reduce this later, if needed
	static const int DGRAM_RETRY_TIMEOUT = 20; // ms

	bool CommonInit(string connect_addr, string local_addr, string multicast_intf);
	void ClearTxQueue();
	void UpdateFlag();
	bool SafeToWriteBuf() const { return static_cast<int>(m_tx_queue.size()) < m_max_queue_depth; }
	void QueueBuffer(DatagramBuf* buf);
	template<WriteType TYPE>
	bool WriteBytesCommon(const char* buf, int len, const sockaddr* toaddr, socklen_t addr_len);
	template<WriteType TYPE>
	bool WriteMessageCommon(Message& msg, const sockaddr* toaddr, socklen_t addr_len);
	// from FDH
	virtual void read();
	virtual void write();

	/// Single entry receive queue
	DatagramBuf m_rx_buf;
	/// Tx queue
	std::deque<DatagramBuf*> m_tx_queue;
	/// Read callback
	Callback1<DatagramBuf*> m_on_read;
	/// Maximum tx queue depth
	int m_max_queue_depth;
	/// Statistics container
	ValueList m_stats;
	/// callback to trigger if peer disconnects
	Callback1<DatagramSocketLg&> m_on_peer_disconnected;
};

#define DGRAMLGSTAT(stat) m_stats[Stat_##stat].AsInt()

}

#endif
