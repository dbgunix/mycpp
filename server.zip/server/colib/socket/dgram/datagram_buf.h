#if !defined(__DATAGRAM_BUF_H__)
#define __DATAGRAM_BUF_H__

#include <socket/socket_addr.h>

namespace colib
{

class DatagramBuf
{
public:
	static const int MAX_SIZE = 65535; // max size of an IPv4 packet

	DatagramBuf();
	DatagramBuf(int capacity);
	~DatagramBuf();

	int GetDataLength() const { return m_data_len; }
	int GetCapacity() const { return m_capacity; }
	SocketAddr& GetSockAddr() { return m_addr; }
	char* GetData() { return m_buf; }
	int MaxLength() const { return MAX_SIZE; }

	void SetCapacity(int capacity);
	int SetDataLength(int data_length);
	int SetBuf(const char* data, int length);
	void ClearData() { m_data_len = 0; }
	void ClearBuffer();
	void ClearAddr() { m_addr.Clear(); }

private:
	char* m_buf;
	int m_data_len;
	int m_capacity;
	SocketAddr m_addr;
};

}

#endif
