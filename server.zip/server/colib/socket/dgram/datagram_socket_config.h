#if !defined(__DATAGRAM_SOCKET_CONFIG_H__)
#define __DATAGRAM_SOCKET_CONFIG_H__

#include<utils/string.h>
#include<event_loop/fdh.h>
#include<socket/socket_addr.h>
#include<timer/oneshot_timer.h>
#include<utils/trace/writable.h>

namespace colib
{

class DatagramSocketConfig : public FileDescriptorHandler
{
public:
	virtual ~DatagramSocketConfig();
	const SocketAddr& GetLocalAddr() const { return m_local_addr; }
	const SocketAddr& GetConnectAddr() const { return m_connect_addr; }

	void AddWritable(int level, Writable *out) { m_trace_set.AddWritable(level, out); }

protected:
	DatagramSocketConfig(string name);

	bool ConfigureBindAddr(int &type, string local_addr);
	bool BindSocket(string multicast_interface);
	bool ConfigureConnectAddr(int &type, string connect_addr);
	bool ConnectSocket(string multicast_interface);
	bool SetupSocket(int type);
	void CloseSocket();
	bool RegisterWithEventLoop();
	void OnRetryTimerExpired(unsigned int clock, void *data);

	/// Local address
	SocketAddr m_local_addr;
	/// Foreign address
	SocketAddr m_connect_addr;
	/// Timer for retrying transmissions
	OneShotTimer m_retry_timer;
	/// Debug member set
	MemberSet m_trace_set;
	/// Connected flag
	bool m_connected;
};

}

#endif
