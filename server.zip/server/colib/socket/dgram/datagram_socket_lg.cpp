#include "datagram_socket_lg.h"
#include <utils/trace/trace.h>
#include <message/message.h>
#include <console/command/debug.h>

#include <errno.h>
#include <unistd.h>

namespace colib
{

static ValueList::ValueHolder InitStats()
{
	return
	{
		Value("rx_bytes", 0),
		Value("tx_bytes", 0),
		Value("rx_datagrams", 0),
		Value("tx_datagrams", 0),
		Value("encode_failed", 0),
		Value("invalid_sendto_addr", 0),
		Value("set_buffer_failed", 0)
	};
};

template<DatagramSocketLg::WriteType> bool SetDgramBufAddr(DatagramBuf* buf, const sockaddr* addr, socklen_t len);

template<> bool SetDgramBufAddr<DatagramSocketLg::SEND>(DatagramBuf* buf, const sockaddr* addr, socklen_t len)
{
	(void)buf;
	(void)addr;
	(void)len;
	return true;
}

template<> bool SetDgramBufAddr<DatagramSocketLg::SENDTO>(DatagramBuf* buf, const sockaddr* addr, socklen_t len)
{
	return buf->GetSockAddr().SetTo(addr, len);
}

DatagramSocketLg::DatagramSocketLg(string name)
	: DatagramSocketConfig(name)
	, m_rx_buf(DatagramBuf::MAX_SIZE)
	, m_tx_queue()
	, m_on_read()
	, m_max_queue_depth(DEFAULT_MAX_QUEUE_DEPTH)
	, m_stats(InitStats())
	, m_on_peer_disconnected()
{
}

DatagramSocketLg::~DatagramSocketLg()
{
	ClearTxQueue();
}

bool DatagramSocketLg::Init(string connect_addr, string local_addr, string multicast_intf)
{
	return CommonInit(connect_addr, local_addr, multicast_intf);
}

bool DatagramSocketLg::Init(string local_addr, string multicast_intf)
{
	return CommonInit("", local_addr, multicast_intf);
}

bool DatagramSocketLg::JoinMulticastGroup(string multicast_addr, string multicast_intf)
{
	bool res = false;
	SocketAddr mcast_sock_addr;
	if (mcast_sock_addr.SetFromString(multicast_addr) && mcast_sock_addr.IsMulticastAddress())
	{
		res = mcast_sock_addr.JoinMulticastGroup(m_fd, multicast_intf);
	}
	return res;
}

void DatagramSocketLg::Close()
{
	m_retry_timer.Stop();
	CloseSocket();
	m_max_queue_depth = DEFAULT_MAX_QUEUE_DEPTH;
	m_connected = false; // unnecessary, but harmless when connectionless
	ClearTxQueue();
}

int DatagramSocketLg::ReadBytes(char* buf, int len)
{
	int bytes = -1;
	if (len > 0 && buf)
	{
		bytes = std::min(m_rx_buf.GetDataLength(), len);
		memcpy(buf, m_rx_buf.GetData(), bytes);
		m_rx_buf.ClearData(); // NOTE: assumes caller got all the data they wanted
	}
	return bytes;
}

DatagramBuf* DatagramSocketLg::ReadBuf()
{
	return &m_rx_buf;
}

bool DatagramSocketLg::WriteBytes(const char* buf, int len)
{
	return WriteBytesCommon<SEND>(buf, len, NULL, 0);
}

bool DatagramSocketLg::WriteBytes(const char* buf, int len, const sockaddr* toaddr, socklen_t addr_len)
{
	return WriteBytesCommon<SENDTO>(buf, len, toaddr, addr_len);
}

template <DatagramSocketLg::WriteType TYPE>
bool DatagramSocketLg::WriteBytesCommon(const char* buf, int len, const sockaddr* toaddr, socklen_t addr_len)
{
	bool ret = false;
	if (len > 0 && SafeToWriteBuf())
	{
		DatagramBuf *tx_buf = new DatagramBuf;
		if (SetDgramBufAddr<TYPE>(tx_buf, toaddr, addr_len))
		{
			if (tx_buf->SetBuf(buf, len) == len)
			{
				QueueBuffer(tx_buf);
				ret = true;
			}
			else
			{
				++DGRAMLGSTAT(set_buffer_failed);
				m_trace_set.Trace(0, "%s::%s failed to set buffer\n", GetName().c_str(), __func__);
				delete tx_buf;
			}
		}
		else
		{
			++DGRAMLGSTAT(invalid_sendto_addr);
			m_trace_set.Trace(0, "%s::%s invalid sendto addr (%p)\n", GetName().c_str(), __func__, toaddr);
			delete tx_buf;
		}
	}
	return ret;
}

bool DatagramSocketLg::WriteBuf(DatagramBuf* buf)
{
	bool ret = false;
	if (buf && SafeToWriteBuf())
	{
		buf->GetSockAddr().Clear(); // just in case
		QueueBuffer(buf);
		ret = true;
	}
	return ret;
}

bool DatagramSocketLg::WriteBuf(DatagramBuf* buf, const sockaddr* toaddr, socklen_t addr_len)
{
	bool ret = false;
	if (buf && SafeToWriteBuf())
	{
		if (buf->GetSockAddr().SetTo(toaddr, addr_len))
		{
			QueueBuffer(buf);
			ret = true;
		}
		else
		{
			++DGRAMLGSTAT(invalid_sendto_addr);
			m_trace_set.Trace(0, "%s::%s invalid sendto addr (%p)\n", GetName().c_str(), __func__, toaddr);
		}
	}
	return ret;
}

bool DatagramSocketLg::WriteMessage(Message& msg)
{
	return WriteMessageCommon<SEND>(msg, NULL, 0);
}

bool DatagramSocketLg::WriteMessage(Message& msg, const sockaddr* toaddr, socklen_t addr_len)
{
	return WriteMessageCommon<SENDTO>(msg, toaddr, addr_len);
}

template<DatagramSocketLg::WriteType TYPE>
bool DatagramSocketLg::WriteMessageCommon(Message& msg, const sockaddr* toaddr, socklen_t addr_len)
{
	bool ret = false;
	if (SafeToWriteBuf())
	{
		DatagramBuf* tx_buf = new DatagramBuf(DatagramBuf::MAX_SIZE);
		if (SetDgramBufAddr<TYPE>(tx_buf, toaddr, addr_len))
		{
			unsigned int len = tx_buf->GetCapacity();
			if (msg.Encode(tx_buf->GetData(), &len))
			{
				tx_buf->SetDataLength(len);
				QueueBuffer(tx_buf);
				ret = true;
			}
			else
			{
				++DGRAMLGSTAT(encode_failed);
				m_trace_set.Trace(0, "%s::%s failed to encode msg %d\n", GetName().c_str(), __func__, msg.GetType());
				delete tx_buf;
			}
		}
		else
		{
			++DGRAMLGSTAT(invalid_sendto_addr);
			m_trace_set.Trace(0, "%s::%s invalid sendto addr (%p)\n", GetName().c_str(), __func__, toaddr);
			delete tx_buf;
		}
	}
	return ret;
}

bool DatagramSocketLg::CommonInit(string connect_addr, string local_addr, string multicast_intf)
{
	Close();
	int type = PF_UNSPEC;

	if (!ConfigureBindAddr(type, local_addr))
	{
		return false;
	}

	if (!connect_addr.is_empty() && !ConfigureConnectAddr(type, connect_addr))
	{
		return false;
	}

	// if type is PF_UNSPEC at this point then no local addr provided
	// for now, use default PF of PF_INET
	if (type == PF_UNSPEC)
	{
		type = PF_INET;
	}

	return SetupSocket(type)
		&& (m_local_addr.GetType() == PF_UNSPEC || BindSocket(multicast_intf))
		&& (m_connect_addr.GetType() == PF_UNSPEC || ConnectSocket(multicast_intf))
		&& m_rx_buf.GetSockAddr().SetType(type)
		&& RegisterWithEventLoop();
}

void DatagramSocketLg::read()
{
	int bytes_read = recvfrom(m_fd, m_rx_buf.GetData(), m_rx_buf.MaxLength(), 0, m_rx_buf.GetSockAddr().m_data, &m_rx_buf.GetSockAddr().m_data_len);
	if (bytes_read > 0)
	{
		++DGRAMLGSTAT(rx_datagrams);
		DGRAMLGSTAT(rx_bytes) += bytes_read;
		m_trace_set.Trace(5, "%s::read - %d bytes\n", m_name.c_str(), bytes_read);
		m_rx_buf.SetDataLength(bytes_read);
		m_on_read.Dispatch(&m_rx_buf);
		// TODO: reset here?
	}
	else
	{
		m_trace_set.Trace(0, "%s read failure: %s (%d)\n", GetName().c_str(), strerror(errno), errno);
	}
}

void DatagramSocketLg::write()
{
	// write should not get called if the tx queue is empty
	// in case it does, turn off write events and return
	if (m_tx_queue.empty())
	{
		RemoveFlag(FileDescriptorHandler::WRITE_NOTIFY_FLAG);
		return;
	}

	int bytes_written = 0;
	DatagramBuf *tx_buf = m_tx_queue.front();
	if (tx_buf->GetSockAddr().IsEmpty())
	{
		// no address provided, need to be connected to send
		// if we are not already connected, try to connect
		m_connected = m_connected || ::connect(m_fd, m_connect_addr.m_data, m_connect_addr.m_data_len) == 0;
		if (!m_connected)
		{
			// error, don't try to write
			m_trace_set.Trace(2, "%s::%s - reconnect fail (to %s) when trying to write: %s\n",
				GetName().c_str(),
				__func__,
				m_connect_addr.PutToString().c_str(),
				strerror(errno));
		}
		else
		{
			bytes_written = ::write(m_fd, tx_buf->GetData(), tx_buf->GetDataLength());
		}
	}
	else
	{
		bytes_written = sendto(m_fd, tx_buf->GetData(), tx_buf->GetDataLength(), 0, tx_buf->GetSockAddr().m_data, tx_buf->GetSockAddr().m_data_len);
	}

	bool retry = false;
	if (bytes_written > 0)
	{
		++DGRAMLGSTAT(tx_datagrams);
		DGRAMLGSTAT(tx_bytes) += bytes_written;
		m_trace_set.Trace(8, "%s wrote %d bytes\n", GetName().c_str(), bytes_written);
	}
	else if (bytes_written < 0)
	{
		if (errno == EAGAIN)
		{
			m_trace_set.Trace(5, "%s::%s (%d bytes) - EAGAIN\n", GetName().c_str(), __func__, tx_buf->GetDataLength());
			retry = true;
		}
		else if (errno == ENOTCONN || errno == ECONNREFUSED)
		{
			m_trace_set.Trace(2, "%s::%s - not connected or connection refused\n", GetName().c_str(), __func__);
			m_on_peer_disconnected.Dispatch(*this);
			m_connected = false;
		}
		else
		{
			m_trace_set.Trace(0, "%s failed to write: %s\n", GetName().c_str(), strerror(errno));
		}
	}

	if (!retry)
	{
		// buffer was sent or we're giving up on it, release it
		m_tx_queue.pop_front();
		delete tx_buf;
		m_trace_set.Trace(6, "%s::%s - queue @ %zu\n", GetName().c_str(), __func__, m_tx_queue.size());
		UpdateFlag();
	}
	else
	{
		// retrying due to EAGAIN, disable write flag and start timer
		// retry timer will enable write flag
		RemoveFlag(FileDescriptorHandler::WRITE_NOTIFY_FLAG);
		m_retry_timer.Start(DGRAM_RETRY_TIMEOUT);
	}
}

void DatagramSocketLg::ClearTxQueue()
{
	for (auto it(m_tx_queue.begin()); it != m_tx_queue.end(); ++it)
	{
		delete *it;
	}
	m_tx_queue.clear();
}

void DatagramSocketLg::UpdateFlag()
{
	if (m_tx_queue.empty())
	{
		RemoveFlag(FileDescriptorHandler::WRITE_NOTIFY_FLAG);
	}
	else
	{
		AddFlag(FileDescriptorHandler::WRITE_NOTIFY_FLAG);
	}
}

void DatagramSocketLg::QueueBuffer(DatagramBuf* buf)
{
	m_tx_queue.push_back(buf);
	AddFlag(FileDescriptorHandler::WRITE_NOTIFY_FLAG);
}

void DatagramSocketLg::ConsoleCommand(Writable* to, int argc, char* argv[])
{
	const char *usage = "Usage: status | stats | debug\n";
	if (!to)
	{
		return;
	}

	if (argc < 1)
	{
		to->PrintString(usage);
	}
	else if (!strcmp(argv[0], "status"))
	{
		to->Print("Name: %s\nLocal Address: %s\nForeign Address: %s\n", m_name.c_str(), m_local_addr.PutToString().c_str(), m_connect_addr.PutToString().c_str());
	}
	else if (!strcmp(argv[0], "stats"))
	{
		m_stats.ConsoleCommand(to, argc-1, argv+1);
	}
	else if (!strcmp(argv[0], "params"))
	{
	}
	else if (!strcmp(argv[0], "debug"))
	{
		HandleDebugCommand(to, argc-1, argv+1, m_trace_set, m_name.c_str());
	}
	else
	{
		to->PrintString(usage);
	}
}

}
