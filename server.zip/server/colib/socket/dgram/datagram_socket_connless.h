#if !defined(__DATAGRAM_SOCKET_CONNLESS_H__)
#define __DATAGRAM_SOCKET_CONNLESS_H__

#include<utils/string.h>
#include<socket/dgram/datagram_socket_base.h>

namespace colib
{

class SocketBuffer;
class Message;

class DatagramSocketConnless : public DatagramSocketBase
{
public:
	DatagramSocketConnless(string name);
	virtual ~DatagramSocketConnless() { }

	bool Init(string local_addr, string multicast_interface);

	bool WriteBytes(const char *buf, int len, const sockaddr *toaddr, socklen_t addr_len);
	bool WriteBuf(SocketBuffer *buf, const sockaddr *toaddr, socklen_t addr_len);
	bool WriteMessage(Message &msg, const sockaddr *toaddr, socklen_t addr_len);

	void ConsoleCommand(Writable *to, int argc, char *argv[]);

private:
	virtual void write();
};

}

#endif
