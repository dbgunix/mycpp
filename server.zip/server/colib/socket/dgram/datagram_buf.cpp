#include "datagram_buf.h"
#include <algorithm>

namespace colib
{

DatagramBuf::DatagramBuf()
	: m_buf(NULL)
	, m_data_len(0)
	, m_capacity(0)
	, m_addr()
{
}

DatagramBuf::DatagramBuf(int capacity)
	: m_buf(capacity > 0 ? new char[capacity] : NULL)
	, m_data_len(0)
	, m_capacity(std::max(capacity, 0))
	, m_addr()
{
}

DatagramBuf::~DatagramBuf()
{
	if (m_buf)
	{
		delete [] m_buf;
	}
}

void DatagramBuf::SetCapacity(int capacity)
{
	// TODO: consider checking if capacity is already at max
	// if so, no reason to delete/re-alloc
	if (capacity > m_capacity)
	{
		ClearBuffer();
		// 0 <= capacity <= MAX_SIZE
		int tmp = DatagramBuf::MAX_SIZE;
		m_capacity = std::min(tmp, std::max(capacity, 0));
		m_buf = new char[m_capacity];
		m_data_len = m_capacity; // TODO: questionable
	}
	else
	{
		m_data_len = capacity; // TODO: questionable
	}
}

int DatagramBuf::SetDataLength(int data_length)
{
	m_data_len = std::min(data_length, m_capacity);
	return m_data_len;
}

int DatagramBuf::SetBuf(const char* data, int length)
{
	int ret = -1;
	if (data && length > 0)
	{
		SetCapacity(length);
		memcpy(m_buf, data, length);
		ret = GetDataLength();
	}
	return ret;
}

void DatagramBuf::ClearBuffer()
{
	if (m_buf)
	{
		delete [] m_buf;
		m_buf = NULL;
	}
	m_data_len = 0;
	m_capacity = 0;
}

}
