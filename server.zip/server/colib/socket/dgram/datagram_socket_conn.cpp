#include<socket/dgram/datagram_socket_conn.h>
#include<socket/socket_buffer.h>
#include<socket/socket_buffer_pool.h>
#include<utils/trace/trace.h>
#include<message/message.h>
#include<console/command/debug.h>

#include <unistd.h>
#include <errno.h>
#include <net/if.h>

namespace colib
{

/** DatagramSocketConn ctor
 * \param[in] name Name of the socket
 */
DatagramSocketConn::DatagramSocketConn(string name)
	: DatagramSocketBase(name)
	, m_on_peer_disconnected()
{
}

/** Perform all initialization steps for a connection oriented datagram socket
 * \param[in] connect_addr String with the foreign address (optional)
 * \param[in] local_addr String with the local address (optional)
 * \param[in] multicast_interface String with the multicast interface (optional)
 * \return True if initialization succeeded, false if not
 */
bool DatagramSocketConn::Init(string connect_addr, string local_addr, string multicast_interface)
{
	//even though it's not supposed to call init multiple times, just in case
	Close();

	int type = PF_UNSPEC;

	if (!ConfigureBindAddr(type, local_addr))
	{
		return false;
	}
	if (!ConfigureConnectAddr(type, connect_addr))
	{
		return false;
	}

	// if type is PF_UNSPEC at this point then no local/connect addr provided
	// for now, use default PF of PF_INET
	if (type == PF_UNSPEC)
	{
		type = PF_INET;
	}

	if (!SetupSocket(type))
	{
		return false;
	}

	if (m_local_addr.GetType() != PF_UNSPEC && !BindSocket(multicast_interface))
	{
		return false;
	}
	if (m_connect_addr.GetType() != PF_UNSPEC && !ConnectSocket(multicast_interface))
	{
		return false;
	}
	if (!m_rx_buf.GetSocketAddr().SetType(type))
	{
		return false;
	}
	return RegisterWithEventLoop();
}

bool DatagramSocketConn::BindToDevice(string &status)
{
	//This function is to bind the socket to a specific device.
	//The reason to provide this funtion is that with client DGRAM socket,
	//bind to an address just set the source address of outgoing packets, not indeed bind
	//the interface of the address.

	//currently this is function is for special case of heartbeat and blade status msg
	//which are intended to be going out of tunnel interface.
	if (0 >= m_fd)
	{
		//invalid socket
		status = "Invalid socket handler";
		return false;
	}

	//get interface name of m_local_addr
	colib::string listen_interface = m_local_addr.GetInterfaceName();
	if (listen_interface.is_empty())
	{
		//empty interface
		status = "Listen address is empty";
		return false;
	}

	struct ifreq interface;
	strncpy(interface.ifr_name, listen_interface.c_str(), sizeof(interface.ifr_name));
	int res = setsockopt(m_fd, SOL_SOCKET, SO_BINDTODEVICE, &interface, sizeof(interface));
	if (-1 == res)
	{
		status = string::Format("Fail to bind: %s(%d)", strerror(errno), errno);
		return false;
	}
	return true;
}

/** Write bytes to the socket
 * \param[in] buf Bytes to write
 * \param[in] len Length of \a buf
 * \return True if \a len bytes were written, false if not
 * \note This is an all-or-nothing write
 */
bool DatagramSocketConn::WriteBytes(const char *buf, int len)
{
	if (len <= 0 || !SafeToWriteBuf())
	{
		return false;
	}

	SocketBuffer *tx_buf = m_buf_pool.Get();
	if (tx_buf)
	{
		if (tx_buf->SetBuf(buf, len) == len)
		{
			QueueBuffer(tx_buf);
			return true;
		}
		else
		{
			m_buf_pool.Return(tx_buf);
		}
	}
	return false;
}

/** Write a Socketbuffer to the socket
 * \param[in] buf SocketBuffer to write
 * \return True if the write succeeded, false if not
 */
bool DatagramSocketConn::WriteBuf(SocketBuffer *buf)
{
	bool ret = false;
	if (buf && SafeToWriteBuf())
	{
		QueueBuffer(buf);
		ret = true;
	}
	return ret;
}

/** Write a Message to the socket
 * \param[in] msg Message to write
 * \return True if the write succeeded, false if not
 */
bool DatagramSocketConn::WriteMessage(Message& msg)
{
	bool ret = false;
	if (SafeToWriteBuf())
	{
		SocketBuffer *sbuf = m_buf_pool.Get();
		if (sbuf)
		{
			unsigned int len = sbuf->MaxLength();
			if (msg.Encode(sbuf->GetData(), &len))
			{
				sbuf->SetLength(len);
				QueueBuffer(sbuf);
				ret = true;
			}
			else
			{
				m_buf_pool.Return(sbuf);
			}
		}
	}
	return ret;
}

/// Perform a syscall write to the socket
void DatagramSocketConn::write()
{
	// write should not get called if the tx queue is empty
	// in case it does, turn off write events and return
	if (m_tx_queue.empty())
	{
		RemoveFlag(FileDescriptorHandler::WRITE_NOTIFY_FLAG);
		return;
	}

	// if not currently connected, try to connect (sets peer's address)
	if (!m_connected)
	{
		m_connected = (::connect(m_fd, m_connect_addr.m_data, m_connect_addr.m_data_len) == 0);
	}

	int n = 0;
	SocketBuffer *tx_buf = m_tx_queue.front();

	if (m_connected)
	{
		n = ::write(m_fd, tx_buf->GetData(), tx_buf->GetLength());
	}
	else
	{
		member_TRACE(&m_trace_set, 2, "%s::%s - reconnect fail (to %s) when trying to write: %s\n", GetName().c_str(), __FUNCTION__, m_connect_addr.PutToString().c_str(), strerror(errno));
	}

	bool retry = false;
	if (n < 0)
	{
		if (errno == EAGAIN)
		{
			member_TRACE(&m_trace_set, 5, "%s::%s (%d bytes) - EAGAIN\n", GetName().c_str(), __FUNCTION__, tx_buf->GetLength());
			retry = true;
		}
		else if (errno == ENOTCONN || errno == ECONNREFUSED)
		{
			member_TRACE(&m_trace_set, "%s::%s - not connected or connection refused\n", GetName().c_str(), __FUNCTION__);
			m_on_peer_disconnected.Dispatch(this);
			m_connected = false;
		}
		else
		{
			/*
			int en = errno;
			member_TRACE(&m_debug, "datagram_socket(0x%p, \"%s\")::write - errno = %d\n", this, m_name.c_str(), en);
			member_TRACE(&m_debug, "err=\"%s\" m_fd=%d \n", strerror(en), m_fd );
			member_TRACE(&m_debug, "m_tx_buf->buf=0x%p, m_tx_buf->len=%d\n", m_tx_buf->GetBuf(), m_tx_buf->GetDataLength());
			if(m_connected)
			{
				member_TRACE(&m_debug, "connected to:%s\n", m_connect_addr.GetStringVal().c_str() );
			}
			*/
		}
	}
	else if (n > 0)
	{
		++DGRAMSTAT(tx_datagrams);
		DGRAMSTAT(tx_bytes) += n;
		member_TRACE(&m_trace_set, 8, "%s wrote %d bytes\n", GetName().c_str(), n);
	}

	if (!retry)
	{
		// buffer was sent or we're giving up on it, release it
		m_tx_queue.pop_front();
		m_buf_pool.Return(tx_buf);
		member_TRACE(&m_trace_set, 6, "%s::%s - queue @ %zu\n", GetName().c_str(), __FUNCTION__, m_tx_queue.size());
		UpdateFlag();
	}
	else
	{
		// retrying due to EAGAIN, disable write flag and start timer
		// retry timer will enable write flag
		RemoveFlag(FileDescriptorHandler::WRITE_NOTIFY_FLAG);
		m_retry_timer.Start(DGRAM_RETRY_TIMEOUT);
	}
}

/** Process a DatagramSocketConn console command
 * \param[in] to Writable to use for output
 * \param[in] argc Number of arguments
 * \param[in] argv Array of arguments
 */
void DatagramSocketConn::ConsoleCommand(Writable *to, int argc, char *argv[])
{
	const char *usage = "Usage: status | stats | debug\n";
	if (!to)
	{
		return;
	}

	if (argc < 1)
	{
		to->PrintString(usage);
	}
	else if (!strcmp(argv[0], "status"))
	{
		to->Print("Name: %s\nLocal Address: %s\nForeign Address: %s\n", m_name.c_str(), m_local_addr.PutToString().c_str(), m_connect_addr.PutToString().c_str());
	}
	else if (!strcmp(argv[0], "stats"))
	{
		m_stats.ConsoleCommand(to, argc-1, argv+1);
	}
	else if (!strcmp(argv[0], "params"))
	{
	}
	else if (!strcmp(argv[0], "debug"))
	{
		HandleDebugCommand(to, argc-1, argv+1, m_trace_set, m_name.c_str());
	}
	else
	{
		to->PrintString(usage);
	}
}

}
