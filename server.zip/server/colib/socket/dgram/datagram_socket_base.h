#if !defined(__DATAGRAM_SOCKET_BASE_H__)
#define __DATAGRAM_SOCKET_BASE_H__

#include<utils/callback.h>
#include<utils/string.h>
#include<socket/dgram/datagram_socket_config.h>
#include<socket/socket_addr.h>
#include<timer/oneshot_timer.h>
#include<utils/trace/writable.h>
#include<config/value.h>
#include<socket/socket_buffer.h>

#include <list>

namespace colib
{

class SocketBufferPool;

class DatagramSocketBase : public DatagramSocketConfig
{
public:
	enum Stats
	{
		Stat_rx_bytes,
		Stat_tx_bytes,
		Stat_rx_datagrams,
		Stat_tx_datagrams
	};

	virtual ~DatagramSocketBase();

	void SetReadCallback(const Callback1<SocketBuffer*> &read_cb) { m_on_read = read_cb; }
	bool JoinMulticastGroup(string multicast_addr, string multicast_intf);
	bool SetMulticastTTL(int ttl, string& err);

	int GetTxQueueDepth() const { return m_tx_queue.size(); }
	void SetMaxQueueDepth(int depth) { m_max_queue_depth = depth; }

	int ReadBytes(char *buf, int len);
	SocketBuffer* ReadBuf();

	void Close();

protected:
	static const int DEFAULT_MAX_QUEUE_DEPTH = 2000;  // We could reduce this later, if needed
	static const int DGRAM_RETRY_TIMEOUT = 20; // ms

	DatagramSocketBase(string name);

	void ReturnTxQueue();
	void UpdateFlag();
	bool SafeToWriteBuf() const { return static_cast<int>(m_tx_queue.size()) < m_max_queue_depth; }
	void QueueBuffer(SocketBuffer *buf);

	/// Single entry receive queue
	SocketBuffer m_rx_buf;
	/// Tx queue
	std::list<SocketBuffer*> m_tx_queue;
	/// SocketBufferPool
	SocketBufferPool& m_buf_pool; // not strictly needed, will be used later
	/// Read callback
	Callback1<SocketBuffer*> m_on_read;
	/// Maximum tx queue depth
	int m_max_queue_depth;
	/// Statistics container
	ValueList m_stats;

private:
	virtual void read();
};

#define DGRAMSTAT(stat) m_stats[Stat_##stat].AsInt()

}

#endif
