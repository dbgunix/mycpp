#include<socket/socket_buffer.h>

#ifdef DEBUG_SOCKET_BUFFER
#include<utils/trace/trace.h>
#endif

namespace colib
{

/// SocketBuffer ctor
SocketBuffer::SocketBuffer()
	: DataBuffer<SOCKET_BUFFER_MTU>(SOCKET_BUFFER_INITIAL_OFFSET)
	, m_addr()
{
#ifdef DEBUG_SOCKET_BUFFER
	TRACE("DEBUG %s - %p", __PRETTY_FUNCTION__, this);
#endif
}

/// SocketBuffer dtor
SocketBuffer::~SocketBuffer()
{
#ifdef DEBUG_SOCKET_BUFFER
	TRACE("DEBUG %s - %p", __PRETTY_FUNCTION__, this);
#endif
}

/** Sets the Socketbuffer to another buffer of bytes
 * \param[in] pBuff Buffer to set (copy)
 * \param[in] length Length of \a pBuff
 * \return Number of bytes copied
 * \note Performs a memcpy
 */
int SocketBuffer::SetBuf(const char *pBuff, int length)
{
	int ret = 0;
	Reset();
	if (SetLength(length))
	{
		memcpy(GetData(), pBuff, length);
		ret = length;
	}
	return ret;
}

}
