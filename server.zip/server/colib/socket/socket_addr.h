//socket_addr.h
// vi:set ts=4 sw=4 nowrap:

#ifndef SOCKET_ADDR_H_ALREADY_INCLUDED
#define SOCKET_ADDR_H_ALREADY_INCLUDED

#include <utils/string.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/un.h>

namespace colib
{

class SocketAddr
{
public:
	SocketAddr();
	SocketAddr(int type);
	SocketAddr(const SocketAddr &of);
	SocketAddr(string from_str);
	SocketAddr(const sockaddr *sock_addr, socklen_t len );
	SocketAddr(sockaddr *sock_addr, socklen_t len, unsigned short portno_host_byte_order);

	~SocketAddr();

	void Clear();

	SocketAddr& operator=(const SocketAddr &to);
	bool operator==(const SocketAddr &to) const;
	bool operator!=(const SocketAddr &to) const { return !(*this == to); }

	int GetType() const { return m_data ? m_data->sa_family : PF_UNSPEC; }
	bool IsEmpty() const { return NULL == m_data; }

	// set value from string "INET?;?????;###"
	bool SetFromString( string str );
	// put to string "INET?;?????;###"
	string PutToString() const;

	static bool GetAddrString(string AddrPort, string& AddrOnly);
	// static to string   "INET?;?????;###"
	static string PutToString(uint32_t ipv4_addr_net_order, unsigned short portno_host_order);
	static string PutToString(const SocketAddr &sock_addr, unsigned short portno_host_order);
	static string PutToString(const SocketAddr &sock_addr);
	static string PutToString(const sockaddr * sock_addr, unsigned short portno_host_order);
	static string PutToString(const sockaddr * sock_addr);
	// A.B.C.D + port => INET;A.B.C.D;port, also support IPV6 address
	static string PutToString(string addr_str, unsigned short portno_host_order);

	static string GetAddrAny(unsigned short portno_host_order);		//INET;0.0.0.0;port or INET6;::;port ?
	static string GetAddrLoopBack(unsigned short portno_host_order);	//INET;127.0.0.1;port or INET6;::1;port ?

	bool IsAddrLoopBack() const;

	// set value
	bool SetToIPv4AddrPort(uint32_t addr_net_byte_order, unsigned short portno_host_byte_order);
	bool SetTo(const SocketAddr &sock_addr, unsigned short portno_host_order);
	bool SetTo(const SocketAddr &sock_addr);
	bool SetTo(sockaddr * sock_addr, socklen_t len, unsigned short portno_host_order);
	bool SetTo(const sockaddr * sock_addr, socklen_t len);

	static int ExtractTypeFromString( string &str ); // the TYPE will be eliminated
	static bool IsTypeFormat(string str); // check if the address is in INET?;?????;### format
	static int GetPortFromString(const char* str);

	bool IsMulticastAddress() const;
	bool JoinMulticastGroup(int fd, string multicast_interface);
	bool SetMulticastTransmitInterface(int fd, string multicast_interface);

	//legacy IPv4 only function
	bool GetIPv4AddrPort(uint32_t &addr_net_byte_order, unsigned short &portno_host_byte_order);
	static bool GetIPv4AddrPortFromString(const char* str, uint32_t& addr_net, uint16_t& port_host);
	static string FormatIPv4AddrPort(uint32_t ipv4_addr_net_order, unsigned short portno_host_order);

	string GetInterfaceName();
	void SetAnyAddress(unsigned short portno_host_order);

	string GetIpString() const;
	uint16_t GetPort() const;
	void SetPort(uint16_t port_host_order);
	uint32_t GetIPv4Addr() const;

public:
	sockaddr *m_data;
	socklen_t m_data_len;

	bool SetType( int type );

private:
	static string ToStringIPv4(const sockaddr_in *pin, unsigned short portno_host_order);
	static string ToStringIPv4(uint32_t addr_net_order, unsigned short portno_host_order);
	static string ToStringIPv6(const sockaddr_in6 *pin6, unsigned short portno_host_order);
	static string ToStringUnix(const sockaddr_un *pun);
	bool FromStringIPv4(string str);
	bool FromStringIPv4ToIPv6(string str);
	bool FromStringIPv6(string str);
	bool FromStringUnix(string str);
};

}//end namespace colib

#endif

