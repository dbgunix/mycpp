#include<socket/sb_multi_encode.h>
#include<socket/socket_buffer_pool.h>
#include<socket/socket_buffer.h>
#include<utils/trace/trace.h>
#include<utils/system/macros.h>

namespace colib
{

static void ReturnBuffers(std::list<SocketBuffer*> &sb_list)
{
	for (auto it(sb_list.begin()); it != sb_list.end(); ++it)
	{
		SocketBufferPool::GetInstance().Return(*it);
	}
	sb_list.clear();
}

SocketBufferMultiEncoder::SocketBufferMultiEncoder(MemberSet* trace_set)
	: m_sb_list()
	, m_total_length(0)
	, m_trace_set(trace_set)
	, m_pool_empty(false)
{
	// always try to have 1 buffer ready
	SocketBuffer *init_buf = SocketBufferPool::GetInstance().Get();
	if (init_buf != NULL)
	{
		m_sb_list.push_back(init_buf);
	}
}

SocketBufferMultiEncoder::~SocketBufferMultiEncoder()
{
	if (!m_sb_list.empty())
	{
		member_TRACE(m_trace_set, 4, "multi encoder not emptied before dtor (%zu)\n", m_sb_list.size());
		ReturnBuffers(m_sb_list);
	}
}

bool SocketBufferMultiEncoder::WriteXdrBytes(const char* data, int len)
{
	SocketBuffer *cur_buf = !m_sb_list.empty() ? m_sb_list.back() : NULL;
	int offset = 0;
	do
	{
		if (cur_buf == NULL || cur_buf->BytesAvailable() <= 0)
		{
			cur_buf = SocketBufferPool::GetInstance().Get();
			if (cur_buf == NULL)
			{
				m_pool_empty = true;
				member_TRACE(m_trace_set, 2, "MultiEncoder failed to get buffer from pool\n");
				ReturnBuffers(m_sb_list);
				return false;
			}
			m_sb_list.push_back(cur_buf);
		}
		int bytes_to_copy = std::min(len, cur_buf->BytesAvailable());
		m_total_length += bytes_to_copy;
		cur_buf->AppendData(data+offset, bytes_to_copy);
		len -= bytes_to_copy;
		offset += bytes_to_copy;
	}
	while (len > 0);
	return true;
}

void SocketBufferMultiEncoder::PrependLength(unsigned int len)
{
	if (!m_sb_list.empty())
	{
		member_TRACE(m_trace_set, 9, "MultiEncoder prepending length %u\n", len);
		SocketBuffer* first = m_sb_list.front();
		*((unsigned int*) first->GetData()) = FLIP(len);
	}
	else
	{
		member_TRACE(m_trace_set, 0, "MultiEncoder empty, cannot prepend length\n");
	}
}

}
