#if !defined(__SB_MULTI_ENCODE_H__)
#define __SB_MULTI_ENCODE_H__

#include<utils/multi_enc_intf.h>

#include <list>

namespace colib
{

class SocketBuffer;
class MemberSet;

class SocketBufferMultiEncoder : public MultiEncodeIntf
{
public:
	SocketBufferMultiEncoder(MemberSet *trace_set);
	virtual ~SocketBufferMultiEncoder();

	virtual bool WriteXdrBytes(const char *data, int len);
	virtual unsigned int GetLength() const { return m_total_length; }
	virtual void PrependLength(unsigned int len);

	std::list<SocketBuffer*>& GetBufList() { return m_sb_list; }
	bool IsPoolEmpty() const { return m_pool_empty; }

	SocketBufferMultiEncoder(const SocketBufferMultiEncoder&) = delete;
	SocketBufferMultiEncoder& operator=(const SocketBufferMultiEncoder&) = delete;

private:
	std::list<SocketBuffer*> m_sb_list;
	int m_total_length;
	MemberSet *m_trace_set;
	bool m_pool_empty;
};

}

#endif
