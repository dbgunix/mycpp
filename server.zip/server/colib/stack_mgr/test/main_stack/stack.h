// stack.hpp
// vi:set ts=4 sw=4 nowrap:

#ifndef SSS_STACK_HPP_ALREADY_INCLUDED
#define SSS_STACK_HPP_ALREADY_INCLUDED

#include "stack_mgr/main_stack_mgr.h"
#include "console/session.h"
#include "ses.h"

namespace colib
{
	class SSSStack : public MainStackMgr
	{
		public:

			virtual						~SSSStack ();
										SSSStack ();

			const char*					GetApplicationName () const { return "SimpleStreamServer"; }
	
			void						ProcessSESConsoleCommand (ConsoleSession*, int, char* argv[]);

		protected:

			void						RegisterConsoleCommand ();
			static void					SESConsoleCommand (SSSStack*, ConsoleSession*, int, char* argv[]);

			bool						InitStack ();
			bool						ChangeStack (Options*, string&);

		private:

			SimpleEchoServer			m_echo_server;
	};

}//end namespace colib


#endif

