// stack.cpp
// vi:set ts=4 sw=4 nowrap:

#include "stack.h"
#include "console/role.h"
#include "console/command.h"
#include "console/broadcast.h"
#include "event_loop/event_loop.h"
#include "utils/trace/trace.h"
#include "socket/stream/console/console.h"
#include "options/file_options.h"

namespace colib
{
	SSSStack::SSSStack()
	{
	}

	SSSStack::~SSSStack()
	{
	}

	void				SSSStack::RegisterConsoleCommand()
	{
		MainStackMgr::RegisterConsoleCommand();	
	
		ConsoleCommand::Register(	
				CONSOLE_ROLE_EVERYONE,
				(ConsoleCommand::Handler*)SESConsoleCommand, this,
				"sss", "SimpleStreamServer control");	
	}
	
	void				SSSStack::SESConsoleCommand(SSSStack* stack, ConsoleSession* con, int argc, char* argv[])
	{
		if ( stack ) stack->ProcessSESConsoleCommand(con, argc, argv);
	}
	
	void				SSSStack::ProcessSESConsoleCommand(ConsoleSession* con, int argc, char* argv[])
	{
		m_echo_server.ProcessConsoleCommand(con, argc-1, argv+1);
	}
	
	bool				SSSStack::InitStack()
	{	
		if ( !MainStackMgr::InitStack() ) return false;

		string err;
		colib::FileOptions options;
		if ( !options.LoadFile("./ses.opt") )
		{
			TRACE("Load ses.opt failed\n");
			m_echo_server.Reload(0, err);
		}
		else
		{	
			ChangeStack(&options, err);
		}

		return true;
	}

	bool				SSSStack::ChangeStack(Options* opt, string& err)
	{
		if ( !m_echo_server.Reload(opt, err) ) return false;
		if ( !MainStackMgr::ChangeStack(opt, err) ) return false;
		return true;
	}

}//end namespace colib

