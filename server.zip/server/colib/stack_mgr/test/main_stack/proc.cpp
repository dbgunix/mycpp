#include "stack.h"

using namespace colib;

int main(int argc, char* argv[])
{	
	SSSStack stack;
	stack.Run(argc, argv);
	return 0;
}
