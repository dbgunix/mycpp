// vi:set ts=4 sw=4 nowrap:

#ifndef SIMPLE_ECHO_SERVER_HPP_ALREADY_INCLUDED
#define SIMPLE_ECHO_SERVER_HPP_ALREADY_INCLUDED

#include "config/value.h"
#include "socket/stream/stream_server.h"
#include "options/options.h"
#include "console/session.h"
#include "utils/trace/trace.h"

namespace colib
{
	class SimpleEchoServer
	{
		public:
		
			enum Params
			{
				Param_stream_server_address,
				Param_track_connection_enabled,
				ParamCount
			};
	
			enum Stats
			{
				Stat_num_active_connections,
				Stat_num_total_connections,	
				Stat_num_echo_bytes,
				StatCount
			};

										SimpleEchoServer ();
			virtual						~SimpleEchoServer ();

			bool						Reload (Options*, string&);	
			void						ProcessConsoleCommand (ConsoleSession*, int, char* argv[]);

		private:

			void						OnNewConnection (StreamClientHandler*);
			void						Echo (StreamBase*);			
			
		private:	
		
			StreamServer				m_echo_server;

			MemberSet					m_debug_set;

			ValueList					m_params;
			ValueList					m_stats;

	};
	#define SES_PARAM(param)			m_params[SimpleEchoServer::Param_##param].AsInt()
	#define SES_STR_PARAM(param)		m_params[SimpleEchoServer::Param_##param].AsString()
	#define SES_STAT(stat)				m_stats[SimpleEchoServer::Stat_##stat].AsInt()

}//end namespace colib


#endif

