// vi:set ts=4 sw=4 nowrap:

#include "ses.h"
#include "utils/callback.h"
#include "utils/string.h"

#include <ctype.h>

namespace colib
{
	static ValueList::ValueHolder InitParams()
	{
		return
		{
			Value("stream_server_address", "INET;0.0.0.0;9000"),
			Value("track_connection_enabled", 0 )
		};
	};

	static ValueList::ValueHolder InitStats()
	{
		return
		{
			Value("num_active_connections", 0 ),
			Value("num_total_connections", 0 ),
			Value("num_echo_bytes", 0)
		};
	};

	SimpleEchoServer::SimpleEchoServer()
		:
		m_echo_server("EchoServer", StreamBase::TlsOpt::DISABLE_TLS, StreamBase::XdrOpt::DISABLE_XDR),
		m_params(InitParams()),	m_stats(InitStats())
	{
		m_echo_server.SetNewClientCallback(callback(this, &SimpleEchoServer::OnNewConnection));
		m_echo_server.SetReadCallback(callback(this, &SimpleEchoServer::Echo));
	}

	SimpleEchoServer::~SimpleEchoServer()
	{
	}

	bool				SimpleEchoServer::Reload(Options* opt, string& err)
	{
		static bool first_time = true;

		OptionsNode grp;
		if ( opt ) grp = opt->GetOptionsNode("SES");
		string old_address = SES_STR_PARAM(stream_server_address);
		if ( !grp.IsEmpty() ) m_params.LoadFromOptions(grp);

		bool address_changed = ( old_address != SES_STR_PARAM(stream_server_address) );

		if ( first_time || address_changed || !strcmp(SES_STR_PARAM(stream_server_address), "") )
		{
			first_time = false;

			if ( !strcmp(SES_STR_PARAM(stream_server_address), "") )
			{
				err = "SimpleEchoServer server address invalid";
				return false;
			}
			if ( !m_echo_server.Init(SES_STR_PARAM(stream_server_address)) )
			{
				err = string::Format("Cannot start SimpleEchoServer on address %s", SES_STR_PARAM(stream_server_address));
				return false;
			}
		}

		return true;
	}
	
	void				SimpleEchoServer::OnNewConnection(StreamClientHandler*)
	{
		member_TRACE(&m_debug_set, 7, "SimpleEchoServer::NewClient accepted succeed\n");
		if ( SES_PARAM(track_connection_enabled) ) SES_STAT(num_total_connections)++;
	}

	void				SimpleEchoServer::Echo(StreamBase* socket)
	{
		char buf[128];

		if ( socket )
		{
			while ( true )
			{
				int num = socket->ReadBytes(buf, sizeof(buf));
				if ( num <= 0 ) break;
				socket->WriteBytes(buf, num);
				member_TRACE(&m_debug_set, 7, "SimpleEchoServer::Echo %d bytes succeed\n", num);
				SES_STAT(num_echo_bytes) += num;
			}
		}
	}

	void				SimpleEchoServer::ProcessConsoleCommand(ConsoleSession* con, int argc, char* argv[])
	{
		const char* usage = "Usage:\tparams|stats|debug {level|off}";

		if ( argc == 0 )
		{
			con->Print(usage); return;
		}
		
		if ( !strcmp(argv[0], "params") )
		{
			m_params.ConsoleCommand(con, argc-1, argv+1);
		}	
		else if ( !strcmp(argv[0], "stats") )
		{
			SES_STAT(num_active_connections) = m_echo_server.GetNumClients();
			m_stats.ConsoleCommand(con, argc-1, argv+1);
		}
		else if ( !strcmp(argv[0], "debug") )
		{
			if ( argc == 2 )
			{
				if ( !strcmp(argv[1], "off") )
				{
					m_debug_set.DropWritable(con);
				}
				else if ( isdigit((int)(*argv[1])) )
				{
					m_debug_set.AddWritable(atoi(argv[1]), con);
				}
				else con->Print(usage);
			}
			else con->Print(usage);
		}
		else con->Print(usage);	
	}

}//end namespace colib

