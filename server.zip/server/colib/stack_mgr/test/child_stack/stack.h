// stack.h
// vi:set ts=4 sw=4 nowrap:

#ifndef STACK_H_ALREADY_INCLUDED
#define STACK_H_ALREADY_INCLUDED

#include "stack_mgr/child_stack_mgr.h"

namespace colib
{
	class TestChildStack : public ChildStackMgr
	{
		public:

			virtual					~TestChildStack() {};
									TestChildStack() {};

			const char*				GetApplicationName () { return "TestChild"; }

			bool					StartConsole();

			void					RegisterConsoleCommand();
			static void				CmdPassword(void* ctx, ConsoleSession* con, int argc, char* argv[]);
	};

}//end namespace colib


#endif

