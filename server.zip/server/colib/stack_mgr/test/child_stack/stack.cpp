// stack.cpp
// vi:set ts=4 sw=4 nowrap:

#include "stack.h"
#include "socket/stream/console/console.h"
#include "console/role.h"
#include "console/interactive.h"

namespace colib
{
	struct ChgPasswdCtrl
	{
		int m_state;
		string m_first_input;
	};

	bool	TestChildStack::StartConsole()
	{
		GlobalTelnetConsoleServer::GetInstance().Init(SocketAddr::GetAddrAny(8000+GetProcID()));
		return ChildStackMgr::StartConsole();
	}

	void	TestChildStack::RegisterConsoleCommand()
	{
		ChildStackMgr::RegisterConsoleCommand();
	
		ConsoleCommand::Register(	
				CONSOLE_ROLE_EVERYONE,
				(ConsoleCommand::Handler*)CmdPassword, NULL,
				"passwd", "Change Password");
	}

	void	FreeChangePasswordParams(void* ctx)
	{
		ChgPasswdCtrl* ctrl = (ChgPasswdCtrl*)ctx;
		delete ctrl;
	}

	bool	ChangePasswordCallback(void* ctx, ConsoleSession* con, ConsolePrompt* prompt, int argc, char* argv[])
	{
		argc--; argv++;
		bool to_exit = false;
		ChgPasswdCtrl* ctrl = (ChgPasswdCtrl*)ctx;

		switch ( ctrl->m_state )
		{
			case 0 :
			{
				ctrl->m_state = 1;
				prompt->SetPrompt("New password: "); 
				prompt->SetEcho('*');
				break;
			}
			case 1 :
			{
				ctrl->m_state = 2;
				ctrl->m_first_input = prompt->GetBuffer();
				prompt->SetPrompt("Retype new password: "); 
				prompt->SetEcho('*');
				break;
			}
			case 2 :
			{
				ctrl->m_state = 3;
				string retype_passwd = prompt->GetBuffer();
				if ( retype_passwd != ctrl->m_first_input )
				{
					con->Print("Password not match!\n");
				}
				else
				{
					con->Print("Aha, you cannot change password from console!\n");
				}

				to_exit = true;
				break;
			}
			default: 
			{
				to_exit = true;
				break;
			}
		}	
		
		return !to_exit;
	}

	void	TestChildStack::CmdPassword(void* ctx, ConsoleSession* con, int argc, char* argv[])
	{
        (void)ctx; (void)con; (void)argc; (void)argv;
		ChgPasswdCtrl* ctrl = new ChgPasswdCtrl;
		ctrl->m_state = 0;
		con->EnterInteractive((InteractiveShell::Handler*)ChangePasswordCallback, (InteractiveShell::Releaser*)FreeChangePasswordParams, ctrl);
	}


}//end namespace colib

