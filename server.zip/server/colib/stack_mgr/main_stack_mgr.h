// main_stack_mgr.hpp
// vi:set ts=4 sw=4 nowrap:

#ifndef MAIN_STACK_MGR_HPP_ALREADY_INCLUDED
#define MAIN_STACK_MGR_HPP_ALREADY_INCLUDED

#include<stack_mgr/stack_mgr_base.h>

namespace colib
{
	const int	DEFAULT_TELNET_CONSOLE_PORT		=	13255;
	//
	// MainStackMgr
	//
	class MainStackMgr : public StackMgr
	{
		public:

			virtual							~MainStackMgr();
											MainStackMgr(
														bool manage_child_proc = false,
														bool manage_thirdparty_child_proc = false);	
								
			void							Run(int argc, char* argv[]);

		protected:

			bool							ParseCmdLine(int argc, char* argv[]);
			string							CmdLineHelp();

			bool							InitStack();
			void							StartupLog(int, const char*);

		protected:
	
			StandaloneControl				m_standalone_control;
	};

}//end namespace colib

#endif
