// child_stack_mgr.cpp
// vi:set ts=4 sw=4 nowrap:

#include<stack_mgr/child_stack_mgr.h>
#include<socket/stream/console/uni_console.h>
#include<utils/trace/trace.h>
#include<console/role.h>

#include <ctype.h>
#include <syslog.h>
#include <sys/types.h>
#include <unistd.h>

namespace colib
{	
	//
	// ChildStackMgr
	//
	ChildStackMgr::ChildStackMgr(bool manage_child_proc, bool manage_thirdparty_child_proc)
		:
		StackMgr(manage_child_proc, manage_thirdparty_child_proc),
		m_hb_client(this)	
	{	
	}

	ChildStackMgr::~ChildStackMgr()
	{
	}

	string					ChildStackMgr::CmdLineHelp()
	{
		return StackMgr::CmdLineHelp() + " " + "-pn name" + " " + m_hb_client.CmdLineHelp();
	}

	bool					ChildStackMgr::ParseCmdLine(int argc, char* argv[])
	{	
		for ( int i = 1; i < argc; i++ )
		{	
			if ( !strcmp(argv[i], "-pn") )
			{
				i++;
				if ( argc <= i ) 
				{
					PrintCmdLineHelp(argv[0]);
					return false;
				}
				m_proc_name = string(argv[i]);
			}
		}

		if ( !m_hb_client.ParseCmdLine(argc, argv) )
		{	
			PrintCmdLineHelp(argv[0]);
			return false;	
		}

		return StackMgr::ParseCmdLine(argc, argv);
	}

	bool					ChildStackMgr::InitStack()
	{
		if ( !StackMgr::InitStack() ) return false;
			
		string err;
		if ( !m_hb_client.Init(err) )
		{
			TRACE("ChildStackMgr::InitStack - fail to init ChildHBClient (%s)\n", err.c_str());
			return false;
		}
	
		return true;
	}

	bool					ChildStackMgr::StartConsole()
	{
		if ( !StackMgr::StartConsole() ) return false;

		string path = UniConsoleServer::ConnectPath(GetProcName(), GetProcID());
		if ( GetChildProcessMgr() ) return UniConsoleServer::GetInstance().InitInternal(GetProcName(), "UNIX;" + path);
		else return GlobalInternalConsoleServer::GetInstance().Init("UNIX;" + path);
	}

	void					ChildStackMgr::RegisterConsoleCommand()
	{
		StackMgr::RegisterConsoleCommand();
	
		ConsoleCommand::Register(	
				CONSOLE_ROLE_EVERYONE,
				(ConsoleCommand::Handler*)IPCConsoleCommand, this,
				"heartbeat", "Heartbeat IPC control");
	}

	void					ChildStackMgr::IPCConsoleCommand(ChildStackMgr* stack, ConsoleSession* con, int argc, char* argv[])
	{
		if ( stack ) stack->m_hb_client.ConsoleCommand(con, argc-1, argv+1);
	}

}//end namespace colib

