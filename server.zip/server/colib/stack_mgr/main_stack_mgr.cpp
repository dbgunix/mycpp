// main_stack_mgr.cpp
// vi:set ts=4 sw=4 nowrap:

#include<stack_mgr/main_stack_mgr.h>
#include<socket/stream/console/console.h>

#include <stdlib.h>
#include <sched.h>
#include <string.h>
#include <stdio.h>
#include <ctype.h>
#include <syslog.h>
#include <unistd.h>
#include <sys/wait.h>

namespace colib
{
	//
	// MainStackMgr
	//
	MainStackMgr::MainStackMgr(bool manage_child_proc, bool manage_thirdparty_child_proc)
		:
		StackMgr(manage_child_proc, manage_thirdparty_child_proc)	
	{
		SetConsolePort(DEFAULT_TELNET_CONSOLE_PORT);
	}

	MainStackMgr::~MainStackMgr()
	{
	}

	string					MainStackMgr::CmdLineHelp()
	{
		return StackMgr::CmdLineHelp() + " " + m_standalone_control.CmdLineHelp();
	}

	bool					MainStackMgr::ParseCmdLine(int argc, char* argv[])
	{	
		if ( !m_standalone_control.ParseCmdLine(argc, argv) )
		{
			PrintCmdLineHelp(argv[0]);
			return false;
		}
	
		return StackMgr::ParseCmdLine(argc, argv);
	}

	void					MainStackMgr::StartupLog(int level, const char* s)
	{	
		openlog(GetProcName(), 0, LOG_USER);
		syslog(level, "%s", s);
		closelog();
	}

	bool					MainStackMgr::InitStack()
	{
		if ( !m_standalone_control.Init() ) return false;
		return StackMgr::InitStack();
	}

	void					MainStackMgr::Run(int argc, char* argv[])
	{
		StackMgr::Run(argc, argv);
		m_standalone_control.Run();
	}

}//end namespace colib
