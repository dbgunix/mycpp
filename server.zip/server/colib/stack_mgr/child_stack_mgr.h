// child_stack_mgr.hpp
// vi:set ts=4 sw=4 nowrap:

#ifndef CHILD_STACK_MGR_HPP_ALREADY_INCLUDED
#define CHILD_STACK_MGR_HPP_ALREADY_INCLUDED

#include<stack_mgr/stack_mgr_base.h>
#include<proc_mgr/child_hb_client.h>
#include<console/session.h>


namespace colib
{	
	//
	// ChildStackMgr
	//
	class ChildStackMgr : public StackMgr
	{
		public:

			virtual 						~ChildStackMgr();
											ChildStackMgr(
														bool manange_child_proc = false, 
														bool manage_thirdparty_child_proc = false);

			virtual const char*				GetProcName() { return m_proc_name == "" ? StackMgr::GetProcName() : m_proc_name.c_str(); }					

			ChildHBClient*					GetIPCClientToParent() { return &m_hb_client; }

		protected:

			bool							ParseCmdLine(int argc, char* argv[]);
			string							CmdLineHelp();

			bool							InitStack();
			bool							StartConsole();
			void							RegisterConsoleCommand();
	
		protected:
			//
			// Console Command
			//
			static void						IPCConsoleCommand (ChildStackMgr*, ConsoleSession*, int, char* argv[]);

		protected:
	
			string							m_proc_name;
			ChildHBClient					m_hb_client;
	};

}//end namespace colib


#endif

