// stack_mgr_base.hpp
// vi:set ts=4 sw=4 nowrap:

#ifndef STACK_MGR_BASE_HPP_ALREADY_INCLUDED
#define STACK_MGR_BASE_HPP_ALREADY_INCLUDED

#include<proc_mgr/colib_proc_mgr.h>
#include<proc_mgr/thirdparty_proc_mgr.h>
#include<utils/string.h>
#include<options/options.h>

namespace colib
{
	//
	// StackMgr
	//
	class StackMgr : public ProcInterface
	{
		public:

			virtual							~StackMgr();
											StackMgr(bool manage_child_proc, bool manage_thirdparty_child_proc);											
			//
			// Pure virtual functions
			//
			virtual const char*				GetApplicationName() const = 0;
			//
			// Child Process Manager
			//
			ProcessMgr*						GetChildProcessMgr() { return m_manage_child_proc ? &m_child_proc_mgr : 0; }
			ProcessMgr*						GetThirdpartyChildProcessMgr() { return m_manage_thirdparty_child_proc ? &m_thirdparty_child_proc_mgr : 0; }
			//
			// Main
			//
			virtual void					Run(int argc, char* argv[]);
			//
			// Functions for ProcInterface
			//
			virtual const char*				GetProcName() const { return GetApplicationName(); }
			virtual int						GetProcID() const { return m_proc_id; }

		protected:
			//
			// Unless very necesary, don't change runtime directory
			//
			virtual const char*				RuntimeDir() const { return "/var/run/rt"; }
			//
			// Console
			//
			void							SetConsolePort(int console_port) { m_console_port = console_port; }
			virtual bool					StartConsole();
			virtual const char*				ConsolePrompt();
			//
			// Console Command
			//
			virtual void					RegisterConsoleCommand();	
			static void						ProcConsoleCommand(StackMgr*, ConsoleSession*, int, char* argv[]);	
			static void						ThirdpartyProcConsoleCommand(StackMgr*, ConsoleSession*, int, char* argv[]);	
			//
			// Parsing Cmd Line
			//
			void							PrintCmdLineHelp(const char* app_name = 0);
			bool							FixCmdLine(int argc, char* argv[]);
			virtual bool					ParseCmdLine(int argc, char* argv[]);
			virtual string					CmdLineHelp();
			//
			// Stack Init
			//
			virtual bool					InitStack();
			virtual bool					ChangeStack(Options* opt, string& err);
			virtual void					StartupLog(int, const char*);

		protected:

			bool							m_manage_child_proc;
			bool							m_manage_thirdparty_child_proc;

			ColibProcessMgr				m_child_proc_mgr;
			ThirdpartyProcessMgr			m_thirdparty_child_proc_mgr;

			int								m_console_port;
			int								m_proc_id;
			string							m_root_prompt;
			bool							m_change_dir;

		protected:

			int								m_argc;
			char*							m_argv[COMMAND_ARGC_MAX];				
	};
	
	//
	// Standalone control
	// 
	class StandaloneControl
	{
		public:

											StandaloneControl();
			virtual							~StandaloneControl();								

			string							CmdLineHelp();
			bool							ParseCmdLine(int argc, char* argv[]);
			bool							Init();
			void							Run();

		private:

			bool							m_daemon;
			bool							m_realtime;	
	};

}//end namespace iDirect

#endif
