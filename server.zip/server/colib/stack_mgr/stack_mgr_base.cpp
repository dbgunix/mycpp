// stack_mgr_base.cpp
// vi:set ts=4 sw=4 nowrap:

#include <stack_mgr/stack_mgr_base.h>
#include <utils/trace/trace.h>
#include <utils/trace/syslogger.h>
#include <utils/trace/stdio_writable.h>
#include <event_loop/event_loop.h>
#include <version/version.h>
#include <version_registrar/version_registrar.h>
#include <version/version_str.h>
#include <socket/stream/console/console.h>
#include <socket/stream/console/uni_console.h>
#include <console/command.h>
#include <console/manager.h>
#include <console/role.h>
#include <console/periodic.h>
#include <config/global_params.h>
#include <socket/socket_buffer_pool.h>

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <syslog.h>
#include <sys/wait.h>
#include <errno.h>
#include <unistd.h>

namespace colib
{

	void					AssertTrace(const char* message, const char* file, const unsigned line)
	{
		TRACE("Assertion Failed: %s[%u] ==> '%s'\r\n", file, line, message);
		abort();
	}

	static void				sigterm_handler(int)
	{
		static bool called = false;
		if ( called ) abort();
		EventLoop::GetInstance().Terminate(called = true);
	}

	static void				sigpipe_handler(int)
	{
	}	
	
	static int				set_realtime_priority(void)
	{
		struct sched_param schp;
		memset(&schp, 0, sizeof(schp));
		schp.sched_priority = sched_get_priority_max(SCHED_FIFO);
		if ( sched_setscheduler(0, SCHED_FIFO, &schp) != 0 ) 
		{
			perror("sched_setscheduler");
			return -1;
		}
		return 0;
	}

	//
	// StandaloneControl
	//
	StandaloneControl::StandaloneControl()
		:
		m_daemon(true), 
		m_realtime(false) 
	{
	}

	StandaloneControl::~StandaloneControl()
	{
	}

	string					StandaloneControl::CmdLineHelp()
	{
		return "[debug] [realtime]";
	}

	bool					StandaloneControl::ParseCmdLine(int argc, char* argv[])
	{	
		for ( int i = 1; i < argc; i++ )
		{
			if ( !strcmp(argv[i], "debug") )
			{
				m_daemon = false;
			}
			else if ( !strcmp(argv[i], "realtime") )
			{
				m_realtime = true;
			}
		}

		return true;
	}
	
	bool					StandaloneControl::Init()
	{	
		if ( m_daemon ) daemon(1, 0);	
		if ( m_realtime ) set_realtime_priority();
		return true;
	}

	void					StandaloneControl::Run()
	{
		if ( !m_daemon ) while(waitpid(0, 0, WNOHANG) > 0) {};
	}

	//
	// StackMgr
	//
	StackMgr::StackMgr(bool manage_child_proc, bool manage_thirdparty_child_proc)
		:
		m_manage_child_proc(manage_child_proc),
		m_manage_thirdparty_child_proc(manage_thirdparty_child_proc),
		m_child_proc_mgr(this),
		m_console_port(0),
		m_proc_id(0),
		m_change_dir(true),
		m_argc(0)
	{
		for ( int i = 0; i < COMMAND_ARGC_MAX; i++ )
		{
			m_argv[i] = 0;
		}
	}

	StackMgr::~StackMgr()
	{
		//
		// Memory leak of m_argv[]?
		// Who care ... process already exit
		//
	}

	const char*				StackMgr::ConsolePrompt()
	{
		m_root_prompt = GetProcName();
		if ( m_proc_id ) m_root_prompt.AppendFmt("(%d)", m_proc_id);
		return m_root_prompt;
	}

	void					StackMgr::RegisterConsoleCommand()
	{
		ConsoleGlobal::GetInstance().RegisterConsoleCommand();

		if ( m_manage_child_proc )
		{
			ConsoleCommand::Register(
					CONSOLE_ROLE_EVERYONE,
					(ConsoleCommand::Handler*)ProcConsoleCommand, this,
					"proc", "ChildProc control");
		}

		if ( m_manage_thirdparty_child_proc )
		{
			ConsoleCommand::Register(
					CONSOLE_ROLE_EVERYONE,
					(ConsoleCommand::Handler*)ThirdpartyProcConsoleCommand, this,
					"third_proc", "Thirdparty ChildProc control");
		}
	}

	void					StackMgr::ProcConsoleCommand(StackMgr* stack, ConsoleSession* con, int argc, char* argv[])
	{
		ProcessMgr* mgr = stack ? stack->GetChildProcessMgr() : NULL;
		if ( mgr ) mgr->ConsoleCommand(con, argc-1, argv+1);
	}

	void					StackMgr::ThirdpartyProcConsoleCommand(StackMgr* stack, ConsoleSession* con, int argc, char* argv[])
	{
		ProcessMgr* mgr = stack ? stack->GetThirdpartyChildProcessMgr() : NULL;
		if ( mgr ) mgr->ConsoleCommand(con, argc-1, argv+1);
	}

	string					StackMgr::CmdLineHelp()
	{
		return "--version | [-pid proc_id] [-cp console_port] [nocd]";
	}

	void					StackMgr::PrintCmdLineHelp(const char* app_name )
	{
		string usage = string::Format("Usage:\n%s %s", app_name ? app_name : "", CmdLineHelp().c_str());
		fprintf(stderr, "%s\n", usage.c_str());
	}

	bool					StackMgr::FixCmdLine(int argc, char* argv[])
	{
		if ( argc < 1 ) return false;
		string input = string(argv[0]);
		for ( int i = 1; i < argc; i++)
		{
			input.AppendFmt(" %s", argv[i]);
		}
		char* line = input.detach();

		m_argc = 0;
		m_argv[argc++] = 0;

		char ch = '\0';
		while ( *line != '\0' )
		{
			switch (*line)
			{
				case ' ':
				case '\t':
				{
					*line = '\0';
					break;
				}
				default:
				{
					if (ch == '\0')
					{
						m_argv[m_argc++] = line;
						if ( m_argc == COMMAND_ARGC_MAX ) return false;
					}
					break;
				}
			}
			ch = *line++;
		}

		return true;
	}

	bool					StackMgr::ParseCmdLine(int argc, char* argv[])
	{
		if ( argc == 1 )
		{
			fprintf(stderr, "%s will run with default parameters. Use \"--help\" for usage\n", argv[0]);
		}
		else
		{
			for ( int i = 1; i < argc; i++ )
			{
				if ( !strcmp(argv[i], "--version") )
				{
					StdioWritable err_out;
					// look at next argument (if there is one)
					if ((i+1 < argc) && strcmp(argv[i+1], "full") == 0)
					{
						// consume the argument
						++i;
						VersionRegistrar::GetInstance().PrintFull(&err_out);
					}
					else
					{
						VersionRegistrar::GetInstance().PrintBrief(&err_out);
					}
					return false;
				}
				else if ( !strcmp(argv[i], "-pid") )
				{
					i++;
					if ( ( argc <= i ) || !isdigit((int)(*argv[i])) )
					{
						PrintCmdLineHelp(argv[0]);
						return false;
					}
					m_proc_id = atoi(argv[i]);
				}
				else if ( !strcmp(argv[i], "-cp") )
				{
					i++;
					if ( ( argc <= i ) || !isdigit((int)(*argv[i])) )
					{
						PrintCmdLineHelp(argv[0]);
						return false;
					}
					SetConsolePort(atoi(argv[i]));
				}
				else if ( !strcmp(argv[i], "nocd") )
				{
					m_change_dir = false;
				}
				else if ( !strcmp(argv[i], "--help") )
				{
					PrintCmdLineHelp(argv[0]);
					return false;
				}
			}
		}

		return true;
	}

	void					StackMgr::StartupLog(int, const char* s)
	{
		TRACE(s);
	}

	bool					StackMgr::StartConsole()
	{
		if ( m_console_port != 0 )
		{
            // @ modify by zhanlu
			// if ( m_manage_child_proc ) return UniConsoleServer::GetInstance().InitTelnet(GetProcName(), SocketAddr::GetAddrLoopBack(m_console_port));
			// else return GlobalTelnetConsoleServer::GetInstance().Init(SocketAddr::GetAddrLoopBack(m_console_port));
            //
			if ( m_manage_child_proc ) return UniConsoleServer::GetInstance().InitTelnet(
                    GetProcName(), SocketAddr::GetAddrAny(m_console_port));
			else return GlobalTelnetConsoleServer::GetInstance().Init(
                    SocketAddr::GetAddrAny(m_console_port));
		}

		return true;
	}

	bool					StackMgr::InitStack()
	{
		//
		// Event loop
		//
		if ( !EventLoop::GetInstance().Initialize() )
		{
			return false;
		}

		// Console
		ConsoleManager::GetInstance().SetName(ConsolePrompt());

		if ( !StartConsole() )
		{
			string info = string::Format(
					"Failed to start console service ...\n"
					"Please ensure that no other %s running with the same configuration\n",
				   	GetProcName());
			StartupLog(LOG_ERR, info.c_str());
			return false;
		}

		RegisterConsoleCommand();

		// Trace
		// NOTE: this must be after StartConsole (which calls TraceToConsole)
		// TraceToConsole() will overwrite the trace function pointers
		Syslogger::instance.Enable(GetProcName());

		// Assert
		colib::OnAssert = AssertTrace;

		SocketBufferPool::GetInstance().Init(10000);

		ProcessMgr* mgr = GetChildProcessMgr();
		if ( mgr )
		{
			string err;
			if ( !mgr->Init(err) )
			{
				StartupLog(LOG_ERR, err.c_str());
				return false;
			}
		}

		ProcessMgr* thirdparty_mgr = GetThirdpartyChildProcessMgr();
		if ( thirdparty_mgr )
		{
			string err;
			if ( !thirdparty_mgr->Init(err) )
			{
				StartupLog(LOG_ERR, err.c_str());
				return false;
			}
		}

		return true;
	}

	bool					StackMgr::ChangeStack(Options* opt, string& err)
	{
		GlobalParams::GetInstance().LoadFromOptions(*opt);

		ProcessMgr* mgr = GetChildProcessMgr();
		if ( mgr && !mgr->Reload(opt, err) )
		{
			TRACE("StackMgr::ChangeStack - fail to reload ColibChildProcessMgr (%s)\n", err.c_str());
			return false;
		}

		ProcessMgr* thirdparty_mgr = GetThirdpartyChildProcessMgr();
		if ( thirdparty_mgr && !thirdparty_mgr->Reload(opt, err) )
		{
			TRACE("StackMgr::ChangeStack - fail to reload ThirdpartyChildProcessMgr (%s)\n", err.c_str());
			return false;
		}

		return true;
	}

	void					StackMgr::Run(int argc, char* argv[])
	{
		// provide application name to version registrar
		VersionRegistrar::GetInstance().SetApplicationName(GetApplicationName());

		if ( !FixCmdLine(argc, argv) || !ParseCmdLine(m_argc, m_argv) ) return;

		struct sigaction sa;
		sa.sa_handler = sigterm_handler;
		sa.sa_flags = 0;
		sigemptyset(&sa.sa_mask);
		if ( -1 == sigaction(SIGTERM, &sa, 0) )
		{	
			StartupLog(LOG_ERR, "Failed to set SIGTERM signal handler\n");
			return;
		}
		if ( -1 == sigaction(SIGINT, &sa, 0) )
		{
			StartupLog(LOG_ERR, "Failed to set SIGINT signal handler\n");
			return;
		}

		sa.sa_handler = sigpipe_handler;
		if ( -1 == sigaction(SIGPIPE, &sa, 0) )
		{
			StartupLog(LOG_ERR, "Failed to set SIGPIPE signal handler\n");
			return;
		}

		string info = string::Format("Initializing %s ...\n", GetProcName());
		StartupLog(LOG_INFO, info.c_str());

		if ( m_change_dir && chdir(RuntimeDir()) )
		{
			string error = string::Format(
				"Failed to change to %s: %s\n"
				"Please ensure that %s is correctly installed\n",
				RuntimeDir(), strerror(errno), GetProcName());
			StartupLog(LOG_ERR, error.c_str());
			return;
		}

		if ( !InitStack() )
		{
			string error = string::Format(
				"Failed to initialize %s stack, exiting ...\n",
				GetProcName());
			StartupLog(LOG_ERR, error.c_str());
			return;
		}

		// Event loop listening
		EventLoop::GetInstance().Main();
	}

}//end namespace colib

