#ifndef _ACTIVITY_MANAGER__
#define _ACTIVITY_MANAGER__

#include<utils/string.h>
#include<utils/data_struct/dlist.h>


namespace colib
{

// Nicely separate the manager from the Keeper
// and use forward declarations.
// This way, there are no nasty dependencies.
// The user class to know the event_loop.h only

class ActivityHold;
typedef ActivityHold* ActivityHoldPtr;
class Writable;


class ActivityManager
{
public:
	ActivityManager();
	~ActivityManager();

	bool AddActivity(ActivityHoldPtr actHolder);
	bool DeleteActivity(ActivityHoldPtr actHolder);
	void Go();
	colib::string Dump() const;
	void Dump(Writable *to) const;
	bool HasActivities() const;

private:
	Dlist<ActivityHold*> m_first_list;
	Dlist<ActivityHold*> m_second_list;
	Dlist<ActivityHold*>* mp_activity_list;
	Dlist<ActivityHold*>* mp_new_list;

	colib::string DumpList(Dlist<ActivityHold*>* pList) const;
	void ClearList(Dlist<ActivityHold*>* pList);

	ActivityManager& operator=(const ActivityManager&);
	ActivityManager(const ActivityManager&);

};

typedef ActivityManager* ActivityManagerPtr;

}
#endif

