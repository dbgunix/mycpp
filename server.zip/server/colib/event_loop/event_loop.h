#if !defined(_EVENT_LOOP_EPOLL_H__)
#define _EVENT_LOOP_EPOLL_H__

#include<timer/timekeeper_intf.h>
#include<utils/mono_time.h>

#include <sys/epoll.h>
#include <sys/time.h>
#include <map>


namespace colib
{
class Writable;
class ActivityHold;
class ActivityManager;
class FileDescriptorHandler;

class EventLoop
{
public:
	~EventLoop();

	static EventLoop& GetInstance();

	bool Initialize();
	void Main();
	void Close();

	void Terminate(bool terminate) { m_Terminate = terminate; }
	bool OnMainLoopError(int err) const;  // return value == is fatal error?

	bool AddHandler(FileDescriptorHandler &handler);
	bool RemoveHandler(FileDescriptorHandler &handler);

	bool AddActivity(ActivityHold* actHold);
	bool DeleteActivity(ActivityHold* actHold);

	bool SetFDBit(FileDescriptorHandler &handler);
	bool ClearFDBit(FileDescriptorHandler &handler);
	bool ModifyFDBit(FileDescriptorHandler &handler);

	void DumpStatus(Writable *to) const;
	void ResetStatus();

	void ConsoleCommand(Writable *to, int argc, char *argv[]);

	EventLoop(const EventLoop&) = delete;
	EventLoop& operator=(const EventLoop&) = delete;

private:
	typedef std::map<int, FileDescriptorHandler*> FileDescHandlerMap;
	/// max number of simultaneous fd events
	// (may need adjusting)
	static const int MAX_EVENTS = 128;

	/// Timekeeper instance interface
	TimeKeeperIntf &m_timekeeper;
	/// Epoll file descriptor
	int m_epoll_fd;
	/// Container of epoll events
	epoll_event m_epoll_events[MAX_EVENTS];
	/// Dirty flag for file descriptor container
	bool m_handlers_modified;
	/// Terminate flag
	bool m_Terminate;
	/// Container of FileDescriptorHandlers, sorted by file descriptor
	FileDescHandlerMap m_fd_map;
	/// ActivityManager
	ActivityManager *m_act_mgr;

	EventLoop();
	MonoTime GetWaitOptions();
	void DispatchExpiredTimers() { m_timekeeper.DispatchTimers(); }
	bool HandleFdActivity();
	//void Debug0ReadyFd();
	void DumpFdStatus(Writable *to) const;
	void DumpTimerStatus(Writable *to) const { m_timekeeper.DumpStatus(to); }
	void DumpActStatus(Writable *to) const;
	void DispatchFdActivity(int numEvents, epoll_event *event_list);

	// Debug stuff
	static const unsigned int DEBUG_SERVICE_CALL_THRESHOLD = 20; // ms
};

}

#endif
