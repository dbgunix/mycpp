#include<event_loop/fdh.h>
#include<event_loop/event_loop.h>
#include<utils/trace/writable.h>
#include<utils/trace/trace.h>

#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>

namespace colib
{

/** FileDescriptorHandler ctor
 * \param[in] name Name of the file descriptor
 * \param[in] fd File descriptor integer
 * \param[in] flag Bitmask of event flags
 */
FileDescriptorHandler::FileDescriptorHandler(string name, int fd, unsigned int flag)
	: m_name(name)
	, m_fd(fd)
	, m_read_count(0)
	, m_write_count(0)
	, m_flag(flag | EXCEPTION_NOTIFY_FLAG)
	, m_allowed_flags(ALL_FLAGS)
{
	/* guarantee Eloop is created before FDH (and destroyed after).
	 * solves static ctor/dtor problem between Eloop and global
	 * telnet console (and possibly others in the future).
	 */
	EventLoop::GetInstance();
}

/** FileDescriptorHandler ctor
 * \param[in] name Name of the file descriptor
 */
FileDescriptorHandler::FileDescriptorHandler(string name)
	: m_name(name)
	, m_fd(-1)
	, m_read_count(0)
	, m_write_count(0)
	, m_flag(READ_NOTIFY_FLAG | EXCEPTION_NOTIFY_FLAG)
	, m_allowed_flags(ALL_FLAGS)
{
	/* guarantee Eloop is created before FDH (and destroyed after).
	 * solves static ctor/dtor problem between Eloop and global
	 * telnet console (and possibly others in the future).
	 */
	EventLoop::GetInstance();
}

/** FileDescriptorHandler dtor
 */
FileDescriptorHandler::~FileDescriptorHandler()
{
	if (m_fd > 0)
	{
		EventLoop::GetInstance().RemoveHandler(*this);
		close(m_fd);
		m_fd = -1;
	}
}

void FileDescriptorHandler::Reset()
{
	m_read_count = 0;
	m_write_count = 0;
}

void FileDescriptorHandler::PrintStatus(Writable* to) const
{
	const char* isREAD = READ_NOTIFY_FLAG & m_flag ? "READ ": " " ;
	const char* isWRITE = WRITE_NOTIFY_FLAG & m_flag ? "WRITE ": " " ;
	const char* isEXCEP = EXCEPTION_NOTIFY_FLAG & m_flag ? "EXCEP ": " " ;

	to->Print("%p fd:%d \"%s\" Use Count: %d/%d %s%s%s\n",
		this,
		m_fd,
		m_name.c_str(),
		m_read_count,
		m_write_count,
		isREAD, isWRITE, isEXCEP);
}

bool FileDescriptorHandler::MakeNonBlocking()
{
	int flags = fcntl(m_fd, F_GETFL, 0);
	if (flags < 0)
	{
		TRACE("%s fcntl() get flags failed: %s\n", GetName().c_str(), strerror(errno));
		return false;
	}
	if (fcntl(m_fd, F_SETFL, flags | O_NONBLOCK) == -1)
	{
		TRACE("%s set O_NONBLOCK failed: %s\n", GetName().c_str(), strerror(errno));
		return false;
	}
	return true;
}

/** Update mask of events and notify event loop (if needed)
 * \param[in] flag Mask of events
 */
bool FileDescriptorHandler::ChangeFlag(unsigned int flag)
{
	// mask out flags that have been disabled
	unsigned int new_flags = flag & m_allowed_flags;
	if (m_flag != new_flags)
	{
		// always set exception flags
		m_flag = new_flags | EXCEPTION_NOTIFY_FLAG;
		EventLoop::GetInstance().ModifyFDBit(*this);
		return true;
	}
	return false;
}

}
