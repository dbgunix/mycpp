#include<event_loop/activity_mgr.h>
#include<event_loop/activity_hld.h>
#include<utils/trace/trace.h>
#include<utils/trace/writable.h>

//#define DEBUG_TIME_SPEND 1

#ifdef DEBUG_TIME_SPEND
        #define DEBUG_TIME_SPEND_DISPATCH 1
    #include<utils/time.h>
#endif


namespace colib
{
	ActivityManager::ActivityManager()
	: mp_activity_list(&m_first_list)
	, mp_new_list(&m_second_list)

	{
	}

	ActivityManager::~ActivityManager()
	{
		ClearList(mp_activity_list);
		ClearList(mp_new_list);
	}

	bool ActivityManager::AddActivity(ActivityHoldPtr actHolder)
	{
		if (!actHolder) {
			//uups
			return false;
		}

		if(actHolder->m_node.m_parent) {
			// *** If it is on a list, it will be service anyway
			// *** If on the new list it will be serviced in the next loop
			// *** return value should detemine whether to service activity again.
			return true;
		}

		mp_new_list->Append(&actHolder->m_node);
		actHolder->pActMgr = this;
		return true;
	}

	bool ActivityManager::DeleteActivity(ActivityHoldPtr actHolder)
	{
		if (!actHolder) {
			return false;			//uups
		}
		if (!actHolder->m_node.m_parent) {
			return false;			//uups
		}

		actHolder->m_node.SelfExtract();
		return true;
	}

	void ActivityManager::ClearList(Dlist<ActivityHold*>* pList)
	{
		Dlist<ActivityHold*>::Node* head;
		while (0 != (head=pList->GetHead())) {
			ActivityHoldPtr pAct = head->GetData();
			DeleteActivity(pAct);
		}
	}

	void ActivityManager::Go()
	{
#ifdef DEBUG_TIME_SPEND
		colib::Time t0;
		t0.SetToNow();
#endif
		Dlist<ActivityHold*>* p_old_activity_list = mp_activity_list;
		mp_activity_list = mp_new_list;
		mp_new_list = p_old_activity_list;

		Dlist<ActivityHold*>::Node* head;
		while ( 0 != (head=mp_activity_list->GetHead()) ) {

#ifdef DEBUG_TIME_SPEND_DISPATCH
			colib::Time t0;
			t0.SetToNow();
#endif

			ActivityHoldPtr pAct = head->GetData();

			eCallbackRt bRunAgain = pAct->m_callback.Dispatch();

			/* make sure this activity is still valid
			 * if the activity was destroyed in the dispatch, then
			 * the "cached" head and current head will be different
			 * (activity's dtor will extract it from the dlist)
			 */
			if (head != mp_activity_list->GetHead())
			{
				return;
			}
			pAct->m_node.SelfExtract();

#ifdef DEBUG_TIME_SPEND_DISPATCH
			colib::Time t1;
			t1.SetToNow();
			long tDiff = t1.ConvertToMs() - t0.ConvertToMs();
			if ((tDiff) > THRESHOLD_MSEC) TRACE("Warning: Activity (%s) took %lums\r\n", pAct->m_name.c_str(), tDiff);
#endif

			// Return value prevails
			if (bRunAgain == RunAgain) {
				// Could have been added back again, while in Dispatch
				// which is fine, it is already on the new list.
				AddActivity(pAct);
			}
		}

#ifdef DEBUG_TIME_SPEND
		colib::Time t1;
		t1.SetToNow();
		long tDiff = t1.ConvertToMs() - t0.ConvertToMs();
		if (tDiff > THRESHOLD_MSEC)	TRACE("Warning: ActivityKeeper::Go took %lums\n", tDiff);
#endif
	}

	string ActivityManager::Dump() const
	{
		string ret(256);
		ret.AppendFmt("Current activities: %i\n", mp_activity_list->Size());
		ret += DumpList(mp_activity_list);

		ret.AppendFmt("New activities: %i\n", mp_new_list->Size());
		ret += DumpList(mp_new_list);

		return ret;
	}

	void ActivityManager::Dump(Writable* to) const
	{
		to->Print("Current Activities: %d\n", mp_activity_list->Size());
		for (auto node = mp_activity_list->GetHead(); node; node = mp_activity_list->GetNext(node))
		{
			node->GetData()->Print(to);
		}
		to->Print("New Activities: %d\n", mp_new_list->Size());
		for (auto node = mp_new_list->GetHead(); node; node = mp_new_list->GetNext(node))
		{
			node->GetData()->Print(to);
		}
	}

	string ActivityManager::DumpList(Dlist<ActivityHold*>* pList) const
	{
		colib::string ret;
		Dlist<ActivityHold*>::Node* head = pList->GetHead();

		while ( head != 0)
		{
			ActivityHoldPtr act = head->GetData();
			ret += act->Dump();
			head = pList->GetNext(head);
		}

		return ret;
	}

	bool ActivityManager::HasActivities() const
	{
		return !(mp_activity_list->IsEmpty() && mp_new_list->IsEmpty());
	}
}
