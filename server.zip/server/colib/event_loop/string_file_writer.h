#if !defined(__STRING_FILE_WRITER__)
#define __STRING_FILE_WRITER__

#include<utils/callback.h>
#include<event_loop/activity_hld.h>

#include <stdlib.h>

namespace colib
{

class StringFileWriter;

bool EvtLoop_WriteFile(string str, string filename);
bool EvtLoop_WriteFile(string str, string filename, Callback1<StringFileWriter*> on_done);
bool EvtLoop_WriteFile(string str, string filename, Callback1<StringFileWriter*> o_done, void *context);

///////////////////////////////////////////////////////////////////////////////////////////
// Sequential writer functions- these only use one filedescriptor at a time:
// the callback function will always be called, whether the write succeeds or fails
struct EvtLoop_WriteFile2_result
{
	bool m_status;
	string m_filename;
	string m_last_error;
	void *m_context;
};
void EvtLoop_WriteFile2(string str, string filename, Callback1<EvtLoop_WriteFile2_result> on_done, void *context);
///////////////////////////////////////////////////////////////////////////////////////////


class StringFileWriter
{
public:
	StringFileWriter(Callback1<StringFileWriter*> cb, string to_write, string filename, void *context=NULL);
	~StringFileWriter();
	bool Init();
	bool GetStatus() const { return m_status; }
	string GetLastError() const { return m_last_error; }

	Callback1<StringFileWriter*> m_notify_done;

private:
	eCallbackRt WriteFileAct();

	ActivityHold m_act_hld;
	string m_string_to_write;
	string m_file_name;
	int m_offset;
	int m_length;
	void *m_context;
	bool m_status;
	string m_last_error;
	int m_fd;
};

}

#endif
