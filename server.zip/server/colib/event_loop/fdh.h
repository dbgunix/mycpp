#if !defined(__FDH_H__)
#define __FDH_H__

#include <sys/epoll.h>
#include<utils/string.h>

namespace colib
{

class Writable;

class FileDescriptorHandler
{
public:
	static const unsigned int READ_NOTIFY_FLAG = EPOLLIN;
	static const unsigned int WRITE_NOTIFY_FLAG = EPOLLOUT;
	// NOTE: ERR and HUP are automatically part of the event set of epoll_wait
	static const unsigned int EXCEPTION_NOTIFY_FLAG = EPOLLERR | EPOLLHUP | EPOLLRDHUP;
	static const unsigned int READ_FLAGS = READ_NOTIFY_FLAG|EXCEPTION_NOTIFY_FLAG;
	static const unsigned int ALL_FLAGS = READ_NOTIFY_FLAG|WRITE_NOTIFY_FLAG|EXCEPTION_NOTIFY_FLAG;

	FileDescriptorHandler(string name, int fd, unsigned int flag);
	FileDescriptorHandler(string name);
	virtual ~FileDescriptorHandler();

	/** Pure virtual function. Overload this finction to handle your received event/message. */
	virtual void read() = 0;
	/** Pure virtual function. Overload this finction to send events/messages to the parent thread. */
	virtual void write() = 0;

	unsigned int GetFlag() const { return m_flag; }
	int GetReadCount() const { return m_read_count; }
	int GetWriteCount() const { return m_write_count; }
	int GetFd() const { return m_fd; }
	string GetName() const { return m_name; }

	void Reset();
	void IncReadCount() { ++m_read_count; }
	void IncWriteCount() { ++m_write_count; }

	void PrintStatus(Writable* to) const;

protected:
	/// Add an event flag
	bool AddFlag(unsigned int flag) { return ChangeFlag(m_flag | flag); }
	/// Remove an event flag
	void RemoveFlag(unsigned int flag) { ChangeFlag(m_flag & ~flag); }
	/// Overwrite event flags
	bool SetFlag(unsigned int flag) { return ChangeFlag(flag); }
	/// Prevent read events
	void DisableRead() { m_allowed_flags &= ~READ_NOTIFY_FLAG; RemoveFlag(READ_NOTIFY_FLAG); }
	/// Prevent write events
	void DisableWrite() { m_allowed_flags &= ~WRITE_NOTIFY_FLAG; RemoveFlag(WRITE_NOTIFY_FLAG); }
	/// Allow read events
	void EnableRead() { m_allowed_flags |= READ_NOTIFY_FLAG; }
	/// Allow write events
	void EnableWrite() { m_allowed_flags |= WRITE_NOTIFY_FLAG; }
	/// Set fd to non-blocking
	bool MakeNonBlocking();

	/// Name of the file descriptor
	string m_name;
	/// The file descriptor
	int m_fd;

private:
	bool ChangeFlag(unsigned int flag);

	/// Number of times this fd had read activity
	int m_read_count;
	/// Number of times this fd had write activity
	int m_write_count;
	/// Mask of current event flags (read,write)
	unsigned int m_flag;
	/// Mask of allowed event flags
	unsigned int m_allowed_flags;
};

}

#endif
