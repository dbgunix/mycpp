#ifndef _ACTIVITY_HOLD_
#define _ACTIVITY_HOLD_

#include<utils/callback.h>
#include<utils/string.h>
#include<utils/data_struct/dlist.h>

namespace colib
{

class ActivityManager;
typedef ActivityManager* ActivityManagerPtr;
class Writable;


class ActivityHold
{
	friend class ActivityManager;

public:
	ActivityHold(CallbackRt n_callback, colib::string n_name);
	~ActivityHold();

	bool IsActive() const { return m_node.m_parent != NULL; }
	void Print(Writable *to) const;

private:
	CallbackRt m_callback;
	colib::string m_name;
	ActivityManagerPtr pActMgr;
	Dlist<ActivityHold*>::Node m_node;

	void Print() const;
	colib::string Dump() const;

	ActivityHold& operator=(const ActivityHold&);
	ActivityHold(const ActivityHold&);

};
typedef ActivityHold* ActivityHoldPtr;



}
#endif

