#include<event_loop/event_loop.h>
#include<event_loop/activity_mgr.h>
#include<event_loop/fdh.h>
#include<utils/trace/writable.h>
#include<utils/trace/trace.h>
#include<timer/timekeeper.h>

#include <unistd.h>
#include <time.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <errno.h>

//#define DEBUG_SERVICE_CALL 1
//#define DEBUG_SELECT 1

#ifdef DEBUG_SERVICE_CALL
#include<utils/kernel/time.h>
#endif

namespace colib
{

/** Get singleton instance of event loop
 * \return EventLoop singleton
 */
EventLoop& EventLoop::GetInstance()
{
	static EventLoop instance;
	return instance;
}

/// Event loop ctor
EventLoop::EventLoop ()
	: m_timekeeper(TimeKeeper::GetTimeKeeperInstance())
	, m_epoll_fd(-1)
	, m_epoll_events()
	, m_handlers_modified(false)
	, m_Terminate(false)
	, m_fd_map()
	, m_act_mgr(new ActivityManager)
{
}

/// Event loop dtor
EventLoop::~EventLoop()
{
	Close();
}

void EventLoop::Close()
{
	if (m_epoll_fd > 0)
	{
		close(m_epoll_fd);
	}
	m_epoll_fd = -1;
	if(m_act_mgr)
	{
		delete m_act_mgr;
		m_act_mgr = NULL;
	}
}
/// Reset status (file descriptors, timekeeper)
void EventLoop::ResetStatus()
{
	for(auto it(m_fd_map.begin()); it != m_fd_map.end(); ++it)
	{
		it->second->Reset();
	}
	m_timekeeper.ResetCount();
}

/** Print file descriptor status
 * \param[in] to Writable to use for output
 */
void EventLoop::DumpFdStatus(Writable *to) const
{
	for (auto it(m_fd_map.cbegin()); it != m_fd_map.cend(); ++it)
	{
		it->second->PrintStatus(to);
	}
}

/** Print activity status
 * \param[in] to Writable to use for output
 */
void EventLoop::DumpActStatus(Writable *to) const
{
	m_act_mgr->Dump(to);
}

/** Print all status (fd, timer, activity)
 * \param[in] to Writable to use for output
 */
void EventLoop::DumpStatus(Writable *to) const
{
	DumpFdStatus(to);
	to->PrintString("\n");
	DumpTimerStatus(to);
	to->PrintString("\n");
	DumpActStatus(to);
}

/** Initialize the event loop internals
 * \return True if the initialize succeeded, false if not
 * \note Must be call before Main()
 */
bool EventLoop::Initialize()
{
	// check if the epoll_fd was already initialized
	// and protect against multiple calls
	if (m_epoll_fd < 0)
	{
		// since kernel version 2.6.8 the size param to epoll_create
		// is unused, but must be positive (see man page)
		m_epoll_fd = epoll_create(10);
		if (m_epoll_fd < 0)
		{
			TRACE("epoll_create() failed: %s (%d)\n", strerror(errno), errno);
			return false;
		}
	}
	return true;
}

#if 0
void EventLoop::Debug0ReadyFd()
{
	// timeout occurred - no socket activity this time around
	ELP1_TRACE(3,"m_maxfdp1=%d\n",m_maxfdp1);
	ELP1_TRACE(3,"%d\n",read_set.__fds_bits[0]);
	ELP0_TRACE(3,"main loop no activity\n");
	FileDescriptorHandler *sh;
	LockHandlers();
	FileDescHandlerMap::iterator at = m_Handlers.begin();
	FileDescHandlerMap::iterator atEnd = m_Handlers.end();
	for(;at != atEnd; ++at) {
	sh = at->second;
	ELP1_TRACE(3,"FD %d in :",sh->m_fd);
		fd_set_mutex_lock();
	if (FD_ISSET(sh->m_fd, &m_read_set) ) { //socket is readable
		ELP0_TRACE(3,"read set ");
	}
	if (FD_ISSET(sh->m_fd, &m_write_set) ) { //socket is writable
		ELP0_TRACE(3,"write set ");
	}
		fd_set_mutex_unlock();
	ELP0_TRACE(3,"\n");
	}
	FileDescHandlerMap::iterator at2 = m_Handlers_hp.begin();
	FileDescHandlerMap::iterator atEnd2 = m_Handlers_hp.end();
	for(;at2 != atEnd2; ++at2) {
	sh = at2->second;
	ELP1_TRACE(3,"FD %d in :",sh->m_fd);
		fd_set_mutex_lock();
	if (FD_ISSET(sh->m_fd, &m_read_set) ) { //socket is readable
		ELP0_TRACE(3,"read set ");
	}
	if (FD_ISSET(sh->m_fd, &m_write_set) ) { //socket is writable
		ELP0_TRACE(3,"write set ");
	}
		fd_set_mutex_unlock();
	ELP0_TRACE(3,"\n");
	}

	UnlockHandlers();
//}
#endif

/** Iterate over epoll events and call event handlers
 * \param[in] numEvents number of events in \a event_list
 * \param[in] event_list list of pending events
 */
void EventLoop::DispatchFdActivity(int numEvents, epoll_event *event_list)
{
	for (int ii(0); ii < numEvents; ++ii)
	{
		auto at(m_fd_map.find(event_list[ii].data.fd));
		if (at != m_fd_map.end())
		{
			// read event
			FileDescriptorHandler *cur_fd(at->second);
			if (event_list[ii].events & FileDescriptorHandler::READ_FLAGS)
			{
				cur_fd->IncReadCount();
				cur_fd->read();
			}
			/* if the read event has modified the fd container then skip
			 * write activity for this fd and move on to the next event.
			 * ("cur_fd" may have been deleted) */
			if (m_handlers_modified)
			{
				m_handlers_modified = false;
			}
			// write event
			else if (event_list[ii].events & FileDescriptorHandler::WRITE_NOTIFY_FLAG)
			{
				cur_fd->IncWriteCount();
				cur_fd->write();
			}
		}
	}
}

/** Wait for file descriptor events
 * \return False if there were any errors, true otherwise
 */
bool EventLoop::HandleFdActivity()
{
	// figure out how long to wait based for FD activity
	MonoTime wait(GetWaitOptions());

#ifdef DEBUG_SELECT
	TRACE("wait in select = %d.%06d\n", wait.GetSeconds(), wait.GetUsec());
	colib::Time t0;
	t0.SetToNow();
#endif

	// if wait has nonzero nsec and ConvertToMs returns 0, wait at least 1 msec
	int msec_to_wait = wait.GetNsec() > 0 ? std::max(wait.ConvertToMs(), 1L) : wait.ConvertToMs();
	int numReady = epoll_wait(m_epoll_fd, m_epoll_events, MAX_EVENTS, msec_to_wait);

#ifdef DEBUG_SELECT
	colib::Time t1;
	t1.SetToNow();
	colib::Time t2;
	t2 = t1 - t0;
	TRACE("time in select = %d.%d, actual wait = %d,%d, numReady = %d\n", t2.GetSeconds(), t2.GetUsec(), wait.GetSeconds(), wait.GetUsec(), numReady);
#endif

	if (numReady == -1)
	{
		// don't log epoll interruption via a signal
		if (errno != EINTR)
		{
			TRACE("EventLoop error %s (%d)\n", strerror(errno), errno);
		}
		// Shutdown the event loop only if OnError() returns true.
		if (OnMainLoopError(errno))
		{
			Terminate(true);
			//dont bother to fall through to dispatch timers:
			return false;
		}
	}
	else if (numReady == 0)
	{
#ifdef DEBUG_EVENT_LOOP
		Debug0ReadyFd();
#endif
	}
	else
	{
		// at least on fd with an event, handle it
		DispatchFdActivity(numReady, m_epoll_events);
	}
	return true;
}

/** Run the event loop, waiting for events
 * \note Must call Initialize() before Main()
 */
void EventLoop::Main()
{
	m_Terminate = false;

	while (!m_Terminate)
	{
		// file desc
		HandleFdActivity();
		// then handle timers
		DispatchExpiredTimers();
		// then handle activities
		m_act_mgr->Go();
	}
	TRACE("EventLoop terminated\n");
}

bool EventLoop::OnMainLoopError(int err) const
{
	// By default, don't terminate.
	return err == EBADF;
}

/** Add a new FDH to the container of active fd's
 * \param[in] handler FDH to add
 * \return True if add succeeded, false if not
 */
bool EventLoop::AddHandler(FileDescriptorHandler &handler)
{
	if(handler.GetFd() < 0)
	{
		TRACE(2,"In EventLoop::AddHandler, File Descriptor is bad(%d), name: %s.\n", handler.GetFd(), handler.GetName().c_str());
		return false;
	}

	fcntl(handler.GetFd(),F_SETFD,FD_CLOEXEC);

	auto at = m_fd_map.find(handler.GetFd());
	if (at != m_fd_map.end())
	{
		TRACE(2,"In EventLoop::AddHandler, Handler already present, name: %s.\n", handler.GetName().c_str());
		return false;
	}

	if (m_fd_map.insert(std::pair<int, FileDescriptorHandler*>(handler.GetFd(), &handler)).second)
	{
		handler.Reset();
		//TRACE(5, "In EventLoop::AddHandler,Handler added, %d remain\n", m_Handlers.Size());
		//m_maxfdp1 = m_Handlers.Size() + 1;
		SetFDBit(handler);
		m_handlers_modified = true;
		return true;
	}

	TRACE(2,"In EventLoop::AddHandler, failed to add handler %d/%s.\n", handler.GetFd(), handler.GetName().c_str());
	return false;
}

/** Remove a FDH to the container of active fd's
 * \param[in] handler FDH to remove
 * \return True if remove succeeded, false if not found
 */
bool EventLoop::RemoveHandler(FileDescriptorHandler &handler)
{
	bool ret = false;
	auto at = m_fd_map.find(handler.GetFd());
	if (at != m_fd_map.end())
	{
		ClearFDBit(handler);
		m_fd_map.erase(at);
		m_handlers_modified = true;
		ret = true;
	}
	return ret;
}

/** Add event notifications for a given FDH using its current flag mask
 * \param[in] handler FDH to modify
 * \return True if \a handler events successfully added, false if not.
 */
bool EventLoop::SetFDBit(FileDescriptorHandler &handler)
{
	epoll_event ev;
	// NOTE: level triggering by default
	ev.events = handler.GetFlag();
	ev.data.u64 = 0; // to silence valgrind
	ev.data.fd = handler.GetFd();

	bool ret = true;
	if (epoll_ctl(m_epoll_fd, EPOLL_CTL_ADD, handler.GetFd(), &ev) < 0)
	{
		ret = false;
		TRACE("epoll_ctl_add failed on(%s) (%d/%d): %s\n", handler.GetName().c_str(), m_epoll_fd, handler.GetFd(), strerror(errno));
	}
	return ret;
}

/** Remove all event notifications for a given FDH
 * \param[in] handler FDH to modify
 * \return True if \a handler events successfully removed, false if not
 */
bool EventLoop::ClearFDBit(FileDescriptorHandler &handler)
{
	bool ret = true;
	// NOTE: ev ptr can be null on kernel > 2.6.9
	if (epoll_ctl(m_epoll_fd, EPOLL_CTL_DEL, handler.GetFd(), NULL) < 0)
	{
		ret = false;
		// don't bother logging the case where the fd was not
		// registered with the epoll fd
		// (ModifyFDBit may have already removed the fd)
		if (errno != ENOENT)
		{
			TRACE("epoll_ctl_del failed on(%s) (%d/%d): %s\n", handler.GetName().c_str(), m_epoll_fd, handler.GetFd(), strerror(errno));
		}
	}
	return ret;
}

/** Modify event notifications for a given FDH using its current flag mask
 * \param[in] handler FDH to modify
 * \return True if \a handler events successfully modified, false if not
 */
bool EventLoop::ModifyFDBit(FileDescriptorHandler &handler)
{
	epoll_event ev;
	ev.events = handler.GetFlag();
	ev.data.u64 = 0; // to silence valgrind
	ev.data.fd = handler.GetFd();

	bool ret = true;
	if (epoll_ctl(m_epoll_fd, EPOLL_CTL_MOD, handler.GetFd(), &ev) < 0)
	{
		ret = false;
		TRACE("epoll_ctl_mod failed on(%s) (%d/%d): %s\n", handler.GetName().c_str(), m_epoll_fd, handler.GetFd(), strerror(errno));
	}
	return ret;
}

/** Determine how long to wait for file descriptor activity
 * \return Relative time to wait for file descriptor activity
 */
MonoTime EventLoop::GetWaitOptions()
{
	// if activities are pending, don't wait
	if (m_act_mgr->HasActivities())
	{
		return MonoTime(0,0);
	}

	//default with no timers is 1 second
	MonoTime min(1,0);

	if (!m_timekeeper.Empty())
	{
		min = m_timekeeper.GetNextTimeout();
	}
	return min;
}

/*
bool Dispatch(colib::Time expiration, colib::Time now)
{
	colib::Time fuzzy = now + DISPATCH_RESOLUTION;

	if ( expiration <= fuzzy)
		return true;
	else
		return false;
}*/

/** Add new activity to event loop
 * \param[in] actHold activity holder to add
 * \return True if the add succeeded, false if not
 */
bool EventLoop::AddActivity(ActivityHold* actHold)
{
	return m_act_mgr->AddActivity(actHold);
}

/** Remove activity from event loop
 * \param[in] actHold activity holder to remove
 * \return True if the remove succeeded, false if not
 */
bool EventLoop::DeleteActivity(ActivityHold* actHold)
{
	return m_act_mgr->DeleteActivity(actHold);
}

/** Process event loop console command
 * \param[in] to Writable to use for output
 * \param[in] argc Number of arguments from console
 * \param[in] argv Array of arguments
 */
void EventLoop::ConsoleCommand(Writable *to, int argc, char *argv[])
{
	const char *usage = "Usage: [fd] | [timer] | [act]\n";

	if (!to)
	{
		return;
	}

	if (0 >= argc)
	{
		DumpStatus(to);
	}
	else if (strcmp(argv[0], "fd") == 0)
	{
		DumpFdStatus(to);
	}
	else if (strcmp(argv[0], "timer") == 0)
	{
		DumpTimerStatus(to);
	}
	else if (strcmp(argv[0], "act") == 0)
	{
		DumpActStatus(to);
	}
	else
	{
		to->PrintString(usage);
	}
}

}
