#include<event_loop/string_file_writer.h>
#include<utils/string.h>
#include<utils/trace/trace.h>
#include<utils/data_struct/dlist.h>
#include<event_loop/event_loop.h>

#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>

namespace colib
{
////////////////////////////////////////////////////////
	// StringFileWriter
////////////////////////////////////////////////////////

StringFileWriter::StringFileWriter(Callback1<StringFileWriter*> cb, string to_write, string filename, void *context)
	: m_notify_done(cb)
	, m_act_hld(callbackRt(this, &StringFileWriter::WriteFileAct), filename)
	, m_string_to_write(to_write)
	, m_file_name(filename)
	, m_offset(0)
	, m_length(strlen(to_write))
	, m_context(context)
	, m_status(false)
	, m_last_error()
	, m_fd(-1)
{
	// default permissions of 644
	const mode_t file_perms = S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH;

	if(unlink(filename) != 0)
	{
		//TRACE("fail to unlink %s, %s\n", filename, strerror(errno));
	}

	m_fd = open(filename, O_WRONLY|O_TRUNC|O_CREAT|O_NONBLOCK, file_perms);
	if (m_fd == -1)
	{
		m_last_error = string::Format("StringFileWriter(%p)::StringFileWriter() -- Open file fail with errno = %d\n", this, errno);
		TRACE("%s\n", m_last_error.c_str());
	}
}

StringFileWriter::~StringFileWriter()
{
	if (m_fd > 0)
	{
		close(m_fd);
		m_fd = -1;
	}
	EventLoop::GetInstance().DeleteActivity(&m_act_hld);
}

bool StringFileWriter::Init()
{
	if (m_fd < 0)
	{
		return false;
	}
	if (!EventLoop::GetInstance().AddActivity(&m_act_hld))
	{
		m_last_error = string::Format( "StringFileWriter(%p)::Init() -- Failed to add FDH to eventloop\n", this);
		return false;
	}
	return true;
}

eCallbackRt StringFileWriter::WriteFileAct()
{
	int n = ::write(m_fd, m_string_to_write.c_str() + m_offset, m_length - m_offset);
	if ( n < 0 )
	{
		m_last_error = string::Format("StringFileWriter(%p)::Write() -- Write file to disk fail, errno = %d\n", this, errno);
#ifdef RELEASE_2
		OptionsDownloadRspMsg rsp(OptionsDownloadRspMsg::DOWNLOAD_FAILED);
		SendData((Message*)&rsp);
#else
		//((MNCClientHandler*)m_parent)->WriterNotifyDone(HPBOptionsRspMsg::HPB_WRITE_FILE_FAIL);
		m_notify_done.Dispatch(this);
#endif
		return DontRunAgain;
	}

	m_offset += n;
	if (m_offset < m_length)
	{
		m_last_error = string::Format("StringFileWriter(%p)::Write() --  Partially Write %d (%d) bytes\n", this, m_offset, m_length);
		return RunAgain;
	}

	m_last_error = string::Format("StringFileWriter(%p)::Write() --  Write complete %d (%d) bytes\n", this, m_offset, m_length);
	m_status = true;
#ifdef RELEASE_2
	OptionsDownloadRspMsg rsp;
	((MNCClientHandler*)m_parent)->SendData((Message*)&rsp);
#else
	//((MNCClientHandler*)m_parent)->WriterNotifyDone(HPBOptionsRspMsg::OK);
	m_notify_done.Dispatch(this);
#endif
	return DontRunAgain;
}

static void ovwop_cleanup(StringFileWriter *pdone)
{
	if(!pdone->GetStatus())
	{
		TRACE("StringFileWriter: Failed to write options file: %s\n", pdone->GetLastError().c_str());
	}
	delete pdone;
}

bool EvtLoop_WriteFile(string str, string filename)
{
	return EvtLoop_WriteFile(str, filename, callback(&ovwop_cleanup), 0);
}

bool EvtLoop_WriteFile(string str, string filename, Callback1<StringFileWriter*> on_done)
{
	return EvtLoop_WriteFile( str, filename, on_done, 0 );
}

bool EvtLoop_WriteFile(string str, string filename, Callback1<StringFileWriter*> on_done, void *context)
{
	if(!str.is_empty())
	{
		StringFileWriter *pnew = new StringFileWriter(on_done, str, filename, context);
		if(pnew)
		{
			if(pnew->Init())
			{
				return true;
			}

			delete pnew;
		}
	}
	return false;
}

///////
//objects used to track work to be done:
struct g_opfr2_work
{
	g_opfr2_work(string to_write, string filename, Callback1<EvtLoop_WriteFile2_result> &done_cb, void *context)
		: m_towrite(to_write)
		, m_filename(filename)
		, m_on_done(done_cb)
		, m_context(context)
	{
	}
	g_opfr2_work()
		: m_towrite()
		, m_filename()
		, m_on_done()
		, m_context(NULL)
	{
	}
	string m_towrite;
	string m_filename;
	Callback1<EvtLoop_WriteFile2_result> m_on_done;
	void *m_context;
};
static bool g_opfr2_busy=false;
static Dlist<g_opfr2_work> g_opfr2_todo;

//forward decls:
static void opfr2_start_work();
static void opfr2_done_cb( StringFileWriter* writer );

static void opfr2_start_work()
{
	if(g_opfr2_busy)
	{
		return;
	}
	Dlist<g_opfr2_work>::Node *job;
	while ((job=g_opfr2_todo.GetHead()))
	{
		g_opfr2_work *ctx = &job->m_data;
		if( EvtLoop_WriteFile(ctx->m_towrite,ctx->m_filename,callback(opfr2_done_cb)) )
		{
			g_opfr2_busy = true;
			return;
		}

		//report failure to start:
		EvtLoop_WriteFile2_result res;
		res.m_status = false;
		res.m_last_error = string::Format("opfr2_start_work: Failed to begin write of options file \"%s\"\n", ctx->m_filename.c_str() );
		res.m_context = ctx->m_context;
		res.m_filename = ctx->m_filename;

		if (ctx->m_on_done.IsSet())
		{
			ctx->m_on_done.Dispatch(res);
		}
		else
		{
			TRACE( "%s", res.m_last_error.c_str() );
		}
		g_opfr2_todo.Remove(job);
	}
}

static void opfr2_done_cb(StringFileWriter* writer)
{
	Dlist<g_opfr2_work>::Node *job=g_opfr2_todo.GetHead();

	//insanity checks:
	if(!writer)
	{
		TRACE("**************************opfr2_done_cb error 1, should never happen !\n");
		return;
	}
	if( !job )
	{
		delete writer;
		TRACE("**************************opfr2_done_cb error 2, should never happen!\n");
		return;
	}

	// callback dispatching:
	EvtLoop_WriteFile2_result res;

	res.m_status = writer->GetStatus();
	res.m_last_error = writer->GetLastError();

	g_opfr2_work *ctx = &job->m_data;

	res.m_context = ctx->m_context;
	res.m_filename = ctx->m_filename;

	if (ctx->m_on_done.IsSet())
	{
		ctx->m_on_done.Dispatch(res);
	}
	else
	{
		if( !res.m_status )
		{
			TRACE("opfr2_done_cb: Failed to write options file \"%s\": %s",  ctx->m_filename.c_str(), res.m_last_error.c_str());
		}
	}

	//we need no more information from writer
	delete writer;

	g_opfr2_todo.Remove(job);
	g_opfr2_busy = false;

	//there may be more work on the list:
	opfr2_start_work();
}

void EvtLoop_WriteFile2(string str, string filename, Callback1<EvtLoop_WriteFile2_result> on_done, void *context)
{
	struct g_opfr2_work new_job(str, filename, on_done, context);
	g_opfr2_todo.Append(new_job);
	opfr2_start_work();
}

}
