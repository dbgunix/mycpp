#include<utils/trace/trace.h>
#include<event_loop/activity_mgr.h>
#include<event_loop/activity_hld.h>
#include<utils/trace/writable.h>

#include <stdio.h>

namespace colib
{

	ActivityHold::ActivityHold(CallbackRt n_callback, colib::string n_name)
		:  m_callback(n_callback), m_name(n_name), pActMgr(0)
	{
		m_node.m_data = this;
	}

	ActivityHold::~ActivityHold()
	{
		// Remove itself from manager
		if(pActMgr)
			pActMgr->DeleteActivity(this);
		pActMgr = 0;
	}

	void ActivityHold::Print() const
	{
		fprintf(stdout, " Print name %s   - ", m_name.c_str());
	}

	void ActivityHold::Print(Writable *to) const
	{
		to->Print("%p - %s\n", this, m_name.c_str());
	}

	colib::string ActivityHold::Dump() const
	{
		return colib::string::Format(" %p - %s\n", this, m_name.c_str());
	}


}
