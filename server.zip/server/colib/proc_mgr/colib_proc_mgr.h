// colib_proc_mgr.h
// vi:set ts=4 sw=4 nowrap:

#ifndef COLIB_PROC_MGR_H_ALREADY_INCLUDED
#define COLIB_PROC_MGR_H_ALREADY_INCLUDED

#include<proc_mgr/proc_mgr.h>
#include<proc_mgr/colib_child_proc.h>
#include<proc_mgr/proc_intf.h>
#include<socket/stream/stream_server.h>
#include<socket/stream/stream_client_handler.h>
#include<proc_mgr/child_hb_client.h>

#include <map>

namespace colib
{
	typedef std::map<int, Callback3<char*, int, StreamBase*>>	MsgCbkMap;
	typedef std::map<string, MsgCbkMap>							ProcMsgCbkMap;

	class ColibProcessMgr : public ProcessMgr
	{
		public:

			enum ColibProcStats
			{	
				ColibProcStat_num_rx_heartbeat,
				ColibProcStat_num_decode_heartbeat_fail,
				ColibProcStat_num_fail_heartbeat,
				ColibProcStat_ipc_path,
				ColibProcStatCount
			};

								ColibProcessMgr(ProcInterface* intf);
			virtual 			~ColibProcessMgr();

			virtual bool		Init(string& err);	
	
			virtual ChildProc*  AddChildProc(
									const string& proc_name, 
									int proc_id,
									string dir_path = "/usr/bin/",
									string extra_args = "");

			//
			// Send Message to child(ren)
			//
			bool				SendMsg2All(Message& item);
			bool				SendData2All(char* data, int len);
			bool				SendMsg(const string& proc_name, int proc_id, Message& item);
			bool				SendData(const string& proc_name, int proc_id, char* data, int len);
			//
			// Receive Message from child(ren)
			//
			void				RegisterAnyHandler4All(
									const Callback3<char*, int, StreamBase*>& cbk);
			void				RegisterAnyHandler4ProcName(
									const string& proc_name,
									const Callback3<char*, int, StreamBase*>& cbk);
			void				RegisterAnyHandler(
									const string& proc_name, int proc_id,
									const Callback3<char*, int, StreamBase*>& cbk);
        
			void				RegisterMsgHandler4All(
									int msg_id, const Callback3<char*, int, StreamBase*>& cbk);
			void				RegisterMsgHandler4ProcName(
									const string& proc_name,
									int msg_id, 
									const Callback3<char*, int, StreamBase*>& cbk);
			void				RegisterMsgHandler(
									const string& proc_name, 
									int proc_id,
									int msg_id, 
									const Callback3<char*, int, StreamBase*>& cbk);

			virtual string		ConsoleHelp();
			virtual void		ConsoleCommand(ConsoleSession* con, int argc, char* argv[]);

		protected:

			virtual ChildProc*	CreateChildProc(const string& proc_name, int proc_id);
			virtual void		StartChildProc(ChildProc*, string extra_args, string dir_path);

			virtual string		GetIPCPath();
			void				OnNewIPCClient(StreamClientHandler* sch);

			void				OnRxHeartbeat(char* data, int len, StreamBase* socket);
	
		protected:
	
			string				RegisterIndex(string proc_name, int proc_id);		
			MsgCbkMap			m_register_all;
			ProcMsgCbkMap		m_register_proc_name;
			ProcMsgCbkMap		m_register_proc_name_id;
				
		private:

			ProcInterface*	m_proc_intf;
			StreamServer		m_ipc_server;
			ValueList			m_colib_proc_stats;
	};
	#define COLIB_PROC_STAT(stat)	m_colib_proc_stats[ColibProcessMgr::ColibProcStat_##stat].AsInt()

}//end namespace colib

#endif

