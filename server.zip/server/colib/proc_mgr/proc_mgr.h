// proc_mgr.h
// vi:set ts=4 sw=4 nowrap:

#ifndef PROC_MGR_H_ALREADY_INCLUDED
#define PROC_MGR_H_ALREADY_INCLUDED

#include<proc_mgr/child_proc.h>
#include<options/options.h>
#include<utils/data_struct/dlist.h>
#include<timer/periodic_timer.h>
#include<console/session.h>
#include<config/value.h>
#include<event_loop/activity_hld.h>

namespace colib
{
	const int DEFAULT_CHILD_HEARTBEAT_INTERVAL_SEC = 10;

	class ProcessMgr
	{
		public:

			enum ProcStats
			{
				ProcStat_num_proc_alive,
				ProcStat_num_proc_request_add,
				ProcStat_num_proc_added,
				ProcStat_num_proc_add_fail,
				ProcStat_num_proc_request_remove,
				ProcStat_num_proc_removed,
				ProcStat_num_proc_remove_fail,
				ProcStat_num_heartbeat_timeout,
				ProcStat_num_start_proc_mgr,
				ProcStat_num_execute_start_stop,
				ProcStat_num_start_request_mgr,
				ProcStat_num_execute_add_remove,
				ProcStat_proc_heartbeat_freq_sec,
				ProcStat_heartbeat_timeout_sec,
				ProcStatCount
			};

								ProcessMgr();
			virtual 			~ProcessMgr();

			virtual ChildProc*	AddChildProc(
									const string& proc_name, 
									int proc_id, 
									string dir_path, 
									string extra_args);

			virtual bool		DelChildProc(
									const string& proc_name, 
									int proc_id);

            ChildProc*          FindChildProc(
									const string& proc_name, 
									int proc_id);
			
			virtual bool		Init(string& err);
			virtual bool		Reload(const Options* opt, string& err);
			//
			// The callback is dispatched when a process successfully started and heartbeated
			//
			virtual void		RegisterProcessSucceedCallback(const Callback2<string, int>& cbk);
			//
			// The callback is dispatched when a process is killed with signal
			//
			virtual void		RegisterProcessKillCallback(const Callback3<string, int, const string&>& cbk);
			//
			//  The callback is dispatched when a process
			//   1. fail to start (reason specified as the third argument)
			//   2. crashed 
			//   3. fail to heartbeat
			//
			virtual void		RegisterProcessFailureCallback(const Callback3<string, int, string>& cbk);

			virtual string		ConsoleHelp();
			virtual void		ConsoleCommand(ConsoleSession* con, int argc, char* argv[]);
			int					NumOfChildProc() { return m_child_proc.Size(); }

		protected:

			virtual ChildProc*	CreateChildProc(const string& proc_name, int proc_id) = 0;
			virtual void		StartChildProc(ChildProc*, string extra_args, string dir_path) = 0;


			void				StartHeartbeatTimer();
			void				OnHeartbeatTimeout(unsigned, void*);
	
			void				OnChildProcStateChange(int state);
			void				StartProcMgr();
			eCallbackRt			StartOrStopChildProc();			

			void				StartRequestMgr();
			eCallbackRt			ProcessRequest();
			void				CleanRequest();

			void				ProcList(ConsoleSession* con);

		public:

			Dlist<ChildProc*>	m_child_proc;
			Dlist<ChildProc*>	m_child_proc_to_delete;
			PID_TO_PROC_MAP     m_pid_to_child_proc_map;
			ActivityHold		m_proc_mgr;
			Dlist<ChildProc*>	m_add_request;
			Dlist<ProcConfig>	m_remove_request;
			ActivityHold		m_request_mgr;			
			PeriodicTimer		m_heartbeat_timer;
			int					m_proc_heartbeat_freq_sec;
			int					m_heartbeat_timeout_sec;
			MemberSet			m_proc_debug_set;	
			Callback2<string, int>			m_proc_succeed_cbk;
			Callback3<string, int, string>	m_proc_failure_cbk;
			Callback3<string, int, const string&>	m_proc_kill_cbk;

			ValueList			m_proc_stats;
	};
	#define PROC_STAT(stat)		m_proc_stats[ProcessMgr::ProcStat_##stat].AsInt()

}//end namespace colib

#endif

