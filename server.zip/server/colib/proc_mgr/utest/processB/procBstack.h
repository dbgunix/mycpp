// stack.h
// vi:set ts=4 sw=4 nowrap:

#ifndef PROCBSTACK_H_ALREADY_INCLUDED
#define PROCBSTACK_H_ALREADY_INCLUDED

//#include <stack_mgr/main_stack_mgr.h"
//#include <stack_mgr/child_stack_mgr.h"
//#include <stack_mgr/main_stack_mgr.h"
//#include <proc_mgr/colib_proc_mgr.h"
#include <stack_mgr/child_stack_mgr.h>

namespace colib
{
	class ProcBStack : public ChildStackMgr
	{
		public:

			virtual					~ProcBStack() {};
									ProcBStack();
			bool					InitStack();
			void 					MsgFromGrandparent(char* data, int len, StreamBase *sch);
			void 					MsgFromChild(char* data, int len, StreamBase *sch);

			const char*				GetApplicationName () { return "ProcBStack"; }

			//bool					StartConsole();

			void					RegisterConsoleCommand();
			static void				ProcConsoleCommand(ProcBStack* stack, ConsoleSession* con, int argc, char* argv[]);
			static void				CmdPassword(void* ctx, ConsoleSession* con, int argc, char* argv[]);
			static void				CmdSendMsgToParent(ProcBStack* stack, ConsoleSession* con, int , char**);
			void					SendTestMessageToParent();
			static void				CmdSendMsgToChildren(ProcBStack* stack, ConsoleSession* con, int , char**);
			static void				CmdGoBusy(ProcBStack* stack, ConsoleSession* con, int , char**);
			void					GoBusy();
			static const int TEST_MESSAGE_FROM_CHILD_ID = 4444;
			class TestMessageFromChild : public Message
			{
			public:
				TestMessageFromChild() : Message(TEST_MESSAGE_FROM_CHILD_ID) { }

				string m_some_str;

				bool XdrProc(CXDR *pXDR);
			};

			static const int TEST_MESSAGE_TO_CHILD_ID = 8888;
			class TestMessageToChild : public Message
			{
			public:
				TestMessageToChild() : Message(TEST_MESSAGE_TO_CHILD_ID) { }
				int m_i;
				string m_s;

				bool XdrProc(CXDR *pXDR);
			};
			private:
			int m_transmitCount;
			int m_receiveCount;

	};

}//end namespace colib


#endif//PROCBSTACK_H_ALREADY_INCLUDED

