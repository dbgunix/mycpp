#include "procBstack.h"

using namespace colib;

int main(int argc, char* argv[])
{	
	ProcBStack stack;
	stack.Run(argc, argv);
	return 0;
}
