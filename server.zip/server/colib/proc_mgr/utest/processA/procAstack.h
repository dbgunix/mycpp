// stack.h
// vi:set ts=4 sw=4 nowrap:

#ifndef PROCASTACK_H_ALREADY_INCLUDED
#define PROCASTACK_H_ALREADY_INCLUDED

#include <stack_mgr/main_stack_mgr.h>
#include <console/session.h>

namespace colib
{	
	typedef struct childentry
	{
		string	procname;
		int		procid;
	} childentry;
	class ProcAStack : public MainStackMgr
	{
		public:

			virtual					~ProcAStack() {};
									ProcAStack();

			const char*				GetApplicationName () { return "ProcA"; }
			void					RegisterConsoleCommand();
			static void 			SendToAllConsoleCommand(ProcAStack* stack, ConsoleSession* con, int argc, char **argv);
			static void 			SendToOneConsoleCommand(ProcAStack* stack, ConsoleSession* con, int argc, char **argv);
			void					OnChildMessage(char *data, int len, StreamBase* socket);
			static void				RegAllConsoleCommand(ProcAStack* stack, ConsoleSession* con, int argc, char *argv[]);
			void					RegisterAll(int msgid);
			static void				RegSomeConsoleCommand(ProcAStack* stack, ConsoleSession* con, int argc, char *argv[]);
			void					RegisterSome(string procname, int msgid);
			static void				RegOneConsoleCommand(ProcAStack* stack, ConsoleSession* con, int argc, char *argv[]);
			void					RegisterOne(string procname, int procid, int msgid);

		protected:

			bool					InitStack();

		private:
			Dlist<childentry>		m_children;

		public:
			static const int TEST_MESSAGE_FROM_CHILD_ID = 4444;
			class TestMessageFromChild : public Message
			{
			public:
				TestMessageFromChild() : Message(TEST_MESSAGE_FROM_CHILD_ID) { }

				string m_some_str;

				bool XdrProc(CXDR *pXDR);
			};

			static const int TEST_MESSAGE_TO_CHILD_ID = 8888;
			class TestMessageToChild : public Message
			{
			public:
				TestMessageToChild() : Message(TEST_MESSAGE_TO_CHILD_ID) { }
				int m_i;
				string m_s;

				bool XdrProc(CXDR *pXDR);
			};
	};

}//end namespace colib


#endif//PROCASTACK_H_ALREADY_INCLUDED

