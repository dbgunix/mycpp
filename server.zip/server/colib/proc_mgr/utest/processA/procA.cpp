#include "procAstack.h"

using namespace colib;

int main(int argc, char* argv[])
{	
	ProcAStack stack;
	stack.Run(argc, argv);
	return 0;
}
