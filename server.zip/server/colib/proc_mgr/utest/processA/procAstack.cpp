// stack.cpp
// vi:set ts=4 sw=4 nowrap:

#include "procAstack.h"
#include <console/role.h>
#include <utils/trace/trace.h>

namespace colib
{
	bool ProcAStack::TestMessageFromChild::XdrProc(CXDR* pXDR)
	{
		return Message::XdrProc(pXDR)
			&& pXDR->XdrStringPadded(m_some_str);
	}

	bool ProcAStack::TestMessageToChild::XdrProc(CXDR* pXDR)
	{
		return Message::XdrProc(pXDR)
			&& pXDR->XdrInt(&m_i)
			&& pXDR->XdrStringPadded(m_s);
	}
	ProcAStack::ProcAStack()
	:
	MainStackMgr(true)
	{
	}
	bool	ProcAStack::InitStack()
	{
		if ( !MainStackMgr::InitStack() ) return false;
		//
		// loop for creating ProcB child processes - ProcB go on to create ProcC processes
		//
		for ( int i = 0; i < 1; i++ )
		{
			int procid = i+1;
			string extra_args = string::Format("-cp %d ", m_console_port+1);
			m_child_proc_mgr.AddChildProc("ProcB", procid, "/tmp/", extra_args);
			childentry child;
			child.procname = "ProcB";
			child.procid = procid;
			m_children.Append(child);
		}

		return true;
	}
	void ProcAStack::RegisterConsoleCommand()
	{
		MainStackMgr::RegisterConsoleCommand();
		ConsoleCommand::Register(
				CONSOLE_ROLE_EVERYONE,
				(ConsoleCommand::Handler*)SendToAllConsoleCommand, this,
				"msg", "Send test message to all children");
		ConsoleCommand::Register(
				CONSOLE_ROLE_EVERYONE,
				(ConsoleCommand::Handler*)SendToOneConsoleCommand, this,
				"msg1", "Send test message to one child");
		ConsoleCommand::Register(
				CONSOLE_ROLE_EVERYONE,
				(ConsoleCommand::Handler*)RegAllConsoleCommand, this,
				"regall", "Register msg to all children");
		ConsoleCommand::Register(
				CONSOLE_ROLE_EVERYONE,
				(ConsoleCommand::Handler*)RegSomeConsoleCommand, this,
				"regsome", "Register msg to children with same name");
		ConsoleCommand::Register(
				CONSOLE_ROLE_EVERYONE,
				(ConsoleCommand::Handler*)RegOneConsoleCommand, this,
				"regone", "Register message to one child");
	}
	void ProcAStack::SendToAllConsoleCommand(ProcAStack* stack, ConsoleSession* , int argc, char *argv[])
	{
		(void)argv;
		if ( stack )
		{
			int n = 10;
			if( argc > 1 )
			{
				n = atoi(argv[1]);
			}
			TestMessageToChild msg;
			msg.m_i = n;
			msg.m_s = "Sending test msg to child";
			stack->m_child_proc_mgr.SendMsg2All(msg);
		}
	}
	void ProcAStack::SendToOneConsoleCommand(ProcAStack* stack, ConsoleSession* con, int argc, char *argv[])
	{
		const char* usage = "Usage:\tChildProcName procID stringToSend";
		if ( stack )
		{
			if( argc != 4 )
			{
				con->Print(usage);
				return;
			}
			string procname = argv[1];
			int procid = atoi(argv[2]);
			string msgstr = argv[3];
			TRACE("Send to child process %s, id %d, msg %s\n", procname.c_str(),procid,msgstr.c_str());
			TestMessageToChild msg;
			msg.m_i = procid;
			msg.m_s = msgstr;
			stack->m_child_proc_mgr.SendMsg(procname,procid,msg);
		}
	}
	void ProcAStack::OnChildMessage(char *data, int len, StreamBase* socket)
	{
		int msg_type = Message::DecodeMsgType(data);
		TRACE("Message from child type %d, len = %d, socket = %p\n",msg_type,len,socket);
		TestMessageFromChild rsp;
		if(!rsp.Decode(data, len))
		{
			TRACE("  failed to decode TestMessageFromChild\n");
		}

	}
	void ProcAStack::RegAllConsoleCommand(ProcAStack* stack, ConsoleSession* con, int argc, char *argv[])
	{
		const char* usage = "Usage:\tregall msgID";
		if ( stack )
		{
			if( argc != 2 )
			{
				con->Print(usage);
				return;
			}
			int msgid = atoi(argv[1]);
			TRACE("Register All child processes for msgid %d\n", msgid);
			stack->RegisterAll(msgid);
		}
	}
	void ProcAStack::RegisterAll(int msgid)
	{
		m_child_proc_mgr.RegisterMsgHandler4All(msgid,
					callback(this,&ProcAStack::OnChildMessage));
	}
	void ProcAStack::RegSomeConsoleCommand(ProcAStack* stack, ConsoleSession* con, int argc, char *argv[])
	{
		const char* usage = "Usage:\tregsome ChildProcName msgID";
		if ( stack )
		{
			if( argc != 3 )
			{
				con->Print(usage);
				return;
			}
			string procname = argv[1];
			int msgid = atoi(argv[2]);
			TRACE("Register some child processes %s, for msgid %d\n", procname.c_str(),msgid);
			stack->RegisterSome(procname,msgid);
		}
	}
	void ProcAStack::RegisterSome(string procname, int msgid)
	{
		m_child_proc_mgr.RegisterMsgHandler4ProcName(procname,
				msgid,
				callback(this,&ProcAStack::OnChildMessage));
	}
	void ProcAStack::RegOneConsoleCommand(ProcAStack* stack, ConsoleSession* con, int argc, char *argv[])
	{
		const char* usage = "Usage:\tregone ChildProcName procID msgID";
		if ( stack )
		{
			if( argc != 4 )
			{
				con->Print(usage);
				return;
			}
			string procname = argv[1];
			int procid = atoi(argv[2]);
			int msgid = atoi(argv[3]);
			TRACE("Register child process %s, id %d, for msgid %d\n", procname.c_str(),procid,msgid);
			stack->RegisterOne(procname,procid,msgid);
		}
	}
	void ProcAStack::RegisterOne(string procname, int procid, int msgid)
	{
		m_child_proc_mgr.RegisterMsgHandler(procname.c_str(),
							procid,
							msgid,
							callback(this,&ProcAStack::OnChildMessage));

	}
}//end namespace colib

