#include "procCstack.h"

using namespace colib;

int main(int argc, char* argv[])
{	
	ProcCStack stack;
	stack.Run(argc, argv);
	return 0;
}
