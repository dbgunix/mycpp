// stack.h
// vi:set ts=4 sw=4 nowrap:

#ifndef PROCCSTACK_H_ALREADY_INCLUDED
#define PROCCSTACK_H_ALREADY_INCLUDED

#include <stack_mgr/child_stack_mgr.h>

namespace colib
{
	class ProcCStack : public ChildStackMgr 
	{
		public:

			virtual					~ProcCStack() {};
									ProcCStack(bool manage_child_proc=false);
			void 					TestMessageReceived(char* data, int len, StreamBase *sch);
			void					OnComm(StreamBase* sock);

			const char*				GetApplicationName () { return "ProcC"; }

			bool					StartConsole();

			void					RegisterConsoleCommand();
			static void				CmdPassword(void* ctx, ConsoleSession* con, int argc, char* argv[]);
			static void				CmdSendMsgToParent(ProcCStack* stack, ConsoleSession* con, int , char**);
			void					SendTestMessageToParent();
			static void				CmdGoBusy(ProcCStack* stack, ConsoleSession* con, int , char**);
			void					GoBusy();
			static const int TEST_MESSAGE_FROM_CHILD_ID = 4444;
			class TestMessageFromChild : public Message
			{
			public:
				TestMessageFromChild() : Message(TEST_MESSAGE_FROM_CHILD_ID) { }

				string m_some_str;

				bool XdrProc(CXDR *pXDR);
			};

			static const int TEST_MESSAGE_TO_CHILD_ID = 8888;
			class TestMessageToChild : public Message
			{
			public:
				TestMessageToChild() : Message(TEST_MESSAGE_TO_CHILD_ID) { }
				int m_i;
				string m_s;

				bool XdrProc(CXDR *pXDR);
			};
			private:
			int m_transmitCount;
			int m_receiveCount;
	};

}//end namespace colib


#endif//PROCCSTACK_H_ALREADY_INCLUDED

