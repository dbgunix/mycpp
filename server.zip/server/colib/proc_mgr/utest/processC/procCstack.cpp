// stack.cpp
// vi:set ts=4 sw=4 nowrap:

#include "procCstack.h"
#include <socket/stream/console/console.h>
#include <console/role.h>
#include <console/interactive.h>
#include <utils/trace/trace.h>

namespace colib
{
	struct ChgPasswdCtrl
	{
		int m_state;
		string m_first_input;
	};
	bool ProcCStack::TestMessageFromChild::XdrProc(CXDR* pXDR)
	{
		return Message::XdrProc(pXDR)
			&& pXDR->XdrStringPadded(m_some_str);
	}

	bool ProcCStack::TestMessageToChild::XdrProc(CXDR* pXDR)
	{
		return Message::XdrProc(pXDR)
			&& pXDR->XdrInt(&m_i)
			&& pXDR->XdrStringPadded(m_s);
	}

	ProcCStack::ProcCStack(bool manage_child_proc)
	:
	ChildStackMgr(manage_child_proc),
	m_transmitCount(0),
	m_receiveCount(0)
	{
		m_hb_client.RegisterMsgHandler(TEST_MESSAGE_TO_CHILD_ID, callback(this, &ProcCStack::TestMessageReceived));
	}
	void ProcCStack::TestMessageReceived(char* data, int len, StreamBase *)
	{
		TestMessageToChild tm;
		tm.Decode(data, len);
		m_receiveCount++;
		TRACE("ProcC received %d bytes TestMessage with int %d and string of %d bytes\n",len,tm.m_i,tm.m_s.get_length());
		TRACE("%s\n", tm.m_s.c_str());
	}
	void				ProcCStack::OnComm(StreamBase* sock)
	{
		TRACE("ProcC OnComm...\n");
		char buf[128];

		if ( sock )
		{
			while ( true )
			{
				int num = sock->ReadBytes(buf, sizeof(buf));
				if ( num <= 0 ) break;
				sock->WriteBytes(buf, num);
				TRACE(3, "ProcCStack::Echo %d bytes succeed\n", num);
			}
		}
	}

	bool	ProcCStack::StartConsole()
	{
		//GlobalTelnetConsoleServer::GetInstance().Init(SocketAddr::GetAddrAny(8000+GetProcID()));
		return ChildStackMgr::StartConsole();
	}

	void	ProcCStack::RegisterConsoleCommand()
	{
		ChildStackMgr::RegisterConsoleCommand();
	
		ConsoleCommand::Register(	
				CONSOLE_ROLE_EVERYONE,
				(ConsoleCommand::Handler*)CmdPassword, NULL,
				"passwd", "Change Password");
		ConsoleCommand::Register(
				CONSOLE_ROLE_EVERYONE,
				(ConsoleCommand::Handler*)CmdSendMsgToParent, this,
				"msg", "Message to parent");
		ConsoleCommand::Register(
				CONSOLE_ROLE_EVERYONE,
				(ConsoleCommand::Handler*)CmdGoBusy, this,
				"gobusy", "demonstrate 100\% cpu usage");
	}

	void	FreeChangePasswordParams(void* ctx)
	{
		ChgPasswdCtrl* ctrl = (ChgPasswdCtrl*)ctx;
		delete ctrl;
	}

	bool	ChangePasswordCallback(void* ctx, ConsoleSession* con, ConsolePrompt* prompt, int argc, char* argv[])
	{
		argc--; argv++;
		bool to_exit = false;
		ChgPasswdCtrl* ctrl = (ChgPasswdCtrl*)ctx;

		switch ( ctrl->m_state )
		{
			case 0 :
			{
				ctrl->m_state = 1;
				prompt->SetPrompt("New password: "); 
				prompt->SetEcho('*');
				break;
			}
			case 1 :
			{
				ctrl->m_state = 2;
				ctrl->m_first_input = prompt->GetBuffer();
				prompt->SetPrompt("Retype new password: "); 
				prompt->SetEcho('*');
				break;
			}
			case 2 :
			{
				ctrl->m_state = 3;
				string retype_passwd = prompt->GetBuffer();
				if ( retype_passwd != ctrl->m_first_input )
				{
					con->Print("Password not match!\n");
				}
				else
				{
					con->Print("Aha, you cannot change password from console!\n");
				}

				to_exit = true;
				break;
			}
			default: 
			{
				to_exit = true;
				break;
			}
		}	
		
		return !to_exit;
	}

	void	ProcCStack::CmdPassword(void*, ConsoleSession* con, int , char**)
	{
		ChgPasswdCtrl* ctrl = new ChgPasswdCtrl;
		ctrl->m_state = 0;
		con->EnterInteractive((InteractiveShell::Handler*)ChangePasswordCallback, (InteractiveShell::Releaser*)FreeChangePasswordParams, ctrl);
	}
	void	ProcCStack::CmdSendMsgToParent(ProcCStack* stack, ConsoleSession* , int , char**)
	{
		if(!stack)
		{
			TRACE("Pointer to child stack is null\n");
			return;
		}
		stack->SendTestMessageToParent();
	}
	void ProcCStack::SendTestMessageToParent()
	{
		TestMessageFromChild c2p;
		c2p.m_some_str = "Child test msg <<<";

		TRACE("ProcCStack sending msg to parent %d\n", ++m_transmitCount);
		m_hb_client.SendMsgToParent(c2p);
	}
	void	ProcCStack::CmdGoBusy(ProcCStack* stack, ConsoleSession* , int , char**)
	{
		if(!stack)
		{
			TRACE("Pointer to child stack is null\n");
			return;
		}
		stack->GoBusy();
	}
	void ProcCStack::GoBusy()
	{
		while(1)
		{
			;
		}
	}

}//end namespace colib

