// colib_proc_mgr.h
// vi:set ts=4 sw=4 nowrap:

#ifndef THIRDPARTY_PROC_MGR_H_ALREADY_INCLUDED
#define THIRDPARTY_PROC_MGR_H_ALREADY_INCLUDED

#include<proc_mgr/proc_mgr.h>

namespace colib
{
	class ThirdpartyProcessMgr : public ProcessMgr
	{
		public:

								ThirdpartyProcessMgr();
			virtual 			~ThirdpartyProcessMgr();

			virtual bool		Init(string& err);
			virtual bool		Reload(const Options* opt, string& err);

			virtual ChildProc*  AddChildProc(const string& proc_name, int proc_id,
									string dir_path = "/usr/bin/",
									string extra_args = "");
		protected:

			virtual ChildProc*	CreateChildProc(const string& proc_name, int proc_id);
			virtual void		StartChildProc(ChildProc*, string extra_args, string dir_path);

			void				StartProcStateValidationTimer();
			void				OnProcessStateValidationTimeout(unsigned, void*);

		protected:

			PeriodicTimer		m_proc_state_validation_timer;
	};

}//end namespace colib

#endif

