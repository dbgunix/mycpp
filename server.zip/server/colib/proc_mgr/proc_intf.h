// colib_proc_intf.h
// vi:set ts=4 sw=4 nowrap:

#ifndef PROC_INTF_H_ALREADY_INCLUDED
#define PROC_INTF_H_ALREADY_INCLUDED

#include<utils/string.h>

namespace colib
{
	class ProcInterface
	{
		public:

			virtual							~ProcInterface() {}
											ProcInterface() {}
			//
			// Pure virtual functions
			//
			virtual const char*				GetProcName() const = 0;
			virtual int						GetProcID() const = 0;
			//
			// Virtual functions as manager
			//
			virtual bool					OnProcessHeartbeat(
													string proc_name, 
													int proc_id, 
													int status_code, 
													string status_str) 
											{
 												(void)proc_name;
												(void)proc_id;
												(void)status_code;
											   	(void)status_str;
												return true; 
											}
			//
			// Virtual functions as child process
			//
			virtual bool					GetStatus4Heartbeat(
													int& status_code,
													string& status_str)
											{
												(void)status_code;
												(void)status_str;
												return true;
											}
	};

}//end namespace colib

#endif
