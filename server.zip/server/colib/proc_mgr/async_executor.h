// async_executor.h
// vi:set ts=4 sw=4 nowrap:

#ifndef ASYNC_EXECUTOR_H_ALREADY_INCLUDED
#define ASYNC_EXECUTOR_H_ALREADY_INCLUDED

#include <event_loop/fdh.h>
#include <event_loop/activity_hld.h>
#include <timer/oneshot_timer.h>

#include <vector>
#include <string>

namespace colib
{
	class AsyncExecutor;

	class PIDMonitor : public FileDescriptorHandler
	{
		public:
		
			virtual ~PIDMonitor() {};
			//
			// Get result
			//
			bool GetStatus() const { return m_status; }
			int GetExitCode() const { return m_exit_code; }
			string GetError() const { return m_error; }
			const char* GetData() const { return &m_data[0]; }
			unsigned GetDataLength() const { return m_data.size(); }

			PIDMonitor(const PIDMonitor&) = delete;
			PIDMonitor& operator=(const PIDMonitor&) = delete;

		private:

			PIDMonitor();

			bool IsReady() const;
			bool Init(int fd, unsigned max_data_size);
			void MonitorPID(int pid, unsigned timeout_sec);
			void SetFinishCallback(const Callback1<const PIDMonitor&>& on_finish) { m_on_finish = on_finish; }
			//
			void read();
			void write() {};

			void RemoveFD();
			void StartZombieCleaner();
			eCallbackRt CleanUp();	
			void OnTransactionTimeout(unsigned, void*);
			void KillTransaction();

			void DispatchCB() { m_on_finish.Dispatch(*this); }

		private:

			Callback1<const PIDMonitor&> m_on_finish;
			OneShotTimer m_transaction_timer;
			ActivityHold m_zombie_cleaner;
			int m_pid;
			bool m_status;
			int m_exit_code;
			string m_error;
			std::vector<char> m_data;
			unsigned m_max_data_size;

		friend class AsyncExecutor;
	};

	class AsyncExecutor
	{
		public:

			virtual ~AsyncExecutor() {};

			bool IsReady() const { return m_pid_monitor.IsReady(); }

			AsyncExecutor(const AsyncExecutor&) = delete;
			AsyncExecutor& operator=(const AsyncExecutor&) = delete;

		protected:

			AsyncExecutor(
					unsigned timeout_sec = 30, 
					unsigned retry_limit = 1, 
					unsigned max_data_size = 32 * 1024);

			virtual void AbnormalExit(string err) = 0;
			virtual void NormalExit(int code) = 0;
			virtual int Execute(int fd) = 0;
			//
			void SetParams(
					unsigned timeout_sec = 30,
					unsigned retry_limit = 1,
					unsigned max_data_size = 32 * 1024);

			void OnFinish(const PIDMonitor&);
			void OnRetry(unsigned, void*);
			void ExecuteAndMonitor();
			//
			const char* PIDMonitorData() const { return m_pid_monitor.GetData(); }
			unsigned PIDMonitorDataLength() const { return m_pid_monitor.GetDataLength(); }

		protected:

			unsigned m_timeout_sec;
			unsigned m_retry_limit;
			unsigned m_max_data_size;

			OneShotTimer m_retry_timer;
			PIDMonitor m_pid_monitor;
	};

	class AsyncFunction : public AsyncExecutor
	{
		public:
            typedef Callback3<const std::string&/*in param*/, std::string&/*out param*/, int&/*status*/> RunFn;
            typedef Callback2<std::string&/*out param*/, int/*status*/> ReturnCb;
            AsyncFunction();
			virtual ~AsyncFunction() {};
            void Run(const std::string& inparam, const RunFn& fn, const ReturnCb& ret);
        private:
			AsyncFunction(const AsyncFunction&) = delete;
			AsyncFunction& operator=(const AsyncFunction&) = delete;
			virtual void AbnormalExit(string err);
			virtual void NormalExit(int code);
			virtual int Execute(int fd);
            RunFn m_fn;
            ReturnCb m_retcb;
            std::string m_inparam;
            static int m_call_req;
    };

}//end namespace colib


#endif

