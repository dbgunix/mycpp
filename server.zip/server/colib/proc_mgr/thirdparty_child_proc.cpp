// vi:set ts=4 sw=4 nowrap:

#include<proc_mgr/thirdparty_child_proc.h>
#include<utils/trace/trace.h>
#include<utils/kernel/SysTime.h>

#include <syslog.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/prctl.h>
#include <unistd.h>
#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <string.h>

namespace colib
{
	const char* ThirdpartyChildProc::PID_STATUS = "/proc/%u/status";

	ThirdpartyChildProc::ThirdpartyChildProc(string proc_name, int proc_id)
		:
		ChildProc(proc_name, proc_id)
	{
	}

	ThirdpartyChildProc::~ThirdpartyChildProc()
	{
	}
	
	int					ThirdpartyChildProc::Run(string exec_str, string extra_args, string ipc_args)
	{
		(void)ipc_args; // don't care	

        // max parameters is 64
        int i = 0; char *argv[65];

        char proctitle[128] = {0};
        snprintf(proctitle, sizeof(proctitle),"%s_%d_", GetProcName().c_str(), GetProcID());
        argv[i++] = proctitle; 
        char *p = strtok((char*)extra_args.c_str(), " ");
        while(p && i<64) {
            argv[i++] = p;
            p = strtok(NULL, " ");
        }
        argv[i] = NULL;
        //prctl(PR_SET_NAME, proctitle);
        return execvp((char*)exec_str.c_str(), argv);

       /* 
		return execl(
					exec_str.c_str(), 
					GetProcName().c_str(), 
					extra_args.c_str(), 
					(char*)0);
                    */
	}

	void				ThirdpartyChildProc::CheckProcessStatus()
	{
		KernelState state = ReadProcessStatus(m_pid);

		if ( 
			( KernelState::RUNNING == state ) || 
			( KernelState::SLEEPING == state) || 
			( KernelState::LOW_PRIORITY == state) )
		{
			ChangeState(Heartbeated);
			m_state_str = "Kernl state checked";
			m_heartbeated = true;
			m_heartbeat_clock = colib::SysTime::Get();
		}
		/*
		 * ShutDown should be done by heartbeat timer
		 *
		else
		{
			ShutDown();
			m_state_str = string::Format("state: (%d)", state);
		}
		*/
	}

	ThirdpartyChildProc::KernelState	ThirdpartyChildProc::ReadProcessStatus(int pid)
	{
		FILE *fp = 0;
		char filename[128], line[256];
		char state = 'U';
		KernelState state_info = KernelState::UNKNOWN;

		sprintf(filename, PID_STATUS, pid);

		if ( 0 == (fp = fopen(filename, "r")) )
		{
			return KernelState::UNKNOWN;
		}

		while (fgets(line, 256, fp) != 0)
		{
			if (!strncmp(line, "State:", 6))
			{
				sscanf(line + 7, "%c", &state);
				break;
			}
		}
		fclose(fp);

		switch(state)
		{
			case 'D':
				state_info = UNINTERRUPTABLE_SLEEP;
				break;
			case 'N':
				state_info = LOW_PRIORITY;
				break;
			case 'R':
				state_info = RUNNING;
				break;
			case 'S':
				state_info = SLEEPING;
				break;
			case 'T':
				state_info = TRACED_STOPPED;
				break;
			case 'Z':
				state_info = ZOMBIE;
				break;
			default:
				state_info = UNKNOWN;
				break;
		}

		return state_info;
	}

}//end namespace colib
