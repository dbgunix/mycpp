// vi:set ts=4 sw=4 nowrap:

#include<proc_mgr/thirdparty_proc_mgr.h>
#include<proc_mgr/thirdparty_child_proc.h>
#include<utils/trace/trace.h>
#include<console/command/debug.h>

#include <signal.h>
#include <ctype.h>

namespace colib
{
	ThirdpartyProcessMgr::ThirdpartyProcessMgr()
		: 
		m_proc_state_validation_timer("ProcessStatus")
	{
		m_proc_state_validation_timer.SetExpireCb(callback(this, 
					&ThirdpartyProcessMgr::OnProcessStateValidationTimeout));
	}

	ThirdpartyProcessMgr::~ThirdpartyProcessMgr()
	{	
	}
	
	bool				ThirdpartyProcessMgr::Init(string& err)
	{
		if ( !ProcessMgr::Init(err) ) return false;
		StartProcStateValidationTimer();	
		return true;
	}

	bool				ThirdpartyProcessMgr::Reload(const Options* opt, string& err)
	{
		int proc_heartbeat_freq_sec = m_proc_heartbeat_freq_sec;

		bool ret = ProcessMgr::Reload(opt, err);
	
		if ( ret )
		{
			if ( proc_heartbeat_freq_sec != m_proc_heartbeat_freq_sec ) 
			{
				StartProcStateValidationTimer();	
			}
		}

		return ret;
	}

	void				ThirdpartyProcessMgr::StartProcStateValidationTimer()
	{
		m_proc_state_validation_timer.Start(m_proc_heartbeat_freq_sec * 1000);
	}

	void				ThirdpartyProcessMgr::OnProcessStateValidationTimeout(unsigned, void*)
	{
        for ( Dlist<ChildProc*>::Node* node = m_child_proc.GetHead();
                node != 0; node = m_child_proc.GetNext(node) )
        {
			ThirdpartyChildProc* proc = reinterpret_cast<ThirdpartyChildProc*>(node->GetData());
            proc->CheckProcessStatus();
        }
	}		
		
	ChildProc*			ThirdpartyProcessMgr::CreateChildProc(const string& proc_name, int proc_id)
	{
		return new ThirdpartyChildProc(proc_name, proc_id);
	}
		
	void				ThirdpartyProcessMgr::StartChildProc(ChildProc* proc, string extra_args, string dir_path)
	{	
		(reinterpret_cast<ThirdpartyChildProc*>(proc))->Start(extra_args, dir_path, "");
	}

	ChildProc*			ThirdpartyProcessMgr::AddChildProc(const string& proc_name, int proc_id, string dir_path, string extra_args)
	{
		return ProcessMgr::AddChildProc(proc_name, proc_id, dir_path, extra_args);
	}

}//end namespace colib

