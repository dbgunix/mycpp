// colib_child_hb_client.cpp
// vi:set ts=4 sw=4 nowrap:

#include<proc_mgr/child_hb_client.h>
#include<message/message_type.h>
#include<event_loop/event_loop.h>
#include<utils/trace/trace.h>
#include<console/role.h>
#include<console/command/debug.h>

#include <ctype.h>
#include <syslog.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>

namespace colib
{	
	//
	// ChildHeartbeatMessage
	//
	ChildHeartbeatMessage::ChildHeartbeatMessage()
		:
		Message(ChildHeartbeatMsgID),	
		m_pid(0),
		m_status_code(0)
	{
	}

	ChildHeartbeatMessage::~ChildHeartbeatMessage()
	{
	}

	bool					ChildHeartbeatMessage::XdrProc(CXDR* xdr)
	{
		if ( 
			!Message::XdrProc(xdr) ||
			!xdr->XdrInt(&m_pid) ||
			!xdr->XdrInt(&m_status_code) ||
			!xdr->XdrStringPacked(m_status_str)
		   ) return false;

		int n = m_commands_support.Size();
		if ( !xdr->XdrInt(&n) ) return false;

		if ( xdr->GetOp() == CXDR::XDR_ENCODE)
		{
			for ( Dlist<string>::Node* node = m_commands_support.GetHead();
					node != 0; node = m_commands_support.GetNext(node) )
			{
				if ( !xdr->XdrStringPacked(node->GetData()) ) return false;
			}
		}
		else
		{
			for ( int i = 0; i < n; i++ )
			{
				string command;
				if ( !xdr->XdrStringPacked(command) ) return false;
				m_commands_support.Append(command);
			}
		}

		return true;
	}

	string					ChildHeartbeatMessage::DumpHeartbeat(bool dump_full)
	{
		string heartbeat_str = "";

		if ( dump_full ) heartbeat_str.AppendFmt("Heartbeat::m_pid = %d\n", m_pid);

		heartbeat_str.AppendFmt("Heartbeat::m_status_code = %d\n", m_status_code);
		heartbeat_str.AppendFmt("Heartbeat::m_status_str = %s\n", m_status_str.c_str());

		if ( dump_full )
		{
			heartbeat_str += "Heartbeat::m_commands_support = {";
			for ( Dlist<string>::Node* node = m_commands_support.GetHead();
					node != 0; node = m_commands_support.GetNext(node) )
			{
				heartbeat_str.AppendFmt("\"%s\", ", node->GetData().c_str());
			}
			heartbeat_str += "}\n";
		}

		return heartbeat_str;
	}
	//
	// ChildHBClient
	//
	static ValueList::ValueHolder	InitStats()
	{
		return 
		{
			Value("ipc_path", "" ),
			Value("heartbeat_sec", 0 ),
			Value("num_tx_heartbeat", 0 ),
			Value("num_fail_heartbeat", 0 ),
			Value("latest_heartbeat_pid", 0 ),
			Value("latest_heartbeat_status_code", 0 ),
			Value("latest_heartbeat_status_str", "" )
		};
	};

	ChildHBClient::ChildHBClient(ProcInterface* intf)
		:
		m_proc_intf(intf),
		m_ipc_socket("IPCSocket", StreamBase::TlsOpt::DISABLE_TLS, StreamBase::XdrOpt::ENABLE_XDR),	
		m_ipc_reconnect_timer("IPCReconnectTimer"), 
		m_ipc_reconnect_limit(0),
		m_heartbeat_timer("ChildHeartbeatTimer"),
		m_heartbeat_timeout_sec(10),
		m_ipc_stats(InitStats())
	{
		m_ipc_socket.SetCloseCallback(callback(this, &ChildHBClient::OnIPCSocketClosed));
		m_ipc_reconnect_timer.SetExpireCb(callback(this, &ChildHBClient::OnIPCSocketReconnect));
		m_heartbeat_timer.SetExpireCb(callback(this, &ChildHBClient::OnHeartbeatTimeout));
	}

	ChildHBClient::~ChildHBClient()
	{
	}

	string					ChildHBClient::CmdLineHelp()
	{
		return "-ipc path [-hbs heartbeat_sec]";
	}
	
	bool					ChildHBClient::ParseCmdLine(int argc, char* argv[])
	{	
		for ( int i = 1; i < argc; i++ )
		{	
			if ( !strcmp(argv[i], "-ipc") )
			{
				i++;
				if ( argc <= i ) 
				{
					return false;
				}
				m_ipc_path = string(argv[i]);				
			}
			else if ( !strcmp(argv[i], "-hbs") )
			{	
				i++;
				if ( ( argc <= i ) || !isdigit((int)(*argv[i])) )
				{
					return false;
				}
				m_heartbeat_timeout_sec = atoi(argv[i]);
			}
		}

		return true;
	}

	bool					ChildHBClient::Init(string& err)
	{
		if ( m_proc_intf == 0 )
		{
			err = "colib process interface NULL pointer\n";
			return false;
		}

		if ( m_ipc_path == "" ) 
		{
			err = "IPC HB path to parent process missing, mandatory through \"-ipc\" in CmdLine\n";
			return false;
		}

		m_ipc_reconnect_limit = 10;
		ConnectIPC();

		m_heartbeat_timer.Start(m_heartbeat_timeout_sec * 1000);
	
		return true;
	}

	bool					ChildHBClient::ConnectIPC()
	{
		string ipc_path = "UNIX;" + m_ipc_path;

		if ( !m_ipc_socket.Connect(ipc_path, "", false) )
		{
			m_ipc_reconnect_timer.Start(50);	// Retry after 50ms
			m_ipc_reconnect_limit--;
			return false;
		}
		else
		{	
			OnHeartbeatTimeout(0,0);	//Send heartbeat
			return true;
		}
	}

	void					ChildHBClient::OnIPCSocketReconnect(unsigned, void*)
	{
		if ( m_ipc_reconnect_limit <= 0 ) 
		{
			TRACE("%s(%d) exit after exceed retry limit to connect parent IPC\n",
					m_proc_intf->GetProcName(), m_proc_intf->GetProcID());
			EventLoop::GetInstance().Terminate(true);
		}
		else
		{
			//
			// Reconnect
			//
			ConnectIPC();
		}
	}

	void					ChildHBClient::OnHeartbeatTimeout(unsigned, void*)
	{
		ChildHeartbeatMessage heartbeat;
		heartbeat.m_pid = getpid();
		
		if ( !m_proc_intf->GetStatus4Heartbeat(heartbeat.m_status_code, heartbeat.m_status_str) )
		{	
			member_TRACE(&m_ipc_debug, 3, "%s(%d) fail to get heartbeat status\n",
					m_proc_intf->GetProcName(), m_proc_intf->GetProcID());
			IPC_STAT(num_fail_heartbeat)++;
			return;
		}

		RootConsoleCommand::GetInstance().GetAllCommands(heartbeat.m_commands_support);

		if ( !SendMsgToParent(heartbeat) )
		{
			member_TRACE(&m_ipc_debug, 3, "%s(%d) fail to encode/send heartbeat\n",
					m_proc_intf->GetProcName(), m_proc_intf->GetProcID());
			IPC_STAT(num_fail_heartbeat)++;
		}
		else
		{
			member_TRACE(&m_ipc_debug, 5, "%s(%d) send heartbeat succeed at time: %d\n", 
					m_proc_intf->GetProcName(), m_proc_intf->GetProcID(), (int)time(NULL));
			member_TRACE(&m_ipc_debug, 7, "Heartbeat detail --\n");
			member_TRACE(&m_ipc_debug, 7, "%s\n", heartbeat.DumpHeartbeat(true).c_str());
			IPC_STAT(num_tx_heartbeat)++;
			IPC_STAT(latest_heartbeat_pid) = heartbeat.m_pid;
			IPC_STAT(latest_heartbeat_status_code) = heartbeat.m_status_code;
			m_ipc_stats[ChildHBClient::IPCStat_latest_heartbeat_status_str].SetFromString(heartbeat.m_status_str.c_str());
		}
	}

	void					ChildHBClient::OnIPCSocketClosed(StreamBase*)
	{
		TRACE("Exit on detecting IPC socket to parent closed\n");
		EventLoop::GetInstance().Terminate(true);
	}
	
	void		ChildHBClient::RegisterMsgHandler(int msg_id, const Callback3<char*, int, StreamBase*>& cbk)
	{
		m_ipc_socket.RegisterMsgHandler(msg_id, cbk);
	}

	void		ChildHBClient::RegisterAnyHandler(const Callback3<char*, int, StreamBase*>& cbk)
	{
		m_ipc_socket.RegisterAnyHandler(cbk);
	}

	bool		ChildHBClient::SendDataToParent(char* buf, int len)
	{
		return len == m_ipc_socket.WriteBytes(buf, len);
	}

	bool		ChildHBClient::SendMsgToParent(Message& msg)
	{
		return m_ipc_socket.WriteMessage(msg);
	}

	void		ChildHBClient::ConsoleCommand(ConsoleSession* con, int argc, char* argv[])
	{
		const char* usage = "Usage:\tstats|debug|ipcc";

		if ( argc == 0 )
		{
			con->Print(usage);
			return;
		}
			
		if ( !strcmp(argv[0], "stats") )
		{
			string ipc_path = "UNIX;" + m_ipc_path;
			m_ipc_stats[ChildHBClient::IPCStat_ipc_path].SetFromString(ipc_path.c_str());
			IPC_STAT(heartbeat_sec) = m_heartbeat_timeout_sec;
			m_ipc_stats.ConsoleCommand(con, argc-1, argv+1);
		}
		else if ( !strcmp(argv[0], "ipcc") )
		{
			m_ipc_socket.ConsoleCommand(con, argc-1, argv+1);
		}
		else if ( !strcmp(argv[0], "debug") )
		{	
			HandleDebugCommand(con, argc-1, argv+1, m_ipc_debug, "ChildHBClient");
		}
		else con->Print(usage);
	}

}//end namespace colib
