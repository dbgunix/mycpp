// child_proc.h
// vi:set ts=4 sw=4 nowrap:

#ifndef CHILD_PROC_H_ALREADY_INCLUDED
#define CHILD_PROC_H_ALREADY_INCLUDED

#include<utils/string.h>
#include<utils/callback.h>
#include <event_loop/fdh.h>

#include <map>

namespace colib
{
	class ProcessMgr;
	
	class ChildProc;
	//
	// ProcConfig
	//
	class ProcConfig
	{
		public:

								ProcConfig();
								ProcConfig(string name, int id);
			virtual				~ProcConfig();
			//
			string				GetName() const { return m_name; }
			void				SetName(string name) { m_name = name; }
			//
			int					GetID() const { return m_id; }		
			void				SetID(int id) { m_id = id; }
			//
			string				GetExtraArgs() const { return m_extra_args; }
			void				SetExtraArgs(string extra_args) { m_extra_args = extra_args; }
			//
			string				GetDirPath() const { return m_dir_path; }
			void				SetDirPath(string dir_path) { m_dir_path = dir_path; }

		private:

			string				m_name;
			int					m_id;
			//
			// The attributes not mandatory
			//
			string				m_extra_args;
			string				m_dir_path;
	};
	//
	// ProcMonitor
	//
	class ProcMonitor : public FileDescriptorHandler
	{
		public:
		
			virtual 			~ProcMonitor() {};
	
								ProcMonitor(const ProcMonitor&) = delete;
								ProcMonitor& operator=(const ProcMonitor&) = delete;

		private:

								ProcMonitor(ChildProc&);

			bool 				Init(int fd);
			void				RemoveFD();
			//
			void				read();
			void				write() {};

		private:

			ChildProc&			m_parent;

		friend class ChildProc;
	};
	//
	// ChildProc
	//
	class ChildProc
	{
		public:
			//	
			// Retry limit to avoid keep restarting the child proc
			//
			static const int	QuickRestartRetryCount	=	5;

			enum State
			{
				Instantiated = 0,
				Forked,
				Heartbeated,
				Killed,
				Error,
				StateCount
			};

								ChildProc(string proc_name, int proc_id);
			virtual				~ChildProc();
			
			virtual string		GetType() const = 0;					

			string				GetProcName() const { return m_proc_config.GetName(); }
			int					GetProcID() const { return m_proc_config.GetID(); }

			string				GetDirPath() const { return m_proc_config.GetDirPath(); }
			void				SetDirPath(string dir_path) { m_proc_config.SetDirPath(dir_path); }

			string				GetExtraArgs() const { return m_proc_config.GetExtraArgs(); }
			void				SetExtraArgs(string extra_args) { m_proc_config.SetExtraArgs(extra_args); }

			void				SetStateChangeCbk(const Callback1<int>& cbk) { m_state_change = cbk; }

            void                SetSucceedCbk(const Callback2<string, int>& cbk) { m_succeed_cbk = cbk; }
            void                SetFailureCbk(const Callback3<string, int, string>& cbk) { m_failure_cbk = cbk; }
            void                SetKillCbk(const Callback3<string, int, const string&>& cbk) { m_kill_cbk = cbk; }
		protected:	
			
			void				Start(string extra_args, string dir_path, string ipc_path);
			virtual int			Run(string exec_str, string extra_args, string ipc_args) = 0;

			void				CheckHeartbeat();
			void				ChangeState(int);
			void				Terminate(int sig);
			void				CleanUp();
			virtual void		ShutDown(string reason);		

			virtual void		OnStartSucceed() = 0;
			virtual void		OnShutDownSucceed() = 0;

			void				DispatchSucceed() { m_succeed_cbk.Dispatch(GetProcName(), GetProcID()); }
			void				DispatchFailure(string err) { m_failure_cbk.Dispatch(GetProcName(), GetProcID(), err); }
			void				DispatchKill(const string& err) { m_kill_cbk.Dispatch(GetProcName(), GetProcID(), err); }

			virtual string		DumpStatus();

		protected:

			ProcConfig			m_proc_config;
			int					m_pid;
			ProcMonitor			m_monitor;

			Callback1<int>		m_state_change;
			int					m_quick_restart_limit;

			int					m_state;
			string				m_state_str;
			
			bool				m_heartbeated;
			unsigned			m_heartbeat_clock;
			string              m_heartbeat_status;
	
			Callback2<string, int>			m_succeed_cbk;
			Callback3<string, int, string>	m_failure_cbk;
			Callback3<string, int, const string&>	m_kill_cbk;

		friend class ProcessMgr;
		friend class ProcMonitor;
	};

	typedef std::map<int, ChildProc*> PID_TO_PROC_MAP;

}//end namespace colib

#endif
