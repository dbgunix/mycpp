// colib_child_hb_client.h
// vi:set ts=4 sw=4 nowrap:

#ifndef CHILD_HB_CLIENT_H_ALREADY_INCLUDED
#define CHILD_HB_CLIENT_H_ALREADY_INCLUDED

#include<proc_mgr/proc_intf.h>
#include<message/message.h>
#include<config/value.h>
#include<timer/oneshot_timer.h>
#include<timer/periodic_timer.h>
#include<socket/stream/stream_client.h>
#include<console/session.h>

namespace colib
{	
	//
	// ChildHeartbeatMessage
	//
	class ChildHeartbeatMessage : public Message
	{
		public:

			virtual				~ChildHeartbeatMessage();
								ChildHeartbeatMessage();

			string				DumpHeartbeat(bool dump_full = false);

		public:

			int					m_pid;
			int					m_status_code;
			string				m_status_str;
			Dlist<string>		m_commands_support;

		protected:

			virtual bool		XdrProc (CXDR*);
	};
	//
	// ChildHBClient
	//
	class ChildHBClient
	{
		public:	
	
			enum IPCStats
			{
				IPCStat_ipc_path,
				IPCStat_heartbeat_sec,
				IPCStat_num_tx_heartbeat,
				IPCStat_num_fail_heartbeat,
				IPCStat_latest_heartbeat_pid,
				IPCStat_latest_heartbeat_status_code,
				IPCStat_latest_heartbeat_status_str,
				IPCStatCount
			};

								ChildHBClient(ProcInterface* intf);
			virtual				~ChildHBClient();

			bool				Init(string& err);
			const StreamClient*	GetStreamClient() const { return &m_ipc_socket; }
			
			void				RegisterMsgHandler(int msg_id, const Callback3<char*, int, StreamBase*>& cbk);
            void		        RegisterAnyHandler(const Callback3<char*, int, StreamBase*>& cbk);
			bool				SendMsgToParent(Message& msg);
            bool		        SendDataToParent(char* buf, int len);

			string				CmdLineHelp();
			bool				ParseCmdLine(int argc, char* argv[]);

			void				ConsoleCommand(ConsoleSession* con, int argc, char* argv[]);

		private:	
			
			void				OnHeartbeatTimeout(unsigned, void*);	
			bool				ConnectIPC();
			void				OnIPCSocketReconnect(unsigned, void*);
			void				OnIPCSocketClosed(StreamBase*);
		
		private:

			ProcInterface*	m_proc_intf;
			MemberSet			m_ipc_debug;

			StreamClient		m_ipc_socket;
			string				m_ipc_path;
			OneShotTimer		m_ipc_reconnect_timer;
			int					m_ipc_reconnect_limit;
			PeriodicTimer		m_heartbeat_timer;
			int					m_heartbeat_timeout_sec;		
			
			ValueList			m_ipc_stats;
	};
	#define IPC_STAT(stat)		m_ipc_stats[ChildHBClient::IPCStat_##stat].AsInt()

}
#endif
