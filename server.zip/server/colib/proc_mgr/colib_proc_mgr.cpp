// vi:set ts=4 sw=4 nowrap:

#include<proc_mgr/colib_proc_mgr.h>
#include<message/message_type.h>
#include<utils/trace/trace.h>

namespace colib
{	
	static ValueList::ValueHolder	InitExtraStats()
	{
		return
		{
			Value("num_rx_heartbeat", 0 ),
			Value("num_decode_heartbeat_fail", 0 ),
			Value("num_fail_heartbeat", 0 ),
			Value("ipc_path", "" )
		};
	};
	
	ColibProcessMgr::ColibProcessMgr(ProcInterface* intf)
		:
		m_proc_intf(intf),
		m_ipc_server("IPCServer", StreamBase::TlsOpt::DISABLE_TLS, StreamBase::XdrOpt::ENABLE_XDR),
		m_colib_proc_stats(InitExtraStats())
	{
		m_ipc_server.SetNewClientCallback(callback(this, &ColibProcessMgr::OnNewIPCClient));
	}

	ColibProcessMgr::~ColibProcessMgr()
	{	
	}
	
	bool				ColibProcessMgr::Init(string& err)
	{
		if ( !m_proc_intf )
		{
			err = "colib process interface NULL pointer\n";
			return false;
		}

		string ipc_path = "UNIX;" + GetIPCPath();
		if ( !m_ipc_server.Init(ipc_path) )
		{
			err = string::Format("Fail to start IPC HB server with path %s\n", ipc_path.c_str());
			return false;
		}

		return ProcessMgr::Init(err);
	}
		
	string				ColibProcessMgr::GetIPCPath()
	{
		return string::Format("%s_%d_IPC", m_proc_intf->GetProcName(), m_proc_intf->GetProcID());
	}

	void				ColibProcessMgr::OnNewIPCClient(StreamClientHandler* sch)
	{
		if ( sch )
		{
			sch->RegisterMsgHandler(ChildHeartbeatMsgID, callback(this, &ColibProcessMgr::OnRxHeartbeat));
		}
	}

	void				ColibProcessMgr::OnRxHeartbeat(char* data, int len, StreamBase* socket)
	{
		ChildHeartbeatMessage heartbeat;
		if ( !heartbeat.Decode(data, len) )
		{	
			COLIB_PROC_STAT(num_decode_heartbeat_fail)++;
			member_TRACE(&m_proc_debug_set, 3, "Fail to decode heartbeat message\n");
			return;
		}

		COLIB_PROC_STAT(num_rx_heartbeat)++;
	
		ColibChildProc* proc = 0;
		
		PID_TO_PROC_MAP::iterator it = m_pid_to_child_proc_map.find(heartbeat.m_pid);
		
		if ( it == m_pid_to_child_proc_map.end() )
		{	
			for ( Dlist<ChildProc*>::Node* node = m_child_proc.GetHead();
				node != 0; node = m_child_proc.GetNext(node) )
			{
				ColibChildProc* cur = reinterpret_cast<ColibChildProc*>(node->GetData());
				if ( cur && ( cur->m_pid == heartbeat.m_pid ) )
				{
					proc = cur;
					m_pid_to_child_proc_map.insert(std::pair<int, ChildProc*>(proc->m_pid, proc));
					break;
				}
			}
		}
		else
		{
			proc = reinterpret_cast<ColibChildProc*>(it->second);
		}
	
		if ( proc == 0 )
		{
			COLIB_PROC_STAT(num_fail_heartbeat)++;
			member_TRACE(&m_proc_debug_set, 3, "No child with pid=%d for heartbeat message\n", heartbeat.m_pid);
			return;
		}

		if ( !proc->Heartbeat(&heartbeat, socket) )
		{
			COLIB_PROC_STAT(num_fail_heartbeat)++;
			member_TRACE(&m_proc_debug_set, 3, "Child proc %s(%d) heartbeat failed\n", 
                    proc->GetProcName().c_str(), proc->GetProcID());
			return;
		}

		if ( !m_proc_intf->OnProcessHeartbeat(
												proc->GetProcName(), 
												proc->GetProcID(), 
												heartbeat.m_status_code, 
												heartbeat.m_status_str) )
		{
			COLIB_PROC_STAT(num_fail_heartbeat)++;
			member_TRACE(&m_proc_debug_set, 3, "Process interface heartbeat %s(%d) failed\n", 
					proc->GetProcName().c_str(), proc->GetProcID());
			return;
		}

		member_TRACE(&m_proc_debug_set, 7, "%s(%d) receive heartbeat message\n", 
						proc->GetProcName().c_str(), proc->GetProcID());
		
		return;
	}

	ChildProc*			ColibProcessMgr::CreateChildProc(const string& proc_name, int proc_id)
	{
		return new ColibChildProc(proc_name, proc_id);
	}
	
	void				ColibProcessMgr::StartChildProc(ChildProc* proc, string extra_args, string dir_path)
	{	
		if ( m_proc_heartbeat_freq_sec != DEFAULT_CHILD_HEARTBEAT_INTERVAL_SEC )
		{
			extra_args.AppendFmt("-hbs %d ", m_proc_heartbeat_freq_sec);
		}

		(reinterpret_cast<ColibChildProc*>(proc))->Start(extra_args, dir_path, GetIPCPath());
	}

	ChildProc*			ColibProcessMgr::AddChildProc(const string& proc_name, int proc_id, string dir_path, string extra_args)
	{
		ChildProc* proc = ProcessMgr::AddChildProc(proc_name, proc_id, dir_path, extra_args);
	
		if ( proc )
		{
			ColibChildProc* colib_proc = reinterpret_cast<ColibChildProc*>(proc);

			for ( MsgCbkMap::iterator it = m_register_all.begin();
					it != m_register_all.end(); ++it )
			{
				colib_proc->RegisterMsgHandler(it->first, it->second);
			}

			for ( ProcMsgCbkMap::iterator it = m_register_proc_name.begin();
					it != m_register_proc_name.end(); ++it )
			{
				if ( it->first == proc_name )
				{
					for ( MsgCbkMap::iterator iter = it->second.begin();
							iter != it->second.end(); ++iter )
					{
						colib_proc->RegisterMsgHandler(iter->first, iter->second);
					}
					break;
				}
			}	
	
			for ( ProcMsgCbkMap::iterator it = m_register_proc_name_id.begin();
					it != m_register_proc_name_id.end(); ++it )
			{
				if ( it->first == RegisterIndex(proc_name, proc_id) )
				{
					for ( MsgCbkMap::iterator iter = it->second.begin();
							iter != it->second.end(); ++iter )
					{
						colib_proc->RegisterMsgHandler(iter->first, iter->second);
					}
					break;
				}
			}
		}
	
		return proc;
	}

	bool				ColibProcessMgr::SendMsg2All(Message& item)
	{
		return m_ipc_server.SendMsgToAllClients(item);
	}

	bool				ColibProcessMgr::SendData2All(char* data, int len)
	{
		return m_ipc_server.SendBytesToAllClients(data, len);
	}

	bool				ColibProcessMgr::SendMsg(const string& proc_name, int proc_id, Message& item)
	{
		for ( Dlist<ChildProc*>::Node* node = m_child_proc.GetHead();
				node != 0; node = m_child_proc.GetNext(node) )
		{
			ColibChildProc* cur = reinterpret_cast<ColibChildProc*>(node->GetData());
			if ( cur && (cur->GetProcName() == proc_name) && (cur->GetProcID() == proc_id) )
			{
				return cur->SendMsg(item);
			}
		}

		return false;
	}
	
	bool				ColibProcessMgr::SendData(const string& proc_name, int proc_id, char* buf, int len)
	{
		for ( Dlist<ChildProc*>::Node* node = m_child_proc.GetHead();
				node != 0; node = m_child_proc.GetNext(node) )
		{
			ColibChildProc* cur = reinterpret_cast<ColibChildProc*>(node->GetData());
			if ( cur && (cur->GetProcName() == proc_name) && (cur->GetProcID() == proc_id) )
			{
				return cur->SendData(buf, len);
			}
		}

		return false;
	}
	string				ColibProcessMgr::RegisterIndex(string proc_name, int proc_id)
	{
		return string::Format("%s_%d", proc_name.c_str(), proc_id);
	}


	void				ColibProcessMgr::RegisterMsgHandler4All(int msg_id, const Callback3<char*, int, StreamBase*>& cbk)
	{
		m_register_all[msg_id] = cbk;

		for ( Dlist<ChildProc*>::Node* node = m_child_proc.GetHead();
				node != 0; node = m_child_proc.GetNext(node) )
		{
			ColibChildProc* proc = reinterpret_cast<ColibChildProc*>(node->GetData());
	
			if ( proc )
			{
				proc->RegisterMsgHandler(msg_id, cbk);
			}
		}
	}

	void				ColibProcessMgr::RegisterMsgHandler4ProcName(
																const string& proc_name,
																int msg_id, 
																const Callback3<char*, int, StreamBase*>& cbk)
	{
		m_register_proc_name[proc_name][msg_id] = cbk;

		for ( Dlist<ChildProc*>::Node* node = m_child_proc.GetHead();
				node != 0; node = m_child_proc.GetNext(node) )
		{
			ColibChildProc* proc = reinterpret_cast<ColibChildProc*>(node->GetData());

			if ( proc && ( proc->GetProcName() == proc_name ) )
			{
				proc->RegisterMsgHandler(msg_id, cbk);
			}
		}	
	
		for ( Dlist<ChildProc*>::Node* node = m_add_request.GetHead();
				node != 0; node = m_add_request.GetNext(node) )
		{
			ColibChildProc* proc = reinterpret_cast<ColibChildProc*>(node->GetData());
		
			if ( proc && ( proc->GetProcName() == proc_name ) )
			{
				proc->RegisterMsgHandler(msg_id, cbk);
			}
		}
	}

	void				ColibProcessMgr::RegisterMsgHandler(
																const string& proc_name, 
																int proc_id,
																int msg_id, 
																const Callback3<char*, int, StreamBase*>& cbk)
	{
		m_register_proc_name_id[RegisterIndex(proc_name, proc_id)][msg_id] = cbk;

		for ( Dlist<ChildProc*>::Node* node = m_child_proc.GetHead();
				node != 0; node = m_child_proc.GetNext(node) )
		{
			ColibChildProc* proc = reinterpret_cast<ColibChildProc*>(node->GetData());

			if ( proc && ( proc->GetProcName() == proc_name ) && ( proc->GetProcID() == proc_id ) )
			{
				proc->RegisterMsgHandler(msg_id, cbk);
				return;
			}
		}	
	
		for ( Dlist<ChildProc*>::Node* node = m_add_request.GetHead();
				node != 0; node = m_add_request.GetNext(node) )
		{
			ColibChildProc* proc = reinterpret_cast<ColibChildProc*>(node->GetData());
		
			if ( proc && ( proc->GetProcName() == proc_name ) && ( proc->GetProcID() == proc_id ) )
			{
				proc->RegisterMsgHandler(msg_id, cbk);
				return;
			}
		}
	}

	string				ColibProcessMgr::ConsoleHelp()
	{
		return ProcessMgr::ConsoleHelp() + "|" + "istats|ipcs|msg_reg";
	}

	void				ColibProcessMgr::ConsoleCommand(ConsoleSession* con, int argc, char* argv[])
	{
		if ( ( argc > 0 ) && !strcmp(argv[0], "istats") )
		{	
			string ipc_path = "UNIX;" + GetIPCPath();
			m_colib_proc_stats[ColibProcessMgr::ColibProcStat_ipc_path].SetFromString(ipc_path.c_str());
			m_colib_proc_stats.ConsoleCommand(con, argc-1, argv+1);
			return;
		}
		
		if ( ( argc > 0 ) && !strcmp(argv[0], "ipcs") )
		{
			m_ipc_server.ConsoleCommand(con, argc-1, argv+1);
			return;
		}

		if ( ( argc > 0 ) && !strcmp(argv[0], "msg_reg") )
		{
			con->Print("Message type(s) registered for all: ");
			if ( m_register_all.empty() ) 
			{
				con->Print("N/A\n");
			}
			else
			{	
				for ( MsgCbkMap::iterator it = m_register_all.begin();
					it != m_register_all.end(); ++it )
				{
					con->Print("%d ", it->first);
				}
				con->Print("\n");
			}	
				
			for ( ProcMsgCbkMap::iterator it = m_register_proc_name.begin();
					it != m_register_proc_name.end(); ++it )
			{
				con->Print("Message type(s) registered for %s: ", it->first.c_str());	
				for ( MsgCbkMap::iterator iter = it->second.begin();
						iter != it->second.end(); ++iter )
				{
					con->Print("%d ", iter->first);
				}
				con->Print("\n");
			}
	
			for ( ProcMsgCbkMap::iterator it = m_register_proc_name_id.begin();
					it != m_register_proc_name_id.end(); ++it )
			{
				con->Print("Message type(s) registered for %s: ", it->first.c_str());	
				for ( MsgCbkMap::iterator iter = it->second.begin();
						iter != it->second.end(); ++iter )
				{	
					con->Print("%d ", iter->first);
				}
				con->Print("\n");			
			}

			return;
		}

		ProcessMgr::ConsoleCommand(con, argc, argv);
	}
	
		void 			ColibProcessMgr::RegisterAnyHandler4All(
								const Callback3<char*, int, StreamBase*>& cbk)
	{
		for ( Dlist<ChildProc*>::Node* node = m_child_proc.GetHead();
				node != 0; node = m_child_proc.GetNext(node) )
		{
			ColibChildProc* proc = reinterpret_cast<ColibChildProc*>(node->GetData());
			if ( proc )
			{
				proc->RegisterAnyHandler(cbk);
			}
		}

		for ( Dlist<ChildProc*>::Node* node = m_add_request.GetHead();
				node != 0; node = m_add_request.GetNext(node) )
		{
			if(ColibChildProc* proc = reinterpret_cast<ColibChildProc*>(node->GetData()))
			{
				proc->RegisterAnyHandler(cbk);
				return;
			}
		}
	}

	void 			ColibProcessMgr::RegisterAnyHandler4ProcName(
								const string& proc_name,
								const Callback3<char*, int, StreamBase*>& cbk)
	{
		for ( Dlist<ChildProc*>::Node* node = m_child_proc.GetHead();
				node != 0; node = m_child_proc.GetNext(node) )
		{
			ColibChildProc* proc = reinterpret_cast<ColibChildProc*>(node->GetData());
			if ( proc && ( proc->GetProcName() == proc_name ) )
			{
				proc->RegisterAnyHandler(cbk);
			}
		}

		for ( Dlist<ChildProc*>::Node* node = m_add_request.GetHead();
				node != 0; node = m_add_request.GetNext(node) )
		{
			ColibChildProc* proc = reinterpret_cast<ColibChildProc*>(node->GetData());
		
			if ( proc && ( proc->GetProcName() == proc_name ) )
			{
				proc->RegisterAnyHandler(cbk);
			}
		}
	}

	void			ColibProcessMgr::RegisterAnyHandler(
								const string& proc_name, int proc_id,
								const Callback3<char*, int, StreamBase*>& cbk)
	{
		for ( Dlist<ChildProc*>::Node* node = m_child_proc.GetHead();
				node != 0; node = m_child_proc.GetNext(node) )
		{
			ColibChildProc* proc = reinterpret_cast<ColibChildProc*>(node->GetData());
			if ( proc && ( proc->GetProcName() == proc_name ) && ( proc->GetProcID() == proc_id ) )
			{
				proc->RegisterAnyHandler(cbk);
				return;
			}
		}

		for ( Dlist<ChildProc*>::Node* node = m_add_request.GetHead();
				node != 0; node = m_add_request.GetNext(node) )
		{
			ColibChildProc* proc = reinterpret_cast<ColibChildProc*>(node->GetData());
		
			if ( proc && ( proc->GetProcName() == proc_name ) && ( proc->GetProcID() == proc_id ) )
			{
				proc->RegisterAnyHandler(cbk);
				return;
			}
		}
	}

}//end namespace colib

