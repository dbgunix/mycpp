// async_executor.cpp
// vi:set ts=4 sw=4 nowrap:

#include <proc_mgr/async_executor.h>
#include <event_loop/event_loop.h>

#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <errno.h>
#include <sys/prctl.h>
#include <string.h>

namespace colib
{
	PIDMonitor::PIDMonitor()
		: FileDescriptorHandler("PIDMonitor")
		, m_on_finish()
		, m_transaction_timer("PIDMonitorTransactionTimer")
		, m_zombie_cleaner(callbackRt(this, &PIDMonitor::CleanUp), "PIDMonitorZombieCleaner")
		, m_pid(0)
		, m_status(false)
		, m_exit_code(0)  
		, m_error()
		, m_data()
		, m_max_data_size(0)  
	{
		m_transaction_timer.SetExpireCb(callback(this, &PIDMonitor::OnTransactionTimeout));
	}

	bool PIDMonitor::IsReady() const
	{
		if ( m_fd > 0 ) return false;
		if ( m_pid ) return false;
		if ( m_transaction_timer.IsActive() ) return false;
		if ( m_zombie_cleaner.IsActive() ) return false;
		//
		return true;
	}
	
	bool PIDMonitor::Init(int fd, unsigned max_data_size)
	{
		if ( fcntl(fd, F_SETFL, O_NONBLOCK) == -1 ) return false;
		m_fd = fd;
		//
		m_max_data_size = max_data_size;
		m_data.clear();
		//
		return EventLoop::GetInstance().AddHandler(*this);
	}
		
	void PIDMonitor::RemoveFD()
	{
		if ( m_fd > 0 )
		{	
			EventLoop::GetInstance().RemoveHandler(*this);
			close(m_fd);
			m_fd = -1;
		}
	}

	void PIDMonitor::MonitorPID(int pid, unsigned timeout_sec)
	{
		m_pid = pid;	
		m_status = false;
		m_exit_code = 0;
		m_error.clear();
		m_transaction_timer.Start(timeout_sec * 1000);
	}

	void PIDMonitor::read()
	{
		char buf[256];
		int n = ::read(m_fd, buf, sizeof(buf));
		
		if ( n <= 0 ) // child process gone ...
		{
			RemoveFD();	
			m_transaction_timer.Stop();
			StartZombieCleaner();
			return;
		}
		// 
		// Save data
		//
		m_data.insert(m_data.end(), buf, buf + n);
	}
	
	void PIDMonitor::StartZombieCleaner()
	{
		EventLoop::GetInstance().AddActivity(&m_zombie_cleaner);
	}
	
	eCallbackRt PIDMonitor::CleanUp()
	{
		if ( !m_pid ) return DontRunAgain;

		int exit_status;
		pid_t pid = waitpid(m_pid, &exit_status, WNOHANG);

		if ( pid == 0 ) return RunAgain;
		
		if ( pid == -1 )
		{
			m_status = false;
			m_error = string::Format("waitpid fail: %s", strerror(errno));
			m_pid = 0;
			DispatchCB();
			return DontRunAgain;
		}
	
		m_status = false;

		if ( WIFEXITED(exit_status) ) 
		{
			m_status = true;
			m_exit_code = WEXITSTATUS(exit_status);
			m_error = string::Format("Clean Exit(%d)\n", m_exit_code);
		}
		else if ( WIFSIGNALED(exit_status) ) 
		{
			m_error = string::Format("Killed by Signal(%d)\n", WTERMSIG(exit_status));	
		}
		else if ( WIFSTOPPED(exit_status) ) 
		{
			m_error = string::Format("Stopped by Signal(%d)\n", WSTOPSIG(exit_status)); 
		}
		else
		{
			m_error = "Exit with unknown status";
		}
		//
		m_pid = 0;
		DispatchCB();
		return DontRunAgain;
	}

	void PIDMonitor::KillTransaction()
	{
		if ( m_pid ) 
		{
			kill(m_pid, SIGTERM);
			StartZombieCleaner();
		}
	}

	void PIDMonitor::OnTransactionTimeout(unsigned, void*)
	{
		RemoveFD();
		KillTransaction();
	}

	AsyncExecutor::AsyncExecutor(unsigned timeout_sec, unsigned retry_limit, unsigned max_data_size)
		: m_timeout_sec(timeout_sec)
		, m_retry_limit(retry_limit)
		, m_max_data_size(max_data_size)  
		, m_retry_timer("AsyncExecutorRetryTimer")  
		, m_pid_monitor()  
	{
		m_pid_monitor.SetFinishCallback(callback(this, &AsyncExecutor::OnFinish));
		m_retry_timer.SetExpireCb(callback(this, &AsyncExecutor::OnRetry));
	}

	void AsyncExecutor::SetParams(	
							unsigned timeout_sec,
							unsigned retry_limit,
							unsigned max_data_size)
	{
		m_timeout_sec = timeout_sec;
		m_retry_limit = retry_limit;
		if ( !m_retry_limit ) ++m_retry_limit;
		m_max_data_size = max_data_size;
	}

	void AsyncExecutor::ExecuteAndMonitor()
	{
		if ( !m_pid_monitor.IsReady() ) 
		{
			m_retry_timer.Start(100);	// Retry in 100msec
			return;
		}

		if ( m_retry_limit == 0 )
		{
			AbnormalExit("fail too many times, abort!");
			return;
		}

		m_retry_limit--;

		int fd[2];
		if ( ::pipe(fd) != 0 ) return;

		if ( !m_pid_monitor.Init(fd[0], m_max_data_size) )
		{
			close(fd[0]);
			close(fd[1]);
			return;
		}

		int pid = fork();
		if ( pid == -1 )
		{	
			close(fd[0]);
			close(fd[1]);
			return;
		}

		if ( pid > 0 )
		{
			close(fd[1]);
			m_pid_monitor.MonitorPID(pid, m_timeout_sec);
		}
		else
		{
			close(fd[0]);
			prctl(PR_SET_PDEATHSIG, SIGHUP);
			_exit(Execute(fd[1]));
		}
	}

	void AsyncExecutor::OnRetry(unsigned, void*)
	{
		ExecuteAndMonitor();
	}

	void AsyncExecutor::OnFinish(const PIDMonitor& result)
	{
		if ( result.GetStatus() ) NormalExit(result.GetExitCode());
		else if ( m_retry_limit > 0 ) ExecuteAndMonitor();
		else AbnormalExit(result.GetError());
	}

    int AsyncFunction::m_call_req = 0;
    AsyncFunction::AsyncFunction()
    {
    }

    void AsyncFunction::Run(const std::string& inparam, const RunFn& fn, const ReturnCb& ret)
    {
        m_inparam = inparam;
        m_fn      = fn;
        m_retcb   = ret;
        m_call_req++;
        ExecuteAndMonitor();
    }

    void AsyncFunction::AbnormalExit(string err)
    {
        std::string strerr = err.c_str();
        m_retcb.Dispatch(strerr, -1);
    }

    void AsyncFunction::NormalExit(int code)
    {
        std::string ret;
        const char *p = PIDMonitorData();
        int len =  PIDMonitorDataLength();
        if(p && len > 0) {
            ret.assign(p, len);
        }
        m_retcb.Dispatch(ret, code);
    }

    int AsyncFunction::Execute(int fd)
    {
        int rc = 0;
        std::string ret;
        m_fn.Dispatch(m_inparam, ret, rc);

        //TODO
        // write result data to fd
        const char* buf = ret.c_str();
        int len = ret.size();
        int wn = 0, pos = 0;
        while(wn < len) 
        {
            wn = ::write(fd, buf + pos, len - pos);
            pos += wn;
        }
        return rc;
    }
}//end namespace colib

