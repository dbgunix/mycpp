// vi:set ts=5 sw=4 nowrap:

#include <proc_mgr/child_proc.h>
#include <utils/kernel/SysTime.h>
#include <utils/trace/trace.h>
#include <console/command/debug.h>
#include <console/broadcast.h>
#include <utils/time_utils.h>
#include <event_loop/event_loop.h>

#include <syslog.h>
#include <sys/wait.h>
#include <sys/prctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <signal.h>
#include <string.h>
#include <fcntl.h>
#include <stdio.h>

namespace colib
{
	//
	// ProcConfig
	//
	ProcConfig::ProcConfig()
		:
		m_id(0)
	{
	}

	ProcConfig::ProcConfig(string name, int id)
		:
		m_name(name),
		m_id(id)
	{
	}

	ProcConfig::~ProcConfig()
	{	
	}
	//
	// ProcMonitor
	//
	ProcMonitor::ProcMonitor(ChildProc& parent)
		:
		FileDescriptorHandler("ProcMonitor"),	
		m_parent(parent)
	{
	}

	bool				ProcMonitor::Init(int fd)
	{
		if ( fcntl(fd, F_SETFL, O_NONBLOCK) == -1 ) return false;
		m_fd = fd;
		return EventLoop::GetInstance().AddHandler(*this);
	}

	void				ProcMonitor::RemoveFD()
	{
		if ( m_fd > 0 )
		{
			EventLoop::GetInstance().RemoveHandler(*this);
			close(m_fd);
			m_fd = -1;
		}
	}

	void				ProcMonitor::read()
	{
		char buf[256];
		int n = ::read(m_fd, buf, sizeof(buf));

		if ( n <= 0 ) // Child process gone ...
		{
			RemoveFD();
			m_parent.ShutDown("pipe to child closed, crashed?");
		}
		else
		{
			ConsoleBroadcast(buf, n);
		}
	}
	//
	// ChildProc
	//
	ChildProc::ChildProc(string proc_name, int proc_id)
		:
		m_proc_config(proc_name, proc_id), 
		m_pid(0),
		m_monitor(*this),
		m_quick_restart_limit(QuickRestartRetryCount),
		m_state(Instantiated), 
		m_heartbeated(false),
		m_heartbeat_clock(0)
	{
	}

	ChildProc::~ChildProc()
	{
	}
	
	void				ChildProc::CheckHeartbeat()
	{
		bool heartbeated = m_heartbeated;
		m_heartbeated = false;
		
		if ( heartbeated ) 
		{
			if ( m_state == Heartbeated ) m_quick_restart_limit = QuickRestartRetryCount;
			return;
		}

		//
		// No heartbeat received
		//	
		switch ( m_state )
		{
			case Heartbeated:
			case Killed:
			{	
				TRACE("Kill %s(%d) with pid=%d for losing heartbeat ...\n", GetProcName().c_str(), GetProcID(), m_pid);
				DispatchFailure("Killed for losing heartbeat");
				Terminate(SIGABRT);
				break;
			}
			case Forked:
			{
				TRACE("%s(%d) with pid=%d takes too long to start, killing ...\n", GetProcName().c_str(), GetProcID(), m_pid);
				DispatchFailure("Killed for taking too long to start");
				//Terminate(SIGTERM);
				Terminate(SIGKILL);
				break;
			}
			case Error:
			{	
				TRACE("%s(%d) retry from previous bad start ...\n", GetProcName().c_str(), GetProcID());
				ChangeState(Instantiated);
				m_state_str = "Exit error state and retry";
				m_quick_restart_limit = QuickRestartRetryCount;
				break;
			}
			default:
			{
				break;
			}
		}
	}

	void				ChildProc::ChangeState(int state)
	{
		if ( m_state != state )
		{
			m_state = state;
			if ( m_state == Heartbeated ) DispatchSucceed();
			m_state_change.Dispatch(m_state);
		}
	}

	void				ChildProc::Start(string extra_args, string dir_path, string ipc_path)
	{
		if ( m_state != Instantiated ) return;	// Already started

		if ( !m_quick_restart_limit )
		{
			ChangeState(Error);
			m_state_str = "Too many failures in short period of time, pause ... ";
			TRACE("Fail to start %s(%d): %s\n", GetProcName().c_str(), GetProcID(), m_state_str.c_str());
			DispatchFailure("Too many failures to start");
			return;
		}
		if ( m_quick_restart_limit > 0 ) m_quick_restart_limit--;

		string exec_str = dir_path + GetProcName();
		struct stat stat_buf;

		if ( stat(exec_str.c_str(), &stat_buf) == -1 )
		{
			ChangeState(Error);
			m_state_str = string::Format("Cannot access %s - %s", exec_str.c_str(), strerror(errno));
			TRACE("Fail to start %s(%d): %s\n", GetProcName().c_str(), GetProcID(), m_state_str.c_str());
			DispatchFailure("Cannot access " + exec_str);
			return;
		}

		if ( !(stat_buf.st_mode & S_IXUSR) )
		{
			ChangeState(Error);
			m_state_str = string::Format("No permission to run %s", exec_str.c_str());
			TRACE("Fail to start %s(%d): %s\n", GetProcName().c_str(), GetProcID(), m_state_str.c_str());
			DispatchFailure("No permission to run " + exec_str);
			return;
		}	
		//
		// Prepare monitor
		//
		m_monitor.RemoveFD();
		int fd[2];
		if ( ::pipe(fd) != 0 ) 
		{
			ChangeState(Error);	
			m_state_str = "Cannot get pipes";
			TRACE("Fail to start %s(%d): %s\n", GetProcName().c_str(), GetProcID(), m_state_str.c_str());
			DispatchFailure(m_state_str);
			return;
		}
		if ( !m_monitor.Init(fd[0]) )
		{	
			close(fd[0]);
			close(fd[1]);
			ChangeState(Error);	
			m_state_str = "Init monitor failed";
			TRACE("Fail to start %s(%d): %s\n", GetProcName().c_str(), GetProcID(), m_state_str.c_str());
			DispatchFailure(m_state_str);
			return;	
		}

		//
		// Fork
		//
		pid_t pid = fork();

		if ( pid == -1 )
		{
			close(fd[0]);
			close(fd[1]);
			ChangeState(Error);
			m_state_str = string::Format("Fork error - %s\n", strerror(errno));
			TRACE("Fail to start %s(%d): %s\n", GetProcName().c_str(), GetProcID(), m_state_str.c_str());
			DispatchFailure("Fork error");
			return;
		}			

		if ( pid > 0 )
		{
			//
			// This is parent process
			//
			close(fd[1]);
			m_pid = pid;
			ChangeState(Forked);
			m_state_str = string::Format("%d retry left for quick restart", m_quick_restart_limit);
			//
			// In order to avoid newly forked process to be killed by heartbeat timer
			//
			m_heartbeated = true;
			TRACE("Start %s(%d) with pid=%d (%d retry limit left)\n", 
					GetProcName().c_str(), GetProcID(), m_pid, m_quick_restart_limit);
			OnStartSucceed();
		}
		else
		{	
			close(fd[0]);
			EventLoop::GetInstance().Close();

			//dup2(fd[1], 1);
			//dup2(fd[1], 2);

			int ret = Run(exec_str, extra_args, ipc_path);
		
			if ( ret == -1 ) 
			{
				TRACE("exec %s(%d) error - %s\n", GetProcName().c_str(), GetProcID(), strerror(errno));
				_exit(-1);			
			}
		}
	}

	void				ChildProc::Terminate(int sig)
	{
		if ( m_pid ) 
		{
			//if ( ( sig == SIGTERM ) && ( m_state == Killed ) ) return;	// No double SIGTERM
			if ( ( sig == SIGKILL ) && ( m_state == Killed ) ) return;	// No double SIGTERM
			kill(m_pid, sig);
			ShutDown(string::Format("Kill with signal %d", sig));
		}
	}

	void				ChildProc::CleanUp()
	{
		if( m_pid == 0 )
		{
			ChangeState( Error );
			return;
		}

		int exit_status;
		pid_t pid = waitpid(m_pid, &exit_status, WNOHANG);
		
		if ( pid == 0 ) return;	// Haven't exit yet

		if ( pid == -1 )
		{
			ChangeState(Error);
			m_state_str = string::Format( "Waitpid error - %s", strerror( errno ) );
			TRACE("Stop %s(%d) with pid=%d fail: %s\n", GetProcName().c_str(), GetProcID(), m_pid, m_state_str.c_str());
			return;
		}
	
		if ( WIFEXITED(exit_status) )
		{
			m_state_str = string::Format("Clean Exit(%d)", WEXITSTATUS(exit_status));
		}
		else if ( WIFSIGNALED(exit_status) )
		{
			m_state_str = string::Format("Killed by Signal(%d)", WTERMSIG(exit_status));
			if ( WCOREDUMP(exit_status) )
			{
				m_state_str += " CORE DUMPED";
			}
			DispatchKill(m_state_str);
		}
		else if ( WIFSTOPPED(exit_status) )
		{
			m_state_str = string::Format("Stopped by Signal(%d)", WSTOPSIG(exit_status));
		}
		else
		{
			m_state_str = "Unknown exit crashed??";
		}
	
		TRACE("Stop %s(%d) with pid=%d: %s\n", GetProcName().c_str(), GetProcID(), m_pid, m_state_str.c_str());	

		// Ready to be restart	
		ChangeState(Instantiated);
		m_pid = 0;
	}
	
	void				ChildProc::ShutDown(string reason)
	{
		TRACE("Shut down %s(%d): %s\n", GetProcName().c_str(), GetProcID(), reason.c_str());
		m_state_str = reason;
		ChangeState(Killed);
		OnShutDownSucceed();
	}

	string				ChildProc::DumpStatus()
	{
		string status = string::Format("%s(%d):\n", GetProcName().c_str(), GetProcID());
		status.AppendFmt("Dir path: %s\n", GetDirPath().c_str());
		status.AppendFmt("Extra args: %s\n", GetExtraArgs().c_str()); 
		status.AppendFmt("Type: %s\n", GetType().c_str());
		status.AppendFmt("PID: %d\n", m_pid);
		status.AppendFmt("State: %s (%s)\n",
				( m_state == Instantiated ) ? "Instantiated" :
				( m_state == Forked ) ? "Forked" :
				( m_state == Heartbeated ) ? "Heartbeated" :
				( m_state == Killed ) ? "Killed" :
				( m_state == Error ) ? "Error" : "Unknown",
				m_state_str.c_str());
		if ( m_state == Heartbeated )
		{
			unsigned tick = colib::SysTime::Get() - m_heartbeat_clock;
			status.AppendFmt("Heartbeated %s ago\n", FormatReadableClockMS(tick).c_str());
			status += m_heartbeat_status;
		}
		return status;
	}

}//end namespace colib
