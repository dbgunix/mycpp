// colib_child_proc.h
// vi:set ts=4 sw=4 nowrap:

#ifndef COLIB_CHILD_PROC_H_ALREADY_INCLUDED
#define COLIB_CHILD_PROC_H_ALREADY_INCLUDED

#include<proc_mgr/child_proc.h>
#include<proc_mgr/child_hb_client.h>

#include <map>

namespace colib
{
	class ColibProcessMgr;

	//
	// ColibChildProc
	//
	class ColibChildProc : public ChildProc
	{
		public:

								ColibChildProc(string proc_name, int proc_id);
			virtual				~ColibChildProc();

			static string		Type() { return "colib"; }
			virtual string		GetType() const { return Type(); }

			void				RegisterMsgHandler(int msg_id, const Callback3<char*, int, StreamBase*>& cbk);
			bool				SendMsg(Message& item) { return m_heartbeat_socket ? m_heartbeat_socket->WriteMessage(item) : false; }

			void				RegisterAnyHandler(const Callback3<char*, int, StreamBase*>& cbk);
			bool				SendData(char* data, int len) { return m_heartbeat_socket ? len == m_heartbeat_socket->WriteBytes(data, len) : false; }

		protected:

			bool				Heartbeat(ChildHeartbeatMessage*, StreamBase*);

			virtual int			Run(string exec_str, string extra_args, string ipc_args);
			virtual void		ShutDown(string reason);

			virtual void		OnStartSucceed();
			virtual void		OnShutDownSucceed();

			virtual string		DumpStatus();

		private:
			typedef std::map<int, Callback3<char*, int, StreamBase*>>	REGISTER_MAP;

			StreamBase*			m_heartbeat_socket;
			REGISTER_MAP		m_register_map;

            Callback3<char*, int, StreamBase*> m_any_msgcbk;
		friend class ColibProcessMgr;
	};

}//end namespace colib

#endif
