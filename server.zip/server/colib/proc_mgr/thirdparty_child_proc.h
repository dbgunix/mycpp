// colib_child_proc.h
// vi:set ts=4 sw=4 nowrap:

#ifndef THIRDPARTY_CHILD_PROC_H_ALREADY_INCLUDED
#define THIRDPARTY_CHILD_PROC_H_ALREADY_INCLUDED

#include<proc_mgr/child_proc.h>

namespace colib
{
	class ThirdpartyProcessMgr;

	class ThirdpartyChildProc : public ChildProc
	{
		public:

			enum KernelState
			{
				UNKNOWN = 0,
				UNINTERRUPTABLE_SLEEP,	//D
				LOW_PRIORITY,			//N
				RUNNING,				//R
				SLEEPING,				//S
				TRACED_STOPPED,			//T
				ZOMBIE					//Z
			};

								ThirdpartyChildProc(string proc_name, int proc_id);
			virtual				~ThirdpartyChildProc();

			static string		Type() { return "3rdParty"; }
			virtual string		GetType() const { return Type(); }

		protected:

			virtual int			Run(string exec_str, string extra_args, string ipc_args);
			void				CheckProcessStatus();

			virtual void		OnStartSucceed() {};
			virtual void		OnShutDownSucceed() {};

		private:

			KernelState			ReadProcessStatus(int);
			static const char*	PID_STATUS;

		friend class ThirdpartyProcessMgr;
	};

}//end namespace colib

#endif
