// vi:set ts=4 sw=4 nowrap:

#include<proc_mgr/proc_mgr.h>
#include<utils/trace/trace.h>
#include<console/command/debug.h>
#include<event_loop/event_loop.h>

#include <signal.h>
#include <ctype.h>

namespace colib
{
	static ValueList::ValueHolder	InitStats()
	{
		return 
		{
			Value("num_proc_alive", 0 ),
			Value("num_proc_request_add", 0 ),	
			Value("num_proc_added", 0 ),
			Value("num_proc_add_fail", 0 ),
			Value("num_proc_request_remove", 0 ),
			Value("num_proc_removed", 0 ),
			Value("num_proc_remove_fail", 0 ),
			Value("num_heartbeat_timeout", 0 ),
			Value("num_start_proc_mgr", 0 ),
			Value("num_execute_start_stop", 0 ),
			Value("num_start_request_mgr", 0 ),
			Value("num_execute_add_remove", 0 ),
			Value("proc_heartbeat_freq_sec", 0 ),
			Value("heartbeat_timeout_sec", 0 )
		};
	};

	ProcessMgr::ProcessMgr()
		:
		m_proc_mgr(callbackRt(this, &ProcessMgr::StartOrStopChildProc), "ProcMgr"),
		m_request_mgr(callbackRt(this, &ProcessMgr::ProcessRequest), "RequestMgr"),
		m_heartbeat_timer("HeartbeatTimer"),
		m_proc_heartbeat_freq_sec(DEFAULT_CHILD_HEARTBEAT_INTERVAL_SEC), 
		m_heartbeat_timeout_sec(3 * DEFAULT_CHILD_HEARTBEAT_INTERVAL_SEC),
		m_proc_stats(InitStats())
	{
		m_heartbeat_timer.SetExpireCb(callback(this, &ProcessMgr::OnHeartbeatTimeout));
	}

	ProcessMgr::~ProcessMgr()
	{	
		for ( Dlist<ChildProc*>::Node* node = m_child_proc.GetHead();
				node != 0; node = m_child_proc.GetNext(node) )
		{	
			//node->GetData()->Terminate(SIGTERM);
			node->GetData()->Terminate(SIGKILL);
			delete node->GetData();
		}
		m_child_proc.Clear();
	
		for ( Dlist<ChildProc*>::Node* node = m_child_proc_to_delete.GetHead();
				node != 0; node = m_child_proc_to_delete.GetNext(node) )
		{
			delete node->GetData();
		}
		m_child_proc_to_delete.Clear();

		m_pid_to_child_proc_map.clear();

		CleanRequest();
	}
	
	void				ProcessMgr::CleanRequest()
	{	
		for ( Dlist<ChildProc*>::Node* node = m_add_request.GetHead();
				node != 0; node = m_add_request.GetNext(node) )
		{
			PROC_STAT(num_proc_add_fail)++;
			delete node->GetData();
		}	
		m_add_request.Clear();
		m_remove_request.Clear();
	}

	bool				ProcessMgr::Init(string& err)
	{
		(void)err;
		StartHeartbeatTimer();
		return true;
	}
		
	bool				ProcessMgr::Reload(const Options* opt, string&)
	{
		if ( !opt ) return false;

		OptionsNode grp = opt->GetOptionsNode("CHILD_PROC_MGR");

		if ( !grp.IsEmpty() ) 
		{
			int proc_heartbeat_freq_sec = 0;
			grp.GetValue("heartbeat_freq_sec", proc_heartbeat_freq_sec, DEFAULT_CHILD_HEARTBEAT_INTERVAL_SEC);
			if ( proc_heartbeat_freq_sec != m_proc_heartbeat_freq_sec )
			{
				m_proc_heartbeat_freq_sec = proc_heartbeat_freq_sec;
			}

			int heartbeat_timeout_sec = 0;
			grp.GetValue("heartbeat_timeout_sec", heartbeat_timeout_sec, 3 * m_proc_heartbeat_freq_sec);
			if ( heartbeat_timeout_sec != m_heartbeat_timeout_sec )
			{
				m_heartbeat_timeout_sec = heartbeat_timeout_sec;
				StartHeartbeatTimer();
			}
		}

		return true;
	}

	void				ProcessMgr::StartHeartbeatTimer()
	{
		m_heartbeat_timer.Start(m_heartbeat_timeout_sec * 1000);
	}

	ChildProc*			ProcessMgr::AddChildProc(const string& proc_name, int proc_id, string dir_path, string extra_args)
	{
		if ( dir_path == "" ) dir_path = "/usr/bin/";

		for ( Dlist<ChildProc*>::Node* node = m_child_proc.GetHead();
				node != 0; node = m_child_proc.GetNext(node) )
		{
			ChildProc* proc = node->GetData();
			if ( proc && ( proc->GetProcName() == proc_name ) && ( proc->GetProcID() == proc_id ) )
			{
				TRACE(1, "AddChildProc %s(%d) failed: already exist (pid=%d)!\n", 
				proc_name.c_str(), proc_id, proc->m_pid);
				return 0;
			}
		}

		for ( Dlist<ChildProc*>::Node* node = m_add_request.GetHead();
				node != 0; node = m_add_request.GetNext(node) )
		{
			ChildProc* proc = node->GetData();
			if ( proc && ( proc->GetProcName() == proc_name ) && ( proc->GetProcID() == proc_id ) )
			{
				TRACE(1, "AddChildProc %s(%d) failed: already requested!\n", 
				proc_name.c_str(), proc_id);
				return 0;
			}
		}

		ChildProc* proc = CreateChildProc(proc_name, proc_id);
		if ( proc )
		{
			proc->SetDirPath(dir_path);
			proc->SetExtraArgs(extra_args);
			proc->m_succeed_cbk = m_proc_succeed_cbk;
			proc->m_failure_cbk = m_proc_failure_cbk;
			proc->m_kill_cbk = m_proc_kill_cbk;
			proc->SetStateChangeCbk(callback<ProcessMgr, int>(this, &ProcessMgr::OnChildProcStateChange));
			m_add_request.Append(proc);
			PROC_STAT(num_proc_request_add)++;
			member_TRACE(&m_proc_debug_set, 7, "%s(%d) request to add ...\n", proc->GetProcName().c_str(), proc->GetProcID());
			TRACE(0, "%s(%d) request to add ...\n", proc->GetProcName().c_str(), proc->GetProcID());
			StartRequestMgr();
		}
		
		return proc;
	}

	bool				ProcessMgr::DelChildProc(const string& proc_name, int proc_id)
	{
		Dlist<ProcConfig>::Node* node = m_remove_request.Append();
		if ( !node ) return false;
		node->GetData().SetName(proc_name);
		node->GetData().SetID(proc_id);
		PROC_STAT(num_proc_request_remove)++;
		StartRequestMgr();
		return true;
	}

	ChildProc*				ProcessMgr::FindChildProc(const string& proc_name, int proc_id)
	{
		for ( Dlist<ChildProc*>::Node* node = m_child_proc.GetHead();
				node != 0; node = m_child_proc.GetNext(node) )
		{
			ChildProc* proc = node->GetData();
			if ( proc && ( proc->GetProcName() == proc_name ) && ( proc->GetProcID() == proc_id ) )
			{
				return proc;
			}
		}
        return NULL;
	}

	void				ProcessMgr::StartRequestMgr()
	{
		PROC_STAT(num_start_request_mgr)++;
		EventLoop::GetInstance().AddActivity(&m_request_mgr);
	}

	eCallbackRt			ProcessMgr::ProcessRequest()
	{	
		PROC_STAT(num_execute_add_remove)++;

		Dlist<ChildProc*>::Node* next = 0;
		for ( Dlist<ChildProc*>::Node* node = m_add_request.GetHead();
				node != 0; node = next )
		{
			next = m_add_request.GetNext(node);
			node->MoveTo(&m_child_proc);
			PROC_STAT(num_proc_added)++;
			ChildProc* proc = node->GetData();
			member_TRACE(&m_proc_debug_set, 7, "%s(%d) added ...\n", proc->GetProcName().c_str(), proc->GetProcID());
		}
	
		for ( Dlist<ProcConfig>::Node* iter = m_remove_request.GetHead();
				iter != 0; iter = m_remove_request.GetNext(iter) )
		{
			ProcConfig& request = iter->GetData();
			string proc_name = request.GetName();
			int proc_id = request.GetID();		
			bool found = false;
			for ( Dlist<ChildProc*>::Node* node = m_child_proc.GetHead();
					node != 0; node = m_child_proc.GetNext(node) )
			{
				ChildProc* proc = node->GetData();
				if ( proc && ( proc->GetProcName() == proc_name ) && ( proc->GetProcID() == proc_id ) )
				{
					found = true;
					node->MoveTo(&m_child_proc_to_delete);
					//proc->Terminate(SIGTERM);
					proc->Terminate(SIGKILL);
					member_TRACE(&m_proc_debug_set, 7, "%s(%d) to be removed ...\n", 
							proc->GetProcName().c_str(), proc->GetProcID());
					if ( proc->m_pid ) m_pid_to_child_proc_map.erase(proc->m_pid);
					break;
				}
			}
			if ( !found ) PROC_STAT(num_proc_remove_fail)++;
		}
		
		CleanRequest();
		StartProcMgr();

		return DontRunAgain;
	}

	void				ProcessMgr::OnHeartbeatTimeout(unsigned, void*)
	{
		PROC_STAT(num_heartbeat_timeout)++;

		for ( Dlist<ChildProc*>::Node* node = m_child_proc.GetHead();
				node != 0; node = m_child_proc.GetNext(node) )
		{
			node->GetData()->CheckHeartbeat();
		}

		for ( Dlist<ChildProc*>::Node* node = m_child_proc_to_delete.GetHead();
				node != 0; node = m_child_proc_to_delete.GetNext(node) )
		{
			node->GetData()->CheckHeartbeat();
		}
	}

	void				ProcessMgr::OnChildProcStateChange(int state)
	{
		if ( ( state == ChildProc::Killed ) || ( state == ChildProc::Instantiated ) )
		{
			member_TRACE(&m_proc_debug_set, 7, "Start ProcMgr when child state changes...\n");
			StartProcMgr();
		}
	}

	void				ProcessMgr::StartProcMgr()
	{
		PROC_STAT(num_start_proc_mgr)++;
		EventLoop::GetInstance().AddActivity(&m_proc_mgr);
	}

	eCallbackRt			ProcessMgr::StartOrStopChildProc()
	{	
		eCallbackRt ret = DontRunAgain;
		PROC_STAT(num_execute_start_stop)++;

		Dlist<ChildProc*>::Node* next = 0;
		for ( Dlist<ChildProc*>::Node* node = m_child_proc_to_delete.GetHead();
				node != 0; node = next )
		{
			next = m_child_proc_to_delete.GetNext(node);
			ChildProc* proc = node->GetData();
			if ( proc->m_state == ChildProc::Killed )
			{
				proc->CleanUp();
				ret = RunAgain;
			}
			else // exited, time to delete
			{
				member_TRACE(&m_proc_debug_set, 7, "Remove %s(%d) ...\n", 
						proc->GetProcName().c_str(), proc->GetProcID());
				delete proc;
				PROC_STAT(num_proc_removed)++;
				m_child_proc_to_delete.Remove(node);
			}		
		}
	
		for ( Dlist<ChildProc*>::Node* node = m_child_proc.GetHead();
				node != 0; node = m_child_proc.GetNext(node) )
		{
			ChildProc* proc = node->GetData();
			if ( proc->m_state == ChildProc::Killed ) 
			{
				proc->CleanUp();
				ret = RunAgain;
			}
			else if ( proc->m_state == ChildProc::Instantiated ) 
			{
				member_TRACE(&m_proc_debug_set, 7, "Start %s(%d)\n", 
						proc->GetProcName().c_str(), proc->GetProcID());
				StartChildProc(proc, proc->GetExtraArgs(), proc->GetDirPath());
				ret = RunAgain;
			}
		}
		
		return ret;
	}
	
	void				ProcessMgr::ProcList(ConsoleSession* con)
	{
		if ( !con ) return;
	
		con->Print("Total %d active\n", m_child_proc.Size());
		for ( Dlist<ChildProc*>::Node* node = m_child_proc.GetHead();
				node != 0; node = m_child_proc.GetNext(node) )
		{
			ChildProc* proc = node->GetData();
			con->Print("%s\n", proc->DumpStatus().c_str());
		}

		if ( !m_child_proc_to_delete.IsEmpty() )
		{
			con->Print("%d to be removed: ", m_child_proc_to_delete.Size());
			for ( Dlist<ChildProc*>::Node* node = m_child_proc_to_delete.GetHead();
					node != 0; node = m_child_proc_to_delete.GetNext(node) )
			{
				ChildProc* proc = node->GetData();
				con->Print("%s(%d) ", proc->GetProcName().c_str(), proc->GetProcID());
			}
			con->Print("\n");
		}
	}

	void				ProcessMgr::RegisterProcessSucceedCallback(const Callback2<string, int>& cbk)
	{
		m_proc_succeed_cbk = cbk;	
	
		for ( Dlist<ChildProc*>::Node* node = m_child_proc.GetHead();
				node != 0; node = m_child_proc.GetNext(node) )
		{
			ChildProc* proc = node->GetData();
			proc->m_succeed_cbk = m_proc_succeed_cbk;
		}	
	
		for ( Dlist<ChildProc*>::Node* node = m_add_request.GetHead();
				node != 0; node = m_add_request.GetNext(node) )
		{
			ChildProc* proc = node->GetData();
			proc->m_succeed_cbk = m_proc_succeed_cbk;
		}
	}

	void				ProcessMgr::RegisterProcessKillCallback(const Callback3<string, int, const string& >& cbk)
	{
		m_proc_kill_cbk = cbk;	
	
		for ( Dlist<ChildProc*>::Node* node = m_child_proc.GetHead();
				node != 0; node = m_child_proc.GetNext(node) )
		{
			ChildProc* proc = node->GetData();
			proc->m_kill_cbk = m_proc_kill_cbk;
		}	
	
		for ( Dlist<ChildProc*>::Node* node = m_add_request.GetHead();
				node != 0; node = m_add_request.GetNext(node) )
		{
			ChildProc* proc = node->GetData();
			proc->m_kill_cbk = m_proc_kill_cbk;
		}
	}

	void				ProcessMgr::RegisterProcessFailureCallback(const Callback3<string, int, string>& cbk) 
	{ 
		m_proc_failure_cbk = cbk; 	
	
		for ( Dlist<ChildProc*>::Node* node = m_child_proc.GetHead();
				node != 0; node = m_child_proc.GetNext(node) )
		{
			ChildProc* proc = node->GetData();
			proc->m_failure_cbk = m_proc_failure_cbk;
		}	
	
		for ( Dlist<ChildProc*>::Node* node = m_add_request.GetHead();
				node != 0; node = m_add_request.GetNext(node) )
		{
			ChildProc* proc = node->GetData();
			proc->m_failure_cbk = m_proc_failure_cbk;
		}
	}

	string				ProcessMgr::ConsoleHelp()
	{
		return "list|add|stats|debug|proc_name proc_id [subcmd]";
	}

	void				ProcessMgr::ConsoleCommand(ConsoleSession* con, int argc, char* argv[])
	{
		const char* add_usage = "Usage:\tadd proc_name proc_id [dir_path] [extra_args]";
		const char* proc_usage = "Usage:\tstatus|restart|TERMINATE|manual";
		string usage_str = string::Format("Usage:\t%s", ConsoleHelp().c_str());
		const char* usage = usage_str.c_str();

		if ( !argc )
		{
			con->Print(usage);
			return;
		}

		if ( !strcmp(argv[0], "list") )
		{
			ProcList(con);
		}
		else if ( !strcmp(argv[0], "add") )
		{
			if ( ( argc > 2 ) && isdigit((int)(*argv[2])) )
			{
				string proc_name = argv[1];
				int proc_id = atoi(argv[2]);
				string dir_path = "";
				if ( argc > 3 ) dir_path = argv[3];
				string args = "";
				if ( argc > 4 ) args = argv[4];
				if ( AddChildProc(proc_name, proc_id, dir_path, args) )
					con->Print("Add Child process %s(%d) from console succeed\n", 
							proc_name.c_str(), proc_id);
				else con->Print("Add Child process %s(%d) from console failed\n", 
						proc_name.c_str(), proc_id);
			}
			else con->Print(add_usage);
		}
		else if ( !strcmp(argv[0], "stats") )
		{
			PROC_STAT(proc_heartbeat_freq_sec) = m_proc_heartbeat_freq_sec;
			PROC_STAT(heartbeat_timeout_sec) = m_heartbeat_timeout_sec;
			PROC_STAT(num_proc_alive) = m_child_proc.Size();
			m_proc_stats.ConsoleCommand(con, argc-1, argv+1);
		}
		else if ( !strcmp(argv[0], "debug") )
		{
			HandleDebugCommand(con, argc-1, argv+1, m_proc_debug_set, "ProcessMgr");
		}
		else if ( argc >= 2 )
		{
			if ( isdigit((int)(*argv[1])) )
			{
				string proc_name = argv[0];
				int proc_id = atoi(argv[1]);

				ChildProc* proc = 0;

				for ( Dlist<ChildProc*>::Node* node = m_child_proc.GetHead();
						node != 0; node = m_child_proc.GetNext(node) )
				{
					ChildProc* cur = node->GetData();
					if ( cur && ( cur->GetProcName() == proc_name ) && ( cur->GetProcID() == proc_id ) )
					{
						proc = cur;
						break;
					}
				}

				if ( !proc )
				{
					con->Print("Invalid Child process %s(%d)\n", proc_name.c_str(), proc_id);
 					return;
				}

				if ( argc == 2 )
				{
					con->Print(proc_usage);
					return;
				}

				if ( !strcmp(argv[2], "status") )
				{
					con->Print("%s\n", proc->DumpStatus().c_str());
				}
				else if ( !strcmp(argv[2], "restart") )
				{
					con->Print("Restart %s(%d) from console by sending TERMINATE signal\n", 
							proc->GetProcName().c_str(), proc->GetProcID());
					//proc->Terminate(SIGTERM);
					proc->Terminate(SIGKILL);
				}
				else if ( !strcmp(argv[2], "manual") )
				{
					con->Print("Manually start %s(%d) from console\n", proc->GetProcName().c_str(), proc->GetProcID());
					StartChildProc(proc, proc->GetExtraArgs(), proc->GetDirPath());
				}
				else if ( !strcmp(argv[2], "TERMINATE") )
				{
					con->Print("Terminate %s(%d) from console\n", 
							proc->GetProcName().c_str(), proc->GetProcID());
					DelChildProc(proc->GetProcName(), proc->GetProcID());
				}
				else con->Print(proc_usage);
			}
			else con->Print(proc_usage);
		}
		else con->Print(usage);
	}

}//end namespace colib

