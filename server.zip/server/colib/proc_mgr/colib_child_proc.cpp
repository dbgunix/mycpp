// vi:set ts=5 sw=4 nowrap:

#include<proc_mgr/colib_child_proc.h>
#include<utils/trace/trace.h>
#include<socket/stream/console/uni_console.h>
#include<utils/kernel/SysTime.h>
 
#include <unistd.h>

namespace colib
{
	ColibChildProc::ColibChildProc(string proc_name, int proc_id)
		:
		ChildProc(proc_name, proc_id),
		m_heartbeat_socket(0)
	{
	}

	ColibChildProc::~ColibChildProc()
	{
	}
	
	bool 				ColibChildProc::Heartbeat(ChildHeartbeatMessage* heartbeat, StreamBase* socket)
	{
		if ( !heartbeat ) return false;
		ChangeState(Heartbeated);
		m_state_str = "Rx heartbeat message";
		m_heartbeated = true;
		m_heartbeat_clock = colib::SysTime::Get();
		m_heartbeat_status = heartbeat->DumpHeartbeat();
		/*
		m_heartbeat_status += "Supported commands:\n";
		for ( Dlist<string>::Node* node = heartbeat->m_commands_support.GetHead();
				node != 0; node =  heartbeat->m_commands_support.GetNext(node) )
		{
			m_heartbeat_status += node->GetData();
			m_heartbeat_status += " ";
		}
		*/
		UniConsoleServer::GetInstance().UpdateProcCommandsSupport(GetProcName(), GetProcID(), heartbeat->m_commands_support);

		if ( m_heartbeat_socket != socket )
		{
			m_heartbeat_socket = socket;

			if ( m_heartbeat_socket )
			{
				for ( auto it = m_register_map.begin();
						it != m_register_map.end(); ++it )
				{
					m_heartbeat_socket->RegisterMsgHandler(it->first, it->second);
				}
                m_heartbeat_socket->RegisterAnyHandler(m_any_msgcbk);
			}
		}

		return true;
	}

	void				ColibChildProc::ShutDown(string reason)
	{
		ChildProc::ShutDown(reason);
		m_heartbeat_socket = 0;
	}

	int					ColibChildProc::Run(string exec_str, string extra_args, string ipc_arg)
	{	
	    string id_arg = string::Format("%d", GetProcID());

	    int i = 0; char *argv[65];

	    argv[i++] = (char*)exec_str.c_str(); 
	    //argv[i++] = (char*)GetProcName().c_str(); 
	    argv[i++] = (char*)"-pid"; 
	    argv[i++] = (char*)id_arg.c_str(); 
	    argv[i++] = (char*)"-pn"; 
	    argv[i++] = (char*)GetProcName().c_str(); 
	    argv[i++] = (char*)"-ipc"; 
	    argv[i++] = (char*)ipc_arg.c_str(); 

	    char *p = strtok((char*)extra_args.c_str(), " ");
	    while(p && i<64) {
		   argv[i++] = p;
		   p = strtok(NULL, " ");
	    }
	    argv[i] = NULL;
	    return execvp((char*)exec_str.c_str(), argv);

	    /*
	    return execl(
			  exec_str.c_str(), 
			  GetProcName().c_str(), 
			  "-pid", id_arg.c_str(),
			  "-pn", GetProcName().c_str(),
			  "-ipc", ipc_arg.c_str(),
			  extra_args.c_str(), 
			  (char*)0);
			  */
	}

	void				ColibChildProc::OnStartSucceed()
	{
		UniConsoleServer::GetInstance().AddProcess(GetProcName(), GetProcID());
	}

	void				ColibChildProc::OnShutDownSucceed()
	{
		UniConsoleServer::GetInstance().DelProcess(GetProcName(), GetProcID());
	}

	void				ColibChildProc::RegisterAnyHandler(const Callback3<char*, int, StreamBase*>& cbk)
	{
        m_any_msgcbk = cbk;
		if ( m_heartbeat_socket ) m_heartbeat_socket->RegisterAnyHandler(cbk);
	}

	void				ColibChildProc::RegisterMsgHandler(int msg_id, const Callback3<char*, int, StreamBase*>& cbk)
	{
		m_register_map[msg_id] = cbk;
		if ( m_heartbeat_socket ) m_heartbeat_socket->RegisterMsgHandler(msg_id, cbk);
	}
	
	string				ColibChildProc::DumpStatus()
	{
		string status = ChildProc::DumpStatus();
		status.AppendFmt("Heartbeat socket id: %d\n", m_heartbeat_socket ? m_heartbeat_socket->GetId() : 0);
		status += "Message type(s) registered are: ";
		for ( REGISTER_MAP::iterator it = m_register_map.begin();
				it != m_register_map.end(); ++it )
		{
			status.AppendFmt("%d ", it->first);
		}
		status += "\n";

		return status;
	}

}//end namespace colib
